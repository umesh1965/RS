﻿
namespace SriAlpacaDL
{
	partial class FrmTSDataFeedSettings
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.label1 = new System.Windows.Forms.Label();
			this.cmbUnit = new System.Windows.Forms.ComboBox();
			this.cmbSessionTemplate = new System.Windows.Forms.ComboBox();
			this.label2 = new System.Windows.Forms.Label();
			this.cmbDateType = new System.Windows.Forms.ComboBox();
			this.label3 = new System.Windows.Forms.Label();
			this.chkAutoLastDate = new System.Windows.Forms.CheckBox();
			this.label4 = new System.Windows.Forms.Label();
			this.txtInterval = new System.Windows.Forms.TextBox();
			this.label5 = new System.Windows.Forms.Label();
			this.dtStartDate = new System.Windows.Forms.DateTimePicker();
			this.dtEndDate = new System.Windows.Forms.DateTimePicker();
			this.label6 = new System.Windows.Forms.Label();
			this.txtBarsback = new System.Windows.Forms.TextBox();
			this.label7 = new System.Windows.Forms.Label();
			this.txtDaysBack = new System.Windows.Forms.TextBox();
			this.label8 = new System.Windows.Forms.Label();
			this.chkUseSymbolSplit = new System.Windows.Forms.CheckBox();
			this.btnBrowseSymbolListFolder = new System.Windows.Forms.Button();
			this.txtSymbolListFolder = new System.Windows.Forms.TextBox();
			this.label9 = new System.Windows.Forms.Label();
			this.groupVolCal = new System.Windows.Forms.GroupBox();
			this.chkSum3Only = new System.Windows.Forms.CheckBox();
			this.radOutputPTVinVol = new System.Windows.Forms.RadioButton();
			this.radUpDownTickAsVol = new System.Windows.Forms.RadioButton();
			this.radUpDownVolAsVol = new System.Windows.Forms.RadioButton();
			this.radOutputTicks = new System.Windows.Forms.RadioButton();
			this.radUpDownTicks = new System.Windows.Forms.RadioButton();
			this.radUpDownVol = new System.Windows.Forms.RadioButton();
			this.groupDataCleanup = new System.Windows.Forms.GroupBox();
			this.radVolumeMismatch = new System.Windows.Forms.RadioButton();
			this.radPriceMismatch = new System.Windows.Forms.RadioButton();
			this.radMismatchWithZero = new System.Windows.Forms.RadioButton();
			this.radMismatch = new System.Windows.Forms.RadioButton();
			this.chkDataCleanup = new System.Windows.Forms.CheckBox();
			this.btnOK = new System.Windows.Forms.Button();
			this.btnCancel = new System.Windows.Forms.Button();
			this.label10 = new System.Windows.Forms.Label();
			this.radSim = new System.Windows.Forms.RadioButton();
			this.radLive = new System.Windows.Forms.RadioButton();
			this.chkUseMultipleToken = new System.Windows.Forms.CheckBox();
			this.chkVolCal = new System.Windows.Forms.CheckBox();
			this.label11 = new System.Windows.Forms.Label();
			this.label12 = new System.Windows.Forms.Label();
			this.txtTickInterval = new System.Windows.Forms.TextBox();
			this.chkMinRowsCleanup = new System.Windows.Forms.CheckBox();
			this.txtMinRowsCleanup = new System.Windows.Forms.TextBox();
			this.groupVolCal.SuspendLayout();
			this.groupDataCleanup.SuspendLayout();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(31, 159);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(26, 13);
			this.label1.TabIndex = 0;
			this.label1.Text = "Unit";
			// 
			// cmbUnit
			// 
			this.cmbUnit.FormattingEnabled = true;
			this.cmbUnit.Items.AddRange(new object[] {
            "Minute",
            "Daily",
            "Weekly",
            "Monthly"});
			this.cmbUnit.Location = new System.Drawing.Point(141, 156);
			this.cmbUnit.Name = "cmbUnit";
			this.cmbUnit.Size = new System.Drawing.Size(121, 21);
			this.cmbUnit.TabIndex = 1;
			this.cmbUnit.SelectedIndexChanged += new System.EventHandler(this.cmbUnit_SelectedIndexChanged);
			// 
			// cmbSessionTemplate
			// 
			this.cmbSessionTemplate.FormattingEnabled = true;
			this.cmbSessionTemplate.Items.AddRange(new object[] {
            "USEQPre",
            "USEQPost",
            "USEQPreAndPost",
            "Default"});
			this.cmbSessionTemplate.Location = new System.Drawing.Point(141, 226);
			this.cmbSessionTemplate.Name = "cmbSessionTemplate";
			this.cmbSessionTemplate.Size = new System.Drawing.Size(121, 21);
			this.cmbSessionTemplate.TabIndex = 3;
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(31, 229);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(91, 13);
			this.label2.TabIndex = 2;
			this.label2.Text = "Session Template";
			// 
			// cmbDateType
			// 
			this.cmbDateType.FormattingEnabled = true;
			this.cmbDateType.Items.AddRange(new object[] {
            "DateRange",
            "BarsBack",
            "DaysBack"});
			this.cmbDateType.Location = new System.Drawing.Point(141, 262);
			this.cmbDateType.Name = "cmbDateType";
			this.cmbDateType.Size = new System.Drawing.Size(121, 21);
			this.cmbDateType.TabIndex = 5;
			this.cmbDateType.SelectedIndexChanged += new System.EventHandler(this.cmbDateType_SelectedIndexChanged);
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(31, 265);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(54, 13);
			this.label3.TabIndex = 4;
			this.label3.Text = "DataType";
			// 
			// chkAutoLastDate
			// 
			this.chkAutoLastDate.AutoSize = true;
			this.chkAutoLastDate.Location = new System.Drawing.Point(25, 449);
			this.chkAutoLastDate.Name = "chkAutoLastDate";
			this.chkAutoLastDate.Size = new System.Drawing.Size(97, 17);
			this.chkAutoLastDate.TabIndex = 6;
			this.chkAutoLastDate.Text = "Auto Last Date";
			this.chkAutoLastDate.UseVisualStyleBackColor = true;
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(31, 193);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(42, 13);
			this.label4.TabIndex = 7;
			this.label4.Text = "Interval";
			// 
			// txtInterval
			// 
			this.txtInterval.Location = new System.Drawing.Point(141, 190);
			this.txtInterval.Name = "txtInterval";
			this.txtInterval.Size = new System.Drawing.Size(121, 20);
			this.txtInterval.TabIndex = 8;
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(135, 307);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(55, 13);
			this.label5.TabIndex = 9;
			this.label5.Text = "Start Date";
			// 
			// dtStartDate
			// 
			this.dtStartDate.CustomFormat = "MM/dd/yyyy";
			this.dtStartDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			this.dtStartDate.Location = new System.Drawing.Point(202, 301);
			this.dtStartDate.Name = "dtStartDate";
			this.dtStartDate.Size = new System.Drawing.Size(104, 20);
			this.dtStartDate.TabIndex = 10;
			// 
			// dtEndDate
			// 
			this.dtEndDate.CustomFormat = "MM/dd/yyyy";
			this.dtEndDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			this.dtEndDate.Location = new System.Drawing.Point(202, 336);
			this.dtEndDate.Name = "dtEndDate";
			this.dtEndDate.Size = new System.Drawing.Size(104, 20);
			this.dtEndDate.TabIndex = 12;
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Location = new System.Drawing.Point(138, 340);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(52, 13);
			this.label6.TabIndex = 11;
			this.label6.Text = "End Date";
			// 
			// txtBarsback
			// 
			this.txtBarsback.Location = new System.Drawing.Point(202, 372);
			this.txtBarsback.Name = "txtBarsback";
			this.txtBarsback.Size = new System.Drawing.Size(104, 20);
			this.txtBarsback.TabIndex = 14;
			// 
			// label7
			// 
			this.label7.AutoSize = true;
			this.label7.Location = new System.Drawing.Point(134, 375);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(56, 13);
			this.label7.TabIndex = 13;
			this.label7.Text = "Bars Back";
			// 
			// txtDaysBack
			// 
			this.txtDaysBack.Location = new System.Drawing.Point(202, 407);
			this.txtDaysBack.Name = "txtDaysBack";
			this.txtDaysBack.Size = new System.Drawing.Size(104, 20);
			this.txtDaysBack.TabIndex = 16;
			// 
			// label8
			// 
			this.label8.AutoSize = true;
			this.label8.Location = new System.Drawing.Point(131, 410);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(59, 13);
			this.label8.TabIndex = 15;
			this.label8.Text = "Days Back";
			// 
			// chkUseSymbolSplit
			// 
			this.chkUseSymbolSplit.AutoSize = true;
			this.chkUseSymbolSplit.Location = new System.Drawing.Point(33, 84);
			this.chkUseSymbolSplit.Name = "chkUseSymbolSplit";
			this.chkUseSymbolSplit.Size = new System.Drawing.Size(118, 17);
			this.chkUseSymbolSplit.TabIndex = 17;
			this.chkUseSymbolSplit.Text = "Use TS Symbol List";
			this.chkUseSymbolSplit.UseVisualStyleBackColor = true;
			this.chkUseSymbolSplit.CheckedChanged += new System.EventHandler(this.chkUseSymbolSplit_CheckedChanged);
			// 
			// btnBrowseSymbolListFolder
			// 
			this.btnBrowseSymbolListFolder.Location = new System.Drawing.Point(338, 116);
			this.btnBrowseSymbolListFolder.Name = "btnBrowseSymbolListFolder";
			this.btnBrowseSymbolListFolder.Size = new System.Drawing.Size(34, 22);
			this.btnBrowseSymbolListFolder.TabIndex = 55;
			this.btnBrowseSymbolListFolder.Text = "...";
			this.btnBrowseSymbolListFolder.UseVisualStyleBackColor = true;
			this.btnBrowseSymbolListFolder.Click += new System.EventHandler(this.btnBrowseSymbolListFolder_Click);
			// 
			// txtSymbolListFolder
			// 
			this.txtSymbolListFolder.Location = new System.Drawing.Point(141, 117);
			this.txtSymbolListFolder.Name = "txtSymbolListFolder";
			this.txtSymbolListFolder.Size = new System.Drawing.Size(197, 20);
			this.txtSymbolListFolder.TabIndex = 54;
			// 
			// label9
			// 
			this.label9.AutoSize = true;
			this.label9.Location = new System.Drawing.Point(31, 120);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(109, 13);
			this.label9.TabIndex = 56;
			this.label9.Text = "TS Symbol List Folder";
			// 
			// groupVolCal
			// 
			this.groupVolCal.Controls.Add(this.chkSum3Only);
			this.groupVolCal.Controls.Add(this.radOutputPTVinVol);
			this.groupVolCal.Controls.Add(this.radUpDownTickAsVol);
			this.groupVolCal.Controls.Add(this.radUpDownVolAsVol);
			this.groupVolCal.Controls.Add(this.radOutputTicks);
			this.groupVolCal.Controls.Add(this.radUpDownTicks);
			this.groupVolCal.Controls.Add(this.radUpDownVol);
			this.groupVolCal.Location = new System.Drawing.Point(454, 25);
			this.groupVolCal.Name = "groupVolCal";
			this.groupVolCal.Size = new System.Drawing.Size(197, 228);
			this.groupVolCal.TabIndex = 57;
			this.groupVolCal.TabStop = false;
			// 
			// chkSum3Only
			// 
			this.chkSum3Only.AutoSize = true;
			this.chkSum3Only.Location = new System.Drawing.Point(62, 193);
			this.chkSum3Only.Name = "chkSum3Only";
			this.chkSum3Only.Size = new System.Drawing.Size(80, 17);
			this.chkSum3Only.TabIndex = 7;
			this.chkSum3Only.Text = "Sum 3 Only";
			this.chkSum3Only.UseVisualStyleBackColor = true;
			// 
			// radOutputPTVinVol
			// 
			this.radOutputPTVinVol.AutoSize = true;
			this.radOutputPTVinVol.Location = new System.Drawing.Point(37, 165);
			this.radOutputPTVinVol.Name = "radOutputPTVinVol";
			this.radOutputPTVinVol.Size = new System.Drawing.Size(122, 17);
			this.radOutputPTVinVol.TabIndex = 5;
			this.radOutputPTVinVol.TabStop = true;
			this.radOutputPTVinVol.Text = "Output P+T+V in Vol";
			this.radOutputPTVinVol.UseVisualStyleBackColor = true;
			// 
			// radUpDownTickAsVol
			// 
			this.radUpDownTickAsVol.AutoSize = true;
			this.radUpDownTickAsVol.Location = new System.Drawing.Point(37, 138);
			this.radUpDownTickAsVol.Name = "radUpDownTickAsVol";
			this.radUpDownTickAsVol.Size = new System.Drawing.Size(123, 17);
			this.radUpDownTickAsVol.TabIndex = 4;
			this.radUpDownTickAsVol.TabStop = true;
			this.radUpDownTickAsVol.Text = "Up-DownTick as Vol";
			this.radUpDownTickAsVol.UseVisualStyleBackColor = true;
			// 
			// radUpDownVolAsVol
			// 
			this.radUpDownVolAsVol.AutoSize = true;
			this.radUpDownVolAsVol.Location = new System.Drawing.Point(37, 110);
			this.radUpDownVolAsVol.Name = "radUpDownVolAsVol";
			this.radUpDownVolAsVol.Size = new System.Drawing.Size(117, 17);
			this.radUpDownVolAsVol.TabIndex = 3;
			this.radUpDownVolAsVol.TabStop = true;
			this.radUpDownVolAsVol.Text = "Up-DownVol as Vol";
			this.radUpDownVolAsVol.UseVisualStyleBackColor = true;
			// 
			// radOutputTicks
			// 
			this.radOutputTicks.AutoSize = true;
			this.radOutputTicks.Location = new System.Drawing.Point(37, 84);
			this.radOutputTicks.Name = "radOutputTicks";
			this.radOutputTicks.Size = new System.Drawing.Size(104, 17);
			this.radOutputTicks.TabIndex = 2;
			this.radOutputTicks.TabStop = true;
			this.radOutputTicks.Text = "Output Ticks Vol";
			this.radOutputTicks.UseVisualStyleBackColor = true;
			// 
			// radUpDownTicks
			// 
			this.radUpDownTicks.AutoSize = true;
			this.radUpDownTicks.Location = new System.Drawing.Point(37, 57);
			this.radUpDownTicks.Name = "radUpDownTicks";
			this.radUpDownTicks.Size = new System.Drawing.Size(96, 17);
			this.radUpDownTicks.TabIndex = 1;
			this.radUpDownTicks.TabStop = true;
			this.radUpDownTicks.Text = "UpDown Ticks";
			this.radUpDownTicks.UseVisualStyleBackColor = true;
			// 
			// radUpDownVol
			// 
			this.radUpDownVol.AutoSize = true;
			this.radUpDownVol.Location = new System.Drawing.Point(37, 29);
			this.radUpDownVol.Name = "radUpDownVol";
			this.radUpDownVol.Size = new System.Drawing.Size(85, 17);
			this.radUpDownVol.TabIndex = 0;
			this.radUpDownVol.TabStop = true;
			this.radUpDownVol.Text = "UpDown Vol";
			this.radUpDownVol.UseVisualStyleBackColor = true;
			// 
			// groupDataCleanup
			// 
			this.groupDataCleanup.Controls.Add(this.radVolumeMismatch);
			this.groupDataCleanup.Controls.Add(this.radPriceMismatch);
			this.groupDataCleanup.Controls.Add(this.radMismatchWithZero);
			this.groupDataCleanup.Controls.Add(this.radMismatch);
			this.groupDataCleanup.Location = new System.Drawing.Point(454, 259);
			this.groupDataCleanup.Name = "groupDataCleanup";
			this.groupDataCleanup.Size = new System.Drawing.Size(197, 146);
			this.groupDataCleanup.TabIndex = 58;
			this.groupDataCleanup.TabStop = false;
			// 
			// radVolumeMismatch
			// 
			this.radVolumeMismatch.AutoSize = true;
			this.radVolumeMismatch.Location = new System.Drawing.Point(37, 110);
			this.radVolumeMismatch.Name = "radVolumeMismatch";
			this.radVolumeMismatch.Size = new System.Drawing.Size(109, 17);
			this.radVolumeMismatch.TabIndex = 3;
			this.radVolumeMismatch.TabStop = true;
			this.radVolumeMismatch.Text = "Volume MisMatch";
			this.radVolumeMismatch.UseVisualStyleBackColor = true;
			// 
			// radPriceMismatch
			// 
			this.radPriceMismatch.AutoSize = true;
			this.radPriceMismatch.Location = new System.Drawing.Point(37, 84);
			this.radPriceMismatch.Name = "radPriceMismatch";
			this.radPriceMismatch.Size = new System.Drawing.Size(98, 17);
			this.radPriceMismatch.TabIndex = 2;
			this.radPriceMismatch.TabStop = true;
			this.radPriceMismatch.Text = "Price MisMatch";
			this.radPriceMismatch.UseVisualStyleBackColor = true;
			// 
			// radMismatchWithZero
			// 
			this.radMismatchWithZero.AutoSize = true;
			this.radMismatchWithZero.Location = new System.Drawing.Point(37, 57);
			this.radMismatchWithZero.Name = "radMismatchWithZero";
			this.radMismatchWithZero.Size = new System.Drawing.Size(118, 17);
			this.radMismatchWithZero.TabIndex = 1;
			this.radMismatchWithZero.TabStop = true;
			this.radMismatchWithZero.Text = "MisMatch with Zero";
			this.radMismatchWithZero.UseVisualStyleBackColor = true;
			// 
			// radMismatch
			// 
			this.radMismatch.AutoSize = true;
			this.radMismatch.Location = new System.Drawing.Point(37, 29);
			this.radMismatch.Name = "radMismatch";
			this.radMismatch.Size = new System.Drawing.Size(71, 17);
			this.radMismatch.TabIndex = 0;
			this.radMismatch.TabStop = true;
			this.radMismatch.Text = "MisMatch";
			this.radMismatch.UseVisualStyleBackColor = true;
			// 
			// chkDataCleanup
			// 
			this.chkDataCleanup.AutoSize = true;
			this.chkDataCleanup.Location = new System.Drawing.Point(466, 259);
			this.chkDataCleanup.Name = "chkDataCleanup";
			this.chkDataCleanup.Size = new System.Drawing.Size(93, 17);
			this.chkDataCleanup.TabIndex = 59;
			this.chkDataCleanup.Text = "Data CleanUp";
			this.chkDataCleanup.UseVisualStyleBackColor = true;
			this.chkDataCleanup.CheckedChanged += new System.EventHandler(this.chkDataCleanup_CheckedChanged);
			// 
			// btnOK
			// 
			this.btnOK.Location = new System.Drawing.Point(382, 495);
			this.btnOK.Name = "btnOK";
			this.btnOK.Size = new System.Drawing.Size(119, 32);
			this.btnOK.TabIndex = 60;
			this.btnOK.Text = "OK";
			this.btnOK.UseVisualStyleBackColor = true;
			this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
			// 
			// btnCancel
			// 
			this.btnCancel.Location = new System.Drawing.Point(570, 495);
			this.btnCancel.Name = "btnCancel";
			this.btnCancel.Size = new System.Drawing.Size(119, 32);
			this.btnCancel.TabIndex = 61;
			this.btnCancel.Text = "Cancel";
			this.btnCancel.UseVisualStyleBackColor = true;
			this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
			// 
			// label10
			// 
			this.label10.AutoSize = true;
			this.label10.Location = new System.Drawing.Point(30, 22);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(64, 13);
			this.label10.TabIndex = 62;
			this.label10.Text = "Active Base";
			// 
			// radSim
			// 
			this.radSim.AutoSize = true;
			this.radSim.Location = new System.Drawing.Point(220, 20);
			this.radSim.Name = "radSim";
			this.radSim.Size = new System.Drawing.Size(42, 17);
			this.radSim.TabIndex = 64;
			this.radSim.TabStop = true;
			this.radSim.Text = "Sim";
			this.radSim.UseVisualStyleBackColor = true;
			// 
			// radLive
			// 
			this.radLive.AutoSize = true;
			this.radLive.Location = new System.Drawing.Point(137, 20);
			this.radLive.Name = "radLive";
			this.radLive.Size = new System.Drawing.Size(45, 17);
			this.radLive.TabIndex = 63;
			this.radLive.TabStop = true;
			this.radLive.Text = "Live";
			this.radLive.UseVisualStyleBackColor = true;
			this.radLive.CheckedChanged += new System.EventHandler(this.radLive_CheckedChanged);
			// 
			// chkUseMultipleToken
			// 
			this.chkUseMultipleToken.AutoSize = true;
			this.chkUseMultipleToken.Checked = true;
			this.chkUseMultipleToken.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chkUseMultipleToken.Location = new System.Drawing.Point(34, 53);
			this.chkUseMultipleToken.Name = "chkUseMultipleToken";
			this.chkUseMultipleToken.Size = new System.Drawing.Size(163, 17);
			this.chkUseMultipleToken.TabIndex = 65;
			this.chkUseMultipleToken.Text = "Use Multiple Refresh Tokens";
			this.chkUseMultipleToken.UseVisualStyleBackColor = true;
			// 
			// chkVolCal
			// 
			this.chkVolCal.AutoSize = true;
			this.chkVolCal.Location = new System.Drawing.Point(467, 22);
			this.chkVolCal.Name = "chkVolCal";
			this.chkVolCal.Size = new System.Drawing.Size(59, 17);
			this.chkVolCal.TabIndex = 66;
			this.chkVolCal.Text = "Vol Cal";
			this.chkVolCal.UseVisualStyleBackColor = true;
			this.chkVolCal.CheckedChanged += new System.EventHandler(this.chkVolCal_CheckedChanged);
			// 
			// label11
			// 
			this.label11.AutoSize = true;
			this.label11.Location = new System.Drawing.Point(203, 54);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(67, 13);
			this.label11.TabIndex = 67;
			this.label11.Text = "(APIKeys.txt)";
			// 
			// label12
			// 
			this.label12.AutoSize = true;
			this.label12.Location = new System.Drawing.Point(292, 5);
			this.label12.Name = "label12";
			this.label12.Size = new System.Drawing.Size(54, 13);
			this.label12.TabIndex = 68;
			this.label12.Text = "DataType";
			this.label12.Visible = false;
			// 
			// txtTickInterval
			// 
			this.txtTickInterval.Location = new System.Drawing.Point(402, 2);
			this.txtTickInterval.Name = "txtTickInterval";
			this.txtTickInterval.Size = new System.Drawing.Size(121, 20);
			this.txtTickInterval.TabIndex = 69;
			this.txtTickInterval.Visible = false;
			// 
			// chkMinRowsCleanup
			// 
			this.chkMinRowsCleanup.AutoSize = true;
			this.chkMinRowsCleanup.Location = new System.Drawing.Point(25, 484);
			this.chkMinRowsCleanup.Name = "chkMinRowsCleanup";
			this.chkMinRowsCleanup.Size = new System.Drawing.Size(117, 17);
			this.chkMinRowsCleanup.TabIndex = 70;
			this.chkMinRowsCleanup.Text = "Min Rows CleanUp";
			this.chkMinRowsCleanup.UseVisualStyleBackColor = true;
			this.chkMinRowsCleanup.CheckedChanged += new System.EventHandler(this.chkMinRowsCleanup_CheckedChanged);
			// 
			// txtMinRowsCleanup
			// 
			this.txtMinRowsCleanup.Location = new System.Drawing.Point(158, 481);
			this.txtMinRowsCleanup.Name = "txtMinRowsCleanup";
			this.txtMinRowsCleanup.Size = new System.Drawing.Size(104, 20);
			this.txtMinRowsCleanup.TabIndex = 71;
			// 
			// FrmTSDataFeedSettings
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(716, 551);
			this.Controls.Add(this.txtMinRowsCleanup);
			this.Controls.Add(this.chkMinRowsCleanup);
			this.Controls.Add(this.txtTickInterval);
			this.Controls.Add(this.label12);
			this.Controls.Add(this.label11);
			this.Controls.Add(this.chkVolCal);
			this.Controls.Add(this.chkUseMultipleToken);
			this.Controls.Add(this.radSim);
			this.Controls.Add(this.radLive);
			this.Controls.Add(this.label10);
			this.Controls.Add(this.btnCancel);
			this.Controls.Add(this.btnOK);
			this.Controls.Add(this.chkDataCleanup);
			this.Controls.Add(this.groupDataCleanup);
			this.Controls.Add(this.groupVolCal);
			this.Controls.Add(this.label9);
			this.Controls.Add(this.btnBrowseSymbolListFolder);
			this.Controls.Add(this.txtSymbolListFolder);
			this.Controls.Add(this.chkUseSymbolSplit);
			this.Controls.Add(this.txtDaysBack);
			this.Controls.Add(this.label8);
			this.Controls.Add(this.txtBarsback);
			this.Controls.Add(this.label7);
			this.Controls.Add(this.dtEndDate);
			this.Controls.Add(this.label6);
			this.Controls.Add(this.dtStartDate);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.txtInterval);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.chkAutoLastDate);
			this.Controls.Add(this.cmbDateType);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.cmbSessionTemplate);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.cmbUnit);
			this.Controls.Add(this.label1);
			this.Name = "FrmTSDataFeedSettings";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "TSDataFeed Configuration";
			this.Load += new System.EventHandler(this.FrmTSDataFeedSettings_Load);
			this.groupVolCal.ResumeLayout(false);
			this.groupVolCal.PerformLayout();
			this.groupDataCleanup.ResumeLayout(false);
			this.groupDataCleanup.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.ComboBox cmbUnit;
		private System.Windows.Forms.ComboBox cmbSessionTemplate;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.ComboBox cmbDateType;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.CheckBox chkAutoLastDate;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.TextBox txtInterval;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.DateTimePicker dtStartDate;
		private System.Windows.Forms.DateTimePicker dtEndDate;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.TextBox txtBarsback;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.TextBox txtDaysBack;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.CheckBox chkUseSymbolSplit;
		private System.Windows.Forms.Button btnBrowseSymbolListFolder;
		private System.Windows.Forms.TextBox txtSymbolListFolder;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.GroupBox groupVolCal;
		private System.Windows.Forms.CheckBox chkSum3Only;
		private System.Windows.Forms.RadioButton radOutputPTVinVol;
		private System.Windows.Forms.RadioButton radUpDownTickAsVol;
		private System.Windows.Forms.RadioButton radUpDownVolAsVol;
		private System.Windows.Forms.RadioButton radOutputTicks;
		private System.Windows.Forms.RadioButton radUpDownTicks;
		private System.Windows.Forms.RadioButton radUpDownVol;
		private System.Windows.Forms.GroupBox groupDataCleanup;
		private System.Windows.Forms.RadioButton radVolumeMismatch;
		private System.Windows.Forms.RadioButton radPriceMismatch;
		private System.Windows.Forms.RadioButton radMismatchWithZero;
		private System.Windows.Forms.RadioButton radMismatch;
		private System.Windows.Forms.CheckBox chkDataCleanup;
		private System.Windows.Forms.Button btnOK;
		private System.Windows.Forms.Button btnCancel;
		private System.Windows.Forms.Label label10;
		private System.Windows.Forms.RadioButton radSim;
		private System.Windows.Forms.RadioButton radLive;
		private System.Windows.Forms.CheckBox chkUseMultipleToken;
		private System.Windows.Forms.CheckBox chkVolCal;
		private System.Windows.Forms.Label label11;
		private System.Windows.Forms.Label label12;
		private System.Windows.Forms.TextBox txtTickInterval;
		private System.Windows.Forms.CheckBox chkMinRowsCleanup;
		private System.Windows.Forms.TextBox txtMinRowsCleanup;
	}
}