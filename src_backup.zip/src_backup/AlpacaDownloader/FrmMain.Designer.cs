﻿namespace SriAlpacaDL
{
	partial class FrmMain
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.label4 = new System.Windows.Forms.Label();
			this.radioPaper = new System.Windows.Forms.RadioButton();
			this.radioLive = new System.Windows.Forms.RadioButton();
			this.txtLiveKey = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.txtLiveSecretKey = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.btnBrowseInputDataPath = new System.Windows.Forms.Button();
			this.txtOutputDataPath = new System.Windows.Forms.TextBox();
			this.label11 = new System.Windows.Forms.Label();
			this.groupGeneral = new System.Windows.Forms.GroupBox();
			this.chkPlan = new System.Windows.Forms.ComboBox();
			this.btnBrowseSymbolList = new System.Windows.Forms.Button();
			this.txtPaperSecretKey = new System.Windows.Forms.TextBox();
			this.txtPaperKey = new System.Windows.Forms.TextBox();
			this.txtSymbolListFile = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.btnStart = new System.Windows.Forms.Button();
			this.btnExit = new System.Windows.Forms.Button();
			this.timerUpdate = new System.Windows.Forms.Timer(this.components);
			this.groupDataType = new System.Windows.Forms.GroupBox();
			this.btnTest = new System.Windows.Forms.Button();
			this.chkTSOHLCV = new System.Windows.Forms.CheckBox();
			this.panelDatafeedSetting = new System.Windows.Forms.Panel();
			this.btnRefreshToken = new System.Windows.Forms.Button();
			this.btnGlobalDataFeedSetting = new System.Windows.Forms.Button();
			this.chkInputFileTSOptions = new System.Windows.Forms.CheckBox();
			this.panelLocalDataFeedSetting = new System.Windows.Forms.Panel();
			this.lblLocalDataFolder = new System.Windows.Forms.Label();
			this.btnBrowseLocalDataFolder = new System.Windows.Forms.Button();
			this.txtLocalDataFolder = new System.Windows.Forms.TextBox();
			this.panelPolygonDataFeedSetting = new System.Windows.Forms.Panel();
			this.lblPolygonKey = new System.Windows.Forms.Label();
			this.txtPolygonAPIKey = new System.Windows.Forms.TextBox();
			this.label20 = new System.Windows.Forms.Label();
			this.cmbSort = new System.Windows.Forms.ComboBox();
			this.chkRoundVol = new System.Windows.Forms.CheckBox();
			this.chkRoundClose = new System.Windows.Forms.CheckBox();
			this.label5 = new System.Windows.Forms.Label();
			this.chkRoundChange = new System.Windows.Forms.CheckBox();
			this.cmbUnadjusted = new System.Windows.Forms.ComboBox();
			this.txtMultiplier = new System.Windows.Forms.TextBox();
			this.txtRounding = new System.Windows.Forms.TextBox();
			this.label19 = new System.Windows.Forms.Label();
			this.lblMultiplier = new System.Windows.Forms.Label();
			this.dtEndDate = new System.Windows.Forms.DateTimePicker();
			this.dtStartDate = new System.Windows.Forms.DateTimePicker();
			this.label6 = new System.Windows.Forms.Label();
			this.label12 = new System.Windows.Forms.Label();
			this.label8 = new System.Windows.Forms.Label();
			this.cmbDataFeedType = new System.Windows.Forms.ComboBox();
			this.label7 = new System.Windows.Forms.Label();
			this.cmbTimeFrame = new System.Windows.Forms.ComboBox();
			this.txtDelay = new System.Windows.Forms.TextBox();
			this.label18 = new System.Windows.Forms.Label();
			this.btnROutputSettings = new System.Windows.Forms.Button();
			this.chkROutput = new System.Windows.Forms.CheckBox();
			this.chkBackfillUpdate = new System.Windows.Forms.CheckBox();
			this.chkCalendarAutoStart = new System.Windows.Forms.CheckBox();
			this.radioCO = new System.Windows.Forms.RadioButton();
			this.radioHL = new System.Windows.Forms.RadioButton();
			this.radioOHLC = new System.Windows.Forms.RadioButton();
			this.radioHLC = new System.Windows.Forms.RadioButton();
			this.chkCloseBarUpdate = new System.Windows.Forms.CheckBox();
			this.chkAppendData = new System.Windows.Forms.CheckBox();
			this.label10 = new System.Windows.Forms.Label();
			this.radioProcessAuto = new System.Windows.Forms.RadioButton();
			this.radioProcessStatic = new System.Windows.Forms.RadioButton();
			this.label9 = new System.Windows.Forms.Label();
			this.chkMarketHoursOnly = new System.Windows.Forms.CheckBox();
			this.dateTimeEnd = new System.Windows.Forms.DateTimePicker();
			this.dateTimeStart = new System.Windows.Forms.DateTimePicker();
			this.txtBars = new System.Windows.Forms.TextBox();
			this.lblBarLimit = new System.Windows.Forms.Label();
			this.lblTimeFrame = new System.Windows.Forms.Label();
			this.statusStrip1 = new System.Windows.Forms.StatusStrip();
			this.lblProcessStatus = new System.Windows.Forms.ToolStripStatusLabel();
			this.statusProgressBar = new System.Windows.Forms.ToolStripProgressBar();
			this.btnStopWebSocketUpdate = new System.Windows.Forms.Button();
			this.btnStartWebSocketUpdate = new System.Windows.Forms.Button();
			this.lblSocketState = new System.Windows.Forms.Label();
			this.btnGenerateCal = new System.Windows.Forms.Button();
			this.btnTrimInputData = new System.Windows.Forms.Button();
			this.btnGenSectorFile = new System.Windows.Forms.Button();
			this.btnCleanTree = new System.Windows.Forms.Button();
			this.btnSidewayFilters = new System.Windows.Forms.Button();
			this.btnWebSocketSettings = new System.Windows.Forms.Button();
			this.btnMarketView = new System.Windows.Forms.Button();
			this.btnAWSSettings = new System.Windows.Forms.Button();
			this.btnCleanupStockList = new System.Windows.Forms.Button();
			this.btnMiscSettings = new System.Windows.Forms.Button();
			this.btnCleanStockListConfig = new System.Windows.Forms.Button();
			this.button1 = new System.Windows.Forms.Button();
			this.btnSignalSettings = new System.Windows.Forms.Button();
			this.groupGeneral.SuspendLayout();
			this.groupDataType.SuspendLayout();
			this.panelDatafeedSetting.SuspendLayout();
			this.panelLocalDataFeedSetting.SuspendLayout();
			this.panelPolygonDataFeedSetting.SuspendLayout();
			this.statusStrip1.SuspendLayout();
			this.SuspendLayout();
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(75, 17);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(38, 13);
			this.label4.TabIndex = 17;
			this.label4.Text = "Broker";
			// 
			// radioPaper
			// 
			this.radioPaper.AutoSize = true;
			this.radioPaper.Location = new System.Drawing.Point(323, 13);
			this.radioPaper.Name = "radioPaper";
			this.radioPaper.Size = new System.Drawing.Size(53, 17);
			this.radioPaper.TabIndex = 16;
			this.radioPaper.TabStop = true;
			this.radioPaper.Text = "Paper";
			this.radioPaper.UseVisualStyleBackColor = true;
			this.radioPaper.CheckedChanged += new System.EventHandler(this.radioPaper_CheckedChanged);
			// 
			// radioLive
			// 
			this.radioLive.AutoSize = true;
			this.radioLive.Checked = true;
			this.radioLive.Location = new System.Drawing.Point(141, 13);
			this.radioLive.Name = "radioLive";
			this.radioLive.Size = new System.Drawing.Size(45, 17);
			this.radioLive.TabIndex = 15;
			this.radioLive.TabStop = true;
			this.radioLive.Text = "Live";
			this.radioLive.UseVisualStyleBackColor = true;
			this.radioLive.CheckedChanged += new System.EventHandler(this.radioLive_CheckedChanged);
			// 
			// txtLiveKey
			// 
			this.txtLiveKey.Location = new System.Drawing.Point(141, 40);
			this.txtLiveKey.Name = "txtLiveKey";
			this.txtLiveKey.Size = new System.Drawing.Size(156, 20);
			this.txtLiveKey.TabIndex = 19;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(67, 44);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(45, 13);
			this.label1.TabIndex = 18;
			this.label1.Text = "API Key";
			// 
			// txtLiveSecretKey
			// 
			this.txtLiveSecretKey.Location = new System.Drawing.Point(141, 66);
			this.txtLiveSecretKey.Name = "txtLiveSecretKey";
			this.txtLiveSecretKey.Size = new System.Drawing.Size(156, 20);
			this.txtLiveSecretKey.TabIndex = 21;
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(33, 70);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(79, 13);
			this.label2.TabIndex = 20;
			this.label2.Text = "API Secret Key";
			// 
			// btnBrowseInputDataPath
			// 
			this.btnBrowseInputDataPath.Location = new System.Drawing.Point(479, 118);
			this.btnBrowseInputDataPath.Name = "btnBrowseInputDataPath";
			this.btnBrowseInputDataPath.Size = new System.Drawing.Size(27, 22);
			this.btnBrowseInputDataPath.TabIndex = 24;
			this.btnBrowseInputDataPath.Text = "...";
			this.btnBrowseInputDataPath.UseVisualStyleBackColor = true;
			this.btnBrowseInputDataPath.Click += new System.EventHandler(this.btnBrowseInputDataPath_Click);
			// 
			// txtOutputDataPath
			// 
			this.txtOutputDataPath.Location = new System.Drawing.Point(141, 119);
			this.txtOutputDataPath.Name = "txtOutputDataPath";
			this.txtOutputDataPath.Size = new System.Drawing.Size(338, 20);
			this.txtOutputDataPath.TabIndex = 23;
			// 
			// label11
			// 
			this.label11.AutoSize = true;
			this.label11.Location = new System.Drawing.Point(41, 124);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(71, 13);
			this.label11.TabIndex = 22;
			this.label11.Text = "Output Folder";
			// 
			// groupGeneral
			// 
			this.groupGeneral.Controls.Add(this.chkPlan);
			this.groupGeneral.Controls.Add(this.btnBrowseSymbolList);
			this.groupGeneral.Controls.Add(this.txtPaperSecretKey);
			this.groupGeneral.Controls.Add(this.txtPaperKey);
			this.groupGeneral.Controls.Add(this.txtSymbolListFile);
			this.groupGeneral.Controls.Add(this.label3);
			this.groupGeneral.Controls.Add(this.btnBrowseInputDataPath);
			this.groupGeneral.Controls.Add(this.txtOutputDataPath);
			this.groupGeneral.Controls.Add(this.label11);
			this.groupGeneral.Controls.Add(this.txtLiveSecretKey);
			this.groupGeneral.Controls.Add(this.label2);
			this.groupGeneral.Controls.Add(this.txtLiveKey);
			this.groupGeneral.Controls.Add(this.label1);
			this.groupGeneral.Controls.Add(this.label4);
			this.groupGeneral.Controls.Add(this.radioPaper);
			this.groupGeneral.Controls.Add(this.radioLive);
			this.groupGeneral.Location = new System.Drawing.Point(12, 3);
			this.groupGeneral.Name = "groupGeneral";
			this.groupGeneral.Size = new System.Drawing.Size(575, 149);
			this.groupGeneral.TabIndex = 25;
			this.groupGeneral.TabStop = false;
			this.groupGeneral.Text = "General";
			// 
			// chkPlan
			// 
			this.chkPlan.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.chkPlan.FormattingEnabled = true;
			this.chkPlan.Items.AddRange(new object[] {
            "Pro",
            "Basic"});
			this.chkPlan.Location = new System.Drawing.Point(219, 12);
			this.chkPlan.Name = "chkPlan";
			this.chkPlan.Size = new System.Drawing.Size(77, 21);
			this.chkPlan.TabIndex = 30;
			// 
			// btnBrowseSymbolList
			// 
			this.btnBrowseSymbolList.Location = new System.Drawing.Point(479, 91);
			this.btnBrowseSymbolList.Name = "btnBrowseSymbolList";
			this.btnBrowseSymbolList.Size = new System.Drawing.Size(27, 22);
			this.btnBrowseSymbolList.TabIndex = 29;
			this.btnBrowseSymbolList.Text = "...";
			this.btnBrowseSymbolList.UseVisualStyleBackColor = true;
			this.btnBrowseSymbolList.Click += new System.EventHandler(this.btnBrowseSymbolList_Click);
			// 
			// txtPaperSecretKey
			// 
			this.txtPaperSecretKey.Location = new System.Drawing.Point(323, 66);
			this.txtPaperSecretKey.Name = "txtPaperSecretKey";
			this.txtPaperSecretKey.Size = new System.Drawing.Size(156, 20);
			this.txtPaperSecretKey.TabIndex = 26;
			// 
			// txtPaperKey
			// 
			this.txtPaperKey.Location = new System.Drawing.Point(323, 40);
			this.txtPaperKey.Name = "txtPaperKey";
			this.txtPaperKey.Size = new System.Drawing.Size(156, 20);
			this.txtPaperKey.TabIndex = 25;
			// 
			// txtSymbolListFile
			// 
			this.txtSymbolListFile.Location = new System.Drawing.Point(141, 92);
			this.txtSymbolListFile.Name = "txtSymbolListFile";
			this.txtSymbolListFile.Size = new System.Drawing.Size(338, 20);
			this.txtSymbolListFile.TabIndex = 28;
			this.txtSymbolListFile.TextChanged += new System.EventHandler(this.txtSymbolListFile_TextChanged);
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(36, 95);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(76, 13);
			this.label3.TabIndex = 27;
			this.label3.Text = "SymbolList File";
			this.label3.Click += new System.EventHandler(this.label3_Click);
			// 
			// btnStart
			// 
			this.btnStart.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
			this.btnStart.Location = new System.Drawing.Point(13, 500);
			this.btnStart.Name = "btnStart";
			this.btnStart.Size = new System.Drawing.Size(188, 28);
			this.btnStart.TabIndex = 43;
			this.btnStart.Text = "Start";
			this.btnStart.UseVisualStyleBackColor = true;
			this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
			// 
			// btnExit
			// 
			this.btnExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
			this.btnExit.Location = new System.Drawing.Point(397, 665);
			this.btnExit.Name = "btnExit";
			this.btnExit.Size = new System.Drawing.Size(188, 28);
			this.btnExit.TabIndex = 48;
			this.btnExit.Text = "Exit";
			this.btnExit.UseVisualStyleBackColor = true;
			this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
			// 
			// timerUpdate
			// 
			this.timerUpdate.Enabled = true;
			this.timerUpdate.Interval = 1000;
			// 
			// groupDataType
			// 
			this.groupDataType.Controls.Add(this.btnTest);
			this.groupDataType.Controls.Add(this.chkTSOHLCV);
			this.groupDataType.Controls.Add(this.panelDatafeedSetting);
			this.groupDataType.Controls.Add(this.chkInputFileTSOptions);
			this.groupDataType.Controls.Add(this.panelLocalDataFeedSetting);
			this.groupDataType.Controls.Add(this.panelPolygonDataFeedSetting);
			this.groupDataType.Controls.Add(this.label20);
			this.groupDataType.Controls.Add(this.cmbSort);
			this.groupDataType.Controls.Add(this.chkRoundVol);
			this.groupDataType.Controls.Add(this.chkRoundClose);
			this.groupDataType.Controls.Add(this.label5);
			this.groupDataType.Controls.Add(this.chkRoundChange);
			this.groupDataType.Controls.Add(this.cmbUnadjusted);
			this.groupDataType.Controls.Add(this.txtMultiplier);
			this.groupDataType.Controls.Add(this.txtRounding);
			this.groupDataType.Controls.Add(this.label19);
			this.groupDataType.Controls.Add(this.lblMultiplier);
			this.groupDataType.Controls.Add(this.dtEndDate);
			this.groupDataType.Controls.Add(this.dtStartDate);
			this.groupDataType.Controls.Add(this.label6);
			this.groupDataType.Controls.Add(this.label12);
			this.groupDataType.Controls.Add(this.label8);
			this.groupDataType.Controls.Add(this.cmbDataFeedType);
			this.groupDataType.Controls.Add(this.label7);
			this.groupDataType.Controls.Add(this.cmbTimeFrame);
			this.groupDataType.Controls.Add(this.txtDelay);
			this.groupDataType.Controls.Add(this.label18);
			this.groupDataType.Controls.Add(this.btnROutputSettings);
			this.groupDataType.Controls.Add(this.chkROutput);
			this.groupDataType.Controls.Add(this.chkBackfillUpdate);
			this.groupDataType.Controls.Add(this.chkCalendarAutoStart);
			this.groupDataType.Controls.Add(this.radioCO);
			this.groupDataType.Controls.Add(this.radioHL);
			this.groupDataType.Controls.Add(this.radioOHLC);
			this.groupDataType.Controls.Add(this.radioHLC);
			this.groupDataType.Controls.Add(this.chkCloseBarUpdate);
			this.groupDataType.Controls.Add(this.chkAppendData);
			this.groupDataType.Controls.Add(this.label10);
			this.groupDataType.Controls.Add(this.radioProcessAuto);
			this.groupDataType.Controls.Add(this.radioProcessStatic);
			this.groupDataType.Controls.Add(this.label9);
			this.groupDataType.Controls.Add(this.chkMarketHoursOnly);
			this.groupDataType.Controls.Add(this.dateTimeEnd);
			this.groupDataType.Controls.Add(this.dateTimeStart);
			this.groupDataType.Controls.Add(this.txtBars);
			this.groupDataType.Controls.Add(this.lblBarLimit);
			this.groupDataType.Controls.Add(this.lblTimeFrame);
			this.groupDataType.Location = new System.Drawing.Point(13, 152);
			this.groupDataType.Name = "groupDataType";
			this.groupDataType.Size = new System.Drawing.Size(574, 340);
			this.groupDataType.TabIndex = 50;
			this.groupDataType.TabStop = false;
			this.groupDataType.Text = "Data Download Settings";
			// 
			// btnTest
			// 
			this.btnTest.Location = new System.Drawing.Point(482, 150);
			this.btnTest.Name = "btnTest";
			this.btnTest.Size = new System.Drawing.Size(75, 23);
			this.btnTest.TabIndex = 80;
			this.btnTest.Text = "Test";
			this.btnTest.UseVisualStyleBackColor = true;
			this.btnTest.Click += new System.EventHandler(this.btnTest_Click);
			// 
			// chkTSOHLCV
			// 
			this.chkTSOHLCV.AutoSize = true;
			this.chkTSOHLCV.Location = new System.Drawing.Point(175, 276);
			this.chkTSOHLCV.Name = "chkTSOHLCV";
			this.chkTSOHLCV.Size = new System.Drawing.Size(96, 17);
			this.chkTSOHLCV.TabIndex = 79;
			this.chkTSOHLCV.Text = "TS-OHLCV+OI";
			this.chkTSOHLCV.UseVisualStyleBackColor = true;
			// 
			// panelDatafeedSetting
			// 
			this.panelDatafeedSetting.Controls.Add(this.btnRefreshToken);
			this.panelDatafeedSetting.Controls.Add(this.btnGlobalDataFeedSetting);
			this.panelDatafeedSetting.Location = new System.Drawing.Point(266, 17);
			this.panelDatafeedSetting.Name = "panelDatafeedSetting";
			this.panelDatafeedSetting.Size = new System.Drawing.Size(285, 25);
			this.panelDatafeedSetting.TabIndex = 31;
			// 
			// btnRefreshToken
			// 
			this.btnRefreshToken.Location = new System.Drawing.Point(135, 1);
			this.btnRefreshToken.Name = "btnRefreshToken";
			this.btnRefreshToken.Size = new System.Drawing.Size(124, 23);
			this.btnRefreshToken.TabIndex = 75;
			this.btnRefreshToken.Text = "Get Refresh Token";
			this.btnRefreshToken.UseVisualStyleBackColor = true;
			this.btnRefreshToken.Click += new System.EventHandler(this.btnRefreshToken_Click_1);
			// 
			// btnGlobalDataFeedSetting
			// 
			this.btnGlobalDataFeedSetting.Location = new System.Drawing.Point(13, 1);
			this.btnGlobalDataFeedSetting.Name = "btnGlobalDataFeedSetting";
			this.btnGlobalDataFeedSetting.Size = new System.Drawing.Size(116, 23);
			this.btnGlobalDataFeedSetting.TabIndex = 0;
			this.btnGlobalDataFeedSetting.Text = "Settings";
			this.btnGlobalDataFeedSetting.UseVisualStyleBackColor = true;
			this.btnGlobalDataFeedSetting.Click += new System.EventHandler(this.btnGlobalDataFeedSetting_Click);
			// 
			// chkInputFileTSOptions
			// 
			this.chkInputFileTSOptions.AutoSize = true;
			this.chkInputFileTSOptions.Location = new System.Drawing.Point(20, 276);
			this.chkInputFileTSOptions.Name = "chkInputFileTSOptions";
			this.chkInputFileTSOptions.Size = new System.Drawing.Size(152, 17);
			this.chkInputFileTSOptions.TabIndex = 78;
			this.chkInputFileTSOptions.Text = "INPUT-FILE-TS-OPTIONS";
			this.chkInputFileTSOptions.UseVisualStyleBackColor = true;
			// 
			// panelLocalDataFeedSetting
			// 
			this.panelLocalDataFeedSetting.Controls.Add(this.lblLocalDataFolder);
			this.panelLocalDataFeedSetting.Controls.Add(this.btnBrowseLocalDataFolder);
			this.panelLocalDataFeedSetting.Controls.Add(this.txtLocalDataFolder);
			this.panelLocalDataFeedSetting.Location = new System.Drawing.Point(262, 14);
			this.panelLocalDataFeedSetting.Name = "panelLocalDataFeedSetting";
			this.panelLocalDataFeedSetting.Size = new System.Drawing.Size(293, 30);
			this.panelLocalDataFeedSetting.TabIndex = 77;
			// 
			// lblLocalDataFolder
			// 
			this.lblLocalDataFolder.AutoSize = true;
			this.lblLocalDataFolder.Location = new System.Drawing.Point(4, 11);
			this.lblLocalDataFolder.Name = "lblLocalDataFolder";
			this.lblLocalDataFolder.Size = new System.Drawing.Size(67, 13);
			this.lblLocalDataFolder.TabIndex = 79;
			this.lblLocalDataFolder.Text = "Data Source";
			// 
			// btnBrowseLocalDataFolder
			// 
			this.btnBrowseLocalDataFolder.Location = new System.Drawing.Point(262, 6);
			this.btnBrowseLocalDataFolder.Name = "btnBrowseLocalDataFolder";
			this.btnBrowseLocalDataFolder.Size = new System.Drawing.Size(27, 22);
			this.btnBrowseLocalDataFolder.TabIndex = 78;
			this.btnBrowseLocalDataFolder.Text = "...";
			this.btnBrowseLocalDataFolder.UseVisualStyleBackColor = true;
			this.btnBrowseLocalDataFolder.Click += new System.EventHandler(this.btnBrowseLocalDataFolder_Click);
			// 
			// txtLocalDataFolder
			// 
			this.txtLocalDataFolder.Location = new System.Drawing.Point(73, 7);
			this.txtLocalDataFolder.Name = "txtLocalDataFolder";
			this.txtLocalDataFolder.Size = new System.Drawing.Size(189, 20);
			this.txtLocalDataFolder.TabIndex = 77;
			// 
			// panelPolygonDataFeedSetting
			// 
			this.panelPolygonDataFeedSetting.Controls.Add(this.lblPolygonKey);
			this.panelPolygonDataFeedSetting.Controls.Add(this.txtPolygonAPIKey);
			this.panelPolygonDataFeedSetting.Location = new System.Drawing.Point(275, 13);
			this.panelPolygonDataFeedSetting.Name = "panelPolygonDataFeedSetting";
			this.panelPolygonDataFeedSetting.Size = new System.Drawing.Size(282, 29);
			this.panelPolygonDataFeedSetting.TabIndex = 72;
			// 
			// lblPolygonKey
			// 
			this.lblPolygonKey.AutoSize = true;
			this.lblPolygonKey.Location = new System.Drawing.Point(10, 10);
			this.lblPolygonKey.Name = "lblPolygonKey";
			this.lblPolygonKey.Size = new System.Drawing.Size(45, 13);
			this.lblPolygonKey.TabIndex = 67;
			this.lblPolygonKey.Text = "API Key";
			// 
			// txtPolygonAPIKey
			// 
			this.txtPolygonAPIKey.Location = new System.Drawing.Point(57, 5);
			this.txtPolygonAPIKey.Name = "txtPolygonAPIKey";
			this.txtPolygonAPIKey.Size = new System.Drawing.Size(210, 20);
			this.txtPolygonAPIKey.TabIndex = 68;
			// 
			// label20
			// 
			this.label20.AutoSize = true;
			this.label20.Location = new System.Drawing.Point(446, 115);
			this.label20.Name = "label20";
			this.label20.Size = new System.Drawing.Size(26, 13);
			this.label20.TabIndex = 70;
			this.label20.Text = "Sort";
			// 
			// cmbSort
			// 
			this.cmbSort.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cmbSort.FormattingEnabled = true;
			this.cmbSort.Items.AddRange(new object[] {
            "asc",
            "desc"});
			this.cmbSort.Location = new System.Drawing.Point(478, 113);
			this.cmbSort.Name = "cmbSort";
			this.cmbSort.Size = new System.Drawing.Size(79, 21);
			this.cmbSort.TabIndex = 71;
			// 
			// chkRoundVol
			// 
			this.chkRoundVol.AutoSize = true;
			this.chkRoundVol.Location = new System.Drawing.Point(418, 305);
			this.chkRoundVol.Name = "chkRoundVol";
			this.chkRoundVol.Size = new System.Drawing.Size(41, 17);
			this.chkRoundVol.TabIndex = 64;
			this.chkRoundVol.Text = "Vol";
			this.chkRoundVol.UseVisualStyleBackColor = true;
			// 
			// chkRoundClose
			// 
			this.chkRoundClose.AutoSize = true;
			this.chkRoundClose.Location = new System.Drawing.Point(318, 305);
			this.chkRoundClose.Name = "chkRoundClose";
			this.chkRoundClose.Size = new System.Drawing.Size(52, 17);
			this.chkRoundClose.TabIndex = 63;
			this.chkRoundClose.Text = "Close";
			this.chkRoundClose.UseVisualStyleBackColor = true;
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(259, 116);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(61, 13);
			this.label5.TabIndex = 68;
			this.label5.Text = "Unadjusted";
			// 
			// chkRoundChange
			// 
			this.chkRoundChange.AutoSize = true;
			this.chkRoundChange.Location = new System.Drawing.Point(223, 306);
			this.chkRoundChange.Name = "chkRoundChange";
			this.chkRoundChange.Size = new System.Drawing.Size(63, 17);
			this.chkRoundChange.TabIndex = 62;
			this.chkRoundChange.Text = "Change";
			this.chkRoundChange.UseVisualStyleBackColor = true;
			// 
			// cmbUnadjusted
			// 
			this.cmbUnadjusted.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cmbUnadjusted.FormattingEnabled = true;
			this.cmbUnadjusted.Items.AddRange(new object[] {
            "False",
            "True"});
			this.cmbUnadjusted.Location = new System.Drawing.Point(330, 112);
			this.cmbUnadjusted.Name = "cmbUnadjusted";
			this.cmbUnadjusted.Size = new System.Drawing.Size(79, 21);
			this.cmbUnadjusted.TabIndex = 69;
			// 
			// txtMultiplier
			// 
			this.txtMultiplier.Location = new System.Drawing.Point(330, 79);
			this.txtMultiplier.Name = "txtMultiplier";
			this.txtMultiplier.Size = new System.Drawing.Size(79, 20);
			this.txtMultiplier.TabIndex = 66;
			// 
			// txtRounding
			// 
			this.txtRounding.Location = new System.Drawing.Point(117, 303);
			this.txtRounding.Name = "txtRounding";
			this.txtRounding.Size = new System.Drawing.Size(63, 20);
			this.txtRounding.TabIndex = 61;
			// 
			// label19
			// 
			this.label19.AutoSize = true;
			this.label19.Location = new System.Drawing.Point(16, 307);
			this.label19.Name = "label19";
			this.label19.Size = new System.Drawing.Size(75, 13);
			this.label19.TabIndex = 60;
			this.label19.Text = "Use Rounding";
			// 
			// lblMultiplier
			// 
			this.lblMultiplier.AutoSize = true;
			this.lblMultiplier.Location = new System.Drawing.Point(259, 82);
			this.lblMultiplier.Name = "lblMultiplier";
			this.lblMultiplier.Size = new System.Drawing.Size(48, 13);
			this.lblMultiplier.TabIndex = 67;
			this.lblMultiplier.Text = "Multiplier";
			// 
			// dtEndDate
			// 
			this.dtEndDate.CustomFormat = "MM/dd/yyyy";
			this.dtEndDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			this.dtEndDate.Location = new System.Drawing.Point(268, 145);
			this.dtEndDate.Name = "dtEndDate";
			this.dtEndDate.Size = new System.Drawing.Size(90, 20);
			this.dtEndDate.TabIndex = 66;
			// 
			// dtStartDate
			// 
			this.dtStartDate.CustomFormat = "MM/dd/yyyy";
			this.dtStartDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			this.dtStartDate.Location = new System.Drawing.Point(139, 145);
			this.dtStartDate.Name = "dtStartDate";
			this.dtStartDate.Size = new System.Drawing.Size(90, 20);
			this.dtStartDate.TabIndex = 65;
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Location = new System.Drawing.Point(240, 150);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(14, 13);
			this.label6.TabIndex = 63;
			this.label6.Text = "~";
			// 
			// label12
			// 
			this.label12.AutoSize = true;
			this.label12.Location = new System.Drawing.Point(89, 150);
			this.label12.Name = "label12";
			this.label12.Size = new System.Drawing.Size(30, 13);
			this.label12.TabIndex = 62;
			this.label12.Text = "Date";
			// 
			// label8
			// 
			this.label8.AutoSize = true;
			this.label8.Location = new System.Drawing.Point(28, 24);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(91, 13);
			this.label8.TabIndex = 59;
			this.label8.Text = "Primary DataFeed";
			// 
			// cmbDataFeedType
			// 
			this.cmbDataFeedType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cmbDataFeedType.FormattingEnabled = true;
			this.cmbDataFeedType.Items.AddRange(new object[] {
            "Alpaca V1",
            "Alpaca V2",
            "Polygon.IO V2",
            "TradeStation",
            "GlobaDataFeed",
            "TwelveData",
            "Tradier",
            "TDAmeritrade",
            "Local Data"});
			this.cmbDataFeedType.Location = new System.Drawing.Point(140, 19);
			this.cmbDataFeedType.Name = "cmbDataFeedType";
			this.cmbDataFeedType.Size = new System.Drawing.Size(100, 21);
			this.cmbDataFeedType.TabIndex = 58;
			this.cmbDataFeedType.SelectedIndexChanged += new System.EventHandler(this.cmbDataFeedType_SelectedIndexChanged);
			// 
			// label7
			// 
			this.label7.AutoSize = true;
			this.label7.Location = new System.Drawing.Point(240, 182);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(14, 13);
			this.label7.TabIndex = 57;
			this.label7.Text = "~";
			// 
			// cmbTimeFrame
			// 
			this.cmbTimeFrame.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cmbTimeFrame.FormattingEnabled = true;
			this.cmbTimeFrame.Location = new System.Drawing.Point(140, 79);
			this.cmbTimeFrame.Name = "cmbTimeFrame";
			this.cmbTimeFrame.Size = new System.Drawing.Size(89, 21);
			this.cmbTimeFrame.TabIndex = 56;
			this.cmbTimeFrame.SelectedIndexChanged += new System.EventHandler(this.cmbTimeFrame_SelectedIndexChanged);
			// 
			// txtDelay
			// 
			this.txtDelay.Location = new System.Drawing.Point(478, 49);
			this.txtDelay.Name = "txtDelay";
			this.txtDelay.Size = new System.Drawing.Size(79, 20);
			this.txtDelay.TabIndex = 54;
			// 
			// label18
			// 
			this.label18.AutoSize = true;
			this.label18.Location = new System.Drawing.Point(415, 54);
			this.label18.Name = "label18";
			this.label18.Size = new System.Drawing.Size(57, 13);
			this.label18.TabIndex = 53;
			this.label18.Text = "Delay(sec)";
			// 
			// btnROutputSettings
			// 
			this.btnROutputSettings.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
			this.btnROutputSettings.Location = new System.Drawing.Point(410, 236);
			this.btnROutputSettings.Name = "btnROutputSettings";
			this.btnROutputSettings.Size = new System.Drawing.Size(147, 29);
			this.btnROutputSettings.TabIndex = 52;
			this.btnROutputSettings.Text = "R File Output Settings";
			this.btnROutputSettings.UseVisualStyleBackColor = true;
			this.btnROutputSettings.Click += new System.EventHandler(this.btnRConfig_Click);
			// 
			// chkROutput
			// 
			this.chkROutput.AutoSize = true;
			this.chkROutput.Location = new System.Drawing.Point(319, 245);
			this.chkROutput.Name = "chkROutput";
			this.chkROutput.Size = new System.Drawing.Size(93, 17);
			this.chkROutput.TabIndex = 51;
			this.chkROutput.Text = "Output R Files";
			this.chkROutput.UseVisualStyleBackColor = true;
			this.chkROutput.CheckedChanged += new System.EventHandler(this.chkROutput_CheckedChanged);
			// 
			// chkBackfillUpdate
			// 
			this.chkBackfillUpdate.AutoSize = true;
			this.chkBackfillUpdate.Location = new System.Drawing.Point(175, 247);
			this.chkBackfillUpdate.Name = "chkBackfillUpdate";
			this.chkBackfillUpdate.Size = new System.Drawing.Size(98, 17);
			this.chkBackfillUpdate.TabIndex = 49;
			this.chkBackfillUpdate.Text = "Backfill Update";
			this.chkBackfillUpdate.UseVisualStyleBackColor = true;
			// 
			// chkCalendarAutoStart
			// 
			this.chkCalendarAutoStart.AutoSize = true;
			this.chkCalendarAutoStart.Location = new System.Drawing.Point(20, 246);
			this.chkCalendarAutoStart.Name = "chkCalendarAutoStart";
			this.chkCalendarAutoStart.Size = new System.Drawing.Size(133, 17);
			this.chkCalendarAutoStart.TabIndex = 46;
			this.chkCalendarAutoStart.Text = "Auto Start By Calendar";
			this.chkCalendarAutoStart.UseVisualStyleBackColor = true;
			this.chkCalendarAutoStart.CheckedChanged += new System.EventHandler(this.chkCalendarAutoStart_CheckedChanged);
			// 
			// radioCO
			// 
			this.radioCO.AutoCheck = false;
			this.radioCO.AutoSize = true;
			this.radioCO.Location = new System.Drawing.Point(374, 213);
			this.radioCO.Name = "radioCO";
			this.radioCO.Size = new System.Drawing.Size(101, 17);
			this.radioCO.TabIndex = 44;
			this.radioCO.Text = "C > O OR C < O";
			this.radioCO.UseVisualStyleBackColor = true;
			this.radioCO.Click += new System.EventHandler(this.radioHL_Click);
			// 
			// radioHL
			// 
			this.radioHL.AutoCheck = false;
			this.radioHL.AutoSize = true;
			this.radioHL.Location = new System.Drawing.Point(319, 213);
			this.radioHL.Name = "radioHL";
			this.radioHL.Size = new System.Drawing.Size(39, 17);
			this.radioHL.TabIndex = 33;
			this.radioHL.Text = "HL";
			this.radioHL.UseVisualStyleBackColor = true;
			this.radioHL.Click += new System.EventHandler(this.radioHL_Click);
			// 
			// radioOHLC
			// 
			this.radioOHLC.AutoCheck = false;
			this.radioOHLC.AutoSize = true;
			this.radioOHLC.Location = new System.Drawing.Point(250, 214);
			this.radioOHLC.Name = "radioOHLC";
			this.radioOHLC.Size = new System.Drawing.Size(54, 17);
			this.radioOHLC.TabIndex = 32;
			this.radioOHLC.Text = "OHLC";
			this.radioOHLC.UseVisualStyleBackColor = true;
			this.radioOHLC.Click += new System.EventHandler(this.radioHL_Click);
			// 
			// radioHLC
			// 
			this.radioHLC.AutoCheck = false;
			this.radioHLC.AutoSize = true;
			this.radioHLC.Location = new System.Drawing.Point(175, 214);
			this.radioHLC.Name = "radioHLC";
			this.radioHLC.Size = new System.Drawing.Size(46, 17);
			this.radioHLC.TabIndex = 31;
			this.radioHLC.Text = "HLC";
			this.radioHLC.UseVisualStyleBackColor = true;
			this.radioHLC.Click += new System.EventHandler(this.radioHL_Click);
			// 
			// chkCloseBarUpdate
			// 
			this.chkCloseBarUpdate.AutoSize = true;
			this.chkCloseBarUpdate.Location = new System.Drawing.Point(20, 215);
			this.chkCloseBarUpdate.Name = "chkCloseBarUpdate";
			this.chkCloseBarUpdate.Size = new System.Drawing.Size(103, 17);
			this.chkCloseBarUpdate.TabIndex = 40;
			this.chkCloseBarUpdate.Text = "CloseBarUpdate";
			this.chkCloseBarUpdate.UseVisualStyleBackColor = true;
			this.chkCloseBarUpdate.CheckedChanged += new System.EventHandler(this.chkCloseBarUpdate_CheckedChanged);
			// 
			// chkAppendData
			// 
			this.chkAppendData.AutoSize = true;
			this.chkAppendData.Location = new System.Drawing.Point(310, 52);
			this.chkAppendData.Name = "chkAppendData";
			this.chkAppendData.Size = new System.Drawing.Size(89, 17);
			this.chkAppendData.TabIndex = 39;
			this.chkAppendData.Text = "Append Data";
			this.chkAppendData.UseVisualStyleBackColor = true;
			// 
			// label10
			// 
			this.label10.AutoSize = true;
			this.label10.Location = new System.Drawing.Point(51, 183);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(68, 13);
			this.label10.TabIndex = 33;
			this.label10.Text = "MarketHours";
			// 
			// radioProcessAuto
			// 
			this.radioProcessAuto.AutoCheck = false;
			this.radioProcessAuto.AutoSize = true;
			this.radioProcessAuto.Location = new System.Drawing.Point(212, 52);
			this.radioProcessAuto.Name = "radioProcessAuto";
			this.radioProcessAuto.Size = new System.Drawing.Size(85, 17);
			this.radioProcessAuto.TabIndex = 32;
			this.radioProcessAuto.Text = "Auto Update";
			this.radioProcessAuto.UseVisualStyleBackColor = true;
			this.radioProcessAuto.CheckedChanged += new System.EventHandler(this.radioProcessAuto_CheckedChanged);
			this.radioProcessAuto.Click += new System.EventHandler(this.radioProcessStatic_Click);
			// 
			// radioProcessStatic
			// 
			this.radioProcessStatic.AutoCheck = false;
			this.radioProcessStatic.AutoSize = true;
			this.radioProcessStatic.Checked = true;
			this.radioProcessStatic.Location = new System.Drawing.Point(140, 53);
			this.radioProcessStatic.Name = "radioProcessStatic";
			this.radioProcessStatic.Size = new System.Drawing.Size(52, 17);
			this.radioProcessStatic.TabIndex = 31;
			this.radioProcessStatic.TabStop = true;
			this.radioProcessStatic.Text = "Static";
			this.radioProcessStatic.UseVisualStyleBackColor = true;
			this.radioProcessStatic.CheckedChanged += new System.EventHandler(this.radioProcessStatic_CheckedChanged);
			this.radioProcessStatic.Click += new System.EventHandler(this.radioProcessStatic_Click);
			// 
			// label9
			// 
			this.label9.AutoSize = true;
			this.label9.Location = new System.Drawing.Point(50, 54);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(72, 13);
			this.label9.TabIndex = 30;
			this.label9.Text = "Process Type";
			// 
			// chkMarketHoursOnly
			// 
			this.chkMarketHoursOnly.AutoSize = true;
			this.chkMarketHoursOnly.Location = new System.Drawing.Point(419, 181);
			this.chkMarketHoursOnly.Name = "chkMarketHoursOnly";
			this.chkMarketHoursOnly.Size = new System.Drawing.Size(137, 17);
			this.chkMarketHoursOnly.TabIndex = 27;
			this.chkMarketHoursOnly.Text = "MarketHours Data Only";
			this.chkMarketHoursOnly.UseVisualStyleBackColor = true;
			this.chkMarketHoursOnly.CheckedChanged += new System.EventHandler(this.chkMarketHoursOnly_CheckedChanged);
			// 
			// dateTimeEnd
			// 
			this.dateTimeEnd.CustomFormat = "hh:mm tt";
			this.dateTimeEnd.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			this.dateTimeEnd.Location = new System.Drawing.Point(268, 178);
			this.dateTimeEnd.Name = "dateTimeEnd";
			this.dateTimeEnd.ShowUpDown = true;
			this.dateTimeEnd.Size = new System.Drawing.Size(90, 20);
			this.dateTimeEnd.TabIndex = 26;
			this.dateTimeEnd.Value = new System.DateTime(2020, 6, 2, 16, 0, 0, 0);
			// 
			// dateTimeStart
			// 
			this.dateTimeStart.CustomFormat = "hh:mm tt";
			this.dateTimeStart.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			this.dateTimeStart.Location = new System.Drawing.Point(139, 179);
			this.dateTimeStart.Name = "dateTimeStart";
			this.dateTimeStart.ShowUpDown = true;
			this.dateTimeStart.Size = new System.Drawing.Size(90, 20);
			this.dateTimeStart.TabIndex = 25;
			this.dateTimeStart.Value = new System.DateTime(2020, 6, 2, 9, 30, 0, 0);
			// 
			// txtBars
			// 
			this.txtBars.Location = new System.Drawing.Point(139, 112);
			this.txtBars.Name = "txtBars";
			this.txtBars.Size = new System.Drawing.Size(90, 20);
			this.txtBars.TabIndex = 23;
			this.txtBars.TextChanged += new System.EventHandler(this.txtBars_TextChanged);
			// 
			// lblBarLimit
			// 
			this.lblBarLimit.AutoSize = true;
			this.lblBarLimit.Location = new System.Drawing.Point(29, 115);
			this.lblBarLimit.Name = "lblBarLimit";
			this.lblBarLimit.Size = new System.Drawing.Size(91, 13);
			this.lblBarLimit.TabIndex = 22;
			this.lblBarLimit.Text = "#Bar(100 ~ 1000)";
			// 
			// lblTimeFrame
			// 
			this.lblTimeFrame.AutoSize = true;
			this.lblTimeFrame.Location = new System.Drawing.Point(61, 82);
			this.lblTimeFrame.Name = "lblTimeFrame";
			this.lblTimeFrame.Size = new System.Drawing.Size(59, 13);
			this.lblTimeFrame.TabIndex = 0;
			this.lblTimeFrame.Text = "TimeFrame";
			// 
			// statusStrip1
			// 
			this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lblProcessStatus,
            this.statusProgressBar});
			this.statusStrip1.Location = new System.Drawing.Point(0, 733);
			this.statusStrip1.Name = "statusStrip1";
			this.statusStrip1.Size = new System.Drawing.Size(599, 22);
			this.statusStrip1.SizingGrip = false;
			this.statusStrip1.TabIndex = 51;
			this.statusStrip1.Text = "statusStrip1";
			// 
			// lblProcessStatus
			// 
			this.lblProcessStatus.Name = "lblProcessStatus";
			this.lblProcessStatus.Size = new System.Drawing.Size(584, 17);
			this.lblProcessStatus.Spring = true;
			// 
			// statusProgressBar
			// 
			this.statusProgressBar.Name = "statusProgressBar";
			this.statusProgressBar.Size = new System.Drawing.Size(350, 16);
			this.statusProgressBar.Visible = false;
			// 
			// btnStopWebSocketUpdate
			// 
			this.btnStopWebSocketUpdate.Enabled = false;
			this.btnStopWebSocketUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
			this.btnStopWebSocketUpdate.Location = new System.Drawing.Point(397, 566);
			this.btnStopWebSocketUpdate.Name = "btnStopWebSocketUpdate";
			this.btnStopWebSocketUpdate.Size = new System.Drawing.Size(188, 28);
			this.btnStopWebSocketUpdate.TabIndex = 53;
			this.btnStopWebSocketUpdate.Text = "Stop WebSocket Update";
			this.btnStopWebSocketUpdate.UseVisualStyleBackColor = true;
			this.btnStopWebSocketUpdate.Click += new System.EventHandler(this.btnStopWebSocketUpdate_Click);
			// 
			// btnStartWebSocketUpdate
			// 
			this.btnStartWebSocketUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
			this.btnStartWebSocketUpdate.Location = new System.Drawing.Point(205, 566);
			this.btnStartWebSocketUpdate.Name = "btnStartWebSocketUpdate";
			this.btnStartWebSocketUpdate.Size = new System.Drawing.Size(188, 28);
			this.btnStartWebSocketUpdate.TabIndex = 52;
			this.btnStartWebSocketUpdate.Text = "Start WebSocket Update";
			this.btnStartWebSocketUpdate.UseVisualStyleBackColor = true;
			this.btnStartWebSocketUpdate.Click += new System.EventHandler(this.btnStartWebSocketUpdate_Click);
			// 
			// lblSocketState
			// 
			this.lblSocketState.AutoSize = true;
			this.lblSocketState.Location = new System.Drawing.Point(196, 720);
			this.lblSocketState.Name = "lblSocketState";
			this.lblSocketState.Size = new System.Drawing.Size(175, 13);
			this.lblSocketState.TabIndex = 54;
			this.lblSocketState.Text = "WebSocket Stream : Disconnected";
			// 
			// btnGenerateCal
			// 
			this.btnGenerateCal.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
			this.btnGenerateCal.Location = new System.Drawing.Point(397, 533);
			this.btnGenerateCal.Name = "btnGenerateCal";
			this.btnGenerateCal.Size = new System.Drawing.Size(188, 28);
			this.btnGenerateCal.TabIndex = 55;
			this.btnGenerateCal.Text = "Generate Calendar File";
			this.btnGenerateCal.UseVisualStyleBackColor = true;
			this.btnGenerateCal.Click += new System.EventHandler(this.btnGenerateCal_Click);
			// 
			// btnTrimInputData
			// 
			this.btnTrimInputData.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
			this.btnTrimInputData.Location = new System.Drawing.Point(13, 533);
			this.btnTrimInputData.Name = "btnTrimInputData";
			this.btnTrimInputData.Size = new System.Drawing.Size(188, 28);
			this.btnTrimInputData.TabIndex = 56;
			this.btnTrimInputData.Text = "TRIM INPUT DATA(PER R)";
			this.btnTrimInputData.UseVisualStyleBackColor = true;
			this.btnTrimInputData.Click += new System.EventHandler(this.btnTrimInputData_Click);
			// 
			// btnGenSectorFile
			// 
			this.btnGenSectorFile.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
			this.btnGenSectorFile.Location = new System.Drawing.Point(13, 632);
			this.btnGenSectorFile.Name = "btnGenSectorFile";
			this.btnGenSectorFile.Size = new System.Drawing.Size(188, 28);
			this.btnGenSectorFile.TabIndex = 57;
			this.btnGenSectorFile.Text = "Gen-Sector-Files";
			this.btnGenSectorFile.UseVisualStyleBackColor = true;
			this.btnGenSectorFile.Click += new System.EventHandler(this.btnGenSectorFile_Click);
			// 
			// btnCleanTree
			// 
			this.btnCleanTree.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
			this.btnCleanTree.Location = new System.Drawing.Point(205, 500);
			this.btnCleanTree.Name = "btnCleanTree";
			this.btnCleanTree.Size = new System.Drawing.Size(188, 28);
			this.btnCleanTree.TabIndex = 49;
			this.btnCleanTree.Text = "Clean Tree File";
			this.btnCleanTree.UseVisualStyleBackColor = true;
			this.btnCleanTree.Click += new System.EventHandler(this.btnCleanTree_Click);
			// 
			// btnSidewayFilters
			// 
			this.btnSidewayFilters.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
			this.btnSidewayFilters.Location = new System.Drawing.Point(205, 533);
			this.btnSidewayFilters.Name = "btnSidewayFilters";
			this.btnSidewayFilters.Size = new System.Drawing.Size(188, 28);
			this.btnSidewayFilters.TabIndex = 59;
			this.btnSidewayFilters.Text = "Sideway Filters";
			this.btnSidewayFilters.UseVisualStyleBackColor = true;
			this.btnSidewayFilters.Click += new System.EventHandler(this.btnSidewayFilters_Click);
			// 
			// btnWebSocketSettings
			// 
			this.btnWebSocketSettings.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
			this.btnWebSocketSettings.Location = new System.Drawing.Point(13, 566);
			this.btnWebSocketSettings.Name = "btnWebSocketSettings";
			this.btnWebSocketSettings.Size = new System.Drawing.Size(188, 28);
			this.btnWebSocketSettings.TabIndex = 65;
			this.btnWebSocketSettings.Text = "WebSocket Settings";
			this.btnWebSocketSettings.UseVisualStyleBackColor = true;
			this.btnWebSocketSettings.Click += new System.EventHandler(this.btnWebSocketSettings_Click);
			// 
			// btnMarketView
			// 
			this.btnMarketView.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
			this.btnMarketView.Location = new System.Drawing.Point(397, 599);
			this.btnMarketView.Name = "btnMarketView";
			this.btnMarketView.Size = new System.Drawing.Size(188, 28);
			this.btnMarketView.TabIndex = 66;
			this.btnMarketView.Text = "MarketView";
			this.btnMarketView.UseVisualStyleBackColor = true;
			this.btnMarketView.Click += new System.EventHandler(this.btnMarketView_Click);
			// 
			// btnAWSSettings
			// 
			this.btnAWSSettings.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
			this.btnAWSSettings.Location = new System.Drawing.Point(205, 632);
			this.btnAWSSettings.Name = "btnAWSSettings";
			this.btnAWSSettings.Size = new System.Drawing.Size(188, 28);
			this.btnAWSSettings.TabIndex = 67;
			this.btnAWSSettings.Text = "AWS S3 Upload";
			this.btnAWSSettings.UseVisualStyleBackColor = true;
			this.btnAWSSettings.Click += new System.EventHandler(this.btnAWSSettings_Click);
			// 
			// btnCleanupStockList
			// 
			this.btnCleanupStockList.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
			this.btnCleanupStockList.Location = new System.Drawing.Point(205, 599);
			this.btnCleanupStockList.Name = "btnCleanupStockList";
			this.btnCleanupStockList.Size = new System.Drawing.Size(188, 28);
			this.btnCleanupStockList.TabIndex = 68;
			this.btnCleanupStockList.Text = "Cleanup StockList";
			this.btnCleanupStockList.UseVisualStyleBackColor = true;
			this.btnCleanupStockList.Click += new System.EventHandler(this.btnCleanupStockList_Click);
			// 
			// btnMiscSettings
			// 
			this.btnMiscSettings.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
			this.btnMiscSettings.Location = new System.Drawing.Point(397, 500);
			this.btnMiscSettings.Name = "btnMiscSettings";
			this.btnMiscSettings.Size = new System.Drawing.Size(188, 28);
			this.btnMiscSettings.TabIndex = 69;
			this.btnMiscSettings.Text = "Misc Settings";
			this.btnMiscSettings.UseVisualStyleBackColor = true;
			this.btnMiscSettings.Click += new System.EventHandler(this.btnMiscSettings_Click);
			// 
			// btnCleanStockListConfig
			// 
			this.btnCleanStockListConfig.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
			this.btnCleanStockListConfig.Location = new System.Drawing.Point(13, 599);
			this.btnCleanStockListConfig.Name = "btnCleanStockListConfig";
			this.btnCleanStockListConfig.Size = new System.Drawing.Size(188, 28);
			this.btnCleanStockListConfig.TabIndex = 70;
			this.btnCleanStockListConfig.Text = "Cleanup StockList Settings";
			this.btnCleanStockListConfig.UseVisualStyleBackColor = true;
			this.btnCleanStockListConfig.Click += new System.EventHandler(this.btnCleanStockListConfig_Click);
			// 
			// button1
			// 
			this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
			this.button1.Location = new System.Drawing.Point(397, 632);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(188, 28);
			this.button1.TabIndex = 71;
			this.button1.Text = "Pusher";
			this.button1.UseVisualStyleBackColor = true;
			this.button1.Click += new System.EventHandler(this.btnPusherSettings_Click);
			// 
			// btnSignalSettings
			// 
			this.btnSignalSettings.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
			this.btnSignalSettings.Location = new System.Drawing.Point(13, 665);
			this.btnSignalSettings.Name = "btnSignalSettings";
			this.btnSignalSettings.Size = new System.Drawing.Size(188, 28);
			this.btnSignalSettings.TabIndex = 72;
			this.btnSignalSettings.Text = "Signal Settings";
			this.btnSignalSettings.UseVisualStyleBackColor = true;
			this.btnSignalSettings.Click += new System.EventHandler(this.btnSignalSettings_Click);
			// 
			// FrmMain
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(599, 755);
			this.Controls.Add(this.btnSignalSettings);
			this.Controls.Add(this.button1);
			this.Controls.Add(this.btnCleanStockListConfig);
			this.Controls.Add(this.btnCleanTree);
			this.Controls.Add(this.btnTrimInputData);
			this.Controls.Add(this.btnMiscSettings);
			this.Controls.Add(this.btnCleanupStockList);
			this.Controls.Add(this.btnAWSSettings);
			this.Controls.Add(this.btnMarketView);
			this.Controls.Add(this.btnWebSocketSettings);
			this.Controls.Add(this.btnSidewayFilters);
			this.Controls.Add(this.btnGenSectorFile);
			this.Controls.Add(this.btnGenerateCal);
			this.Controls.Add(this.lblSocketState);
			this.Controls.Add(this.btnStopWebSocketUpdate);
			this.Controls.Add(this.btnStartWebSocketUpdate);
			this.Controls.Add(this.statusStrip1);
			this.Controls.Add(this.groupDataType);
			this.Controls.Add(this.btnExit);
			this.Controls.Add(this.btnStart);
			this.Controls.Add(this.groupGeneral);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.Name = "FrmMain";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Sri Alpaca Downloader V14";
			this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FrmMain_FormClosing);
			this.Load += new System.EventHandler(this.FrmMain_Load);
			this.groupGeneral.ResumeLayout(false);
			this.groupGeneral.PerformLayout();
			this.groupDataType.ResumeLayout(false);
			this.groupDataType.PerformLayout();
			this.panelDatafeedSetting.ResumeLayout(false);
			this.panelLocalDataFeedSetting.ResumeLayout(false);
			this.panelLocalDataFeedSetting.PerformLayout();
			this.panelPolygonDataFeedSetting.ResumeLayout(false);
			this.panelPolygonDataFeedSetting.PerformLayout();
			this.statusStrip1.ResumeLayout(false);
			this.statusStrip1.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.RadioButton radioPaper;
		private System.Windows.Forms.RadioButton radioLive;
		private System.Windows.Forms.TextBox txtLiveKey;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox txtLiveSecretKey;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Button btnBrowseInputDataPath;
		private System.Windows.Forms.TextBox txtOutputDataPath;
		private System.Windows.Forms.Label label11;
		private System.Windows.Forms.GroupBox groupGeneral;
		private System.Windows.Forms.Button btnStart;
		private System.Windows.Forms.Button btnExit;
		private System.Windows.Forms.Timer timerUpdate;
		private System.Windows.Forms.TextBox txtPaperSecretKey;
		private System.Windows.Forms.TextBox txtPaperKey;
		private System.Windows.Forms.Button btnBrowseSymbolList;
		private System.Windows.Forms.TextBox txtSymbolListFile;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.GroupBox groupDataType;
		private System.Windows.Forms.Label lblTimeFrame;
		private System.Windows.Forms.TextBox txtBars;
		private System.Windows.Forms.Label lblBarLimit;
		private System.Windows.Forms.StatusStrip statusStrip1;
		private System.Windows.Forms.ToolStripStatusLabel lblProcessStatus;
		private System.Windows.Forms.ToolStripProgressBar statusProgressBar;
		private System.Windows.Forms.CheckBox chkMarketHoursOnly;
		private System.Windows.Forms.DateTimePicker dateTimeEnd;
		private System.Windows.Forms.DateTimePicker dateTimeStart;
		private System.Windows.Forms.RadioButton radioProcessAuto;
		private System.Windows.Forms.RadioButton radioProcessStatic;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.Label label10;
		private System.Windows.Forms.Button btnStopWebSocketUpdate;
		private System.Windows.Forms.Button btnStartWebSocketUpdate;
		private System.Windows.Forms.CheckBox chkAppendData;
		private System.Windows.Forms.RadioButton radioCO;
		private System.Windows.Forms.RadioButton radioHL;
		private System.Windows.Forms.RadioButton radioOHLC;
		private System.Windows.Forms.RadioButton radioHLC;
		private System.Windows.Forms.CheckBox chkCloseBarUpdate;
		private System.Windows.Forms.Label lblSocketState;
		private System.Windows.Forms.Button btnGenerateCal;
		private System.Windows.Forms.CheckBox chkBackfillUpdate;
		private System.Windows.Forms.Button btnROutputSettings;
		private System.Windows.Forms.CheckBox chkROutput;
		private System.Windows.Forms.Button btnTrimInputData;
		private System.Windows.Forms.Button btnGenSectorFile;
		private System.Windows.Forms.Button btnCleanTree;
		private System.Windows.Forms.TextBox txtDelay;
		private System.Windows.Forms.Label label18;
		private System.Windows.Forms.Button btnSidewayFilters;
		private System.Windows.Forms.Label label19;
		private System.Windows.Forms.TextBox txtRounding;
		private System.Windows.Forms.CheckBox chkRoundChange;
		private System.Windows.Forms.CheckBox chkRoundClose;
		private System.Windows.Forms.CheckBox chkRoundVol;
		private System.Windows.Forms.CheckBox chkCalendarAutoStart;
		private System.Windows.Forms.Button btnWebSocketSettings;
		private System.Windows.Forms.ComboBox chkPlan;
		private System.Windows.Forms.ComboBox cmbTimeFrame;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.ComboBox cmbDataFeedType;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label12;
		private System.Windows.Forms.DateTimePicker dtEndDate;
		private System.Windows.Forms.DateTimePicker dtStartDate;
		private System.Windows.Forms.Label lblMultiplier;
		private System.Windows.Forms.TextBox txtMultiplier;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.ComboBox cmbUnadjusted;
		private System.Windows.Forms.Label label20;
		private System.Windows.Forms.ComboBox cmbSort;
		private System.Windows.Forms.Panel panelLocalDataFeedSetting;
		private System.Windows.Forms.Label lblLocalDataFolder;
		private System.Windows.Forms.Button btnBrowseLocalDataFolder;
		private System.Windows.Forms.TextBox txtLocalDataFolder;
		private System.Windows.Forms.Button btnRefreshToken;
		private System.Windows.Forms.Panel panelPolygonDataFeedSetting;
		private System.Windows.Forms.Label lblPolygonKey;
		private System.Windows.Forms.TextBox txtPolygonAPIKey;
		private System.Windows.Forms.Panel panelDatafeedSetting;
		private System.Windows.Forms.Button btnGlobalDataFeedSetting;
		private System.Windows.Forms.Button btnMarketView;
		private System.Windows.Forms.CheckBox chkTSOHLCV;
		private System.Windows.Forms.CheckBox chkInputFileTSOptions;
		private System.Windows.Forms.Button btnAWSSettings;
		private System.Windows.Forms.Button btnCleanupStockList;
		private System.Windows.Forms.Button btnMiscSettings;
		private System.Windows.Forms.Button btnCleanStockListConfig;
		private System.Windows.Forms.Button btnTest;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Button btnSignalSettings;
	}
}

