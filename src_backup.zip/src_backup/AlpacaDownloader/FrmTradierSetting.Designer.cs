﻿
namespace SriAlpacaDL
{
	partial class FrmTradierSetting
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.label1 = new System.Windows.Forms.Label();
			this.txtAPIKey = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.txtRateLimit = new System.Windows.Forms.TextBox();
			this.label4 = new System.Windows.Forms.Label();
			this.cmbAPICallType = new System.Windows.Forms.ComboBox();
			this.btnOK = new System.Windows.Forms.Button();
			this.btnCancel = new System.Windows.Forms.Button();
			this.cmbSessionFilter = new System.Windows.Forms.ComboBox();
			this.lblSessionFilter = new System.Windows.Forms.Label();
			this.cmbUrl = new System.Windows.Forms.ComboBox();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(71, 21);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(29, 13);
			this.label1.TabIndex = 0;
			this.label1.Text = "URL";
			// 
			// txtAPIKey
			// 
			this.txtAPIKey.Location = new System.Drawing.Point(121, 52);
			this.txtAPIKey.Name = "txtAPIKey";
			this.txtAPIKey.Size = new System.Drawing.Size(235, 20);
			this.txtAPIKey.TabIndex = 3;
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(52, 55);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(48, 13);
			this.label2.TabIndex = 2;
			this.label2.Text = "API KEY";
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(46, 90);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(54, 13);
			this.label3.TabIndex = 4;
			this.label3.Text = "Rate Limit";
			// 
			// txtRateLimit
			// 
			this.txtRateLimit.Location = new System.Drawing.Point(121, 86);
			this.txtRateLimit.Name = "txtRateLimit";
			this.txtRateLimit.Size = new System.Drawing.Size(121, 20);
			this.txtRateLimit.TabIndex = 5;
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(17, 124);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(83, 13);
			this.label4.TabIndex = 6;
			this.label4.Text = "Type of API Call";
			// 
			// cmbAPICallType
			// 
			this.cmbAPICallType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cmbAPICallType.FormattingEnabled = true;
			this.cmbAPICallType.Items.AddRange(new object[] {
            "Time&Sales",
            "Historical"});
			this.cmbAPICallType.Location = new System.Drawing.Point(121, 120);
			this.cmbAPICallType.Name = "cmbAPICallType";
			this.cmbAPICallType.Size = new System.Drawing.Size(121, 21);
			this.cmbAPICallType.TabIndex = 7;
			this.cmbAPICallType.SelectedIndexChanged += new System.EventHandler(this.cmbAPICallType_SelectedIndexChanged);
			// 
			// btnOK
			// 
			this.btnOK.Location = new System.Drawing.Point(188, 193);
			this.btnOK.Name = "btnOK";
			this.btnOK.Size = new System.Drawing.Size(75, 26);
			this.btnOK.TabIndex = 8;
			this.btnOK.Text = "OK";
			this.btnOK.UseVisualStyleBackColor = true;
			this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
			// 
			// btnCancel
			// 
			this.btnCancel.Location = new System.Drawing.Point(281, 193);
			this.btnCancel.Name = "btnCancel";
			this.btnCancel.Size = new System.Drawing.Size(75, 26);
			this.btnCancel.TabIndex = 9;
			this.btnCancel.Text = "Cancel";
			this.btnCancel.UseVisualStyleBackColor = true;
			this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
			// 
			// cmbSessionFilter
			// 
			this.cmbSessionFilter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cmbSessionFilter.FormattingEnabled = true;
			this.cmbSessionFilter.Items.AddRange(new object[] {
            "MarketHours(Open)",
            "AllData(all)"});
			this.cmbSessionFilter.Location = new System.Drawing.Point(121, 156);
			this.cmbSessionFilter.Name = "cmbSessionFilter";
			this.cmbSessionFilter.Size = new System.Drawing.Size(121, 21);
			this.cmbSessionFilter.TabIndex = 11;
			// 
			// lblSessionFilter
			// 
			this.lblSessionFilter.AutoSize = true;
			this.lblSessionFilter.Location = new System.Drawing.Point(31, 159);
			this.lblSessionFilter.Name = "lblSessionFilter";
			this.lblSessionFilter.Size = new System.Drawing.Size(69, 13);
			this.lblSessionFilter.TabIndex = 10;
			this.lblSessionFilter.Text = "Session Filter";
			// 
			// cmbUrl
			// 
			this.cmbUrl.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cmbUrl.FormattingEnabled = true;
			this.cmbUrl.Items.AddRange(new object[] {
            "https://api.tradier.com/v1/",
            "https://sandbox.tradier.com/v1/"});
			this.cmbUrl.Location = new System.Drawing.Point(121, 18);
			this.cmbUrl.Name = "cmbUrl";
			this.cmbUrl.Size = new System.Drawing.Size(235, 21);
			this.cmbUrl.TabIndex = 12;
			// 
			// FrmTradierSetting
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(376, 231);
			this.Controls.Add(this.cmbUrl);
			this.Controls.Add(this.cmbSessionFilter);
			this.Controls.Add(this.lblSessionFilter);
			this.Controls.Add(this.btnCancel);
			this.Controls.Add(this.btnOK);
			this.Controls.Add(this.cmbAPICallType);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.txtRateLimit);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.txtAPIKey);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Name = "FrmTradierSetting";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Tradier Settings";
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox txtAPIKey;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.TextBox txtRateLimit;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.ComboBox cmbAPICallType;
		private System.Windows.Forms.Button btnOK;
		private System.Windows.Forms.Button btnCancel;
		private System.Windows.Forms.ComboBox cmbSessionFilter;
		private System.Windows.Forms.Label lblSessionFilter;
		private System.Windows.Forms.ComboBox cmbUrl;
	}
}