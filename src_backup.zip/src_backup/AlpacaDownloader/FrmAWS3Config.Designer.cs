﻿
namespace SriAlpacaDL
{
	partial class FrmAWS3Config
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.chkUseAWSS3 = new System.Windows.Forms.CheckBox();
			this.chkAWSApplySec = new System.Windows.Forms.CheckBox();
			this.chkAWSApplyAlign = new System.Windows.Forms.CheckBox();
			this.chkAWSApplyPrimary = new System.Windows.Forms.CheckBox();
			this.label1 = new System.Windows.Forms.Label();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.txtAWSEncrytionKey = new System.Windows.Forms.TextBox();
			this.label7 = new System.Windows.Forms.Label();
			this.txtAWSCannedACL = new System.Windows.Forms.TextBox();
			this.label6 = new System.Windows.Forms.Label();
			this.cmbAWSRegion = new System.Windows.Forms.ComboBox();
			this.txtBucketName = new System.Windows.Forms.TextBox();
			this.label5 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.txtAWSSecretKey = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.txtAWSAccessKey = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.btnOK = new System.Windows.Forms.Button();
			this.btnCancel = new System.Windows.Forms.Button();
			this.groupBox = new System.Windows.Forms.GroupBox();
			this.chkSaveWithoutR = new System.Windows.Forms.CheckBox();
			this.label8 = new System.Windows.Forms.Label();
			this.chkGzipUsePassword = new System.Windows.Forms.CheckBox();
			this.chkGzipFolder = new System.Windows.Forms.CheckBox();
			this.chkGZipIndividual = new System.Windows.Forms.CheckBox();
			this.txtGzipPassword = new System.Windows.Forms.TextBox();
			this.cmbCompressionFormat = new System.Windows.Forms.ComboBox();
			this.txtGzipFolderName = new System.Windows.Forms.TextBox();
			this.label10 = new System.Windows.Forms.Label();
			this.label12 = new System.Windows.Forms.Label();
			this.label13 = new System.Windows.Forms.Label();
			this.chkMarketView = new System.Windows.Forms.CheckBox();
			this.groupMarketView = new System.Windows.Forms.GroupBox();
			this.chkSectorHistorical = new System.Windows.Forms.CheckBox();
			this.chkSectorReport = new System.Windows.Forms.CheckBox();
			this.chkIndustryHistorical = new System.Windows.Forms.CheckBox();
			this.chkIndustryReport = new System.Windows.Forms.CheckBox();
			this.chkAllMarketHistorical = new System.Windows.Forms.CheckBox();
			this.chkAllSignalReport = new System.Windows.Forms.CheckBox();
			this.txtMarketViewFolder = new System.Windows.Forms.TextBox();
			this.label9 = new System.Windows.Forms.Label();
			this.chkLatestSignal = new System.Windows.Forms.CheckBox();
			this.groupLatestSignal = new System.Windows.Forms.GroupBox();
			this.txtLatestSignalFolder = new System.Windows.Forms.TextBox();
			this.label11 = new System.Windows.Forms.Label();
			this.chkZipNewLatestSignal = new System.Windows.Forms.CheckBox();
			this.chkZipLatestSignalMaster = new System.Windows.Forms.CheckBox();
			this.groupBox1.SuspendLayout();
			this.groupBox.SuspendLayout();
			this.groupMarketView.SuspendLayout();
			this.groupLatestSignal.SuspendLayout();
			this.SuspendLayout();
			// 
			// chkUseAWSS3
			// 
			this.chkUseAWSS3.AutoSize = true;
			this.chkUseAWSS3.Location = new System.Drawing.Point(20, 20);
			this.chkUseAWSS3.Name = "chkUseAWSS3";
			this.chkUseAWSS3.Size = new System.Drawing.Size(118, 17);
			this.chkUseAWSS3.TabIndex = 0;
			this.chkUseAWSS3.Text = "Output To AWS S3";
			this.chkUseAWSS3.UseVisualStyleBackColor = true;
			// 
			// chkAWSApplySec
			// 
			this.chkAWSApplySec.AutoSize = true;
			this.chkAWSApplySec.Location = new System.Drawing.Point(274, 51);
			this.chkAWSApplySec.Name = "chkAWSApplySec";
			this.chkAWSApplySec.Size = new System.Drawing.Size(56, 17);
			this.chkAWSApplySec.TabIndex = 8;
			this.chkAWSApplySec.Text = "Sec R";
			this.chkAWSApplySec.UseVisualStyleBackColor = true;
			// 
			// chkAWSApplyAlign
			// 
			this.chkAWSApplyAlign.AutoSize = true;
			this.chkAWSApplyAlign.Location = new System.Drawing.Point(190, 51);
			this.chkAWSApplyAlign.Name = "chkAWSApplyAlign";
			this.chkAWSApplyAlign.Size = new System.Drawing.Size(60, 17);
			this.chkAWSApplyAlign.TabIndex = 7;
			this.chkAWSApplyAlign.Text = "Align R";
			this.chkAWSApplyAlign.UseVisualStyleBackColor = true;
			// 
			// chkAWSApplyPrimary
			// 
			this.chkAWSApplyPrimary.AutoSize = true;
			this.chkAWSApplyPrimary.Location = new System.Drawing.Point(111, 51);
			this.chkAWSApplyPrimary.Name = "chkAWSApplyPrimary";
			this.chkAWSApplyPrimary.Size = new System.Drawing.Size(71, 17);
			this.chkAWSApplyPrimary.TabIndex = 6;
			this.chkAWSApplyPrimary.Text = "Primary R";
			this.chkAWSApplyPrimary.UseVisualStyleBackColor = true;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(34, 52);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(49, 13);
			this.label1.TabIndex = 5;
			this.label1.Text = "Apply To";
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.txtAWSEncrytionKey);
			this.groupBox1.Controls.Add(this.label7);
			this.groupBox1.Controls.Add(this.txtAWSCannedACL);
			this.groupBox1.Controls.Add(this.label6);
			this.groupBox1.Controls.Add(this.cmbAWSRegion);
			this.groupBox1.Controls.Add(this.txtBucketName);
			this.groupBox1.Controls.Add(this.label5);
			this.groupBox1.Controls.Add(this.label4);
			this.groupBox1.Controls.Add(this.txtAWSSecretKey);
			this.groupBox1.Controls.Add(this.label3);
			this.groupBox1.Controls.Add(this.txtAWSAccessKey);
			this.groupBox1.Controls.Add(this.label2);
			this.groupBox1.Location = new System.Drawing.Point(17, 80);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(329, 228);
			this.groupBox1.TabIndex = 10;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "AWS Connection Info";
			// 
			// txtAWSEncrytionKey
			// 
			this.txtAWSEncrytionKey.Location = new System.Drawing.Point(115, 192);
			this.txtAWSEncrytionKey.Name = "txtAWSEncrytionKey";
			this.txtAWSEncrytionKey.Size = new System.Drawing.Size(197, 20);
			this.txtAWSEncrytionKey.TabIndex = 11;
			// 
			// label7
			// 
			this.label7.AutoSize = true;
			this.label7.Location = new System.Drawing.Point(20, 195);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(78, 13);
			this.label7.TabIndex = 10;
			this.label7.Text = "Encryption Key";
			// 
			// txtAWSCannedACL
			// 
			this.txtAWSCannedACL.Location = new System.Drawing.Point(115, 159);
			this.txtAWSCannedACL.Name = "txtAWSCannedACL";
			this.txtAWSCannedACL.Size = new System.Drawing.Size(123, 20);
			this.txtAWSCannedACL.TabIndex = 9;
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Location = new System.Drawing.Point(20, 162);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(67, 13);
			this.label6.TabIndex = 8;
			this.label6.Text = "Canned ACL";
			// 
			// cmbAWSRegion
			// 
			this.cmbAWSRegion.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cmbAWSRegion.FormattingEnabled = true;
			this.cmbAWSRegion.Items.AddRange(new object[] {
            "USEast1",
            "AFSouth1",
            "MESouth1",
            "CACentral1",
            "CNNorthWest1",
            "CNNorth1",
            "USGovCloudWest1",
            "SAEast1",
            "APSoutheast2",
            "APSoutheast1",
            "APSouth1",
            "APNortheast3",
            "USGovCloudEast1",
            "APNortheast1",
            "APNortheast2",
            "USWest1",
            "USWest2",
            "EUNorth1",
            "EUWest1",
            "USEast2",
            "EUWest3",
            "EUCentral1",
            "EUSouth1",
            "APEast1",
            "EUWest2"});
			this.cmbAWSRegion.Location = new System.Drawing.Point(115, 95);
			this.cmbAWSRegion.Name = "cmbAWSRegion";
			this.cmbAWSRegion.Size = new System.Drawing.Size(123, 21);
			this.cmbAWSRegion.TabIndex = 7;
			// 
			// txtBucketName
			// 
			this.txtBucketName.Location = new System.Drawing.Point(115, 127);
			this.txtBucketName.Name = "txtBucketName";
			this.txtBucketName.Size = new System.Drawing.Size(123, 20);
			this.txtBucketName.TabIndex = 6;
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(20, 130);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(72, 13);
			this.label5.TabIndex = 5;
			this.label5.Text = "Bucket Name";
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(20, 98);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(41, 13);
			this.label4.TabIndex = 4;
			this.label4.Text = "Region";
			// 
			// txtAWSSecretKey
			// 
			this.txtAWSSecretKey.Location = new System.Drawing.Point(115, 64);
			this.txtAWSSecretKey.Name = "txtAWSSecretKey";
			this.txtAWSSecretKey.Size = new System.Drawing.Size(197, 20);
			this.txtAWSSecretKey.TabIndex = 3;
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(20, 67);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(59, 13);
			this.label3.TabIndex = 2;
			this.label3.Text = "Secret Key";
			// 
			// txtAWSAccessKey
			// 
			this.txtAWSAccessKey.Location = new System.Drawing.Point(115, 30);
			this.txtAWSAccessKey.Name = "txtAWSAccessKey";
			this.txtAWSAccessKey.Size = new System.Drawing.Size(197, 20);
			this.txtAWSAccessKey.TabIndex = 1;
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(20, 33);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(63, 13);
			this.label2.TabIndex = 0;
			this.label2.Text = "Access Key";
			// 
			// btnOK
			// 
			this.btnOK.Location = new System.Drawing.Point(457, 489);
			this.btnOK.Name = "btnOK";
			this.btnOK.Size = new System.Drawing.Size(106, 27);
			this.btnOK.TabIndex = 11;
			this.btnOK.Text = "OK";
			this.btnOK.UseVisualStyleBackColor = true;
			this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
			// 
			// btnCancel
			// 
			this.btnCancel.Location = new System.Drawing.Point(577, 489);
			this.btnCancel.Name = "btnCancel";
			this.btnCancel.Size = new System.Drawing.Size(106, 27);
			this.btnCancel.TabIndex = 12;
			this.btnCancel.Text = "Cancel";
			this.btnCancel.UseVisualStyleBackColor = true;
			this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
			// 
			// groupBox
			// 
			this.groupBox.Controls.Add(this.chkSaveWithoutR);
			this.groupBox.Controls.Add(this.label8);
			this.groupBox.Controls.Add(this.chkGzipUsePassword);
			this.groupBox.Controls.Add(this.chkGzipFolder);
			this.groupBox.Controls.Add(this.chkGZipIndividual);
			this.groupBox.Controls.Add(this.txtGzipPassword);
			this.groupBox.Controls.Add(this.cmbCompressionFormat);
			this.groupBox.Controls.Add(this.txtGzipFolderName);
			this.groupBox.Controls.Add(this.label10);
			this.groupBox.Controls.Add(this.label12);
			this.groupBox.Controls.Add(this.label13);
			this.groupBox.Location = new System.Drawing.Point(354, 80);
			this.groupBox.Name = "groupBox";
			this.groupBox.Size = new System.Drawing.Size(329, 228);
			this.groupBox.TabIndex = 13;
			this.groupBox.TabStop = false;
			this.groupBox.Text = "Gzip Settings";
			// 
			// chkSaveWithoutR
			// 
			this.chkSaveWithoutR.AutoSize = true;
			this.chkSaveWithoutR.Location = new System.Drawing.Point(15, 194);
			this.chkSaveWithoutR.Name = "chkSaveWithoutR";
			this.chkSaveWithoutR.Size = new System.Drawing.Size(138, 17);
			this.chkSaveWithoutR.TabIndex = 16;
			this.chkSaveWithoutR.Text = "Upload R File without R";
			this.chkSaveWithoutR.UseVisualStyleBackColor = true;
			// 
			// label8
			// 
			this.label8.AutoSize = true;
			this.label8.Location = new System.Drawing.Point(134, 161);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(53, 13);
			this.label8.TabIndex = 15;
			this.label8.Text = "Password";
			// 
			// chkGzipUsePassword
			// 
			this.chkGzipUsePassword.AutoSize = true;
			this.chkGzipUsePassword.Location = new System.Drawing.Point(15, 161);
			this.chkGzipUsePassword.Name = "chkGzipUsePassword";
			this.chkGzipUsePassword.Size = new System.Drawing.Size(103, 17);
			this.chkGzipUsePassword.TabIndex = 14;
			this.chkGzipUsePassword.Text = "PasswordProect";
			this.chkGzipUsePassword.UseVisualStyleBackColor = true;
			// 
			// chkGzipFolder
			// 
			this.chkGzipFolder.AutoSize = true;
			this.chkGzipFolder.Location = new System.Drawing.Point(126, 94);
			this.chkGzipFolder.Name = "chkGzipFolder";
			this.chkGzipFolder.Size = new System.Drawing.Size(79, 17);
			this.chkGzipFolder.TabIndex = 13;
			this.chkGzipFolder.Text = "Gzip Folder";
			this.chkGzipFolder.UseVisualStyleBackColor = true;
			// 
			// chkGZipIndividual
			// 
			this.chkGZipIndividual.AutoSize = true;
			this.chkGZipIndividual.Location = new System.Drawing.Point(126, 64);
			this.chkGZipIndividual.Name = "chkGZipIndividual";
			this.chkGZipIndividual.Size = new System.Drawing.Size(95, 17);
			this.chkGZipIndividual.TabIndex = 12;
			this.chkGZipIndividual.Text = "Individual Files";
			this.chkGZipIndividual.UseVisualStyleBackColor = true;
			// 
			// txtGzipPassword
			// 
			this.txtGzipPassword.Location = new System.Drawing.Point(229, 158);
			this.txtGzipPassword.Name = "txtGzipPassword";
			this.txtGzipPassword.Size = new System.Drawing.Size(94, 20);
			this.txtGzipPassword.TabIndex = 11;
			// 
			// cmbCompressionFormat
			// 
			this.cmbCompressionFormat.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cmbCompressionFormat.FormattingEnabled = true;
			this.cmbCompressionFormat.Items.AddRange(new object[] {
            "zip",
            "gzip"});
			this.cmbCompressionFormat.Location = new System.Drawing.Point(126, 30);
			this.cmbCompressionFormat.Name = "cmbCompressionFormat";
			this.cmbCompressionFormat.Size = new System.Drawing.Size(123, 21);
			this.cmbCompressionFormat.TabIndex = 7;
			// 
			// txtGzipFolderName
			// 
			this.txtGzipFolderName.Location = new System.Drawing.Point(229, 122);
			this.txtGzipFolderName.Name = "txtGzipFolderName";
			this.txtGzipFolderName.Size = new System.Drawing.Size(94, 20);
			this.txtGzipFolderName.TabIndex = 6;
			// 
			// label10
			// 
			this.label10.AutoSize = true;
			this.label10.Location = new System.Drawing.Point(134, 125);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(62, 13);
			this.label10.TabIndex = 5;
			this.label10.Text = "Root Folder";
			// 
			// label12
			// 
			this.label12.AutoSize = true;
			this.label12.Location = new System.Drawing.Point(7, 66);
			this.label12.Name = "label12";
			this.label12.Size = new System.Drawing.Size(66, 13);
			this.label12.TabIndex = 2;
			this.label12.Text = "Output Type";
			// 
			// label13
			// 
			this.label13.AutoSize = true;
			this.label13.Location = new System.Drawing.Point(7, 33);
			this.label13.Name = "label13";
			this.label13.Size = new System.Drawing.Size(102, 13);
			this.label13.TabIndex = 0;
			this.label13.Text = "Compression Format";
			// 
			// chkMarketView
			// 
			this.chkMarketView.AutoSize = true;
			this.chkMarketView.Location = new System.Drawing.Point(27, 314);
			this.chkMarketView.Name = "chkMarketView";
			this.chkMarketView.Size = new System.Drawing.Size(82, 17);
			this.chkMarketView.TabIndex = 14;
			this.chkMarketView.Text = "MarketView";
			this.chkMarketView.UseVisualStyleBackColor = true;
			// 
			// groupMarketView
			// 
			this.groupMarketView.Controls.Add(this.chkSectorHistorical);
			this.groupMarketView.Controls.Add(this.chkSectorReport);
			this.groupMarketView.Controls.Add(this.chkIndustryHistorical);
			this.groupMarketView.Controls.Add(this.chkIndustryReport);
			this.groupMarketView.Controls.Add(this.chkAllMarketHistorical);
			this.groupMarketView.Controls.Add(this.chkAllSignalReport);
			this.groupMarketView.Controls.Add(this.txtMarketViewFolder);
			this.groupMarketView.Controls.Add(this.label9);
			this.groupMarketView.Location = new System.Drawing.Point(17, 316);
			this.groupMarketView.Name = "groupMarketView";
			this.groupMarketView.Size = new System.Drawing.Size(329, 161);
			this.groupMarketView.TabIndex = 23;
			this.groupMarketView.TabStop = false;
			// 
			// chkSectorHistorical
			// 
			this.chkSectorHistorical.AutoSize = true;
			this.chkSectorHistorical.Location = new System.Drawing.Point(161, 122);
			this.chkSectorHistorical.Name = "chkSectorHistorical";
			this.chkSectorHistorical.Size = new System.Drawing.Size(103, 17);
			this.chkSectorHistorical.TabIndex = 30;
			this.chkSectorHistorical.Text = "Sector Historical";
			this.chkSectorHistorical.UseVisualStyleBackColor = true;
			// 
			// chkSectorReport
			// 
			this.chkSectorReport.AutoSize = true;
			this.chkSectorReport.Location = new System.Drawing.Point(36, 122);
			this.chkSectorReport.Name = "chkSectorReport";
			this.chkSectorReport.Size = new System.Drawing.Size(92, 17);
			this.chkSectorReport.TabIndex = 29;
			this.chkSectorReport.Text = "Sector Report";
			this.chkSectorReport.UseVisualStyleBackColor = true;
			// 
			// chkIndustryHistorical
			// 
			this.chkIndustryHistorical.AutoSize = true;
			this.chkIndustryHistorical.Location = new System.Drawing.Point(161, 95);
			this.chkIndustryHistorical.Name = "chkIndustryHistorical";
			this.chkIndustryHistorical.Size = new System.Drawing.Size(109, 17);
			this.chkIndustryHistorical.TabIndex = 28;
			this.chkIndustryHistorical.Text = "Industry Historical";
			this.chkIndustryHistorical.UseVisualStyleBackColor = true;
			// 
			// chkIndustryReport
			// 
			this.chkIndustryReport.AutoSize = true;
			this.chkIndustryReport.Location = new System.Drawing.Point(36, 95);
			this.chkIndustryReport.Name = "chkIndustryReport";
			this.chkIndustryReport.Size = new System.Drawing.Size(98, 17);
			this.chkIndustryReport.TabIndex = 27;
			this.chkIndustryReport.Text = "Industry Report";
			this.chkIndustryReport.UseVisualStyleBackColor = true;
			// 
			// chkAllMarketHistorical
			// 
			this.chkAllMarketHistorical.AutoSize = true;
			this.chkAllMarketHistorical.Location = new System.Drawing.Point(161, 69);
			this.chkAllMarketHistorical.Name = "chkAllMarketHistorical";
			this.chkAllMarketHistorical.Size = new System.Drawing.Size(119, 17);
			this.chkAllMarketHistorical.TabIndex = 26;
			this.chkAllMarketHistorical.Text = "All Market Historical";
			this.chkAllMarketHistorical.UseVisualStyleBackColor = true;
			// 
			// chkAllSignalReport
			// 
			this.chkAllSignalReport.AutoSize = true;
			this.chkAllSignalReport.Location = new System.Drawing.Point(36, 69);
			this.chkAllSignalReport.Name = "chkAllSignalReport";
			this.chkAllSignalReport.Size = new System.Drawing.Size(109, 17);
			this.chkAllSignalReport.TabIndex = 25;
			this.chkAllSignalReport.Text = "All Signals Report";
			this.chkAllSignalReport.UseVisualStyleBackColor = true;
			// 
			// txtMarketViewFolder
			// 
			this.txtMarketViewFolder.Location = new System.Drawing.Point(115, 30);
			this.txtMarketViewFolder.Name = "txtMarketViewFolder";
			this.txtMarketViewFolder.Size = new System.Drawing.Size(120, 20);
			this.txtMarketViewFolder.TabIndex = 24;
			// 
			// label9
			// 
			this.label9.AutoSize = true;
			this.label9.Location = new System.Drawing.Point(20, 33);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(67, 13);
			this.label9.TabIndex = 23;
			this.label9.Text = "Folder Name";
			// 
			// chkLatestSignal
			// 
			this.chkLatestSignal.AutoSize = true;
			this.chkLatestSignal.Location = new System.Drawing.Point(363, 314);
			this.chkLatestSignal.Name = "chkLatestSignal";
			this.chkLatestSignal.Size = new System.Drawing.Size(127, 17);
			this.chkLatestSignal.TabIndex = 24;
			this.chkLatestSignal.Text = "Latest Signals Output";
			this.chkLatestSignal.UseVisualStyleBackColor = true;
			// 
			// groupLatestSignal
			// 
			this.groupLatestSignal.Controls.Add(this.chkZipNewLatestSignal);
			this.groupLatestSignal.Controls.Add(this.chkZipLatestSignalMaster);
			this.groupLatestSignal.Controls.Add(this.txtLatestSignalFolder);
			this.groupLatestSignal.Controls.Add(this.label11);
			this.groupLatestSignal.Location = new System.Drawing.Point(354, 316);
			this.groupLatestSignal.Name = "groupLatestSignal";
			this.groupLatestSignal.Size = new System.Drawing.Size(329, 161);
			this.groupLatestSignal.TabIndex = 25;
			this.groupLatestSignal.TabStop = false;
			// 
			// txtLatestSignalFolder
			// 
			this.txtLatestSignalFolder.Location = new System.Drawing.Point(126, 30);
			this.txtLatestSignalFolder.Name = "txtLatestSignalFolder";
			this.txtLatestSignalFolder.Size = new System.Drawing.Size(120, 20);
			this.txtLatestSignalFolder.TabIndex = 26;
			// 
			// label11
			// 
			this.label11.AutoSize = true;
			this.label11.Location = new System.Drawing.Point(31, 33);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(67, 13);
			this.label11.TabIndex = 25;
			this.label11.Text = "Folder Name";
			// 
			// chkZipNewLatestSignal
			// 
			this.chkZipNewLatestSignal.AutoSize = true;
			this.chkZipNewLatestSignal.Location = new System.Drawing.Point(34, 108);
			this.chkZipNewLatestSignal.Name = "chkZipNewLatestSignal";
			this.chkZipNewLatestSignal.Size = new System.Drawing.Size(166, 17);
			this.chkZipNewLatestSignal.TabIndex = 30;
			this.chkZipNewLatestSignal.Text = "New Latest Signal Master File";
			this.chkZipNewLatestSignal.UseVisualStyleBackColor = true;
			// 
			// chkZipLatestSignalMaster
			// 
			this.chkZipLatestSignalMaster.AutoSize = true;
			this.chkZipLatestSignalMaster.Location = new System.Drawing.Point(34, 69);
			this.chkZipLatestSignalMaster.Name = "chkZipLatestSignalMaster";
			this.chkZipLatestSignalMaster.Size = new System.Drawing.Size(141, 17);
			this.chkZipLatestSignalMaster.TabIndex = 29;
			this.chkZipLatestSignalMaster.Text = "Latest Signal Master File";
			this.chkZipLatestSignalMaster.UseVisualStyleBackColor = true;
			// 
			// FrmAWS3Config
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(697, 529);
			this.Controls.Add(this.chkLatestSignal);
			this.Controls.Add(this.groupLatestSignal);
			this.Controls.Add(this.chkMarketView);
			this.Controls.Add(this.groupMarketView);
			this.Controls.Add(this.groupBox);
			this.Controls.Add(this.btnCancel);
			this.Controls.Add(this.btnOK);
			this.Controls.Add(this.groupBox1);
			this.Controls.Add(this.chkAWSApplySec);
			this.Controls.Add(this.chkAWSApplyAlign);
			this.Controls.Add(this.chkAWSApplyPrimary);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.chkUseAWSS3);
			this.Name = "FrmAWS3Config";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "AWS S3 Upload Settings";
			this.groupBox1.ResumeLayout(false);
			this.groupBox1.PerformLayout();
			this.groupBox.ResumeLayout(false);
			this.groupBox.PerformLayout();
			this.groupMarketView.ResumeLayout(false);
			this.groupMarketView.PerformLayout();
			this.groupLatestSignal.ResumeLayout(false);
			this.groupLatestSignal.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.CheckBox chkUseAWSS3;
		private System.Windows.Forms.CheckBox chkAWSApplySec;
		private System.Windows.Forms.CheckBox chkAWSApplyAlign;
		private System.Windows.Forms.CheckBox chkAWSApplyPrimary;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.TextBox txtAWSSecretKey;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.TextBox txtAWSAccessKey;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.TextBox txtBucketName;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.ComboBox cmbAWSRegion;
		private System.Windows.Forms.TextBox txtAWSEncrytionKey;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.TextBox txtAWSCannedACL;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Button btnOK;
		private System.Windows.Forms.Button btnCancel;
		private System.Windows.Forms.GroupBox groupBox;
		private System.Windows.Forms.TextBox txtGzipPassword;
		private System.Windows.Forms.ComboBox cmbCompressionFormat;
		private System.Windows.Forms.TextBox txtGzipFolderName;
		private System.Windows.Forms.Label label10;
		private System.Windows.Forms.Label label12;
		private System.Windows.Forms.Label label13;
		private System.Windows.Forms.CheckBox chkGzipFolder;
		private System.Windows.Forms.CheckBox chkGZipIndividual;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.CheckBox chkGzipUsePassword;
		private System.Windows.Forms.CheckBox chkSaveWithoutR;
		private System.Windows.Forms.CheckBox chkMarketView;
		private System.Windows.Forms.GroupBox groupMarketView;
		private System.Windows.Forms.CheckBox chkSectorHistorical;
		private System.Windows.Forms.CheckBox chkSectorReport;
		private System.Windows.Forms.CheckBox chkIndustryHistorical;
		private System.Windows.Forms.CheckBox chkIndustryReport;
		private System.Windows.Forms.CheckBox chkAllMarketHistorical;
		private System.Windows.Forms.CheckBox chkAllSignalReport;
		private System.Windows.Forms.TextBox txtMarketViewFolder;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.CheckBox chkLatestSignal;
		private System.Windows.Forms.GroupBox groupLatestSignal;
		private System.Windows.Forms.CheckBox chkZipNewLatestSignal;
		private System.Windows.Forms.CheckBox chkZipLatestSignalMaster;
		private System.Windows.Forms.TextBox txtLatestSignalFolder;
		private System.Windows.Forms.Label label11;
	}
}