﻿using SriAlpacaDLModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SriAlpacaDL
{
	public partial class FrmSidewayFilterConfig : Form
	{
		private SidewayFilterSettings config;
		public FrmSidewayFilterConfig()
		{
			InitializeComponent();
		}

		public FrmSidewayFilterConfig(SidewayFilterSettings config_) : this()
		{
			config = config_;

			chkSidewayFilter.Checked = config.EnableSidewayFilter;
			chkUseSumLogic.Checked = config.UseSumLogic;
			chkUpToBottom.Checked = config.UptoBottom;

			txtLookbackRows.Text = config.LookbackRows.ToString();
			txtExceptionPercent.Text = config.ExceptionPercent.ToString();

			chkApplyPrimaryR.Checked = config.ApplyPrimaryR;
			chkApplyAlignOutput.Checked = config.ApplyAlignOutputR;
			chkApplySidewayFilter.Checked = config.ApplySidewayFilter;

			groupBoxSideway.Enabled = config.EnableSidewayFilter;
		}

		private void btnOK_Click(object sender, EventArgs e)
		{
			int tempValInt = 0;
			double tempValDouble = 0;
			config.LookbackRows = int.TryParse(txtLookbackRows.Text, out tempValInt) ? tempValInt : 0;
			config.ExceptionPercent = double.TryParse(txtExceptionPercent.Text, out tempValDouble) ? tempValDouble : 0;
			config.EnableSidewayFilter = chkSidewayFilter.Checked;
			config.UseSumLogic = chkUseSumLogic.Checked;
			config.UptoBottom = chkUpToBottom.Checked;
			config.ApplyPrimaryR = chkApplyPrimaryR.Checked;
			config.ApplyAlignOutputR = chkApplyAlignOutput.Checked;
			config.ApplySidewayFilter = chkApplySidewayFilter.Checked;

			this.Close();
		}

		private void btnCancel_Click(object sender, EventArgs e)
		{
			this.Close();
		}

		private void chkSidewayFilter_CheckedChanged(object sender, EventArgs e)
		{
			groupBoxSideway.Enabled = chkSidewayFilter.Enabled;
		}
	}
}
