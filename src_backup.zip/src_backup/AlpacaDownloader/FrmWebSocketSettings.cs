﻿using Ookii.Dialogs.Wpf;
using SriAlpacaDLModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SriAlpacaDL
{
	public partial class FrmWebSocketSettings : Form
	{
		public WebSocketSettings Config { get; set; }
		public FrmWebSocketSettings()
		{
			InitializeComponent();
		}

		public FrmWebSocketSettings(WebSocketSettings config) : this() 
		{
			Config = config;
			cmbWebSocketSource.SelectedIndex = (int)Config.WebSocketType;

			txtOutputDataPath.Text = config.OutputFolder;
			chkCalendarWebSocket.Checked = Config.AutoStartByCalendar;

			if (Config.WebSocketType == WebSocketSource.AlapcaV2)
			{
				//txtEndPoint.Text = Config.EndPointAlpaca;
				//txtParam.Text = Config.ParamsAlpaca;
			}
			else if (Config.WebSocketType == WebSocketSource.Polygon)
			{
				cmbEndPoint.Text = Config.EndPointPolygon;
				cmbParam.Text = Config.ParamsPolygon;
			}
			else if (Config.WebSocketType == WebSocketSource.GlobalDataFeed)
			{
				cmbEndPoint.Text = Config.EndPointGlobalDataFeed;
			}
			else if (Config.WebSocketType == WebSocketSource.TwelveDataFeed)
			{
				cmbEndPoint.Text = Config.EndPointTwelveData;
			}

			txtInterval.Text = Config.Interval.ToString();
			lblInterval.Visible = txtInterval.Visible = Config.WebSocketType == WebSocketSource.TradeStation || Config.WebSocketType == WebSocketSource.TDAmeriTrade;
			lblParam.Visible = cmbParam.Visible = (Config.WebSocketType != WebSocketSource.TradeStation && Config.WebSocketType != WebSocketSource.TDAmeriTrade);

			lblBarsBack.Visible = txtBarsBack.Visible = Config.WebSocketType == WebSocketSource.TradeStation;
			txtBarsBack.Text = config.BarsBack.ToString();

			txtIntervalTick.Text = config.IntervalTick.ToString();
			txtMaxSymbol.Text = config.MaxCallSymbols.ToString();
			lblIntervalTick.Visible = txtIntervalTick.Visible = Config.WebSocketType == WebSocketSource.TradeStation;
		}

		private void btnBrowseInputDataPath_Click(object sender, EventArgs e)
		{
			VistaFolderBrowserDialog folderBrowserDialog = new VistaFolderBrowserDialog();
			folderBrowserDialog.SelectedPath = txtOutputDataPath.Text;
			if (folderBrowserDialog.ShowDialog().GetValueOrDefault())
			{
				GlobalData.Config.OutputDataPath = folderBrowserDialog.SelectedPath;
				txtOutputDataPath.Text = folderBrowserDialog.SelectedPath;
			}
		}

		private void btnOK_Click(object sender, EventArgs e)
		{
			Config.OutputFolder = txtOutputDataPath.Text;
			Config.AutoStartByCalendar = chkCalendarWebSocket.Checked;

			Config.WebSocketType = (WebSocketSource)cmbWebSocketSource.SelectedIndex;

			if (Config.WebSocketType == WebSocketSource.AlapcaV2)
			{
				//Config.ParamsAlpaca = cmbParam.Text;
				//Config.EndPointAlpaca = cmbEndPoint.Text;
			}
			else if (Config.WebSocketType == WebSocketSource.Polygon)
			{
				Config.ParamsPolygon = cmbParam.Text;
				Config.EndPointPolygon = cmbEndPoint.Text;
			}
			else if (Config.WebSocketType == WebSocketSource.GlobalDataFeed)
				Config.EndPointGlobalDataFeed = cmbEndPoint.Text;
			else if (Config.WebSocketType == WebSocketSource.TwelveDataFeed)
				Config.EndPointTwelveData = cmbEndPoint.Text;

			int temp;
			Config.Interval = int.TryParse(txtInterval.Text, out temp) ? temp : 0;
			Config.IntervalTick = int.TryParse(txtIntervalTick.Text, out temp) ? temp : 0;
			Config.BarsBack = int.TryParse(txtBarsBack.Text, out temp) ? temp : 0;
			Config.MaxCallSymbols = int.TryParse(txtMaxSymbol.Text, out temp) ? temp : 1;

			if (Config.WebSocketType == WebSocketSource.TradeStation && (Config.BarsBack <= 0 || Config.BarsBack > 10))
			{
				MessageBox.Show("BarsBack must in range 1~10");
				return;
			}

			this.Close();
		}

		private void btnCancel_Click(object sender, EventArgs e)
		{
			this.Close();
		}

		private void cmbWebSocketSource_SelectedIndexChanged(object sender, EventArgs e)
		{
			WebSocketSource type = (WebSocketSource)cmbWebSocketSource.SelectedIndex;
			if (type == WebSocketSource.AlapcaV2 || type == WebSocketSource.Polygon || type == WebSocketSource.TradeStation || type == WebSocketSource.TDAmeriTrade)
				cmbEndPoint.Enabled = cmbParam.Enabled = false;
			else
				cmbEndPoint.Enabled = cmbParam.Enabled = true;

			if (type == WebSocketSource.Polygon)
			{
				cmbEndPoint.Text = Config.EndPointPolygon;
				cmbParam.Text = Config.ParamsPolygon;
			}
			if (type == WebSocketSource.GlobalDataFeed)
				cmbEndPoint.Text = Config.EndPointGlobalDataFeed;
			else if (type == WebSocketSource.TwelveDataFeed)
				cmbEndPoint.Text = Config.EndPointTwelveData;

			lblMaxSymbol.Visible = txtMaxSymbol.Visible = type == WebSocketSource.TDAmeriTrade;

			lblParam.Visible = cmbParam.Visible = type != WebSocketSource.TradeStation;
			lblInterval.Visible = txtInterval.Visible = type == WebSocketSource.TradeStation;
			cmbParam.Enabled = type == WebSocketSource.Polygon;
			lblBarsBack.Visible = txtBarsBack.Visible = Config.WebSocketType == WebSocketSource.TradeStation;
			lblIntervalTick.Visible = txtIntervalTick.Visible = Config.WebSocketType == WebSocketSource.TradeStation;
		}
	}
}
