﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using SriAlpacaDLModel;
using SriAlpacaDLProcess;
using Ookii.Dialogs.Wpf;

namespace SriAlpacaDL
{
	public partial class FrmMain : Form
	{
		private bool bProcessStarted = false;
		private bool bWebSocketProcessStarted = false;
		private ZeroMQSender msgSender;

		private AlpacaDLProcessor processor;
		private AlpacaDLSettings Config { get => GlobalData.Config; }
		public FrmMain()
		{
			InitializeComponent();
			processor = new AlpacaDLProcessor();
			processor.ProcessNotifier = new AlpacaDLProcessor.ProcessNotifierDelegate(ProcessNotifier);
			processor.MessageSender = new AlpacaDLProcessor.MessageSenderDeleagate(SendMessage);
			GlobalData.LoadSettings();
			timerUpdate.Tick += UpdateTick;
			BindSettings(false);

			msgSender = new ZeroMQSender();

			UpdateControlStateByDataFeed();

			UpdateWebSocketLabels();
		}

		private void UpdateTick(object sender, EventArgs e)
		{
			if (DateTime.Now.Second - Config.AutoUpdateDelay == 0 && bProcessStarted)
				DoAutoUpdate(sender, e);
		}

		private void SendMessage(string msg)
		{
			msgSender.SendMessage(msg);
		}
		private void SelectText(TextBox textBox)
		{
			textBox.Focus();
			textBox.SelectAll();
		}

		public bool BindSettings(bool bFromControl, bool bShowError = false)
		{
			bool bRet = true;
			if (bFromControl)
			{
				GlobalData.Config.OutputDataPath = txtOutputDataPath.Text;
				GlobalData.Config.BrokerIsLive = radioLive.Checked;
				GlobalData.Config.LiveKey = txtLiveKey.Text;
				GlobalData.Config.LiveSecretKey = txtLiveSecretKey.Text;
				GlobalData.Config.PaperKey = txtPaperKey.Text;
				GlobalData.Config.PaperSecretKey = txtPaperSecretKey.Text;
				Config.Plan = chkPlan.SelectedIndex;
				GlobalData.Config.SymbolListFile = txtSymbolListFile.Text;

				try
				{
					GlobalData.Config.BarLimit = int.Parse(txtBars.Text);
					int barMaxLimit = 1000;
					int barMinLimit = 1;
					if (Config.DataFeedSource == DataFeedSouce.AlpacaV2)
						barMaxLimit = 10000;
					else if (Config.DataFeedSource == DataFeedSouce.PolygonV2)
						barMaxLimit = 50000;
					else if (Config.DataFeedSource == DataFeedSouce.TwelveData)
						barMaxLimit = 5000;
					else if (Config.DataFeedSource == DataFeedSouce.GlobalDataFeed)
					{
						barMinLimit = 0;
						barMaxLimit = 5000;
					}
					else if (Config.DataFeedSource == DataFeedSouce.Tradier || Config.DataFeedSource == DataFeedSouce.TradeStation ||
						Config.DataFeedSource == DataFeedSouce.TDAmeritrade)
					{
						barMinLimit = 0;
						barMaxLimit = 999999;
					}
					if (GlobalData.Config.BarLimit < barMinLimit || GlobalData.Config.BarLimit > barMaxLimit)
					{
						if (bShowError)
						{
							MessageBox.Show("#Bar is invalid", GlobalData.AppName, MessageBoxButtons.OK, MessageBoxIcon.Warning);
							SelectText(txtBars);
							return false;
						}
					}
				}
				catch
				{
					bRet = false;
					if (bShowError)
					{
						MessageBox.Show("#Bar is invalid", GlobalData.AppName, MessageBoxButtons.OK, MessageBoxIcon.Warning);
						SelectText(txtBars);
						return false;
					}
				}

				GlobalData.Config.EnableMarketTimeOnly = chkMarketHoursOnly.Checked;
				GlobalData.Config.MarketStartTime = dateTimeStart.Value;
				GlobalData.Config.MarketEndTime = dateTimeEnd.Value;

				GlobalData.Config.IsStaticMode = radioProcessStatic.Checked;
				
				GlobalData.Config.AppendUpdatedData = chkAppendData.Checked;
				GlobalData.Config.EnableCloseBarUpdate = chkCloseBarUpdate.Checked;

				if (radioHLC.Checked)
					GlobalData.Config.CloseBarUpdateMode = 0;
				else if (radioOHLC.Checked)
					GlobalData.Config.CloseBarUpdateMode = 1;
				else if (radioHL.Checked)
					GlobalData.Config.CloseBarUpdateMode = 2;
				else if (radioCO.Checked)
					GlobalData.Config.CloseBarUpdateMode = 3;

				GlobalData.Config.EnableCalendarAutoUpdate = chkCalendarAutoStart.Checked;

				Config.EnableBackfillUpdate = chkBackfillUpdate.Checked;
				Config.EnableRFileOutput = chkROutput.Checked;
				int tempValInt = 0;
				Config.AutoUpdateDelay = int.TryParse(txtDelay.Text, out tempValInt) ? tempValInt : 0;
				Config.RoundPoints = int.TryParse(txtRounding.Text, out tempValInt) ? tempValInt : 0;

				if (Config.RoundPoints == 0)
					Config.RoundPoints = 2;

				Config.RoundChange = chkRoundChange.Checked;
				Config.RoundClose = chkRoundClose.Checked;
				Config.RoundVolume = chkRoundVol.Checked;
				Config.DataFeedSource = (DataFeedSouce)cmbDataFeedType.SelectedIndex;
				Config.DataTimeFrame = SriAlpacaDLProcess.Utils.GetTimeFrameFromName(cmbTimeFrame.Text);
				Config.StartDate = dtStartDate.Value;
				Config.EndDate = dtEndDate.Value;
				Config.PolygonKey = txtPolygonAPIKey.Text;
				Config.Multiplier = int.TryParse(txtMultiplier.Text, out tempValInt) ? tempValInt : 0;
				if (Config.Multiplier <= 0)
					Config.Multiplier = 1;
				Config.Unadjusted = cmbUnadjusted.SelectedIndex == 1 ? true : false;
				Config.Sort = cmbSort.Text;
				Config.LocalDataFolder = txtLocalDataFolder.Text;
				Config.UseInputTSOptions = chkInputFileTSOptions.Checked;
				Config.UseTSOHLCV = chkTSOHLCV.Checked;
			}
			else
			{
				//General
				txtOutputDataPath.Text = GlobalData.Config.OutputDataPath;
				radioLive.Checked = GlobalData.Config.BrokerIsLive;
				radioPaper.Checked = !GlobalData.Config.BrokerIsLive;
				txtLiveKey.Text = GlobalData.Config.LiveKey;
				txtLiveSecretKey.Text = GlobalData.Config.LiveSecretKey;
				txtPaperKey.Text = GlobalData.Config.PaperKey;
				txtPaperSecretKey.Text = GlobalData.Config.PaperSecretKey;
				txtLiveKey.Enabled = txtLiveSecretKey.Enabled = GlobalData.Config.BrokerIsLive;
				txtPaperKey.Enabled = txtPaperSecretKey.Enabled = !GlobalData.Config.BrokerIsLive;

				txtBars.Text = GlobalData.Config.BarLimit.ToString();

				txtSymbolListFile.Text = GlobalData.Config.SymbolListFile;

				chkMarketHoursOnly.Checked = GlobalData.Config.EnableMarketTimeOnly;

				dateTimeStart.Enabled = dateTimeEnd.Enabled = GlobalData.Config.EnableMarketTimeOnly;

				dateTimeStart.Value = GlobalData.Config.MarketStartTime;
				dateTimeEnd.Value = GlobalData.Config.MarketEndTime;

				radioProcessStatic.Checked = GlobalData.Config.IsStaticMode;
				radioProcessAuto.Checked = !GlobalData.Config.IsStaticMode;

				chkAppendData.Checked = GlobalData.Config.AppendUpdatedData;
				chkAppendData.Enabled = !GlobalData.Config.IsStaticMode;

				chkCloseBarUpdate.Checked = GlobalData.Config.EnableCloseBarUpdate;
				radioHLC.Enabled = radioOHLC.Enabled = radioHL.Enabled = radioCO.Enabled = GlobalData.Config.EnableCloseBarUpdate;
				radioHLC.Checked = GlobalData.Config.CloseBarUpdateMode == 0;
				radioOHLC.Checked = GlobalData.Config.CloseBarUpdateMode == 1;
				radioHL.Checked = GlobalData.Config.CloseBarUpdateMode == 2;
				radioCO.Checked = GlobalData.Config.CloseBarUpdateMode == 3;

				chkCalendarAutoStart.Checked = GlobalData.Config.EnableCalendarAutoUpdate;

				dateTimeStart.Enabled = dateTimeEnd.Enabled = !(Config.EnableCalendarAutoUpdate || Config.WebSocketConfig.AutoStartByCalendar);

				chkBackfillUpdate.Checked = Config.EnableBackfillUpdate;

				chkROutput.Checked = Config.EnableRFileOutput;
				btnROutputSettings.Enabled = Config.EnableRFileOutput;

				txtDelay.Text = Config.AutoUpdateDelay.ToString();

				txtRounding.Text = Config.RoundPoints.ToString();
				chkRoundChange.Checked = Config.RoundChange;
				chkRoundClose.Checked = Config.RoundClose;
				chkRoundVol.Checked = Config.RoundVolume;

				chkPlan.SelectedIndex = Config.Plan;
				cmbDataFeedType.SelectedIndex = (int)Config.DataFeedSource;
				dtStartDate.Value = Config.StartDate;
				dtEndDate.Value = Config.EndDate;
				txtPolygonAPIKey.Text = Config.PolygonKey;
				txtMultiplier.Text = Config.Multiplier.ToString();
				cmbUnadjusted.SelectedIndex = Config.Unadjusted ? 1 : 0;
				cmbSort.SelectedIndex = Config.Sort == "desc" ? 1 : 0;
				txtBars.Enabled = dtStartDate.Enabled = dtEndDate.Enabled = Config.DataFeedSource != DataFeedSouce.TradeStation;
				txtLocalDataFolder.Text = Config.LocalDataFolder;
				chkTSOHLCV.Checked = Config.UseTSOHLCV;
				chkInputFileTSOptions.Checked = Config.UseInputTSOptions;
				ShowControlsByDataFeed();
			}

			return bRet;
		}
		private bool CheckStartConditions()
		{
			bool bRet = true;
			if (cmbDataFeedType.SelectedIndex <= 1 || Config.WebSocketConfig.WebSocketType == WebSocketSource.AlapcaV2)
			{
				if (radioLive.Checked)
				{
					if (string.IsNullOrEmpty(txtLiveKey.Text))
					{
						MessageBox.Show("Please enter Live API Key", GlobalData.AppName, MessageBoxButtons.OK, MessageBoxIcon.Warning);
						SelectText(txtLiveKey);
						return false;
					}

					if (string.IsNullOrEmpty(txtLiveSecretKey.Text))
					{
						MessageBox.Show("Please enter Live API Secret Key", GlobalData.AppName, MessageBoxButtons.OK, MessageBoxIcon.Warning);
						SelectText(txtLiveSecretKey);
						return false;
					}
				}

				if (radioPaper.Checked)
				{
					if (string.IsNullOrEmpty(txtPaperKey.Text))
					{
						MessageBox.Show("Please enter Paper API Key", GlobalData.AppName, MessageBoxButtons.OK, MessageBoxIcon.Warning);
						SelectText(txtPaperKey);
						return false;
					}

					if (string.IsNullOrEmpty(txtPaperSecretKey.Text))
					{
						MessageBox.Show("Please enter Paper API Secret Key", GlobalData.AppName, MessageBoxButtons.OK, MessageBoxIcon.Warning);
						SelectText(txtPaperSecretKey);
						return false;
					}
				}
			}

			if (string.IsNullOrEmpty(txtOutputDataPath.Text))
			{
				MessageBox.Show("Please enter Output Data Path", GlobalData.AppName, MessageBoxButtons.OK, MessageBoxIcon.Warning);
				SelectText(txtOutputDataPath);
				return false;
			}

			if (string.IsNullOrEmpty(txtSymbolListFile.Text))
			{
				MessageBox.Show("Please select a symbollist file", GlobalData.AppName, MessageBoxButtons.OK, MessageBoxIcon.Warning);
				SelectText(txtSymbolListFile);
				return false;
			}
			else if (!File.Exists(txtSymbolListFile.Text))
			{
				MessageBox.Show("The symbollist file does not exist", GlobalData.AppName, MessageBoxButtons.OK, MessageBoxIcon.Warning);
				SelectText(txtSymbolListFile);
				return false;
			}

			if (string.IsNullOrEmpty(txtBars.Text))
			{
				MessageBox.Show("Please enter #Bars", GlobalData.AppName, MessageBoxButtons.OK, MessageBoxIcon.Warning);
				SelectText(txtBars);
				return false;
			}

			if (Config.DataFeedSource == DataFeedSouce.Tradier && Config.TradierConfig.EndPoint == TradierSettings.EndPointType.SandBox && cmbTimeFrame.Text == "Tick")
			{
				MessageBox.Show("TimeFrame cannot be Tick in SandBox Mode", GlobalData.AppName, MessageBoxButtons.OK, MessageBoxIcon.Warning);
				return false;
			}
			return bRet;
		}
		private void FrmMain_Load(object sender, EventArgs e)
		{

		}
		private void FrmMain_FormClosing(object sender, FormClosingEventArgs e)
		{
			if (MessageBox.Show("Are you sure you want to exit?", GlobalData.AppName, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
			{
				e.Cancel = true;
				return;
			}

			BindSettings(true);
			GlobalData.SaveSettings();
		}

		private void btnStart_Click(object sender, EventArgs e)
		{
			if (!bProcessStarted)
			{
				if (!CheckStartConditions())
				{
					bProcessStarted = false;
					return;
				}
				if (!BindSettings(true, true))
				{
					bProcessStarted = false;
					return;
				}

				GlobalData.SaveSettings();

				if (Config.EnableCalendarAutoUpdate)
				{
					if (File.Exists(GlobalData.GetCalendarFilePath()))
						processor.PrepareCalendarListFromFile();
					else
					{
						MessageBox.Show("Calendar File does not exist!", GlobalData.AppName, MessageBoxButtons.OK, MessageBoxIcon.Warning);
						bProcessStarted = false;
						return;
					}
				}


				if (!processor.PrepareStockSymbolList(GlobalData.Config.SymbolListFile))
				{
					MessageBox.Show("Failed to load symbollist", GlobalData.AppName, MessageBoxButtons.OK, MessageBoxIcon.Information);
					bProcessStarted = false;
					return;
				}

				processor.PrepareAPIClient();

				bProcessStarted = true;

				EnableAllControls(false);

				processor.ClearOriginalData();

				if (Config.EnableRFileOutput)
				{
					try
					{
						if (!string.IsNullOrEmpty(Config.RFileOutputConfig.ROutputFolder))
							AlpacaDLServices.ClearFolder(Config.RFileOutputConfig.ROutputFolder);

						foreach (var folder in Config.RFileOutputConfig.FolderSettings)
						{
							AlpacaDLServices.ClearFolder(folder.Path);
						}
					}
					catch
					{

					}
				}

				if (!Config.EnableCalendarAutoUpdate || Config.IsStaticMode)
				{
					processor.StopROutput = false;
					processor.TimeFrames = null;
					processor.Start();
				}
				else
					DoAutoUpdate(null, null);

				btnStart.Text = "Stop";
			}
			else
			{
				processor.Stop();
				btnStart.Text = "Start";
				bProcessStarted = false;
				lblProcessStatus.Text = "Cancelled by user";
				statusProgressBar.Visible = false;
				statusProgressBar.Value = 0;
				EnableAllControls(true);
			}
		}

		private void EnableAllControls(bool bEnable)
		{
			groupGeneral.Enabled = bEnable;
			groupDataType.Enabled = bEnable;
		}
		private void RDateFile_Changed(object sender, FileSystemEventArgs e)
		{

		}

		private void RDataFile_Created(object sender, FileSystemEventArgs e)
		{

		}

		private void btnBrowseInputDataPath_Click(object sender, EventArgs e)
		{
			VistaFolderBrowserDialog folderBrowserDialog = new VistaFolderBrowserDialog();
			folderBrowserDialog.SelectedPath = txtOutputDataPath.Text;
			if (folderBrowserDialog.ShowDialog().GetValueOrDefault())
			{
				GlobalData.Config.OutputDataPath = folderBrowserDialog.SelectedPath;
				txtOutputDataPath.Text = folderBrowserDialog.SelectedPath;
			}
		}

		private void ProcessNotifier(AlpacaDLProcessor.ProcessState state, int param)
		{
			switch (state)
			{
				case AlpacaDLProcessor.ProcessState.Start:
					bProcessStarted = true;
					if (Config.RFileOutputConfig.EnableZeroMQ)
						msgSender.Start(Config.RFileOutputConfig.IPAddressZMQ, Config.RFileOutputConfig.PortZMQ);

					BeginInvoke(new Action(() => EnableAllControls(false)));
					BeginInvoke(new Action(() => lblProcessStatus.Text = "Starting..."));
					BeginInvoke(new Action(() => statusProgressBar.Maximum = 100));
					BeginInvoke(new Action(() => statusProgressBar.Value = 0));
					BeginInvoke(new Action(() => statusProgressBar.Visible = true));
					break;
				case AlpacaDLProcessor.ProcessState.Progress:
					BeginInvoke(new Action(() => statusProgressBar.Value = param));
					if (!bWebSocketProcessStarted)
						BeginInvoke(new Action(() => lblProcessStatus.Text = "Overall Progress"));
					break;
				case AlpacaDLProcessor.ProcessState.Pause:
					BeginInvoke(new Action(() => btnStart.Text = "Resume"));
					bProcessStarted = false;
					break;
				case AlpacaDLProcessor.ProcessState.Stop:
					if (Config.RFileOutputConfig.EnableZeroMQ)
						msgSender.Stop();
					BeginInvoke(new Action(() => EnableAllControls(true)));
					BeginInvoke(new Action(() => btnStart.Text = "Start"));
					BeginInvoke(new Action(() => statusProgressBar.Visible = false));
					BeginInvoke(new Action(() => statusProgressBar.Value = 0));
					if (param == -1)
						BeginInvoke(new Action(() => lblProcessStatus.Text = "Connection Error"));
					else
						BeginInvoke(new Action(() => lblProcessStatus.Text = "Cancelled by user"));
					bProcessStarted = false;
					msgSender.Stop();
					break;
				case AlpacaDLProcessor.ProcessState.Complete:
					if (Config.RFileOutputConfig.EnableZeroMQ)
						msgSender.Stop();
					
					if (Config.IsStaticMode)
					{
						bProcessStarted = false;
						BeginInvoke(new Action(() => EnableAllControls(true)));
						BeginInvoke(new Action(() => btnStart.Text = "Start"));
						BeginInvoke(new Action(() => statusProgressBar.Visible = false));
						BeginInvoke(new Action(() => statusProgressBar.Value = 0));
						BeginInvoke(new Action(() => lblProcessStatus.Text = "Download Completed"));
					}
					else
					{
						BeginInvoke(new Action(() => statusProgressBar.Value = 0));
						BeginInvoke(new Action(() => lblProcessStatus.Text = "Waiting for Auto Update..."));
					}
					break;
				case AlpacaDLProcessor.ProcessState.ConnectionError:
					BeginInvoke(new Action(() => lblProcessStatus.Text = "Connection Error. Trying again..."));
					break;
				//case AlpacaDLProcessor.ProcessState.Waiting:
				//	BeginInvoke(new Action(() => statusProgressBar.Value = 0));
				//	BeginInvoke(new Action(() => lblProcessStatus.Text = "Waiting for Auto Update..."));
				//	break;
				case AlpacaDLProcessor.ProcessState.SocketConnected:
					if (param == 1)
						BeginInvoke(new Action(() => lblSocketState.Text = "WebSocket Stream : Connected"));
					else
						BeginInvoke(new Action(() => lblSocketState.Text = "WebSocket Stream : Disconnected"));
					break;
				case AlpacaDLProcessor.ProcessState.Appended:
					BeginInvoke(new Action(() => lblProcessStatus.Text = param.ToString() + " Symbols Appended"));
					break;
				case AlpacaDLProcessor.ProcessState.Calendar:
					if (param == 1)
						BeginInvoke(new Action(() => MessageBox.Show("Calendar File generated successfully!", GlobalData.AppName, MessageBoxButtons.OK, MessageBoxIcon.Information)));
					else
						BeginInvoke(new Action(() => MessageBox.Show("An error occurred while generating Calendar File.", GlobalData.AppName, MessageBoxButtons.OK, MessageBoxIcon.Warning)));
					break;

				case AlpacaDLProcessor.ProcessState.TrimRawData:
					if (param == 1)
					{
						BeginInvoke(new Action(() => TrimControlEnable(false)));
					}
					else if (param == 2)
					{
						BeginInvoke(new Action(() => MessageBox.Show("Trim Completed!", GlobalData.AppName, MessageBoxButtons.OK, MessageBoxIcon.Information)));
						BeginInvoke(new Action(() => TrimControlEnable(true)));
					}
					else
					{
						BeginInvoke(new Action(() => MessageBox.Show("An error occurred while trimming output files.", GlobalData.AppName, MessageBoxButtons.OK, MessageBoxIcon.Warning)));
						BeginInvoke(new Action(() => TrimControlEnable(true)));
					}
					break;
				case AlpacaDLProcessor.ProcessState.ROutputStart:
					msgSender.Start(Config.RFileOutputConfig.IPAddressZMQ, Config.RFileOutputConfig.PortZMQ);
					break;
				case AlpacaDLProcessor.ProcessState.ROutputCompleted:
					msgSender.Stop();
					break;
				case AlpacaDLProcessor.ProcessState.CleanupTree:
					if (param == 1)
					{
						BeginInvoke(new Action(() => CleanupControlEnable(false)));
					}
					else
						BeginInvoke(new Action(() => CleanupControlEnable(true)));
					break;
				case AlpacaDLProcessor.ProcessState.CleanupStockList:
					BeginInvoke(new Action(() => CleanupStockListControlEnable(param == 1)));
					if (param == 1)
						BeginInvoke(new Action(() => MessageBox.Show("Cleanup Completed!")));
					break;
				case AlpacaDLProcessor.ProcessState.LimitExceeded:
					BeginInvoke(new Action(() => lblProcessStatus.Text = "500 symbols/5 min limit excceded!"));
					break;

			}
		}

		private void btnExit_Click(object sender, EventArgs e)
		{
			processor.Stop();
			Application.Exit();
		}

		private void radioPaper_CheckedChanged(object sender, EventArgs e)
		{
			txtPaperKey.Enabled = txtPaperSecretKey.Enabled = radioPaper.Checked;
		}

		private void radioLive_CheckedChanged(object sender, EventArgs e)
		{
			txtLiveKey.Enabled = txtLiveSecretKey.Enabled = radioLive.Checked;
		}

		private void btnBrowseSymbolList_Click(object sender, EventArgs e)
		{
			OpenFileDialog openDlg = new OpenFileDialog();
			openDlg.Filter = "Stock Symbol List|*.txt";
			if (openDlg.ShowDialog() == DialogResult.OK)
			{
				GlobalData.Config.SymbolListFile = openDlg.FileName;
				txtSymbolListFile.Text = openDlg.FileName;
			}
		}

		private void btnStop_Click(object sender, EventArgs e)
		{
			
		}

		private void chkMarketHoursOnly_CheckedChanged(object sender, EventArgs e)
		{
			dateTimeStart.Enabled = dateTimeEnd.Enabled = chkMarketHoursOnly.Checked;
		}

		private void radioProcessStatic_CheckedChanged(object sender, EventArgs e)
		{
			//chkAppendData.Enabled = radioProcessAuto.Checked;
		}
		private bool CanAutoUpdate()
		{
			if (Config.EnableCalendarAutoUpdate)
			{
				return processor.IsTimeInMarketHour(DateTime.UtcNow);
			}
			else
			{
				DateTime now = DateTime.Now;

				DateTime startTime = new DateTime(now.Year, now.Month, now.Day,
														GlobalData.Config.MarketStartTime.Hour, GlobalData.Config.MarketStartTime.Minute, 0);
				DateTime endTime = new DateTime(now.Year, now.Month, now.Day,
											GlobalData.Config.MarketEndTime.Hour, GlobalData.Config.MarketEndTime.Minute, 0);

				if (startTime > now || endTime < now)
					return false;
			}

			return true;
		}
		/// <summary>
		/// Check whether auto update is available in every 1 min.
		/// Do update if time is between open and close
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void DoAutoUpdate(object sender, EventArgs e)
		{
			if (!GlobalData.Config.IsStaticMode)
			{
				if (!CanAutoUpdate())
				{
					BeginInvoke(new Action(() => lblProcessStatus.Text = "Waiting for market open..."));
					return;
				}
				else
				{
					DateTime now = DateTime.Now;

					List<DataTimeFrame> timeFrames = new List<DataTimeFrame>();

					if (e == null)
					{
						timeFrames.Add(Config.DataTimeFrame);
					}
					else
					{
						bool isStartTime = now.Hour == GlobalData.Config.MarketStartTime.Hour && now.Minute == GlobalData.Config.MarketStartTime.Minute;
						bool isEndTime = now.Hour == GlobalData.Config.MarketEndTime.Hour && now.Minute == GlobalData.Config.MarketEndTime.Minute;

						if (Config.DataTimeFrame == DataTimeFrame.Day && (isEndTime || isStartTime))
						{
							timeFrames.Add(DataTimeFrame.Day);      //perform 1D update
						}

						if (Config.DataTimeFrame == DataTimeFrame.Minute)
						{
							timeFrames.Add(DataTimeFrame.Minute);  //TimeFrame.Minute
						}

						if (Config.DataTimeFrame == DataTimeFrame.Minute5 && (now.Minute % 5 == 0 || isStartTime))
						{
							timeFrames.Add(DataTimeFrame.Minute5);  //TimeFrame.FiveMinute
						}

						if (Config.DataTimeFrame == DataTimeFrame.Minute15 && (now.Minute % 15 == 0 || isStartTime))
						{
							timeFrames.Add(DataTimeFrame.Minute15);  //TimeFrame.FiveMinute
						}

						if (Config.DataTimeFrame == DataTimeFrame.Hour && (now.Minute % 60 == 0 || isStartTime))
						{
							timeFrames.Add(DataTimeFrame.Hour);  //TimeFrame.15Mins
						}
					}
					if (timeFrames.Count >= 1)
					{
						processor.StopROutput = false;

						processor.TimeFrames = timeFrames;

						processor.Start();
					}
				}
			}

			if (bWebSocketProcessStarted)
			{
				if (Config.WebSocketConfig.AutoStartByCalendar && processor.IsTimeInMarketHour(DateTime.UtcNow))
					processor.RunWebSocketUpdate();

				if (DateTime.Now.Hour == GlobalData.Config.MarketEndTime.Hour && DateTime.Now.Minute == GlobalData.Config.MarketEndTime.Minute)
				{
					if (Config.WebSocketConfig.AutoStartByCalendar)
						processor.StopWebSocketUpdate();
					else
						StopWebSocketUpdate();
				}
			}
		}

		private void StartWebSocketUpdate()
		{
			bWebSocketProcessStarted = true;
			btnStartWebSocketUpdate.Enabled = false;
			btnStopWebSocketUpdate.Enabled = true;
			if (!Directory.Exists(Config.WebSocketConfig.OutputFolder))
				Directory.CreateDirectory(Config.WebSocketConfig.OutputFolder);

			if (!Config.WebSocketConfig.AutoStartByCalendar)		//start immediately
				processor.RunWebSocketUpdate();
		}
		private void StopWebSocketUpdate()
		{
			bWebSocketProcessStarted = false;
			btnStopWebSocketUpdate.Enabled = false;
			btnStartWebSocketUpdate.Enabled = true;
			processor.StopWebSocketUpdate();
		}
		private void btnStartWebSocketUpdate_Click(object sender, EventArgs e)
		{
			if (!CheckStartConditions() || !BindSettings(true, false))
				return;

			processor.PrepareStockSymbolList(GlobalData.Config.SymbolListFile);

			if (Config.WebSocketConfig.WebSocketType == WebSocketSource.AlapcaV2)
				processor.PrepareStreamClient();

			if (Config.WebSocketConfig.AutoStartByCalendar)
			{
				if (File.Exists(GlobalData.GetCalendarFilePath()))
					processor.PrepareCalendarListFromFile();
				else
				{
					MessageBox.Show("Calendar File does not exist!", GlobalData.AppName, MessageBoxButtons.OK, MessageBoxIcon.Warning);
					return;
				}
			}

			if (Config.EnableRFileOutput)
			{
				try
				{
					if (!string.IsNullOrEmpty(Config.RFileOutputConfig.ROutputFolder))
						AlpacaDLServices.ClearFolder(Config.RFileOutputConfig.ROutputFolder);

					foreach (var folder in Config.RFileOutputConfig.FolderSettings)
					{
						AlpacaDLServices.ClearFolder(folder.Path);
					}

				}
				catch
				{

				}
			}
			Config.EnableBackfillUpdate = true;
			chkBackfillUpdate.Checked = true;
			StartWebSocketUpdate();
		}

		private void btnStopWebSocketUpdate_Click(object sender, EventArgs e)
		{
			StopWebSocketUpdate();	
		}

		private void chkCloseBarUpdate_CheckedChanged(object sender, EventArgs e)
		{
			radioHLC.Enabled = radioHL.Enabled = radioOHLC.Enabled = radioCO.Enabled = chkCloseBarUpdate.Checked;
		}

		private void radioProcessStatic_Click(object sender, EventArgs e)
		{
			RadioButton[] buttons = { radioProcessStatic, radioProcessAuto };

			foreach (var btn in buttons)
			{
				btn.Checked = sender == btn;
				chkAppendData.Enabled = sender == radioProcessAuto;
				txtDelay.Enabled = sender == radioProcessAuto;
			}
		}

		private void radioHL_Click(object sender, EventArgs e)
		{
			RadioButton[] buttons = { radioHLC, radioHL, radioOHLC, radioCO};

			foreach (var btn in buttons)
			{
				btn.Checked = sender == btn;
			}
		}

		private void btnGenerateCal_Click(object sender, EventArgs e)
		{
			BindSettings(true);
			processor.PrepareAPIClient();
			processor.GenerateCalendarFile();
		}

		private void chkCalendarAutoStart_CheckedChanged(object sender, EventArgs e)
		{
			dateTimeStart.Enabled = dateTimeEnd.Enabled = !(chkCalendarAutoStart.Checked);
		}

		private void chkCalendarWebSocket_CheckedChanged(object sender, EventArgs e)
		{
			dateTimeStart.Enabled = dateTimeEnd.Enabled = !(chkCalendarAutoStart.Checked);
		}
		private void btnRConfig_Click(object sender, EventArgs e)
		{
			FrmROutputConfig frmRConfig = new FrmROutputConfig(Config.RFileOutputConfig);
			frmRConfig.ShowDialog();
		}

		private void chkROutput_CheckedChanged(object sender, EventArgs e)
		{
			btnROutputSettings.Enabled = chkROutput.Checked;
		}

		private void btnTrimInputData_Click(object sender, EventArgs e)
		{
			BindSettings(true);
			Thread trimThread = new Thread(() => processor.DoTrim());
			trimThread.Start();
		}

		private string GetFolderPath(string initPath = "")
		{
			VistaFolderBrowserDialog folderBrowserDialog = new VistaFolderBrowserDialog();
			folderBrowserDialog.SelectedPath = initPath;
			if (folderBrowserDialog.ShowDialog().GetValueOrDefault())
			{
				return folderBrowserDialog.SelectedPath;
			}

			return "";
		}

		private void TrimControlEnable(bool bEnable)
		{
			btnTrimInputData.Enabled = bEnable;
		}

		private void CleanupControlEnable(bool bEnable)
		{
			btnCleanTree.Enabled = bEnable;
		}
		private void CleanupStockListControlEnable(bool bEnable)
		{
			btnCleanupStockList.Enabled = bEnable;
		}
		private void btnGenSectorFile_Click(object sender, EventArgs e)
		{
			FrmGenSectorFile frmGenSsectorFile = new FrmGenSectorFile(Config.SectorFileConfig);
			frmGenSsectorFile.ShowDialog();
		}

		private void txtSymbolListFile_TextChanged(object sender, EventArgs e)
		{

		}

		private void label3_Click(object sender, EventArgs e)
		{

		}

		private void btnCleanTree_Click(object sender, EventArgs e)
		{
			new Thread(() => processor.CleanUpTree()).Start();
		}

		private void radioProcessAuto_CheckedChanged(object sender, EventArgs e)
		{

		}

		private void btnSidewayFilters_Click(object sender, EventArgs e)
		{
			FrmSidewayFilterConfig dlg = new FrmSidewayFilterConfig(Config.SideWayConfig);
			dlg.ShowDialog();
		}
		void UpdateWebSocketLabels()
		{
			if (Config.WebSocketConfig.WebSocketType == WebSocketSource.TradeStation)
			{
				btnStartWebSocketUpdate.Text = "Tick Start";
				btnStopWebSocketUpdate.Text = "Tick Stop";
				//cmbDataFeedType.SelectedIndex = 3;
			}
			else
			{
				btnStartWebSocketUpdate.Text = "Start WebSocket Update";
				btnStopWebSocketUpdate.Text = "Stop WebSocket Update";
			}
		}
		private void btnWebSocketSettings_Click(object sender, EventArgs e)
		{
			FrmWebSocketSettings frmWebSetting = new FrmWebSocketSettings(Config.WebSocketConfig);
			frmWebSetting.ShowDialog();

			UpdateWebSocketLabels();
		}

		private void cmbDataFeedType_SelectedIndexChanged(object sender, EventArgs e)
		{
			Config.DataFeedSource = (DataFeedSouce)cmbDataFeedType.SelectedIndex;
			UpdateControlStateByDataFeed();
		}

		void UpdateControlStateByDataFeed()
		{
			UpdateTimeFrameItems(Config.DataFeedSource);

			if (Config.DataFeedSource == DataFeedSouce.AlpacaV1)
			{
				lblBarLimit.Text = "#Bars(100~1000)";
				lblTimeFrame.Text = "TimeFrame";
				dtStartDate.Enabled = dtEndDate.Enabled = false;
			}
			else if (Config.DataFeedSource == DataFeedSouce.AlpacaV2)
			{
				lblBarLimit.Text = "Limit(1~10000)";
				lblTimeFrame.Text = "TimeFrame";
				dtStartDate.Enabled = dtEndDate.Enabled = true;
			}
			else if (Config.DataFeedSource == DataFeedSouce.PolygonV2)
			{
				dtStartDate.Enabled = dtEndDate.Enabled = true;
				lblBarLimit.Text = "Limit(1~50000)";
				lblTimeFrame.Text = "TimeSpan";
			}
			else if (Config.DataFeedSource == DataFeedSouce.TwelveData)
			{
				dtStartDate.Enabled = dtEndDate.Enabled = false;
				lblBarLimit.Text = "#Bars(1~5000)";
			}
			else if (Config.DataFeedSource == DataFeedSouce.OnlyLocalData)
			{
				radioProcessAuto.Checked = false;
				radioProcessStatic.Checked = true;
				chkBackfillUpdate.Checked = true;

				MessageBox.Show("Please set the Start and End Date to Use");
			}
			else if (Config.DataFeedSource == DataFeedSouce.GlobalDataFeed)
			{
				chkMarketHoursOnly.Checked = false;
				lblBarLimit.Text = "#Bars(0~5000)";
				dtStartDate.Enabled = dtEndDate.Enabled = false;
			}
			else if (Config.DataFeedSource == DataFeedSouce.TradeStation)
			{
				dtStartDate.Enabled = dtEndDate.Enabled = false;
			}
			else if (Config.DataFeedSource == DataFeedSouce.Tradier)
			{
				dtStartDate.Enabled = dtEndDate.Enabled = true;
			}

			chkMarketHoursOnly.Enabled = Config.DataFeedSource != DataFeedSouce.GlobalDataFeed;
			cmbUnadjusted.Enabled = cmbSort.Enabled = Config.DataFeedSource == DataFeedSouce.PolygonV2;
			txtMultiplier.Enabled = Config.DataFeedSource == DataFeedSouce.PolygonV2 || Config.DataFeedSource == DataFeedSouce.GlobalDataFeed;
			panelPolygonDataFeedSetting.Visible = Config.DataFeedSource == DataFeedSouce.PolygonV2;
			txtBars.Enabled = Config.DataFeedSource != DataFeedSouce.TradeStation;

			chkTSOHLCV.Enabled = chkInputFileTSOptions.Enabled = Config.DataFeedSource == DataFeedSouce.TradeStation;
			ShowControlsByDataFeed();
		}

		private void UpdateTimeFrameItems(DataFeedSouce dataSource)
		{
			cmbTimeFrame.Items.Clear();
			List<DataTimeFrame> timeFrames = new List<DataTimeFrame>();
			if (dataSource == DataFeedSouce.AlpacaV1)
			{
				timeFrames.Add(DataTimeFrame.Minute);
				timeFrames.Add(DataTimeFrame.Minute5);
				timeFrames.Add(DataTimeFrame.Minute15);
				timeFrames.Add(DataTimeFrame.Hour);
				timeFrames.Add(DataTimeFrame.Day);
			}
			else if (dataSource == DataFeedSouce.AlpacaV2)
			{
				timeFrames.Add(DataTimeFrame.Minute);
				timeFrames.Add(DataTimeFrame.Hour);
				timeFrames.Add(DataTimeFrame.Day);
			}
			else if (dataSource == DataFeedSouce.PolygonV2)
			{
				timeFrames.Add(DataTimeFrame.Minute);
				timeFrames.Add(DataTimeFrame.Hour);
				timeFrames.Add(DataTimeFrame.Day);
				timeFrames.Add(DataTimeFrame.Week);
				timeFrames.Add(DataTimeFrame.Month);
				timeFrames.Add(DataTimeFrame.Quarter);
				timeFrames.Add(DataTimeFrame.Year);
			}
			else if (dataSource == DataFeedSouce.GlobalDataFeed)
			{
				timeFrames.Add(DataTimeFrame.Tick);
				timeFrames.Add(DataTimeFrame.Minute);
				timeFrames.Add(DataTimeFrame.Hour);
				timeFrames.Add(DataTimeFrame.Day);
				timeFrames.Add(DataTimeFrame.Week);
				timeFrames.Add(DataTimeFrame.Month);
			}
			else if (dataSource == DataFeedSouce.TwelveData)
			{
				timeFrames.Add(DataTimeFrame.Minute);
				timeFrames.Add(DataTimeFrame.Minute5);
				timeFrames.Add(DataTimeFrame.Minute15);
				timeFrames.Add(DataTimeFrame.Minute30);
				timeFrames.Add(DataTimeFrame.Minute45);
				timeFrames.Add(DataTimeFrame.Hour);
				timeFrames.Add(DataTimeFrame.Hour2);
				timeFrames.Add(DataTimeFrame.Hour4);
				timeFrames.Add(DataTimeFrame.Day);
				timeFrames.Add(DataTimeFrame.Week);
				timeFrames.Add(DataTimeFrame.Month);
			}
			else if (dataSource == DataFeedSouce.Tradier)
			{
				if (Config.TradierConfig.APICall == TradierSettings.CallType.TimeAndSale)
				{
					timeFrames.Add(DataTimeFrame.Tick);
					timeFrames.Add(DataTimeFrame.Minute);
					timeFrames.Add(DataTimeFrame.Minute5);
					timeFrames.Add(DataTimeFrame.Minute15);
				}
				else
				{
					timeFrames.Add(DataTimeFrame.Day);
					timeFrames.Add(DataTimeFrame.Week);
					timeFrames.Add(DataTimeFrame.Month);
				}
			}
			int selectedIndex = 0;
			for (int i = 0; i < timeFrames.Count; i++)
			{
				cmbTimeFrame.Items.Add(SriAlpacaDLProcess.Utils.GetNameFromTimeFrame(timeFrames[i]));
				if (Config.DataTimeFrame == timeFrames[i])
					selectedIndex = i;
			}

			if (dataSource != DataFeedSouce.OnlyLocalData && dataSource != DataFeedSouce.TradeStation &&
				dataSource != DataFeedSouce.TDAmeritrade)
				cmbTimeFrame.SelectedIndex = selectedIndex;
		}

		private void btnTSDataFeedConfig_Click(object sender, EventArgs e)
		{
			
		}

		private void btnRefreshToken_Click(object sender, EventArgs e)
		{
			
		}

		void ShowControlsByDataFeed()
		{
			panelLocalDataFeedSetting.Visible = Config.DataFeedSource == DataFeedSouce.OnlyLocalData;
			txtBars.Enabled = Config.DataFeedSource != DataFeedSouce.OnlyLocalData && Config.DataFeedSource != DataFeedSouce.TradeStation;
			panelPolygonDataFeedSetting.Visible = Config.DataFeedSource == DataFeedSouce.PolygonV2;
			panelLocalDataFeedSetting.Visible = Config.DataFeedSource == DataFeedSouce.OnlyLocalData;
			panelDatafeedSetting.Visible = Config.DataFeedSource == DataFeedSouce.GlobalDataFeed || Config.DataFeedSource == DataFeedSouce.TradeStation || 
				Config.DataFeedSource == DataFeedSouce.TwelveData || Config.DataFeedSource == DataFeedSouce.Tradier ||
				Config.DataFeedSource == DataFeedSouce.TDAmeritrade;
			if (Config.BarLimit > 0 && Config.DataFeedSource == DataFeedSouce.GlobalDataFeed)
			{
				dtStartDate.Enabled = dtEndDate.Enabled = false;
			}

			btnRefreshToken.Visible = Config.DataFeedSource == DataFeedSouce.TradeStation;// || Config.DataFeedSource == DataFeedSouce.Tradier;
		}

		private void btnBrowseLocalDataFolder_Click(object sender, EventArgs e)
		{
			txtLocalDataFolder.Text = GetFolderPath(txtLocalDataFolder.Text);
		}

		private void btnGlobalDataFeedSetting_Click(object sender, EventArgs e)
		{
			if (Config.DataFeedSource == DataFeedSouce.TradeStation)
			{
				FrmTSDataFeedSettings frm = new FrmTSDataFeedSettings(Config.TSDataFeedConfig);
				frm.ShowDialog();
			}

			else if (Config.DataFeedSource == DataFeedSouce.GlobalDataFeed)
			{
				FrmGlobalDataFeedConfig frm = new FrmGlobalDataFeedConfig(Config.GlobalDataFeedConfig);
				frm.ShowDialog();
			}
			else if (Config.DataFeedSource == DataFeedSouce.TwelveData)
			{
				FrmTwelveDataSetting frm = new FrmTwelveDataSetting(Config.TwelveDataConfig);
				frm.ShowDialog();
			}
			else if (Config.DataFeedSource == DataFeedSouce.Tradier)
			{
				FrmTradierSetting frm = new FrmTradierSetting(Config.TradierConfig);
				frm.ShowDialog();
				UpdateTimeFrameItems(Config.DataFeedSource);
			}
			else if (Config.DataFeedSource == DataFeedSouce.TDAmeritrade)
			{
				FrmTDAmeritradeSetting frm = new FrmTDAmeritradeSetting(Config.TDAmeritradeConfig);
				frm.ShowDialog();
			}
		}

		private void txtBars_TextChanged(object sender, EventArgs e)
		{
			int bar = 0;
			if (Config.DataFeedSource == DataFeedSouce.GlobalDataFeed)
			{
				if (string.IsNullOrEmpty(txtBars.Text) || int.TryParse(txtBars.Text, out bar))
				{
					dtStartDate.Enabled = dtEndDate.Enabled = bar == 0;
				}
			}
		}

		private void cmbTimeFrame_SelectedIndexChanged(object sender, EventArgs e)
		{

		}

		private void btnRefreshToken_Click_1(object sender, EventArgs e)
		{
			string token = "";
			if (Config.DataFeedSource == DataFeedSouce.TradeStation)
			{
				token = processor.GetRefreshToken();
			}
			else if (Config.DataFeedSource == DataFeedSouce.Tradier)
			{
				
			}
			if (!string.IsNullOrEmpty(token))
			{
				File.WriteAllText("refresh_token.txt", token);
				MessageBox.Show("RefreshToken hasn been updated." + Environment.NewLine +
					"Please check [refresh_token.txt]");
			}
		}

		private void btnMarketView_Click(object sender, EventArgs e)
		{
			FrmMarketViewConfig frm = new FrmMarketViewConfig(Config.MarketViewReportConfig);
			frm.ShowDialog();
		}

		private void btnAWSSettings_Click(object sender, EventArgs e)
		{
			FrmAWS3Config frm = new FrmAWS3Config(Config.AWSS3Config);
			frm.ShowDialog();
		}

		private void btnCleanupStockList_Click(object sender, EventArgs e)
		{
			processor.CleanupStockList();
		}

		private void btnMiscSettings_Click(object sender, EventArgs e)
		{
			FrmMiscSettings frm = new FrmMiscSettings(Config.MiscConfig);
			frm.ShowDialog();
		}

		private void btnCleanStockListConfig_Click(object sender, EventArgs e)
		{
			FrmCleanStockListSettings frm = new FrmCleanStockListSettings(Config.CleanupStockListConfig);
			frm.ShowDialog();
		}

		private void btnTest_Click(object sender, EventArgs e)
		{
			processor.Test();
		}

		private void btnPusherSettings_Click(object sender, EventArgs e)
		{
			FrmPusherConfig frm = new FrmPusherConfig(Config.PushConfig);
			frm.ShowDialog();
		}

		private void btnSignalSettings_Click(object sender, EventArgs e)
		{
			FrmSignalSettings frm = new FrmSignalSettings(Config.SignalConfig);
			frm.ShowDialog();
		}
	}
}
