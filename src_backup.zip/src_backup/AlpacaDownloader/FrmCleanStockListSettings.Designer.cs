﻿
namespace SriAlpacaDL
{
	partial class FrmCleanStockListSettings
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btnBrowseSymbolList = new System.Windows.Forms.Button();
			this.txtSymbolListFile = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.chkStatus = new System.Windows.Forms.CheckBox();
			this.chkMarginable = new System.Windows.Forms.CheckBox();
			this.chkShortable = new System.Windows.Forms.CheckBox();
			this.chkEasyToBorrow = new System.Windows.Forms.CheckBox();
			this.chkFractionable = new System.Windows.Forms.CheckBox();
			this.label2 = new System.Windows.Forms.Label();
			this.btnOK = new System.Windows.Forms.Button();
			this.btnCancel = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// btnBrowseSymbolList
			// 
			this.btnBrowseSymbolList.Location = new System.Drawing.Point(342, 12);
			this.btnBrowseSymbolList.Name = "btnBrowseSymbolList";
			this.btnBrowseSymbolList.Size = new System.Drawing.Size(27, 22);
			this.btnBrowseSymbolList.TabIndex = 31;
			this.btnBrowseSymbolList.Text = "...";
			this.btnBrowseSymbolList.UseVisualStyleBackColor = true;
			this.btnBrowseSymbolList.Click += new System.EventHandler(this.btnBrowseSymbolList_Click);
			// 
			// txtSymbolListFile
			// 
			this.txtSymbolListFile.Location = new System.Drawing.Point(89, 13);
			this.txtSymbolListFile.Name = "txtSymbolListFile";
			this.txtSymbolListFile.Size = new System.Drawing.Size(253, 20);
			this.txtSymbolListFile.TabIndex = 30;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(23, 16);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(54, 13);
			this.label1.TabIndex = 32;
			this.label1.Text = "Stock List";
			// 
			// chkStatus
			// 
			this.chkStatus.AutoSize = true;
			this.chkStatus.Location = new System.Drawing.Point(89, 73);
			this.chkStatus.Name = "chkStatus";
			this.chkStatus.Size = new System.Drawing.Size(100, 17);
			this.chkStatus.TabIndex = 33;
			this.chkStatus.Text = "Status=Inactive";
			this.chkStatus.UseVisualStyleBackColor = true;
			// 
			// chkMarginable
			// 
			this.chkMarginable.AutoSize = true;
			this.chkMarginable.Location = new System.Drawing.Point(89, 101);
			this.chkMarginable.Name = "chkMarginable";
			this.chkMarginable.Size = new System.Drawing.Size(109, 17);
			this.chkMarginable.TabIndex = 34;
			this.chkMarginable.Text = "Marginable=False";
			this.chkMarginable.UseVisualStyleBackColor = true;
			// 
			// chkShortable
			// 
			this.chkShortable.AutoSize = true;
			this.chkShortable.Location = new System.Drawing.Point(89, 129);
			this.chkShortable.Name = "chkShortable";
			this.chkShortable.Size = new System.Drawing.Size(102, 17);
			this.chkShortable.TabIndex = 35;
			this.chkShortable.Text = "Shortable=False";
			this.chkShortable.UseVisualStyleBackColor = true;
			// 
			// chkEasyToBorrow
			// 
			this.chkEasyToBorrow.AutoSize = true;
			this.chkEasyToBorrow.Location = new System.Drawing.Point(89, 157);
			this.chkEasyToBorrow.Name = "chkEasyToBorrow";
			this.chkEasyToBorrow.Size = new System.Drawing.Size(132, 17);
			this.chkEasyToBorrow.TabIndex = 36;
			this.chkEasyToBorrow.Text = "Easy To Borrow=False";
			this.chkEasyToBorrow.UseVisualStyleBackColor = true;
			// 
			// chkFractionable
			// 
			this.chkFractionable.AutoSize = true;
			this.chkFractionable.Location = new System.Drawing.Point(89, 184);
			this.chkFractionable.Name = "chkFractionable";
			this.chkFractionable.Size = new System.Drawing.Size(115, 17);
			this.chkFractionable.TabIndex = 37;
			this.chkFractionable.Text = "Fractionable=False";
			this.chkFractionable.UseVisualStyleBackColor = true;
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(26, 49);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(84, 13);
			this.label2.TabIndex = 38;
			this.label2.Text = "Delete Symbol If";
			// 
			// btnOK
			// 
			this.btnOK.Location = new System.Drawing.Point(128, 212);
			this.btnOK.Name = "btnOK";
			this.btnOK.Size = new System.Drawing.Size(112, 26);
			this.btnOK.TabIndex = 39;
			this.btnOK.Text = "OK";
			this.btnOK.UseVisualStyleBackColor = true;
			this.btnOK.Click += new System.EventHandler(this.btnCleanup_Click);
			// 
			// btnCancel
			// 
			this.btnCancel.Location = new System.Drawing.Point(260, 212);
			this.btnCancel.Name = "btnCancel";
			this.btnCancel.Size = new System.Drawing.Size(112, 26);
			this.btnCancel.TabIndex = 40;
			this.btnCancel.Text = "Cancel";
			this.btnCancel.UseVisualStyleBackColor = true;
			this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
			// 
			// FrmCleanStockListSettings
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(384, 250);
			this.Controls.Add(this.btnCancel);
			this.Controls.Add(this.btnOK);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.chkFractionable);
			this.Controls.Add(this.chkEasyToBorrow);
			this.Controls.Add(this.chkShortable);
			this.Controls.Add(this.chkMarginable);
			this.Controls.Add(this.chkStatus);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.btnBrowseSymbolList);
			this.Controls.Add(this.txtSymbolListFile);
			this.Name = "FrmCleanStockListSettings";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Cleanup Stock List";
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Button btnBrowseSymbolList;
		private System.Windows.Forms.TextBox txtSymbolListFile;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.CheckBox chkStatus;
		private System.Windows.Forms.CheckBox chkMarginable;
		private System.Windows.Forms.CheckBox chkShortable;
		private System.Windows.Forms.CheckBox chkEasyToBorrow;
		private System.Windows.Forms.CheckBox chkFractionable;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Button btnOK;
		private System.Windows.Forms.Button btnCancel;
	}
}