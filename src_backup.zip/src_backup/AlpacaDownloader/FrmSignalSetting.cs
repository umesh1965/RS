﻿using SriAlpacaDLModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SriAlpacaDL
{
	public partial class FrmSignalSettings : Form
	{
		SignalSettings config;
		public FrmSignalSettings()
		{
			InitializeComponent();
		}
		public FrmSignalSettings(SignalSettings config_) : this()
		{
			config = config_;
			BindData(false);
			EnableControls();
		}
		private void chkEnableBSSignal_CheckedChanged(object sender, EventArgs e)
		{
			EnableControls();
		}

		private void checkBox1_CheckedChanged(object sender, EventArgs e)
		{
			EnableControls();
		}

		void EnableControls()
		{
			groupBSSignal.Enabled = chkEnableBSSignal.Checked;
			groupTrendSignal.Enabled = chkTrendSignals.Checked;
			txtBSLevels.Enabled = radioBSLevel.Checked;
			txtLavgSignal.Enabled = radLavgSignal.Checked;
			groupGenSignal.Enabled = chkGenSignal.Checked;
		}

		void BindData(bool fromControl)
		{
			if (fromControl)
			{
				double tempVal = 0;
				config.EnableBSSignals = chkEnableBSSignal.Checked;
				config.BSSignalMode = radioBSLevel.Checked ? 0 : 1;
				config.BSLevels = double.TryParse(txtBSLevels.Text, out tempVal) ? (int)tempVal : 0;
				config.Lavg1SignalMin = double.TryParse(txtLavgSignal.Text, out tempVal) ? tempVal : 0;
				config.L1 = chkL1.Checked;
				config.L2 = chkL2.Checked;
				config.L3 = chkL3.Checked;
				config.L4 = chkL4.Checked;
				config.L13 = chkL13.Checked;
				config.L14 = chkL14.Checked;
				config.L23 = chkL23.Checked;
				config.L24 = chkL24.Checked;
				config.L34 = chkL34.Checked;
				config.GenSignalText = chkGenSignal.Checked;
				config.GenSignalFolder = txtFolderPath.Text;
				config.MaxTimeGap = double.TryParse(txtMaxTimeGap.Text, out tempVal) ? (int)tempVal : 0;
				config.QtyCalculation = (QtyCalculationMode)cmbQtyCalculation.SelectedIndex;
				config.GenMode = radGenBSSignal.Checked ? GenSignalMode.BS : GenSignalMode.Trend;
				config.L1 = chkL1.Checked;
				config.Amount = double.TryParse(txtAmount.Text, out tempVal) ? (int)tempVal : 0;
				config.EnableTrendSignal = chkTrendSignals.Checked;
			}
			else
			{
				chkEnableBSSignal.Checked = config.EnableBSSignals;
				txtBSLevels.Text = config.BSLevels.ToString();
				radioBSLevel.Checked = config.BSSignalMode == 0;
				radLavgSignal.Checked = config.BSSignalMode == 1;
				txtLavgSignal.Text = config.Lavg1SignalMin.ToString("0.00");
				chkTrendSignals.Checked = config.EnableTrendSignal;
				chkL1.Checked = config.L1;
				chkL2.Checked = config.L2;
				chkL3.Checked = config.L3;
				chkL4.Checked = config.L4;
				chkL13.Checked = config.L13;
				chkL14.Checked = config.L14;
				chkL23.Checked = config.L23;
				chkL24.Checked = config.L24;
				chkL34.Checked = config.L34;
				chkGenSignal.Checked = config.GenSignalText;
				txtFolderPath.Text = config.GenSignalFolder;
				txtMaxTimeGap.Text = config.MaxTimeGap.ToString();
				cmbQtyCalculation.SelectedIndex = (int)config.QtyCalculation;
				radGenBSSignal.Checked = config.GenMode == GenSignalMode.BS;
				radioGenTrendSignal.Checked = config.GenMode != GenSignalMode.BS;
				txtAmount.Text = config.Amount.ToString();
				//
			}
		}

		private void btnOK_Click(object sender, EventArgs e)
		{
			BindData(true);
			Close();
		}

		private void btnCancel_Click(object sender, EventArgs e)
		{
			Close();
		}

		private void btnBrowseFolder_Click(object sender, EventArgs e)
		{
			txtFolderPath.Text = Utils.GetFolderPath(txtFolderPath.Text);
		}

		private void cmbQtyCalculation_SelectedIndexChanged(object sender, EventArgs e)
		{
			if (cmbQtyCalculation.SelectedIndex == 0)
				lblAmount.Text = "Amount";
			else
				lblAmount.Text = "Qty";
		}

		private void chkTrendSignals_CheckedChanged(object sender, EventArgs e)
		{
			groupTrendSignal.Enabled = chkTrendSignals.Checked;
		}
	}
}
