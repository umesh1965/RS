﻿
namespace SriAlpacaDL
{
	partial class FrmROutputConfig
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.txtLevel = new System.Windows.Forms.TextBox();
			this.label6 = new System.Windows.Forms.Label();
			this.txtBar = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.groupBoxMultipleFiles = new System.Windows.Forms.GroupBox();
			this.label17 = new System.Windows.Forms.Label();
			this.label16 = new System.Windows.Forms.Label();
			this.btnBrowseFolder10 = new System.Windows.Forms.Button();
			this.txtBarFolder10 = new System.Windows.Forms.TextBox();
			this.txtFolder10Path = new System.Windows.Forms.TextBox();
			this.label13 = new System.Windows.Forms.Label();
			this.btnBrowseFolder9 = new System.Windows.Forms.Button();
			this.btnBrowseFolder8 = new System.Windows.Forms.Button();
			this.txtBarFolder9 = new System.Windows.Forms.TextBox();
			this.txtFolder9Path = new System.Windows.Forms.TextBox();
			this.label9 = new System.Windows.Forms.Label();
			this.txtBarFolder8 = new System.Windows.Forms.TextBox();
			this.txtFolder8Path = new System.Windows.Forms.TextBox();
			this.label10 = new System.Windows.Forms.Label();
			this.btnBrowseFolder7 = new System.Windows.Forms.Button();
			this.btnBrowseFolder6 = new System.Windows.Forms.Button();
			this.txtBarFolder7 = new System.Windows.Forms.TextBox();
			this.txtFolder7Path = new System.Windows.Forms.TextBox();
			this.label11 = new System.Windows.Forms.Label();
			this.txtBarFolder6 = new System.Windows.Forms.TextBox();
			this.txtFolder6Path = new System.Windows.Forms.TextBox();
			this.label12 = new System.Windows.Forms.Label();
			this.btnBrowseFolder5 = new System.Windows.Forms.Button();
			this.btnBrowseFolder4 = new System.Windows.Forms.Button();
			this.txtBarFolder5 = new System.Windows.Forms.TextBox();
			this.txtFolder5Path = new System.Windows.Forms.TextBox();
			this.label7 = new System.Windows.Forms.Label();
			this.txtBarFolder4 = new System.Windows.Forms.TextBox();
			this.txtFolder4Path = new System.Windows.Forms.TextBox();
			this.label8 = new System.Windows.Forms.Label();
			this.btnBrowseFolder3 = new System.Windows.Forms.Button();
			this.btnBrowseFolder2 = new System.Windows.Forms.Button();
			this.txtBarFolder3 = new System.Windows.Forms.TextBox();
			this.txtFolder3Path = new System.Windows.Forms.TextBox();
			this.label5 = new System.Windows.Forms.Label();
			this.txtBarFolder2 = new System.Windows.Forms.TextBox();
			this.txtFolder2Path = new System.Windows.Forms.TextBox();
			this.label4 = new System.Windows.Forms.Label();
			this.txtNumberOfFolders = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.chkMultipleRFiles = new System.Windows.Forms.CheckBox();
			this.groupBoxZMQ = new System.Windows.Forms.GroupBox();
			this.chkSendCycleCompleteMsg = new System.Windows.Forms.CheckBox();
			this.txtPort = new System.Windows.Forms.TextBox();
			this.label15 = new System.Windows.Forms.Label();
			this.txtIP = new System.Windows.Forms.TextBox();
			this.label14 = new System.Windows.Forms.Label();
			this.chkSendZMQ = new System.Windows.Forms.CheckBox();
			this.btnOK = new System.Windows.Forms.Button();
			this.btnCancel = new System.Windows.Forms.Button();
			this.btnBrowseROutputFolder = new System.Windows.Forms.Button();
			this.txtROutputFolder = new System.Windows.Forms.TextBox();
			this.label18 = new System.Windows.Forms.Label();
			this.chkStoreBarChange = new System.Windows.Forms.CheckBox();
			this.chkDontOutputFiles = new System.Windows.Forms.CheckBox();
			this.chkGenAlignOutput = new System.Windows.Forms.CheckBox();
			this.groupAlignOutput = new System.Windows.Forms.GroupBox();
			this.chkApplyAfterCleanup = new System.Windows.Forms.CheckBox();
			this.chkVolCal = new System.Windows.Forms.CheckBox();
			this.txtCleanupTo = new System.Windows.Forms.TextBox();
			this.label21 = new System.Windows.Forms.Label();
			this.txtCleanupFrom = new System.Windows.Forms.TextBox();
			this.label20 = new System.Windows.Forms.Label();
			this.btnBrowseAlignOutputFolder = new System.Windows.Forms.Button();
			this.txtAlignOutputFolder = new System.Windows.Forms.TextBox();
			this.label19 = new System.Windows.Forms.Label();
			this.chkBinaryCleanup = new System.Windows.Forms.CheckBox();
			this.txtNumberOfAlignFolders = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.chkOutputOnlyR = new System.Windows.Forms.CheckBox();
			this.txtOutputOnlyR = new System.Windows.Forms.TextBox();
			this.groupSubCal = new System.Windows.Forms.GroupBox();
			this.chkUseVolForLevels = new System.Windows.Forms.CheckBox();
			this.chkCalAvg = new System.Windows.Forms.CheckBox();
			this.txtSubCalLevels = new System.Windows.Forms.TextBox();
			this.label23 = new System.Windows.Forms.Label();
			this.chkApplyAlignR = new System.Windows.Forms.CheckBox();
			this.chkApplyMultipleR = new System.Windows.Forms.CheckBox();
			this.chkApplyPrimaryR = new System.Windows.Forms.CheckBox();
			this.label22 = new System.Windows.Forms.Label();
			this.panelCalAvg = new System.Windows.Forms.Panel();
			this.txtLavg4End = new System.Windows.Forms.TextBox();
			this.txtLavg4Start = new System.Windows.Forms.TextBox();
			this.label30 = new System.Windows.Forms.Label();
			this.txtLavg3End = new System.Windows.Forms.TextBox();
			this.txtLavg3Start = new System.Windows.Forms.TextBox();
			this.label29 = new System.Windows.Forms.Label();
			this.txtLavg2End = new System.Windows.Forms.TextBox();
			this.txtLavg2Start = new System.Windows.Forms.TextBox();
			this.label28 = new System.Windows.Forms.Label();
			this.label27 = new System.Windows.Forms.Label();
			this.txtLavg1End = new System.Windows.Forms.TextBox();
			this.label26 = new System.Windows.Forms.Label();
			this.txtLavg1Start = new System.Windows.Forms.TextBox();
			this.label25 = new System.Windows.Forms.Label();
			this.chkSubCal = new System.Windows.Forms.CheckBox();
			this.groupLatestSignal = new System.Windows.Forms.GroupBox();
			this.chkLatestMasterNew = new System.Windows.Forms.CheckBox();
			this.chkGenLatestMasterFile = new System.Windows.Forms.CheckBox();
			this.chkGenLatestFile = new System.Windows.Forms.CheckBox();
			this.btnBrowselatestOutput = new System.Windows.Forms.Button();
			this.txtLastOutputFolder = new System.Windows.Forms.TextBox();
			this.label31 = new System.Windows.Forms.Label();
			this.chkLatestOutAlign = new System.Windows.Forms.CheckBox();
			this.chkLatestOutMultiple = new System.Windows.Forms.CheckBox();
			this.chkLatestOutPrimary = new System.Windows.Forms.CheckBox();
			this.label24 = new System.Windows.Forms.Label();
			this.chkCustomPricePoint = new System.Windows.Forms.CheckBox();
			this.btnBrowseCustomPricePoint = new System.Windows.Forms.Button();
			this.txtCustomPricePointBarPath = new System.Windows.Forms.TextBox();
			this.btnBrowseCustomBarPercent = new System.Windows.Forms.Button();
			this.txtCustomBarPercentPath = new System.Windows.Forms.TextBox();
			this.chkCustomPercentBar = new System.Windows.Forms.CheckBox();
			this.chkLatestSignalOutput = new System.Windows.Forms.CheckBox();
			this.chkColumnToUseForLabel = new System.Windows.Forms.CheckBox();
			this.cmbColumnForLevel = new System.Windows.Forms.ComboBox();
			this.chkBinaryLevels = new System.Windows.Forms.CheckBox();
			this.chkMapLevels = new System.Windows.Forms.CheckBox();
			this.btnBrowseMapLevelFile = new System.Windows.Forms.Button();
			this.txtMapLevelFile = new System.Windows.Forms.TextBox();
			this.chkMasterColumnReport = new System.Windows.Forms.CheckBox();
			this.groupMasterColumnReport = new System.Windows.Forms.GroupBox();
			this.chkMasterReportDTC = new System.Windows.Forms.CheckBox();
			this.chkMasterReportColumnOnly = new System.Windows.Forms.CheckBox();
			this.label34 = new System.Windows.Forms.Label();
			this.label33 = new System.Windows.Forms.Label();
			this.txtRowsToOutput = new System.Windows.Forms.TextBox();
			this.label32 = new System.Windows.Forms.Label();
			this.cmbMasterColOutput = new System.Windows.Forms.ComboBox();
			this.btnBrowseMasterReportOutput = new System.Windows.Forms.Button();
			this.txtMasterReportOutput = new System.Windows.Forms.TextBox();
			this.groupBoxMultipleFiles.SuspendLayout();
			this.groupBoxZMQ.SuspendLayout();
			this.groupAlignOutput.SuspendLayout();
			this.groupSubCal.SuspendLayout();
			this.panelCalAvg.SuspendLayout();
			this.groupLatestSignal.SuspendLayout();
			this.groupMasterColumnReport.SuspendLayout();
			this.SuspendLayout();
			// 
			// txtLevel
			// 
			this.txtLevel.Location = new System.Drawing.Point(151, 46);
			this.txtLevel.Name = "txtLevel";
			this.txtLevel.Size = new System.Drawing.Size(83, 20);
			this.txtLevel.TabIndex = 25;
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Location = new System.Drawing.Point(40, 49);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(33, 13);
			this.label6.TabIndex = 24;
			this.label6.Text = "Level";
			// 
			// txtBar
			// 
			this.txtBar.Location = new System.Drawing.Point(321, 46);
			this.txtBar.Name = "txtBar";
			this.txtBar.Size = new System.Drawing.Size(80, 20);
			this.txtBar.TabIndex = 27;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(284, 49);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(31, 13);
			this.label1.TabIndex = 26;
			this.label1.Text = "Bar%";
			// 
			// groupBoxMultipleFiles
			// 
			this.groupBoxMultipleFiles.Controls.Add(this.label17);
			this.groupBoxMultipleFiles.Controls.Add(this.label16);
			this.groupBoxMultipleFiles.Controls.Add(this.btnBrowseFolder10);
			this.groupBoxMultipleFiles.Controls.Add(this.txtBarFolder10);
			this.groupBoxMultipleFiles.Controls.Add(this.txtFolder10Path);
			this.groupBoxMultipleFiles.Controls.Add(this.label13);
			this.groupBoxMultipleFiles.Controls.Add(this.btnBrowseFolder9);
			this.groupBoxMultipleFiles.Controls.Add(this.btnBrowseFolder8);
			this.groupBoxMultipleFiles.Controls.Add(this.txtBarFolder9);
			this.groupBoxMultipleFiles.Controls.Add(this.txtFolder9Path);
			this.groupBoxMultipleFiles.Controls.Add(this.label9);
			this.groupBoxMultipleFiles.Controls.Add(this.txtBarFolder8);
			this.groupBoxMultipleFiles.Controls.Add(this.txtFolder8Path);
			this.groupBoxMultipleFiles.Controls.Add(this.label10);
			this.groupBoxMultipleFiles.Controls.Add(this.btnBrowseFolder7);
			this.groupBoxMultipleFiles.Controls.Add(this.btnBrowseFolder6);
			this.groupBoxMultipleFiles.Controls.Add(this.txtBarFolder7);
			this.groupBoxMultipleFiles.Controls.Add(this.txtFolder7Path);
			this.groupBoxMultipleFiles.Controls.Add(this.label11);
			this.groupBoxMultipleFiles.Controls.Add(this.txtBarFolder6);
			this.groupBoxMultipleFiles.Controls.Add(this.txtFolder6Path);
			this.groupBoxMultipleFiles.Controls.Add(this.label12);
			this.groupBoxMultipleFiles.Controls.Add(this.btnBrowseFolder5);
			this.groupBoxMultipleFiles.Controls.Add(this.btnBrowseFolder4);
			this.groupBoxMultipleFiles.Controls.Add(this.txtBarFolder5);
			this.groupBoxMultipleFiles.Controls.Add(this.txtFolder5Path);
			this.groupBoxMultipleFiles.Controls.Add(this.label7);
			this.groupBoxMultipleFiles.Controls.Add(this.txtBarFolder4);
			this.groupBoxMultipleFiles.Controls.Add(this.txtFolder4Path);
			this.groupBoxMultipleFiles.Controls.Add(this.label8);
			this.groupBoxMultipleFiles.Controls.Add(this.btnBrowseFolder3);
			this.groupBoxMultipleFiles.Controls.Add(this.btnBrowseFolder2);
			this.groupBoxMultipleFiles.Controls.Add(this.txtBarFolder3);
			this.groupBoxMultipleFiles.Controls.Add(this.txtFolder3Path);
			this.groupBoxMultipleFiles.Controls.Add(this.label5);
			this.groupBoxMultipleFiles.Controls.Add(this.txtBarFolder2);
			this.groupBoxMultipleFiles.Controls.Add(this.txtFolder2Path);
			this.groupBoxMultipleFiles.Controls.Add(this.label4);
			this.groupBoxMultipleFiles.Controls.Add(this.txtNumberOfFolders);
			this.groupBoxMultipleFiles.Controls.Add(this.label2);
			this.groupBoxMultipleFiles.Location = new System.Drawing.Point(19, 313);
			this.groupBoxMultipleFiles.Name = "groupBoxMultipleFiles";
			this.groupBoxMultipleFiles.Size = new System.Drawing.Size(418, 307);
			this.groupBoxMultipleFiles.TabIndex = 28;
			this.groupBoxMultipleFiles.TabStop = false;
			// 
			// label17
			// 
			this.label17.AutoSize = true;
			this.label17.Location = new System.Drawing.Point(367, 46);
			this.label17.Name = "label17";
			this.label17.Size = new System.Drawing.Size(31, 13);
			this.label17.TabIndex = 69;
			this.label17.Text = "Bar%";
			// 
			// label16
			// 
			this.label16.AutoSize = true;
			this.label16.Location = new System.Drawing.Point(222, 46);
			this.label16.Name = "label16";
			this.label16.Size = new System.Drawing.Size(29, 13);
			this.label16.TabIndex = 68;
			this.label16.Text = "Path";
			// 
			// btnBrowseFolder10
			// 
			this.btnBrowseFolder10.Location = new System.Drawing.Point(296, 275);
			this.btnBrowseFolder10.Name = "btnBrowseFolder10";
			this.btnBrowseFolder10.Size = new System.Drawing.Size(34, 22);
			this.btnBrowseFolder10.TabIndex = 67;
			this.btnBrowseFolder10.Text = "...";
			this.btnBrowseFolder10.UseVisualStyleBackColor = true;
			this.btnBrowseFolder10.Click += new System.EventHandler(this.btnBrowseFolder10_Click);
			// 
			// txtBarFolder10
			// 
			this.txtBarFolder10.Location = new System.Drawing.Point(341, 276);
			this.txtBarFolder10.Name = "txtBarFolder10";
			this.txtBarFolder10.Size = new System.Drawing.Size(66, 20);
			this.txtBarFolder10.TabIndex = 66;
			// 
			// txtFolder10Path
			// 
			this.txtFolder10Path.Location = new System.Drawing.Point(99, 276);
			this.txtFolder10Path.Name = "txtFolder10Path";
			this.txtFolder10Path.Size = new System.Drawing.Size(197, 20);
			this.txtFolder10Path.TabIndex = 65;
			// 
			// label13
			// 
			this.label13.AutoSize = true;
			this.label13.Location = new System.Drawing.Point(20, 279);
			this.label13.Name = "label13";
			this.label13.Size = new System.Drawing.Size(48, 13);
			this.label13.TabIndex = 64;
			this.label13.Text = "Folder10";
			// 
			// btnBrowseFolder9
			// 
			this.btnBrowseFolder9.Location = new System.Drawing.Point(296, 248);
			this.btnBrowseFolder9.Name = "btnBrowseFolder9";
			this.btnBrowseFolder9.Size = new System.Drawing.Size(34, 22);
			this.btnBrowseFolder9.TabIndex = 63;
			this.btnBrowseFolder9.Text = "...";
			this.btnBrowseFolder9.UseVisualStyleBackColor = true;
			this.btnBrowseFolder9.Click += new System.EventHandler(this.btnBrowseFolder9_Click);
			// 
			// btnBrowseFolder8
			// 
			this.btnBrowseFolder8.Location = new System.Drawing.Point(296, 222);
			this.btnBrowseFolder8.Name = "btnBrowseFolder8";
			this.btnBrowseFolder8.Size = new System.Drawing.Size(34, 22);
			this.btnBrowseFolder8.TabIndex = 62;
			this.btnBrowseFolder8.Text = "...";
			this.btnBrowseFolder8.UseVisualStyleBackColor = true;
			this.btnBrowseFolder8.Click += new System.EventHandler(this.btnBrowseFolder8_Click);
			// 
			// txtBarFolder9
			// 
			this.txtBarFolder9.Location = new System.Drawing.Point(341, 249);
			this.txtBarFolder9.Name = "txtBarFolder9";
			this.txtBarFolder9.Size = new System.Drawing.Size(66, 20);
			this.txtBarFolder9.TabIndex = 61;
			// 
			// txtFolder9Path
			// 
			this.txtFolder9Path.Location = new System.Drawing.Point(99, 249);
			this.txtFolder9Path.Name = "txtFolder9Path";
			this.txtFolder9Path.Size = new System.Drawing.Size(197, 20);
			this.txtFolder9Path.TabIndex = 60;
			// 
			// label9
			// 
			this.label9.AutoSize = true;
			this.label9.Location = new System.Drawing.Point(20, 252);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(42, 13);
			this.label9.TabIndex = 59;
			this.label9.Text = "Folder9";
			// 
			// txtBarFolder8
			// 
			this.txtBarFolder8.Location = new System.Drawing.Point(341, 223);
			this.txtBarFolder8.Name = "txtBarFolder8";
			this.txtBarFolder8.Size = new System.Drawing.Size(66, 20);
			this.txtBarFolder8.TabIndex = 58;
			// 
			// txtFolder8Path
			// 
			this.txtFolder8Path.Location = new System.Drawing.Point(99, 223);
			this.txtFolder8Path.Name = "txtFolder8Path";
			this.txtFolder8Path.Size = new System.Drawing.Size(197, 20);
			this.txtFolder8Path.TabIndex = 57;
			// 
			// label10
			// 
			this.label10.AutoSize = true;
			this.label10.Location = new System.Drawing.Point(20, 226);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(42, 13);
			this.label10.TabIndex = 56;
			this.label10.Text = "Folder8";
			// 
			// btnBrowseFolder7
			// 
			this.btnBrowseFolder7.Location = new System.Drawing.Point(296, 196);
			this.btnBrowseFolder7.Name = "btnBrowseFolder7";
			this.btnBrowseFolder7.Size = new System.Drawing.Size(34, 22);
			this.btnBrowseFolder7.TabIndex = 55;
			this.btnBrowseFolder7.Text = "...";
			this.btnBrowseFolder7.UseVisualStyleBackColor = true;
			this.btnBrowseFolder7.Click += new System.EventHandler(this.btnBrowseFolder7_Click);
			// 
			// btnBrowseFolder6
			// 
			this.btnBrowseFolder6.Location = new System.Drawing.Point(296, 170);
			this.btnBrowseFolder6.Name = "btnBrowseFolder6";
			this.btnBrowseFolder6.Size = new System.Drawing.Size(34, 22);
			this.btnBrowseFolder6.TabIndex = 54;
			this.btnBrowseFolder6.Text = "...";
			this.btnBrowseFolder6.UseVisualStyleBackColor = true;
			this.btnBrowseFolder6.Click += new System.EventHandler(this.btnBrowseFolder6_Click);
			// 
			// txtBarFolder7
			// 
			this.txtBarFolder7.Location = new System.Drawing.Point(341, 197);
			this.txtBarFolder7.Name = "txtBarFolder7";
			this.txtBarFolder7.Size = new System.Drawing.Size(66, 20);
			this.txtBarFolder7.TabIndex = 53;
			// 
			// txtFolder7Path
			// 
			this.txtFolder7Path.Location = new System.Drawing.Point(99, 197);
			this.txtFolder7Path.Name = "txtFolder7Path";
			this.txtFolder7Path.Size = new System.Drawing.Size(197, 20);
			this.txtFolder7Path.TabIndex = 52;
			// 
			// label11
			// 
			this.label11.AutoSize = true;
			this.label11.Location = new System.Drawing.Point(20, 200);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(42, 13);
			this.label11.TabIndex = 51;
			this.label11.Text = "Folder7";
			// 
			// txtBarFolder6
			// 
			this.txtBarFolder6.Location = new System.Drawing.Point(341, 171);
			this.txtBarFolder6.Name = "txtBarFolder6";
			this.txtBarFolder6.Size = new System.Drawing.Size(66, 20);
			this.txtBarFolder6.TabIndex = 50;
			// 
			// txtFolder6Path
			// 
			this.txtFolder6Path.Location = new System.Drawing.Point(99, 171);
			this.txtFolder6Path.Name = "txtFolder6Path";
			this.txtFolder6Path.Size = new System.Drawing.Size(197, 20);
			this.txtFolder6Path.TabIndex = 49;
			// 
			// label12
			// 
			this.label12.AutoSize = true;
			this.label12.Location = new System.Drawing.Point(20, 174);
			this.label12.Name = "label12";
			this.label12.Size = new System.Drawing.Size(42, 13);
			this.label12.TabIndex = 48;
			this.label12.Text = "Folder6";
			// 
			// btnBrowseFolder5
			// 
			this.btnBrowseFolder5.Location = new System.Drawing.Point(296, 144);
			this.btnBrowseFolder5.Name = "btnBrowseFolder5";
			this.btnBrowseFolder5.Size = new System.Drawing.Size(34, 22);
			this.btnBrowseFolder5.TabIndex = 47;
			this.btnBrowseFolder5.Text = "...";
			this.btnBrowseFolder5.UseVisualStyleBackColor = true;
			this.btnBrowseFolder5.Click += new System.EventHandler(this.btnBrowseFolder5_Click);
			// 
			// btnBrowseFolder4
			// 
			this.btnBrowseFolder4.Location = new System.Drawing.Point(296, 118);
			this.btnBrowseFolder4.Name = "btnBrowseFolder4";
			this.btnBrowseFolder4.Size = new System.Drawing.Size(34, 22);
			this.btnBrowseFolder4.TabIndex = 46;
			this.btnBrowseFolder4.Text = "...";
			this.btnBrowseFolder4.UseVisualStyleBackColor = true;
			this.btnBrowseFolder4.Click += new System.EventHandler(this.btnBrowseFolder4_Click);
			// 
			// txtBarFolder5
			// 
			this.txtBarFolder5.Location = new System.Drawing.Point(341, 145);
			this.txtBarFolder5.Name = "txtBarFolder5";
			this.txtBarFolder5.Size = new System.Drawing.Size(66, 20);
			this.txtBarFolder5.TabIndex = 45;
			// 
			// txtFolder5Path
			// 
			this.txtFolder5Path.Location = new System.Drawing.Point(99, 145);
			this.txtFolder5Path.Name = "txtFolder5Path";
			this.txtFolder5Path.Size = new System.Drawing.Size(197, 20);
			this.txtFolder5Path.TabIndex = 44;
			// 
			// label7
			// 
			this.label7.AutoSize = true;
			this.label7.Location = new System.Drawing.Point(20, 148);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(42, 13);
			this.label7.TabIndex = 43;
			this.label7.Text = "Folder5";
			// 
			// txtBarFolder4
			// 
			this.txtBarFolder4.Location = new System.Drawing.Point(341, 119);
			this.txtBarFolder4.Name = "txtBarFolder4";
			this.txtBarFolder4.Size = new System.Drawing.Size(66, 20);
			this.txtBarFolder4.TabIndex = 42;
			// 
			// txtFolder4Path
			// 
			this.txtFolder4Path.Location = new System.Drawing.Point(99, 119);
			this.txtFolder4Path.Name = "txtFolder4Path";
			this.txtFolder4Path.Size = new System.Drawing.Size(197, 20);
			this.txtFolder4Path.TabIndex = 41;
			// 
			// label8
			// 
			this.label8.AutoSize = true;
			this.label8.Location = new System.Drawing.Point(20, 122);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(42, 13);
			this.label8.TabIndex = 40;
			this.label8.Text = "Folder4";
			// 
			// btnBrowseFolder3
			// 
			this.btnBrowseFolder3.Location = new System.Drawing.Point(296, 92);
			this.btnBrowseFolder3.Name = "btnBrowseFolder3";
			this.btnBrowseFolder3.Size = new System.Drawing.Size(34, 22);
			this.btnBrowseFolder3.TabIndex = 39;
			this.btnBrowseFolder3.Text = "...";
			this.btnBrowseFolder3.UseVisualStyleBackColor = true;
			this.btnBrowseFolder3.Click += new System.EventHandler(this.btnBrowseFolder3_Click);
			// 
			// btnBrowseFolder2
			// 
			this.btnBrowseFolder2.Location = new System.Drawing.Point(296, 66);
			this.btnBrowseFolder2.Name = "btnBrowseFolder2";
			this.btnBrowseFolder2.Size = new System.Drawing.Size(34, 22);
			this.btnBrowseFolder2.TabIndex = 38;
			this.btnBrowseFolder2.Text = "...";
			this.btnBrowseFolder2.UseVisualStyleBackColor = true;
			this.btnBrowseFolder2.Click += new System.EventHandler(this.btnBrowseFolder2_Click);
			// 
			// txtBarFolder3
			// 
			this.txtBarFolder3.Location = new System.Drawing.Point(341, 93);
			this.txtBarFolder3.Name = "txtBarFolder3";
			this.txtBarFolder3.Size = new System.Drawing.Size(66, 20);
			this.txtBarFolder3.TabIndex = 36;
			// 
			// txtFolder3Path
			// 
			this.txtFolder3Path.Location = new System.Drawing.Point(99, 93);
			this.txtFolder3Path.Name = "txtFolder3Path";
			this.txtFolder3Path.Size = new System.Drawing.Size(197, 20);
			this.txtFolder3Path.TabIndex = 35;
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(20, 96);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(42, 13);
			this.label5.TabIndex = 34;
			this.label5.Text = "Folder3";
			// 
			// txtBarFolder2
			// 
			this.txtBarFolder2.Location = new System.Drawing.Point(341, 67);
			this.txtBarFolder2.Name = "txtBarFolder2";
			this.txtBarFolder2.Size = new System.Drawing.Size(66, 20);
			this.txtBarFolder2.TabIndex = 33;
			// 
			// txtFolder2Path
			// 
			this.txtFolder2Path.Location = new System.Drawing.Point(99, 67);
			this.txtFolder2Path.Name = "txtFolder2Path";
			this.txtFolder2Path.Size = new System.Drawing.Size(197, 20);
			this.txtFolder2Path.TabIndex = 32;
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(20, 70);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(42, 13);
			this.label4.TabIndex = 31;
			this.label4.Text = "Folder2";
			// 
			// txtNumberOfFolders
			// 
			this.txtNumberOfFolders.Location = new System.Drawing.Point(132, 24);
			this.txtNumberOfFolders.Name = "txtNumberOfFolders";
			this.txtNumberOfFolders.Size = new System.Drawing.Size(81, 20);
			this.txtNumberOfFolders.TabIndex = 27;
			this.txtNumberOfFolders.TextChanged += new System.EventHandler(this.txtNumberOfFolders_TextChanged);
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(20, 27);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(82, 13);
			this.label2.TabIndex = 26;
			this.label2.Text = "# of Folder Files";
			// 
			// chkMultipleRFiles
			// 
			this.chkMultipleRFiles.AutoSize = true;
			this.chkMultipleRFiles.Location = new System.Drawing.Point(29, 309);
			this.chkMultipleRFiles.Name = "chkMultipleRFiles";
			this.chkMultipleRFiles.Size = new System.Drawing.Size(132, 17);
			this.chkMultipleRFiles.TabIndex = 0;
			this.chkMultipleRFiles.Text = "Output Multiple R Files";
			this.chkMultipleRFiles.UseVisualStyleBackColor = true;
			this.chkMultipleRFiles.CheckedChanged += new System.EventHandler(this.chkMultipleRFiles_CheckedChanged);
			// 
			// groupBoxZMQ
			// 
			this.groupBoxZMQ.Controls.Add(this.chkSendCycleCompleteMsg);
			this.groupBoxZMQ.Controls.Add(this.txtPort);
			this.groupBoxZMQ.Controls.Add(this.label15);
			this.groupBoxZMQ.Controls.Add(this.txtIP);
			this.groupBoxZMQ.Controls.Add(this.label14);
			this.groupBoxZMQ.Location = new System.Drawing.Point(776, 378);
			this.groupBoxZMQ.Name = "groupBoxZMQ";
			this.groupBoxZMQ.Size = new System.Drawing.Size(294, 162);
			this.groupBoxZMQ.TabIndex = 29;
			this.groupBoxZMQ.TabStop = false;
			// 
			// chkSendCycleCompleteMsg
			// 
			this.chkSendCycleCompleteMsg.AutoSize = true;
			this.chkSendCycleCompleteMsg.Location = new System.Drawing.Point(13, 100);
			this.chkSendCycleCompleteMsg.Name = "chkSendCycleCompleteMsg";
			this.chkSendCycleCompleteMsg.Size = new System.Drawing.Size(150, 17);
			this.chkSendCycleCompleteMsg.TabIndex = 30;
			this.chkSendCycleCompleteMsg.Text = "Send Cycle Complete Msg";
			this.chkSendCycleCompleteMsg.UseVisualStyleBackColor = true;
			// 
			// txtPort
			// 
			this.txtPort.Location = new System.Drawing.Point(99, 63);
			this.txtPort.Name = "txtPort";
			this.txtPort.Size = new System.Drawing.Size(59, 20);
			this.txtPort.TabIndex = 29;
			this.txtPort.Text = "12345";
			// 
			// label15
			// 
			this.label15.AutoSize = true;
			this.label15.Location = new System.Drawing.Point(52, 66);
			this.label15.Name = "label15";
			this.label15.Size = new System.Drawing.Size(26, 13);
			this.label15.TabIndex = 28;
			this.label15.Text = "Port";
			// 
			// txtIP
			// 
			this.txtIP.Location = new System.Drawing.Point(99, 31);
			this.txtIP.Name = "txtIP";
			this.txtIP.Size = new System.Drawing.Size(143, 20);
			this.txtIP.TabIndex = 27;
			this.txtIP.Text = "127.0.0.1";
			// 
			// label14
			// 
			this.label14.AutoSize = true;
			this.label14.Location = new System.Drawing.Point(20, 34);
			this.label14.Name = "label14";
			this.label14.Size = new System.Drawing.Size(58, 13);
			this.label14.TabIndex = 26;
			this.label14.Text = "IP Address";
			// 
			// chkSendZMQ
			// 
			this.chkSendZMQ.AutoSize = true;
			this.chkSendZMQ.Location = new System.Drawing.Point(783, 374);
			this.chkSendZMQ.Name = "chkSendZMQ";
			this.chkSendZMQ.Size = new System.Drawing.Size(139, 17);
			this.chkSendZMQ.TabIndex = 1;
			this.chkSendZMQ.Text = "Send ZeroMQ Message";
			this.chkSendZMQ.UseVisualStyleBackColor = true;
			this.chkSendZMQ.CheckedChanged += new System.EventHandler(this.chkSendZMQ_CheckedChanged);
			// 
			// btnOK
			// 
			this.btnOK.Location = new System.Drawing.Point(813, 560);
			this.btnOK.Name = "btnOK";
			this.btnOK.Size = new System.Drawing.Size(112, 31);
			this.btnOK.TabIndex = 30;
			this.btnOK.Text = "OK";
			this.btnOK.UseVisualStyleBackColor = true;
			this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
			// 
			// btnCancel
			// 
			this.btnCancel.Location = new System.Drawing.Point(958, 557);
			this.btnCancel.Name = "btnCancel";
			this.btnCancel.Size = new System.Drawing.Size(112, 31);
			this.btnCancel.TabIndex = 31;
			this.btnCancel.Text = "Cancel";
			this.btnCancel.UseVisualStyleBackColor = true;
			this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
			// 
			// btnBrowseROutputFolder
			// 
			this.btnBrowseROutputFolder.Location = new System.Drawing.Point(396, 11);
			this.btnBrowseROutputFolder.Name = "btnBrowseROutputFolder";
			this.btnBrowseROutputFolder.Size = new System.Drawing.Size(34, 22);
			this.btnBrowseROutputFolder.TabIndex = 40;
			this.btnBrowseROutputFolder.Text = "...";
			this.btnBrowseROutputFolder.UseVisualStyleBackColor = true;
			this.btnBrowseROutputFolder.Click += new System.EventHandler(this.button1_Click);
			// 
			// txtROutputFolder
			// 
			this.txtROutputFolder.Location = new System.Drawing.Point(151, 12);
			this.txtROutputFolder.Name = "txtROutputFolder";
			this.txtROutputFolder.Size = new System.Drawing.Size(245, 20);
			this.txtROutputFolder.TabIndex = 39;
			// 
			// label18
			// 
			this.label18.AutoSize = true;
			this.label18.Location = new System.Drawing.Point(40, 15);
			this.label18.Name = "label18";
			this.label18.Size = new System.Drawing.Size(103, 13);
			this.label18.TabIndex = 38;
			this.label18.Text = "Primary R File Folder";
			// 
			// chkStoreBarChange
			// 
			this.chkStoreBarChange.AutoSize = true;
			this.chkStoreBarChange.Checked = true;
			this.chkStoreBarChange.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chkStoreBarChange.Location = new System.Drawing.Point(321, 77);
			this.chkStoreBarChange.Name = "chkStoreBarChange";
			this.chkStoreBarChange.Size = new System.Drawing.Size(129, 17);
			this.chkStoreBarChange.TabIndex = 41;
			this.chkStoreBarChange.Text = "Store Bar% in Change";
			this.chkStoreBarChange.UseVisualStyleBackColor = true;
			// 
			// chkDontOutputFiles
			// 
			this.chkDontOutputFiles.AutoSize = true;
			this.chkDontOutputFiles.Location = new System.Drawing.Point(151, 77);
			this.chkDontOutputFiles.Name = "chkDontOutputFiles";
			this.chkDontOutputFiles.Size = new System.Drawing.Size(110, 17);
			this.chkDontOutputFiles.TabIndex = 42;
			this.chkDontOutputFiles.Text = "Don\'t Output Files";
			this.chkDontOutputFiles.UseVisualStyleBackColor = true;
			// 
			// chkGenAlignOutput
			// 
			this.chkGenAlignOutput.AutoSize = true;
			this.chkGenAlignOutput.Location = new System.Drawing.Point(30, 162);
			this.chkGenAlignOutput.Name = "chkGenAlignOutput";
			this.chkGenAlignOutput.Size = new System.Drawing.Size(134, 17);
			this.chkGenAlignOutput.TabIndex = 43;
			this.chkGenAlignOutput.Text = "Gen. Align Output Files";
			this.chkGenAlignOutput.UseVisualStyleBackColor = true;
			this.chkGenAlignOutput.CheckedChanged += new System.EventHandler(this.chkGenAlignOutput_CheckedChanged);
			// 
			// groupAlignOutput
			// 
			this.groupAlignOutput.Controls.Add(this.chkApplyAfterCleanup);
			this.groupAlignOutput.Controls.Add(this.chkVolCal);
			this.groupAlignOutput.Controls.Add(this.txtCleanupTo);
			this.groupAlignOutput.Controls.Add(this.label21);
			this.groupAlignOutput.Controls.Add(this.txtCleanupFrom);
			this.groupAlignOutput.Controls.Add(this.label20);
			this.groupAlignOutput.Controls.Add(this.btnBrowseAlignOutputFolder);
			this.groupAlignOutput.Controls.Add(this.txtAlignOutputFolder);
			this.groupAlignOutput.Controls.Add(this.label19);
			this.groupAlignOutput.Controls.Add(this.chkBinaryCleanup);
			this.groupAlignOutput.Controls.Add(this.txtNumberOfAlignFolders);
			this.groupAlignOutput.Controls.Add(this.label3);
			this.groupAlignOutput.Location = new System.Drawing.Point(20, 166);
			this.groupAlignOutput.Name = "groupAlignOutput";
			this.groupAlignOutput.Size = new System.Drawing.Size(417, 136);
			this.groupAlignOutput.TabIndex = 44;
			this.groupAlignOutput.TabStop = false;
			// 
			// chkApplyAfterCleanup
			// 
			this.chkApplyAfterCleanup.AutoSize = true;
			this.chkApplyAfterCleanup.Checked = true;
			this.chkApplyAfterCleanup.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chkApplyAfterCleanup.Location = new System.Drawing.Point(274, 51);
			this.chkApplyAfterCleanup.Name = "chkApplyAfterCleanup";
			this.chkApplyAfterCleanup.Size = new System.Drawing.Size(119, 17);
			this.chkApplyAfterCleanup.TabIndex = 51;
			this.chkApplyAfterCleanup.Text = "Apply After Cleanup";
			this.chkApplyAfterCleanup.UseVisualStyleBackColor = true;
			// 
			// chkVolCal
			// 
			this.chkVolCal.AutoSize = true;
			this.chkVolCal.Checked = true;
			this.chkVolCal.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chkVolCal.Location = new System.Drawing.Point(131, 51);
			this.chkVolCal.Name = "chkVolCal";
			this.chkVolCal.Size = new System.Drawing.Size(139, 17);
			this.chkVolCal.TabIndex = 50;
			this.chkVolCal.Text = "Use Vol Cal For Change";
			this.chkVolCal.UseVisualStyleBackColor = true;
			this.chkVolCal.CheckedChanged += new System.EventHandler(this.chkVolCal_CheckedChanged);
			// 
			// txtCleanupTo
			// 
			this.txtCleanupTo.Location = new System.Drawing.Point(348, 105);
			this.txtCleanupTo.Name = "txtCleanupTo";
			this.txtCleanupTo.Size = new System.Drawing.Size(58, 20);
			this.txtCleanupTo.TabIndex = 49;
			// 
			// label21
			// 
			this.label21.AutoSize = true;
			this.label21.Location = new System.Drawing.Point(295, 108);
			this.label21.Name = "label21";
			this.label21.Size = new System.Drawing.Size(44, 13);
			this.label21.TabIndex = 48;
			this.label21.Text = "To(Pos)";
			// 
			// txtCleanupFrom
			// 
			this.txtCleanupFrom.Location = new System.Drawing.Point(217, 105);
			this.txtCleanupFrom.Name = "txtCleanupFrom";
			this.txtCleanupFrom.Size = new System.Drawing.Size(63, 20);
			this.txtCleanupFrom.TabIndex = 47;
			// 
			// label20
			// 
			this.label20.AutoSize = true;
			this.label20.Location = new System.Drawing.Point(155, 108);
			this.label20.Name = "label20";
			this.label20.Size = new System.Drawing.Size(56, 13);
			this.label20.TabIndex = 46;
			this.label20.Text = "From(Neg)";
			// 
			// btnBrowseAlignOutputFolder
			// 
			this.btnBrowseAlignOutputFolder.Location = new System.Drawing.Point(376, 73);
			this.btnBrowseAlignOutputFolder.Name = "btnBrowseAlignOutputFolder";
			this.btnBrowseAlignOutputFolder.Size = new System.Drawing.Size(34, 22);
			this.btnBrowseAlignOutputFolder.TabIndex = 45;
			this.btnBrowseAlignOutputFolder.Text = "...";
			this.btnBrowseAlignOutputFolder.UseVisualStyleBackColor = true;
			this.btnBrowseAlignOutputFolder.Click += new System.EventHandler(this.btnBrowseAlignOutputFolder_Click);
			// 
			// txtAlignOutputFolder
			// 
			this.txtAlignOutputFolder.Location = new System.Drawing.Point(131, 74);
			this.txtAlignOutputFolder.Name = "txtAlignOutputFolder";
			this.txtAlignOutputFolder.Size = new System.Drawing.Size(245, 20);
			this.txtAlignOutputFolder.TabIndex = 44;
			// 
			// label19
			// 
			this.label19.AutoSize = true;
			this.label19.Location = new System.Drawing.Point(20, 77);
			this.label19.Name = "label19";
			this.label19.Size = new System.Drawing.Size(97, 13);
			this.label19.TabIndex = 43;
			this.label19.Text = "Align Output Folder";
			// 
			// chkBinaryCleanup
			// 
			this.chkBinaryCleanup.AutoSize = true;
			this.chkBinaryCleanup.Checked = true;
			this.chkBinaryCleanup.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chkBinaryCleanup.Location = new System.Drawing.Point(22, 107);
			this.chkBinaryCleanup.Name = "chkBinaryCleanup";
			this.chkBinaryCleanup.Size = new System.Drawing.Size(122, 17);
			this.chkBinaryCleanup.TabIndex = 42;
			this.chkBinaryCleanup.Text = "User Binary Cleanup";
			this.chkBinaryCleanup.UseVisualStyleBackColor = true;
			this.chkBinaryCleanup.CheckedChanged += new System.EventHandler(this.chkBinaryCleanup_CheckedChanged);
			// 
			// txtNumberOfAlignFolders
			// 
			this.txtNumberOfAlignFolders.Location = new System.Drawing.Point(131, 23);
			this.txtNumberOfAlignFolders.Name = "txtNumberOfAlignFolders";
			this.txtNumberOfAlignFolders.Size = new System.Drawing.Size(72, 20);
			this.txtNumberOfAlignFolders.TabIndex = 29;
			this.txtNumberOfAlignFolders.TextChanged += new System.EventHandler(this.txtNumberOfAlignFolders_TextChanged);
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(20, 26);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(104, 13);
			this.label3.TabIndex = 28;
			this.label3.Text = "Folders to Use(Align)";
			// 
			// chkOutputOnlyR
			// 
			this.chkOutputOnlyR.AutoSize = true;
			this.chkOutputOnlyR.Location = new System.Drawing.Point(460, 15);
			this.chkOutputOnlyR.Name = "chkOutputOnlyR";
			this.chkOutputOnlyR.Size = new System.Drawing.Size(130, 17);
			this.chkOutputOnlyR.TabIndex = 45;
			this.chkOutputOnlyR.Text = "Output Only R #Rows";
			this.chkOutputOnlyR.UseVisualStyleBackColor = true;
			this.chkOutputOnlyR.CheckedChanged += new System.EventHandler(this.chkOutputOnlyR_CheckedChanged);
			// 
			// txtOutputOnlyR
			// 
			this.txtOutputOnlyR.Location = new System.Drawing.Point(614, 12);
			this.txtOutputOnlyR.Name = "txtOutputOnlyR";
			this.txtOutputOnlyR.Size = new System.Drawing.Size(80, 20);
			this.txtOutputOnlyR.TabIndex = 46;
			// 
			// groupSubCal
			// 
			this.groupSubCal.Controls.Add(this.chkUseVolForLevels);
			this.groupSubCal.Controls.Add(this.chkCalAvg);
			this.groupSubCal.Controls.Add(this.txtSubCalLevels);
			this.groupSubCal.Controls.Add(this.label23);
			this.groupSubCal.Controls.Add(this.chkApplyAlignR);
			this.groupSubCal.Controls.Add(this.chkApplyMultipleR);
			this.groupSubCal.Controls.Add(this.chkApplyPrimaryR);
			this.groupSubCal.Controls.Add(this.label22);
			this.groupSubCal.Controls.Add(this.panelCalAvg);
			this.groupSubCal.Location = new System.Drawing.Point(448, 47);
			this.groupSubCal.Name = "groupSubCal";
			this.groupSubCal.Size = new System.Drawing.Size(318, 321);
			this.groupSubCal.TabIndex = 47;
			this.groupSubCal.TabStop = false;
			// 
			// chkUseVolForLevels
			// 
			this.chkUseVolForLevels.AutoSize = true;
			this.chkUseVolForLevels.Location = new System.Drawing.Point(36, 105);
			this.chkUseVolForLevels.Name = "chkUseVolForLevels";
			this.chkUseVolForLevels.Size = new System.Drawing.Size(132, 17);
			this.chkUseVolForLevels.TabIndex = 73;
			this.chkUseVolForLevels.Text = "Use Volume for Levels";
			this.chkUseVolForLevels.UseVisualStyleBackColor = true;
			// 
			// chkCalAvg
			// 
			this.chkCalAvg.AutoSize = true;
			this.chkCalAvg.Location = new System.Drawing.Point(19, 140);
			this.chkCalAvg.Name = "chkCalAvg";
			this.chkCalAvg.Size = new System.Drawing.Size(63, 17);
			this.chkCalAvg.TabIndex = 52;
			this.chkCalAvg.Text = "Cal-Avg";
			this.chkCalAvg.UseVisualStyleBackColor = true;
			this.chkCalAvg.CheckedChanged += new System.EventHandler(this.chkCalAvg_CheckedChanged);
			// 
			// txtSubCalLevels
			// 
			this.txtSubCalLevels.Location = new System.Drawing.Point(140, 78);
			this.txtSubCalLevels.Name = "txtSubCalLevels";
			this.txtSubCalLevels.Size = new System.Drawing.Size(106, 20);
			this.txtSubCalLevels.TabIndex = 49;
			// 
			// label23
			// 
			this.label23.AutoSize = true;
			this.label23.Location = new System.Drawing.Point(21, 82);
			this.label23.Name = "label23";
			this.label23.Size = new System.Drawing.Size(78, 13);
			this.label23.TabIndex = 48;
			this.label23.Text = "Sub-Cal Levels";
			// 
			// chkApplyAlignR
			// 
			this.chkApplyAlignR.AutoSize = true;
			this.chkApplyAlignR.Location = new System.Drawing.Point(216, 50);
			this.chkApplyAlignR.Name = "chkApplyAlignR";
			this.chkApplyAlignR.Size = new System.Drawing.Size(60, 17);
			this.chkApplyAlignR.TabIndex = 47;
			this.chkApplyAlignR.Text = "Align R";
			this.chkApplyAlignR.UseVisualStyleBackColor = true;
			// 
			// chkApplyMultipleR
			// 
			this.chkApplyMultipleR.AutoSize = true;
			this.chkApplyMultipleR.Location = new System.Drawing.Point(127, 50);
			this.chkApplyMultipleR.Name = "chkApplyMultipleR";
			this.chkApplyMultipleR.Size = new System.Drawing.Size(73, 17);
			this.chkApplyMultipleR.TabIndex = 46;
			this.chkApplyMultipleR.Text = "Multiple R";
			this.chkApplyMultipleR.UseVisualStyleBackColor = true;
			// 
			// chkApplyPrimaryR
			// 
			this.chkApplyPrimaryR.AutoSize = true;
			this.chkApplyPrimaryR.Location = new System.Drawing.Point(36, 50);
			this.chkApplyPrimaryR.Name = "chkApplyPrimaryR";
			this.chkApplyPrimaryR.Size = new System.Drawing.Size(71, 17);
			this.chkApplyPrimaryR.TabIndex = 45;
			this.chkApplyPrimaryR.Text = "Primary R";
			this.chkApplyPrimaryR.UseVisualStyleBackColor = true;
			// 
			// label22
			// 
			this.label22.AutoSize = true;
			this.label22.Location = new System.Drawing.Point(21, 26);
			this.label22.Name = "label22";
			this.label22.Size = new System.Drawing.Size(97, 13);
			this.label22.TabIndex = 44;
			this.label22.Text = "Sub-Cal Applies To";
			// 
			// panelCalAvg
			// 
			this.panelCalAvg.Controls.Add(this.txtLavg4End);
			this.panelCalAvg.Controls.Add(this.txtLavg4Start);
			this.panelCalAvg.Controls.Add(this.label30);
			this.panelCalAvg.Controls.Add(this.txtLavg3End);
			this.panelCalAvg.Controls.Add(this.txtLavg3Start);
			this.panelCalAvg.Controls.Add(this.label29);
			this.panelCalAvg.Controls.Add(this.txtLavg2End);
			this.panelCalAvg.Controls.Add(this.txtLavg2Start);
			this.panelCalAvg.Controls.Add(this.label28);
			this.panelCalAvg.Controls.Add(this.label27);
			this.panelCalAvg.Controls.Add(this.txtLavg1End);
			this.panelCalAvg.Controls.Add(this.label26);
			this.panelCalAvg.Controls.Add(this.txtLavg1Start);
			this.panelCalAvg.Controls.Add(this.label25);
			this.panelCalAvg.Location = new System.Drawing.Point(24, 153);
			this.panelCalAvg.Name = "panelCalAvg";
			this.panelCalAvg.Size = new System.Drawing.Size(283, 153);
			this.panelCalAvg.TabIndex = 67;
			// 
			// txtLavg4End
			// 
			this.txtLavg4End.Location = new System.Drawing.Point(178, 124);
			this.txtLavg4End.Name = "txtLavg4End";
			this.txtLavg4End.Size = new System.Drawing.Size(80, 20);
			this.txtLavg4End.TabIndex = 80;
			// 
			// txtLavg4Start
			// 
			this.txtLavg4Start.Location = new System.Drawing.Point(82, 124);
			this.txtLavg4Start.Name = "txtLavg4Start";
			this.txtLavg4Start.Size = new System.Drawing.Size(80, 20);
			this.txtLavg4Start.TabIndex = 79;
			// 
			// label30
			// 
			this.label30.AutoSize = true;
			this.label30.Location = new System.Drawing.Point(24, 127);
			this.label30.Name = "label30";
			this.label30.Size = new System.Drawing.Size(37, 13);
			this.label30.TabIndex = 78;
			this.label30.Text = "Lavg4";
			// 
			// txtLavg3End
			// 
			this.txtLavg3End.Location = new System.Drawing.Point(178, 94);
			this.txtLavg3End.Name = "txtLavg3End";
			this.txtLavg3End.Size = new System.Drawing.Size(80, 20);
			this.txtLavg3End.TabIndex = 77;
			// 
			// txtLavg3Start
			// 
			this.txtLavg3Start.Location = new System.Drawing.Point(82, 94);
			this.txtLavg3Start.Name = "txtLavg3Start";
			this.txtLavg3Start.Size = new System.Drawing.Size(80, 20);
			this.txtLavg3Start.TabIndex = 76;
			// 
			// label29
			// 
			this.label29.AutoSize = true;
			this.label29.Location = new System.Drawing.Point(24, 97);
			this.label29.Name = "label29";
			this.label29.Size = new System.Drawing.Size(37, 13);
			this.label29.TabIndex = 75;
			this.label29.Text = "Lavg3";
			// 
			// txtLavg2End
			// 
			this.txtLavg2End.Location = new System.Drawing.Point(178, 61);
			this.txtLavg2End.Name = "txtLavg2End";
			this.txtLavg2End.Size = new System.Drawing.Size(80, 20);
			this.txtLavg2End.TabIndex = 74;
			// 
			// txtLavg2Start
			// 
			this.txtLavg2Start.Location = new System.Drawing.Point(82, 61);
			this.txtLavg2Start.Name = "txtLavg2Start";
			this.txtLavg2Start.Size = new System.Drawing.Size(80, 20);
			this.txtLavg2Start.TabIndex = 73;
			// 
			// label28
			// 
			this.label28.AutoSize = true;
			this.label28.Location = new System.Drawing.Point(24, 64);
			this.label28.Name = "label28";
			this.label28.Size = new System.Drawing.Size(37, 13);
			this.label28.TabIndex = 72;
			this.label28.Text = "Lavg2";
			// 
			// label27
			// 
			this.label27.AutoSize = true;
			this.label27.Location = new System.Drawing.Point(204, 8);
			this.label27.Name = "label27";
			this.label27.Size = new System.Drawing.Size(26, 13);
			this.label27.TabIndex = 71;
			this.label27.Text = "End";
			// 
			// txtLavg1End
			// 
			this.txtLavg1End.Location = new System.Drawing.Point(178, 29);
			this.txtLavg1End.Name = "txtLavg1End";
			this.txtLavg1End.Size = new System.Drawing.Size(80, 20);
			this.txtLavg1End.TabIndex = 70;
			// 
			// label26
			// 
			this.label26.AutoSize = true;
			this.label26.Location = new System.Drawing.Point(108, 8);
			this.label26.Name = "label26";
			this.label26.Size = new System.Drawing.Size(29, 13);
			this.label26.TabIndex = 69;
			this.label26.Text = "Start";
			// 
			// txtLavg1Start
			// 
			this.txtLavg1Start.Location = new System.Drawing.Point(82, 29);
			this.txtLavg1Start.Name = "txtLavg1Start";
			this.txtLavg1Start.Size = new System.Drawing.Size(80, 20);
			this.txtLavg1Start.TabIndex = 68;
			// 
			// label25
			// 
			this.label25.AutoSize = true;
			this.label25.Location = new System.Drawing.Point(24, 32);
			this.label25.Name = "label25";
			this.label25.Size = new System.Drawing.Size(37, 13);
			this.label25.TabIndex = 67;
			this.label25.Text = "Lavg1";
			// 
			// chkSubCal
			// 
			this.chkSubCal.AutoSize = true;
			this.chkSubCal.Location = new System.Drawing.Point(460, 45);
			this.chkSubCal.Name = "chkSubCal";
			this.chkSubCal.Size = new System.Drawing.Size(63, 17);
			this.chkSubCal.TabIndex = 49;
			this.chkSubCal.Text = "Sub-Cal";
			this.chkSubCal.UseVisualStyleBackColor = true;
			this.chkSubCal.CheckedChanged += new System.EventHandler(this.chkSubCal_CheckedChanged);
			// 
			// groupLatestSignal
			// 
			this.groupLatestSignal.Controls.Add(this.chkLatestMasterNew);
			this.groupLatestSignal.Controls.Add(this.chkGenLatestMasterFile);
			this.groupLatestSignal.Controls.Add(this.chkGenLatestFile);
			this.groupLatestSignal.Controls.Add(this.btnBrowselatestOutput);
			this.groupLatestSignal.Controls.Add(this.txtLastOutputFolder);
			this.groupLatestSignal.Controls.Add(this.label31);
			this.groupLatestSignal.Controls.Add(this.chkLatestOutAlign);
			this.groupLatestSignal.Controls.Add(this.chkLatestOutMultiple);
			this.groupLatestSignal.Controls.Add(this.chkLatestOutPrimary);
			this.groupLatestSignal.Controls.Add(this.label24);
			this.groupLatestSignal.Location = new System.Drawing.Point(448, 379);
			this.groupLatestSignal.Name = "groupLatestSignal";
			this.groupLatestSignal.Size = new System.Drawing.Size(318, 161);
			this.groupLatestSignal.TabIndex = 50;
			this.groupLatestSignal.TabStop = false;
			// 
			// chkLatestMasterNew
			// 
			this.chkLatestMasterNew.AutoSize = true;
			this.chkLatestMasterNew.Location = new System.Drawing.Point(216, 120);
			this.chkLatestMasterNew.Name = "chkLatestMasterNew";
			this.chkLatestMasterNew.Size = new System.Drawing.Size(48, 17);
			this.chkLatestMasterNew.TabIndex = 57;
			this.chkLatestMasterNew.Text = "New";
			this.chkLatestMasterNew.UseVisualStyleBackColor = true;
			// 
			// chkGenLatestMasterFile
			// 
			this.chkGenLatestMasterFile.AutoSize = true;
			this.chkGenLatestMasterFile.Location = new System.Drawing.Point(41, 120);
			this.chkGenLatestMasterFile.Name = "chkGenLatestMasterFile";
			this.chkGenLatestMasterFile.Size = new System.Drawing.Size(164, 17);
			this.chkGenLatestMasterFile.TabIndex = 56;
			this.chkGenLatestMasterFile.Text = "Gen Latest Signal Master File";
			this.chkGenLatestMasterFile.UseVisualStyleBackColor = true;
			this.chkGenLatestMasterFile.CheckedChanged += new System.EventHandler(this.chkGenLatestMasterFile_CheckedChanged);
			// 
			// chkGenLatestFile
			// 
			this.chkGenLatestFile.AutoSize = true;
			this.chkGenLatestFile.Location = new System.Drawing.Point(41, 94);
			this.chkGenLatestFile.Name = "chkGenLatestFile";
			this.chkGenLatestFile.Size = new System.Drawing.Size(129, 17);
			this.chkGenLatestFile.TabIndex = 55;
			this.chkGenLatestFile.Text = "Gen Latest Signal File";
			this.chkGenLatestFile.UseVisualStyleBackColor = true;
			// 
			// btnBrowselatestOutput
			// 
			this.btnBrowselatestOutput.Location = new System.Drawing.Point(282, 61);
			this.btnBrowselatestOutput.Name = "btnBrowselatestOutput";
			this.btnBrowselatestOutput.Size = new System.Drawing.Size(28, 22);
			this.btnBrowselatestOutput.TabIndex = 54;
			this.btnBrowselatestOutput.Text = "...";
			this.btnBrowselatestOutput.UseVisualStyleBackColor = true;
			this.btnBrowselatestOutput.Click += new System.EventHandler(this.btnBrowselatestOutput_Click);
			// 
			// txtLastOutputFolder
			// 
			this.txtLastOutputFolder.Location = new System.Drawing.Point(58, 62);
			this.txtLastOutputFolder.Name = "txtLastOutputFolder";
			this.txtLastOutputFolder.Size = new System.Drawing.Size(224, 20);
			this.txtLastOutputFolder.TabIndex = 53;
			// 
			// label31
			// 
			this.label31.AutoSize = true;
			this.label31.Location = new System.Drawing.Point(8, 65);
			this.label31.Name = "label31";
			this.label31.Size = new System.Drawing.Size(39, 13);
			this.label31.TabIndex = 52;
			this.label31.Text = "Output";
			// 
			// chkLatestOutAlign
			// 
			this.chkLatestOutAlign.AutoSize = true;
			this.chkLatestOutAlign.Location = new System.Drawing.Point(221, 42);
			this.chkLatestOutAlign.Name = "chkLatestOutAlign";
			this.chkLatestOutAlign.Size = new System.Drawing.Size(60, 17);
			this.chkLatestOutAlign.TabIndex = 51;
			this.chkLatestOutAlign.Text = "Align R";
			this.chkLatestOutAlign.UseVisualStyleBackColor = true;
			// 
			// chkLatestOutMultiple
			// 
			this.chkLatestOutMultiple.AutoSize = true;
			this.chkLatestOutMultiple.Location = new System.Drawing.Point(132, 42);
			this.chkLatestOutMultiple.Name = "chkLatestOutMultiple";
			this.chkLatestOutMultiple.Size = new System.Drawing.Size(73, 17);
			this.chkLatestOutMultiple.TabIndex = 50;
			this.chkLatestOutMultiple.Text = "Multiple R";
			this.chkLatestOutMultiple.UseVisualStyleBackColor = true;
			// 
			// chkLatestOutPrimary
			// 
			this.chkLatestOutPrimary.AutoSize = true;
			this.chkLatestOutPrimary.Location = new System.Drawing.Point(41, 42);
			this.chkLatestOutPrimary.Name = "chkLatestOutPrimary";
			this.chkLatestOutPrimary.Size = new System.Drawing.Size(71, 17);
			this.chkLatestOutPrimary.TabIndex = 49;
			this.chkLatestOutPrimary.Text = "Primary R";
			this.chkLatestOutPrimary.UseVisualStyleBackColor = true;
			// 
			// label24
			// 
			this.label24.AutoSize = true;
			this.label24.Location = new System.Drawing.Point(26, 22);
			this.label24.Name = "label24";
			this.label24.Size = new System.Drawing.Size(57, 13);
			this.label24.TabIndex = 48;
			this.label24.Text = "Applies To";
			// 
			// chkCustomPricePoint
			// 
			this.chkCustomPricePoint.AutoSize = true;
			this.chkCustomPricePoint.Location = new System.Drawing.Point(30, 102);
			this.chkCustomPricePoint.Name = "chkCustomPricePoint";
			this.chkCustomPricePoint.Size = new System.Drawing.Size(161, 17);
			this.chkCustomPricePoint.TabIndex = 51;
			this.chkCustomPricePoint.Text = "Use Custom Price Point Bars";
			this.chkCustomPricePoint.UseVisualStyleBackColor = true;
			this.chkCustomPricePoint.CheckedChanged += new System.EventHandler(this.chkCustomPricePoint_CheckedChanged);
			// 
			// btnBrowseCustomPricePoint
			// 
			this.btnBrowseCustomPricePoint.Location = new System.Drawing.Point(396, 97);
			this.btnBrowseCustomPricePoint.Name = "btnBrowseCustomPricePoint";
			this.btnBrowseCustomPricePoint.Size = new System.Drawing.Size(34, 22);
			this.btnBrowseCustomPricePoint.TabIndex = 53;
			this.btnBrowseCustomPricePoint.Text = "...";
			this.btnBrowseCustomPricePoint.UseVisualStyleBackColor = true;
			this.btnBrowseCustomPricePoint.Click += new System.EventHandler(this.btnBrowseCustomerPricePoint_Click);
			// 
			// txtCustomPricePointBarPath
			// 
			this.txtCustomPricePointBarPath.Location = new System.Drawing.Point(215, 98);
			this.txtCustomPricePointBarPath.Name = "txtCustomPricePointBarPath";
			this.txtCustomPricePointBarPath.Size = new System.Drawing.Size(181, 20);
			this.txtCustomPricePointBarPath.TabIndex = 52;
			// 
			// btnBrowseCustomBarPercent
			// 
			this.btnBrowseCustomBarPercent.Location = new System.Drawing.Point(396, 129);
			this.btnBrowseCustomBarPercent.Name = "btnBrowseCustomBarPercent";
			this.btnBrowseCustomBarPercent.Size = new System.Drawing.Size(34, 22);
			this.btnBrowseCustomBarPercent.TabIndex = 56;
			this.btnBrowseCustomBarPercent.Text = "...";
			this.btnBrowseCustomBarPercent.UseVisualStyleBackColor = true;
			this.btnBrowseCustomBarPercent.Click += new System.EventHandler(this.btnBrowseCustomBarPercent_Click);
			// 
			// txtCustomBarPercentPath
			// 
			this.txtCustomBarPercentPath.Location = new System.Drawing.Point(215, 130);
			this.txtCustomBarPercentPath.Name = "txtCustomBarPercentPath";
			this.txtCustomBarPercentPath.Size = new System.Drawing.Size(181, 20);
			this.txtCustomBarPercentPath.TabIndex = 55;
			// 
			// chkCustomPercentBar
			// 
			this.chkCustomPercentBar.AutoSize = true;
			this.chkCustomPercentBar.Location = new System.Drawing.Point(30, 132);
			this.chkCustomPercentBar.Name = "chkCustomPercentBar";
			this.chkCustomPercentBar.Size = new System.Drawing.Size(115, 17);
			this.chkCustomPercentBar.TabIndex = 54;
			this.chkCustomPercentBar.Text = "Use Custom Bars%";
			this.chkCustomPercentBar.UseVisualStyleBackColor = true;
			this.chkCustomPercentBar.CheckedChanged += new System.EventHandler(this.chkCustomPercentBar_CheckedChanged);
			// 
			// chkLatestSignalOutput
			// 
			this.chkLatestSignalOutput.AutoSize = true;
			this.chkLatestSignalOutput.Location = new System.Drawing.Point(461, 375);
			this.chkLatestSignalOutput.Name = "chkLatestSignalOutput";
			this.chkLatestSignalOutput.Size = new System.Drawing.Size(127, 17);
			this.chkLatestSignalOutput.TabIndex = 58;
			this.chkLatestSignalOutput.Text = "Latest Signals Output";
			this.chkLatestSignalOutput.UseVisualStyleBackColor = true;
			this.chkLatestSignalOutput.CheckedChanged += new System.EventHandler(this.chkLatestSignalOutput_CheckedChanged_1);
			// 
			// chkColumnToUseForLabel
			// 
			this.chkColumnToUseForLabel.AutoSize = true;
			this.chkColumnToUseForLabel.Location = new System.Drawing.Point(784, 42);
			this.chkColumnToUseForLabel.Name = "chkColumnToUseForLabel";
			this.chkColumnToUseForLabel.Size = new System.Drawing.Size(144, 17);
			this.chkColumnToUseForLabel.TabIndex = 59;
			this.chkColumnToUseForLabel.Text = "Column to Use for Levels";
			this.chkColumnToUseForLabel.UseVisualStyleBackColor = true;
			// 
			// cmbColumnForLevel
			// 
			this.cmbColumnForLevel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cmbColumnForLevel.FormattingEnabled = true;
			this.cmbColumnForLevel.Items.AddRange(new object[] {
            "Close",
            "Change",
            "Volume"});
			this.cmbColumnForLevel.Location = new System.Drawing.Point(957, 38);
			this.cmbColumnForLevel.Name = "cmbColumnForLevel";
			this.cmbColumnForLevel.Size = new System.Drawing.Size(101, 21);
			this.cmbColumnForLevel.TabIndex = 60;
			// 
			// chkBinaryLevels
			// 
			this.chkBinaryLevels.AutoSize = true;
			this.chkBinaryLevels.Location = new System.Drawing.Point(784, 77);
			this.chkBinaryLevels.Name = "chkBinaryLevels";
			this.chkBinaryLevels.Size = new System.Drawing.Size(89, 17);
			this.chkBinaryLevels.TabIndex = 61;
			this.chkBinaryLevels.Text = "Binary Levels";
			this.chkBinaryLevels.UseVisualStyleBackColor = true;
			// 
			// chkMapLevels
			// 
			this.chkMapLevels.AutoSize = true;
			this.chkMapLevels.Location = new System.Drawing.Point(784, 112);
			this.chkMapLevels.Name = "chkMapLevels";
			this.chkMapLevels.Size = new System.Drawing.Size(99, 17);
			this.chkMapLevels.TabIndex = 62;
			this.chkMapLevels.Text = "Mapped Levels";
			this.chkMapLevels.UseVisualStyleBackColor = true;
			// 
			// btnBrowseMapLevelFile
			// 
			this.btnBrowseMapLevelFile.Location = new System.Drawing.Point(1024, 134);
			this.btnBrowseMapLevelFile.Name = "btnBrowseMapLevelFile";
			this.btnBrowseMapLevelFile.Size = new System.Drawing.Size(34, 22);
			this.btnBrowseMapLevelFile.TabIndex = 64;
			this.btnBrowseMapLevelFile.Text = "...";
			this.btnBrowseMapLevelFile.UseVisualStyleBackColor = true;
			this.btnBrowseMapLevelFile.Click += new System.EventHandler(this.btnBrowseMapLevelFile_Click);
			// 
			// txtMapLevelFile
			// 
			this.txtMapLevelFile.Location = new System.Drawing.Point(843, 135);
			this.txtMapLevelFile.Name = "txtMapLevelFile";
			this.txtMapLevelFile.Size = new System.Drawing.Size(181, 20);
			this.txtMapLevelFile.TabIndex = 63;
			// 
			// chkMasterColumnReport
			// 
			this.chkMasterColumnReport.AutoSize = true;
			this.chkMasterColumnReport.Location = new System.Drawing.Point(784, 170);
			this.chkMasterColumnReport.Name = "chkMasterColumnReport";
			this.chkMasterColumnReport.Size = new System.Drawing.Size(131, 17);
			this.chkMasterColumnReport.TabIndex = 67;
			this.chkMasterColumnReport.Text = "Master Column Report";
			this.chkMasterColumnReport.UseVisualStyleBackColor = true;
			this.chkMasterColumnReport.CheckedChanged += new System.EventHandler(this.chkMasterColumnReport_CheckedChanged);
			// 
			// groupMasterColumnReport
			// 
			this.groupMasterColumnReport.Controls.Add(this.chkMasterReportDTC);
			this.groupMasterColumnReport.Controls.Add(this.chkMasterReportColumnOnly);
			this.groupMasterColumnReport.Controls.Add(this.label34);
			this.groupMasterColumnReport.Controls.Add(this.label33);
			this.groupMasterColumnReport.Controls.Add(this.txtRowsToOutput);
			this.groupMasterColumnReport.Controls.Add(this.label32);
			this.groupMasterColumnReport.Controls.Add(this.cmbMasterColOutput);
			this.groupMasterColumnReport.Controls.Add(this.btnBrowseMasterReportOutput);
			this.groupMasterColumnReport.Controls.Add(this.txtMasterReportOutput);
			this.groupMasterColumnReport.Location = new System.Drawing.Point(776, 174);
			this.groupMasterColumnReport.Name = "groupMasterColumnReport";
			this.groupMasterColumnReport.Size = new System.Drawing.Size(294, 194);
			this.groupMasterColumnReport.TabIndex = 77;
			this.groupMasterColumnReport.TabStop = false;
			// 
			// chkMasterReportDTC
			// 
			this.chkMasterReportDTC.AutoSize = true;
			this.chkMasterReportDTC.Location = new System.Drawing.Point(145, 162);
			this.chkMasterReportDTC.Name = "chkMasterReportDTC";
			this.chkMasterReportDTC.Size = new System.Drawing.Size(60, 17);
			this.chkMasterReportDTC.TabIndex = 85;
			this.chkMasterReportDTC.Text = "D+T+C";
			this.chkMasterReportDTC.UseVisualStyleBackColor = true;
			this.chkMasterReportDTC.CheckedChanged += new System.EventHandler(this.chkMasterReportDTC_CheckedChanged);
			// 
			// chkMasterReportColumnOnly
			// 
			this.chkMasterReportColumnOnly.AutoSize = true;
			this.chkMasterReportColumnOnly.Location = new System.Drawing.Point(145, 131);
			this.chkMasterReportColumnOnly.Name = "chkMasterReportColumnOnly";
			this.chkMasterReportColumnOnly.Size = new System.Drawing.Size(96, 17);
			this.chkMasterReportColumnOnly.TabIndex = 84;
			this.chkMasterReportColumnOnly.Text = "TS-OHLCV+OI";
			this.chkMasterReportColumnOnly.UseVisualStyleBackColor = true;
			this.chkMasterReportColumnOnly.CheckedChanged += new System.EventHandler(this.chkMasterReportColumnOnly_CheckedChanged);
			// 
			// label34
			// 
			this.label34.AutoSize = true;
			this.label34.Location = new System.Drawing.Point(39, 135);
			this.label34.Name = "label34";
			this.label34.Size = new System.Drawing.Size(74, 13);
			this.label34.TabIndex = 83;
			this.label34.Text = "Report Format";
			// 
			// label33
			// 
			this.label33.AutoSize = true;
			this.label33.Location = new System.Drawing.Point(20, 58);
			this.label33.Name = "label33";
			this.label33.Size = new System.Drawing.Size(93, 13);
			this.label33.TabIndex = 82;
			this.label33.Text = "Column To Output";
			// 
			// txtRowsToOutput
			// 
			this.txtRowsToOutput.Location = new System.Drawing.Point(145, 91);
			this.txtRowsToOutput.Name = "txtRowsToOutput";
			this.txtRowsToOutput.Size = new System.Drawing.Size(121, 20);
			this.txtRowsToOutput.TabIndex = 81;
			// 
			// label32
			// 
			this.label32.AutoSize = true;
			this.label32.Location = new System.Drawing.Point(21, 94);
			this.label32.Name = "label32";
			this.label32.Size = new System.Drawing.Size(92, 13);
			this.label32.TabIndex = 80;
			this.label32.Text = "#Rows To Output";
			// 
			// cmbMasterColOutput
			// 
			this.cmbMasterColOutput.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cmbMasterColOutput.FormattingEnabled = true;
			this.cmbMasterColOutput.Items.AddRange(new object[] {
            "Volume",
            "Change"});
			this.cmbMasterColOutput.Location = new System.Drawing.Point(145, 55);
			this.cmbMasterColOutput.Name = "cmbMasterColOutput";
			this.cmbMasterColOutput.Size = new System.Drawing.Size(121, 21);
			this.cmbMasterColOutput.TabIndex = 79;
			// 
			// btnBrowseMasterReportOutput
			// 
			this.btnBrowseMasterReportOutput.Location = new System.Drawing.Point(232, 15);
			this.btnBrowseMasterReportOutput.Name = "btnBrowseMasterReportOutput";
			this.btnBrowseMasterReportOutput.Size = new System.Drawing.Size(34, 22);
			this.btnBrowseMasterReportOutput.TabIndex = 78;
			this.btnBrowseMasterReportOutput.Text = "...";
			this.btnBrowseMasterReportOutput.UseVisualStyleBackColor = true;
			this.btnBrowseMasterReportOutput.Click += new System.EventHandler(this.btnBrowseMasterReportOutput_Click);
			// 
			// txtMasterReportOutput
			// 
			this.txtMasterReportOutput.Location = new System.Drawing.Point(51, 16);
			this.txtMasterReportOutput.Name = "txtMasterReportOutput";
			this.txtMasterReportOutput.Size = new System.Drawing.Size(181, 20);
			this.txtMasterReportOutput.TabIndex = 77;
			// 
			// FrmROutputConfig
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(1079, 629);
			this.Controls.Add(this.chkMasterColumnReport);
			this.Controls.Add(this.groupMasterColumnReport);
			this.Controls.Add(this.btnBrowseMapLevelFile);
			this.Controls.Add(this.txtMapLevelFile);
			this.Controls.Add(this.chkMapLevels);
			this.Controls.Add(this.chkBinaryLevels);
			this.Controls.Add(this.cmbColumnForLevel);
			this.Controls.Add(this.chkColumnToUseForLabel);
			this.Controls.Add(this.chkLatestSignalOutput);
			this.Controls.Add(this.btnBrowseCustomBarPercent);
			this.Controls.Add(this.txtCustomBarPercentPath);
			this.Controls.Add(this.chkCustomPercentBar);
			this.Controls.Add(this.btnBrowseCustomPricePoint);
			this.Controls.Add(this.txtCustomPricePointBarPath);
			this.Controls.Add(this.chkCustomPricePoint);
			this.Controls.Add(this.groupLatestSignal);
			this.Controls.Add(this.chkSubCal);
			this.Controls.Add(this.groupSubCal);
			this.Controls.Add(this.txtOutputOnlyR);
			this.Controls.Add(this.chkOutputOnlyR);
			this.Controls.Add(this.chkGenAlignOutput);
			this.Controls.Add(this.groupAlignOutput);
			this.Controls.Add(this.chkDontOutputFiles);
			this.Controls.Add(this.chkStoreBarChange);
			this.Controls.Add(this.chkSendZMQ);
			this.Controls.Add(this.chkMultipleRFiles);
			this.Controls.Add(this.btnBrowseROutputFolder);
			this.Controls.Add(this.txtROutputFolder);
			this.Controls.Add(this.label18);
			this.Controls.Add(this.btnCancel);
			this.Controls.Add(this.btnOK);
			this.Controls.Add(this.groupBoxZMQ);
			this.Controls.Add(this.groupBoxMultipleFiles);
			this.Controls.Add(this.txtBar);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.txtLevel);
			this.Controls.Add(this.label6);
			this.Name = "FrmROutputConfig";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "R File Output Settings";
			this.Load += new System.EventHandler(this.FrmROutputConfig_Load);
			this.groupBoxMultipleFiles.ResumeLayout(false);
			this.groupBoxMultipleFiles.PerformLayout();
			this.groupBoxZMQ.ResumeLayout(false);
			this.groupBoxZMQ.PerformLayout();
			this.groupAlignOutput.ResumeLayout(false);
			this.groupAlignOutput.PerformLayout();
			this.groupSubCal.ResumeLayout(false);
			this.groupSubCal.PerformLayout();
			this.panelCalAvg.ResumeLayout(false);
			this.panelCalAvg.PerformLayout();
			this.groupLatestSignal.ResumeLayout(false);
			this.groupLatestSignal.PerformLayout();
			this.groupMasterColumnReport.ResumeLayout(false);
			this.groupMasterColumnReport.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.TextBox txtLevel;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.TextBox txtBar;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.GroupBox groupBoxMultipleFiles;
		private System.Windows.Forms.CheckBox chkMultipleRFiles;
		private System.Windows.Forms.TextBox txtNumberOfFolders;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.TextBox txtBarFolder2;
		private System.Windows.Forms.TextBox txtFolder2Path;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Button btnBrowseFolder10;
		private System.Windows.Forms.TextBox txtBarFolder10;
		private System.Windows.Forms.TextBox txtFolder10Path;
		private System.Windows.Forms.Label label13;
		private System.Windows.Forms.Button btnBrowseFolder9;
		private System.Windows.Forms.Button btnBrowseFolder8;
		private System.Windows.Forms.TextBox txtBarFolder9;
		private System.Windows.Forms.TextBox txtFolder9Path;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.TextBox txtBarFolder8;
		private System.Windows.Forms.TextBox txtFolder8Path;
		private System.Windows.Forms.Label label10;
		private System.Windows.Forms.Button btnBrowseFolder7;
		private System.Windows.Forms.Button btnBrowseFolder6;
		private System.Windows.Forms.TextBox txtBarFolder7;
		private System.Windows.Forms.TextBox txtFolder7Path;
		private System.Windows.Forms.Label label11;
		private System.Windows.Forms.TextBox txtBarFolder6;
		private System.Windows.Forms.TextBox txtFolder6Path;
		private System.Windows.Forms.Label label12;
		private System.Windows.Forms.Button btnBrowseFolder5;
		private System.Windows.Forms.Button btnBrowseFolder4;
		private System.Windows.Forms.TextBox txtBarFolder5;
		private System.Windows.Forms.TextBox txtFolder5Path;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.TextBox txtBarFolder4;
		private System.Windows.Forms.TextBox txtFolder4Path;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.Button btnBrowseFolder3;
		private System.Windows.Forms.Button btnBrowseFolder2;
		private System.Windows.Forms.TextBox txtBarFolder3;
		private System.Windows.Forms.TextBox txtFolder3Path;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.GroupBox groupBoxZMQ;
		private System.Windows.Forms.TextBox txtPort;
		private System.Windows.Forms.Label label15;
		private System.Windows.Forms.TextBox txtIP;
		private System.Windows.Forms.Label label14;
		private System.Windows.Forms.CheckBox chkSendZMQ;
		private System.Windows.Forms.Button btnOK;
		private System.Windows.Forms.Button btnCancel;
		private System.Windows.Forms.Label label17;
		private System.Windows.Forms.Label label16;
		private System.Windows.Forms.Button btnBrowseROutputFolder;
		private System.Windows.Forms.TextBox txtROutputFolder;
		private System.Windows.Forms.Label label18;
		private System.Windows.Forms.CheckBox chkStoreBarChange;
		private System.Windows.Forms.CheckBox chkDontOutputFiles;
		private System.Windows.Forms.CheckBox chkGenAlignOutput;
		private System.Windows.Forms.GroupBox groupAlignOutput;
		private System.Windows.Forms.TextBox txtNumberOfAlignFolders;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.CheckBox chkBinaryCleanup;
		private System.Windows.Forms.Button btnBrowseAlignOutputFolder;
		private System.Windows.Forms.TextBox txtAlignOutputFolder;
		private System.Windows.Forms.Label label19;
		private System.Windows.Forms.TextBox txtCleanupTo;
		private System.Windows.Forms.Label label21;
		private System.Windows.Forms.TextBox txtCleanupFrom;
		private System.Windows.Forms.Label label20;
		private System.Windows.Forms.CheckBox chkOutputOnlyR;
		private System.Windows.Forms.TextBox txtOutputOnlyR;
		private System.Windows.Forms.GroupBox groupSubCal;
		private System.Windows.Forms.CheckBox chkSubCal;
		private System.Windows.Forms.CheckBox chkApplyAlignR;
		private System.Windows.Forms.CheckBox chkApplyMultipleR;
		private System.Windows.Forms.CheckBox chkApplyPrimaryR;
		private System.Windows.Forms.Label label22;
		private System.Windows.Forms.TextBox txtSubCalLevels;
		private System.Windows.Forms.Label label23;
		private System.Windows.Forms.CheckBox chkCalAvg;
		private System.Windows.Forms.Panel panelCalAvg;
		private System.Windows.Forms.TextBox txtLavg4End;
		private System.Windows.Forms.TextBox txtLavg4Start;
		private System.Windows.Forms.Label label30;
		private System.Windows.Forms.TextBox txtLavg3End;
		private System.Windows.Forms.TextBox txtLavg3Start;
		private System.Windows.Forms.Label label29;
		private System.Windows.Forms.TextBox txtLavg2End;
		private System.Windows.Forms.TextBox txtLavg2Start;
		private System.Windows.Forms.Label label28;
		private System.Windows.Forms.Label label27;
		private System.Windows.Forms.TextBox txtLavg1End;
		private System.Windows.Forms.Label label26;
		private System.Windows.Forms.TextBox txtLavg1Start;
		private System.Windows.Forms.Label label25;
		private System.Windows.Forms.CheckBox chkVolCal;
		private System.Windows.Forms.CheckBox chkSendCycleCompleteMsg;
		private System.Windows.Forms.CheckBox chkApplyAfterCleanup;
		private System.Windows.Forms.GroupBox groupLatestSignal;
		private System.Windows.Forms.CheckBox chkLatestOutAlign;
		private System.Windows.Forms.CheckBox chkLatestOutMultiple;
		private System.Windows.Forms.CheckBox chkLatestOutPrimary;
		private System.Windows.Forms.Label label24;
		private System.Windows.Forms.Button btnBrowselatestOutput;
		private System.Windows.Forms.TextBox txtLastOutputFolder;
		private System.Windows.Forms.Label label31;
		private System.Windows.Forms.CheckBox chkGenLatestMasterFile;
		private System.Windows.Forms.CheckBox chkGenLatestFile;
		private System.Windows.Forms.CheckBox chkCustomPricePoint;
		private System.Windows.Forms.Button btnBrowseCustomPricePoint;
		private System.Windows.Forms.TextBox txtCustomPricePointBarPath;
		private System.Windows.Forms.Button btnBrowseCustomBarPercent;
		private System.Windows.Forms.TextBox txtCustomBarPercentPath;
		private System.Windows.Forms.CheckBox chkCustomPercentBar;
		private System.Windows.Forms.CheckBox chkLatestMasterNew;
		private System.Windows.Forms.CheckBox chkLatestSignalOutput;
		private System.Windows.Forms.CheckBox chkUseVolForLevels;
		private System.Windows.Forms.CheckBox chkColumnToUseForLabel;
		private System.Windows.Forms.ComboBox cmbColumnForLevel;
		private System.Windows.Forms.CheckBox chkBinaryLevels;
		private System.Windows.Forms.CheckBox chkMapLevels;
		private System.Windows.Forms.Button btnBrowseMapLevelFile;
		private System.Windows.Forms.TextBox txtMapLevelFile;
		private System.Windows.Forms.CheckBox chkMasterColumnReport;
		private System.Windows.Forms.GroupBox groupMasterColumnReport;
		private System.Windows.Forms.CheckBox chkMasterReportDTC;
		private System.Windows.Forms.CheckBox chkMasterReportColumnOnly;
		private System.Windows.Forms.Label label34;
		private System.Windows.Forms.Label label33;
		private System.Windows.Forms.TextBox txtRowsToOutput;
		private System.Windows.Forms.Label label32;
		private System.Windows.Forms.ComboBox cmbMasterColOutput;
		private System.Windows.Forms.Button btnBrowseMasterReportOutput;
		private System.Windows.Forms.TextBox txtMasterReportOutput;
	}
}