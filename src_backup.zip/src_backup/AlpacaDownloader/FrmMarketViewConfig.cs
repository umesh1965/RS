﻿using SriAlpacaDLModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SriAlpacaDL
{
	public partial class FrmMarketViewConfig : Form
	{
		MarketViewSettings config;
		public FrmMarketViewConfig()
		{
			InitializeComponent();
		}

		public FrmMarketViewConfig(MarketViewSettings config_) : this()
		{
			config = config_;

			chkGenMarketViewReports.Checked = config.EnableMarketView;
			txtMappingFile.Text = config.MappingFile;
			txtOutputFolder.Text = config.OutputFolder;
			radioPrimary.Checked = config.UsePrimary;
			radioAlign.Checked = !config.UsePrimary;
			chkAllSignalReport.Checked = config.GenAllMarketView;
			chkAllMarketHistorical.Checked = config.GenAllHistoricalReport;
			chkIndustryReport.Checked = config.GenIndustryReport;
			chkIndustryHistorical.Checked = config.GenIndustryHistoricalReport;
			chkSectorReport.Checked = config.GenSectorReport;
			chkSectorHistorical.Checked = config.GenSectorHistoricalReport;
			groupMarketView.Enabled = config.EnableMarketView;
		}

		private void btnBrowseMappingFile_Click(object sender, EventArgs e)
		{
			OpenFileDialog openDlg = new OpenFileDialog();
			openDlg.Filter = "Mapping File|*.csv";
			if (openDlg.ShowDialog() == DialogResult.OK)
			{
				GlobalData.Config.SymbolListFile = openDlg.FileName;
				txtMappingFile.Text = openDlg.FileName;
			}
		}

		private void btnBrowseOutputFolder_Click(object sender, EventArgs e)
		{
			txtOutputFolder.Text = Utils.GetFolderPath(txtOutputFolder.Text);
		}

		private void btnOK_Click(object sender, EventArgs e)
		{
			config.EnableMarketView = chkGenMarketViewReports.Checked;
			config.MappingFile = txtMappingFile.Text;
			config.OutputFolder = txtOutputFolder.Text;
			config.UsePrimary = radioPrimary.Checked;
			config.GenAllMarketView = chkAllSignalReport.Checked;
			config.GenAllHistoricalReport = chkAllMarketHistorical.Checked;
			config.GenIndustryReport = chkIndustryReport.Checked;
			config.GenIndustryHistoricalReport = chkIndustryHistorical.Checked;
			config.GenSectorReport = chkSectorReport.Checked;
			config.GenSectorHistoricalReport = chkSectorHistorical.Checked;

			this.Close();
		}

		private void chkGenMarketViewReports_CheckedChanged(object sender, EventArgs e)
		{
			groupMarketView.Enabled = chkGenMarketViewReports.Checked;
		}

		private void btnCancel_Click(object sender, EventArgs e)
		{
			this.Close();
		}

		private void chkAllMarketHistorical_CheckedChanged(object sender, EventArgs e)
		{
			if (chkAllMarketHistorical.Checked)
				chkSectorReport.Checked = true;
		}

		private void chkIndustryHistorical_CheckedChanged(object sender, EventArgs e)
		{
			if (chkIndustryHistorical.Checked)
				chkIndustryReport.Checked = true;
		}

		private void chkSectorHistorical_CheckedChanged(object sender, EventArgs e)
		{
			if (chkSectorHistorical.Checked)
				chkSectorReport.Checked = true;
		}
	}
}
