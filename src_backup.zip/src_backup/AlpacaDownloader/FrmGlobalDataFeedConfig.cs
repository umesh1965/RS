﻿using SriAlpacaDLModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SriAlpacaDL
{
	public partial class FrmGlobalDataFeedConfig : Form
	{
		GlobalDataFeedSettings config;
		public FrmGlobalDataFeedConfig()
		{
			InitializeComponent();
		}
		public FrmGlobalDataFeedConfig(GlobalDataFeedSettings config_) : this()
		{
			config = config_;

			txtEndPoint.Text = config.EndPointForHistorical;
			txtAPIKey.Text = config.APIKey;
			txtExchangeCode.Text = config.ExchangeCode;
			cmbShortIdentifier.SelectedIndex = config.IsShortIdentifier ? 1 : 0;
		}

		private void FrmGlobalDataFeedConfig_Load(object sender, EventArgs e)
		{

		}

		private void btnOK_Click(object sender, EventArgs e)
		{
			if (!CheckValidations())
				return;

			config.EndPointForHistorical = txtEndPoint.Text;
			config.APIKey = txtAPIKey.Text;
			config.ExchangeCode = txtExchangeCode.Text;
			config.IsShortIdentifier = cmbShortIdentifier.SelectedIndex == 0 ? false : true;
			this.Close();
		}

		private void btnCancel_Click(object sender, EventArgs e)
		{
			this.Close();
		}

		private bool CheckValidations()
		{
			if (txtEndPoint.Text.LastIndexOf('/') == txtEndPoint.Text.Length - 1)
			{
				MessageBox.Show("The EndPoint should not have slash[/] at the end.");
				return false;
			}

			return true;
		}
	}
}
