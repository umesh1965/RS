﻿using SriAlpacaDLModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SriAlpacaDL
{
	public partial class FrmGenSectorFile : Form
	{
		private SectorFileSettings config;
		public FrmGenSectorFile()
		{
			InitializeComponent();
		}

		public FrmGenSectorFile(SectorFileSettings config_) : this()
		{
			config = config_;

			chkGenSectorFile.Checked = config.EnableGenSectorFile;
			txtMappingFile.Text = config.MappingFile;
			txtMergedOutput.Text = config.MergedOutputFolder;

			chkGenSectorRFile.Checked = config.EnableGenSectorRFile;
			txtSectorRFileFolder.Text = config.GenSectorRFileFolder;

			txtBar.Text = config.BarPercent.ToString();
			chkStoreBarChange.Checked = config.EnableStoreBarPercent;

			chkOutputOnlyR.Checked = config.EnableOutputOnlyRow;
			txtOutputOnlyR.Text = config.OutputOnlyRowNumbers.ToString();

			//subcal settings
			chkApplyPrimaryR.Checked = config.SubCalConfig.ApplyPrimaryR;
			chkApplyMultipleR.Checked = config.SubCalConfig.ApplyMultipleR;
			chkApplyAlignR.Checked = config.SubCalConfig.ApplyAlignR;

			txtSubCalLevels.Text = config.SubCalConfig.SubCalLevels.ToString();
			//txtBSLevels.Text = GlobalData.Config.SignalConfig.BSLevels.ToString();

			chkSubCal.Checked = config.SubCalConfig.EnableSubCal;
			chkCalAvg.Checked = config.SubCalConfig.EnableCalAvg;

			txtLavg1Start.Text = config.SubCalConfig.LAvg1Start.ToString();
			txtLavg2Start.Text = config.SubCalConfig.LAvg2Start.ToString();
			txtLavg3Start.Text = config.SubCalConfig.LAvg3Start.ToString();
			txtLavg4Start.Text = config.SubCalConfig.LAvg4Start.ToString();

			txtLavg1End.Text = config.SubCalConfig.LAvg1End.ToString();
			txtLavg2End.Text = config.SubCalConfig.LAvg2End.ToString();
			txtLavg3End.Text = config.SubCalConfig.LAvg3End.ToString();
			txtLavg4End.Text = config.SubCalConfig.LAvg4End.ToString();
		}

		private void btnOK_Click(object sender, EventArgs e)
		{
			config.EnableGenSectorFile = chkGenSectorFile.Checked;
			config.EnableGenSectorRFile = chkGenSectorRFile.Checked;

			config.MappingFile = txtMappingFile.Text;
			config.MergedOutputFolder = txtMergedOutput.Text;
			config.GenSectorRFileFolder = txtSectorRFileFolder.Text;

			double tempValDouble = 0;
			int tempValInt = 0;

			config.BarPercent = double.TryParse(txtBar.Text, out tempValDouble) ? tempValDouble : 0;
			config.EnableStoreBarPercent = chkStoreBarChange.Checked;

			config.EnableOutputOnlyRow = chkOutputOnlyR.Checked;
			config.OutputOnlyRowNumbers = int.TryParse(txtOutputOnlyR.Text, out tempValInt) ? tempValInt : 0;

			config.SubCalConfig.EnableSubCal = chkSubCal.Checked;
			config.SubCalConfig.ApplyPrimaryR = chkApplyPrimaryR.Checked;
			config.SubCalConfig.ApplyMultipleR = chkApplyMultipleR.Checked;
			config.SubCalConfig.ApplyAlignR = chkApplyAlignR.Checked;

			config.SubCalConfig.EnableCalAvg = chkCalAvg.Checked;
			config.SubCalConfig.SubCalLevels = int.TryParse(txtSubCalLevels.Text, out tempValInt) ? tempValInt : 0;
			//config.SubCalConfig.BSLevels = int.TryParse(txtBSLevels.Text, out tempValInt) ? tempValInt : 0;

			config.SubCalConfig.LAvg1Start = int.TryParse(txtLavg1Start.Text, out tempValInt) ? tempValInt : 0;
			config.SubCalConfig.LAvg2Start = int.TryParse(txtLavg2Start.Text, out tempValInt) ? tempValInt : 0;
			config.SubCalConfig.LAvg3Start = int.TryParse(txtLavg3Start.Text, out tempValInt) ? tempValInt : 0;
			config.SubCalConfig.LAvg4Start = int.TryParse(txtLavg4Start.Text, out tempValInt) ? tempValInt : 0;

			config.SubCalConfig.LAvg1End = int.TryParse(txtLavg1End.Text, out tempValInt) ? tempValInt : 0;
			config.SubCalConfig.LAvg2End = int.TryParse(txtLavg2End.Text, out tempValInt) ? tempValInt : 0;
			config.SubCalConfig.LAvg3End = int.TryParse(txtLavg3End.Text, out tempValInt) ? tempValInt : 0;
			config.SubCalConfig.LAvg4End = int.TryParse(txtLavg4End.Text, out tempValInt) ? tempValInt : 0;

			this.Close();
		}

		private void btnBrowseMergedOutput_Click(object sender, EventArgs e)
		{
			txtMergedOutput.Text = Utils.GetFolderPath(txtMergedOutput.Text);
		}

		private void btnBrowseSectorRFileFolder_Click(object sender, EventArgs e)
		{
			txtSectorRFileFolder.Text = Utils.GetFolderPath(txtSectorRFileFolder.Text);
		}

		private void btnBrowseMappingFile_Click(object sender, EventArgs e)
		{
			OpenFileDialog openDlg = new OpenFileDialog();
			openDlg.Filter = "Sector Mapping File |*.csv";
			if (openDlg.ShowDialog() == DialogResult.OK)
			{
				GlobalData.Config.SymbolListFile = openDlg.FileName;
				txtMappingFile.Text = openDlg.FileName;
			}
		}

		private void btnCancel_Click(object sender, EventArgs e)
		{
			this.Close();
		}

		private void chkSubCal_CheckedChanged(object sender, EventArgs e)
		{
			groupSubCal.Enabled = chkSubCal.Checked;
		}

		private void chkOutputOnlyR_CheckedChanged(object sender, EventArgs e)
		{
			txtOutputOnlyR.Enabled = chkOutputOnlyR.Checked;
		}

		private void chkEnableBSSignal_CheckedChanged(object sender, EventArgs e)
		{
		}

		private void radioBSLevel_CheckedChanged(object sender, EventArgs e)
		{
		}

		private void radLavgSignal_CheckedChanged(object sender, EventArgs e)
		{
		}
	}
}
