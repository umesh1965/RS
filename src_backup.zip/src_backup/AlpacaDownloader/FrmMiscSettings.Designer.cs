﻿
namespace SriAlpacaDL
{
	partial class FrmMiscSettings
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.groupCleanTree = new System.Windows.Forms.GroupBox();
			this.txtCleanUp = new System.Windows.Forms.TextBox();
			this.label17 = new System.Windows.Forms.Label();
			this.groupTrimData = new System.Windows.Forms.GroupBox();
			this.txtDaysBefore = new System.Windows.Forms.TextBox();
			this.label16 = new System.Windows.Forms.Label();
			this.btnBrowseTrimFolder = new System.Windows.Forms.Button();
			this.btnBrowseTrimRaw = new System.Windows.Forms.Button();
			this.txtTrimRawFolder = new System.Windows.Forms.TextBox();
			this.label15 = new System.Windows.Forms.Label();
			this.txtFolderForTrim = new System.Windows.Forms.TextBox();
			this.label14 = new System.Windows.Forms.Label();
			this.btnOK = new System.Windows.Forms.Button();
			this.btnCancel = new System.Windows.Forms.Button();
			this.groupCleanTree.SuspendLayout();
			this.groupTrimData.SuspendLayout();
			this.SuspendLayout();
			// 
			// groupCleanTree
			// 
			this.groupCleanTree.Controls.Add(this.txtCleanUp);
			this.groupCleanTree.Controls.Add(this.label17);
			this.groupCleanTree.Location = new System.Drawing.Point(13, 135);
			this.groupCleanTree.Name = "groupCleanTree";
			this.groupCleanTree.Size = new System.Drawing.Size(312, 59);
			this.groupCleanTree.TabIndex = 60;
			this.groupCleanTree.TabStop = false;
			this.groupCleanTree.Text = "Clean Tree File";
			// 
			// txtCleanUp
			// 
			this.txtCleanUp.Location = new System.Drawing.Point(202, 24);
			this.txtCleanUp.Name = "txtCleanUp";
			this.txtCleanUp.Size = new System.Drawing.Size(81, 20);
			this.txtCleanUp.TabIndex = 25;
			// 
			// label17
			// 
			this.label17.AutoSize = true;
			this.label17.Location = new System.Drawing.Point(15, 27);
			this.label17.Name = "label17";
			this.label17.Size = new System.Drawing.Size(76, 13);
			this.label17.TabIndex = 24;
			this.label17.Text = "CleanUp% Min";
			// 
			// groupTrimData
			// 
			this.groupTrimData.Controls.Add(this.txtDaysBefore);
			this.groupTrimData.Controls.Add(this.label16);
			this.groupTrimData.Controls.Add(this.btnBrowseTrimFolder);
			this.groupTrimData.Controls.Add(this.btnBrowseTrimRaw);
			this.groupTrimData.Controls.Add(this.txtTrimRawFolder);
			this.groupTrimData.Controls.Add(this.label15);
			this.groupTrimData.Controls.Add(this.txtFolderForTrim);
			this.groupTrimData.Controls.Add(this.label14);
			this.groupTrimData.Location = new System.Drawing.Point(12, 12);
			this.groupTrimData.Name = "groupTrimData";
			this.groupTrimData.Size = new System.Drawing.Size(526, 117);
			this.groupTrimData.TabIndex = 59;
			this.groupTrimData.TabStop = false;
			this.groupTrimData.Text = "Trim Input Data(Per R Files)";
			// 
			// txtDaysBefore
			// 
			this.txtDaysBefore.Location = new System.Drawing.Point(203, 77);
			this.txtDaysBefore.Name = "txtDaysBefore";
			this.txtDaysBefore.Size = new System.Drawing.Size(81, 20);
			this.txtDaysBefore.TabIndex = 33;
			// 
			// label16
			// 
			this.label16.AutoSize = true;
			this.label16.Location = new System.Drawing.Point(19, 81);
			this.label16.Name = "label16";
			this.label16.Size = new System.Drawing.Size(178, 13);
			this.label16.TabIndex = 32;
			this.label16.Text = "# Days Before 1st row Date to Keep";
			// 
			// btnBrowseTrimFolder
			// 
			this.btnBrowseTrimFolder.Location = new System.Drawing.Point(467, 16);
			this.btnBrowseTrimFolder.Name = "btnBrowseTrimFolder";
			this.btnBrowseTrimFolder.Size = new System.Drawing.Size(27, 22);
			this.btnBrowseTrimFolder.TabIndex = 31;
			this.btnBrowseTrimFolder.Text = "...";
			this.btnBrowseTrimFolder.UseVisualStyleBackColor = true;
			this.btnBrowseTrimFolder.Click += new System.EventHandler(this.btnBrowseTrimFolder_Click);
			// 
			// btnBrowseTrimRaw
			// 
			this.btnBrowseTrimRaw.Location = new System.Drawing.Point(467, 47);
			this.btnBrowseTrimRaw.Name = "btnBrowseTrimRaw";
			this.btnBrowseTrimRaw.Size = new System.Drawing.Size(27, 22);
			this.btnBrowseTrimRaw.TabIndex = 30;
			this.btnBrowseTrimRaw.Text = "...";
			this.btnBrowseTrimRaw.UseVisualStyleBackColor = true;
			this.btnBrowseTrimRaw.Click += new System.EventHandler(this.btnBrowseTrimRaw_Click);
			// 
			// txtTrimRawFolder
			// 
			this.txtTrimRawFolder.Location = new System.Drawing.Point(203, 48);
			this.txtTrimRawFolder.Name = "txtTrimRawFolder";
			this.txtTrimRawFolder.Size = new System.Drawing.Size(264, 20);
			this.txtTrimRawFolder.TabIndex = 27;
			// 
			// label15
			// 
			this.label15.AutoSize = true;
			this.label15.Location = new System.Drawing.Point(19, 50);
			this.label15.Name = "label15";
			this.label15.Size = new System.Drawing.Size(87, 13);
			this.label15.TabIndex = 26;
			this.label15.Text = "Raw Data Folder";
			// 
			// txtFolderForTrim
			// 
			this.txtFolderForTrim.Location = new System.Drawing.Point(203, 17);
			this.txtFolderForTrim.Name = "txtFolderForTrim";
			this.txtFolderForTrim.Size = new System.Drawing.Size(264, 20);
			this.txtFolderForTrim.TabIndex = 25;
			// 
			// label14
			// 
			this.label14.AutoSize = true;
			this.label14.Location = new System.Drawing.Point(19, 22);
			this.label14.Name = "label14";
			this.label14.Size = new System.Drawing.Size(119, 13);
			this.label14.TabIndex = 24;
			this.label14.Text = "R Folder to Use for Trim";
			// 
			// btnOK
			// 
			this.btnOK.Location = new System.Drawing.Point(346, 162);
			this.btnOK.Name = "btnOK";
			this.btnOK.Size = new System.Drawing.Size(92, 32);
			this.btnOK.TabIndex = 61;
			this.btnOK.Text = "OK";
			this.btnOK.UseVisualStyleBackColor = true;
			this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
			// 
			// btnCancel
			// 
			this.btnCancel.Location = new System.Drawing.Point(444, 162);
			this.btnCancel.Name = "btnCancel";
			this.btnCancel.Size = new System.Drawing.Size(94, 32);
			this.btnCancel.TabIndex = 62;
			this.btnCancel.Text = "Cancel";
			this.btnCancel.UseVisualStyleBackColor = true;
			this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
			// 
			// FrmMiscSettings
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(546, 204);
			this.Controls.Add(this.btnCancel);
			this.Controls.Add(this.btnOK);
			this.Controls.Add(this.groupCleanTree);
			this.Controls.Add(this.groupTrimData);
			this.Name = "FrmMiscSettings";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Misc Settings";
			this.groupCleanTree.ResumeLayout(false);
			this.groupCleanTree.PerformLayout();
			this.groupTrimData.ResumeLayout(false);
			this.groupTrimData.PerformLayout();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.GroupBox groupCleanTree;
		private System.Windows.Forms.TextBox txtCleanUp;
		private System.Windows.Forms.Label label17;
		private System.Windows.Forms.GroupBox groupTrimData;
		private System.Windows.Forms.TextBox txtDaysBefore;
		private System.Windows.Forms.Label label16;
		private System.Windows.Forms.Button btnBrowseTrimFolder;
		private System.Windows.Forms.Button btnBrowseTrimRaw;
		private System.Windows.Forms.TextBox txtTrimRawFolder;
		private System.Windows.Forms.Label label15;
		private System.Windows.Forms.TextBox txtFolderForTrim;
		private System.Windows.Forms.Label label14;
		private System.Windows.Forms.Button btnOK;
		private System.Windows.Forms.Button btnCancel;
	}
}