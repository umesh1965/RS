﻿using SriAlpacaDLModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SriAlpacaDL
{
	public partial class FrmMiscSettings : Form
	{
		MiscSettings config;
		public FrmMiscSettings()
		{
			InitializeComponent();
		}

		public FrmMiscSettings(MiscSettings config_) : this()
		{
			config = config_;
		}

		void BindData(bool fromControl)
		{
			if (fromControl)
			{
				int val = 0;
				config.TrimRawDataFolder = txtTrimRawFolder.Text;
				config.TrimRDataFolder = txtFolderForTrim.Text;
				config.TrimDaysToKeep = int.TryParse(txtDaysBefore.Text, out val) ? val : 0;
				config.CleanupPercent = int.TryParse(txtCleanUp.Text, out val) ? val : 0;
			}
			else
			{
				txtTrimRawFolder.Text = config.TrimRawDataFolder;
				txtFolderForTrim.Text = config.TrimRDataFolder;
				txtDaysBefore.Text = config.TrimDaysToKeep.ToString();
				txtCleanUp.Text = config.CleanupPercent.ToString();
			}
		}

		private void btnOK_Click(object sender, EventArgs e)
		{
			BindData(true);
			Close();
		}

		private void btnCancel_Click(object sender, EventArgs e)
		{
			Close();
		}

		private void btnBrowseTrimFolder_Click(object sender, EventArgs e)
		{
			txtFolderForTrim.Text = Utils.GetFolderPath(txtFolderForTrim.Text);
		}

		private void btnBrowseTrimRaw_Click(object sender, EventArgs e)
		{
			txtTrimRawFolder.Text = Utils.GetFolderPath(txtTrimRawFolder.Text);
		}
	}
}
