﻿using Ookii.Dialogs.Wpf;
using SriAlpacaDLModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SriAlpacaDL
{
	public partial class FrmROutputConfig : Form
	{
		private ROutputSettings config;
		public FrmROutputConfig()
		{
			InitializeComponent();
		}
		public FrmROutputConfig(ROutputSettings config_) : this()
		{
			config = config_;

			txtROutputFolder.Text = config.ROutputFolder;
			txtLevel.Text = config.Level.ToString();
			txtBar.Text = config.BarPercent.ToString("0.##");

			chkMultipleRFiles.Checked = config.EnableMultipleROutput;
			groupBoxMultipleFiles.Enabled = config.EnableMultipleROutput;

			txtNumberOfFolders.Text = config.NumberofFolderes.ToString();
				
			TextBox[] pathTexts = { txtFolder2Path, txtFolder3Path, txtFolder4Path,
			txtFolder5Path, txtFolder6Path, txtFolder7Path, txtFolder8Path,  txtFolder9Path, txtFolder10Path};

			TextBox[] barTexts = {txtBarFolder2, txtBarFolder3, txtBarFolder4, txtBarFolder5,
			txtBarFolder6, txtBarFolder7, txtBarFolder8, txtBarFolder9, txtBarFolder10};

			Button[] browseButtons = {btnBrowseFolder2, btnBrowseFolder3, btnBrowseFolder4,
			btnBrowseFolder5, btnBrowseFolder6, btnBrowseFolder7, btnBrowseFolder8, btnBrowseFolder9, btnBrowseFolder10};
			for (int i = 0; i < config.FolderSettings.Count; i++)
			{
				if (config.FolderSettings[i] == null)
					break;

				pathTexts[i].Text = config.FolderSettings[i].Path;
				barTexts[i].Text = config.FolderSettings[i].BarPercent.ToString("0.##");
					
				pathTexts[i].Enabled = true;
				barTexts[i].Enabled = true;
				browseButtons[i].Enabled = true;
			}

			for (int i = Math.Max(config.NumberofFolderes - 1, 0); i < pathTexts.Length; i++)
			{
				pathTexts[i].Enabled = false;
				barTexts[i].Enabled = false;
				browseButtons[i].Enabled = false;
			}

			chkSendZMQ.Checked = config.EnableZeroMQ;
			groupBoxZMQ.Enabled = config.EnableZeroMQ;
			chkStoreBarChange.Checked = config.StoreBarPercentAsChange;

			if (config.EnableZeroMQ)
			{
				txtIP.Text = config.IPAddressZMQ;
				txtPort.Text = config.PortZMQ.ToString();
			}

			chkDontOutputFiles.Checked = config.DontOutputFiles;
			chkGenAlignOutput.Checked = config.EnableGenAlignFiles;
			groupAlignOutput.Enabled = config.EnableGenAlignFiles;
			txtAlignOutputFolder.Text = config.AlignOutputFolder;
			chkBinaryCleanup.Checked = config.EnableBinaryCleanup;
			txtCleanupFrom.Text = config.CleanupFrom.ToString("0.00");
			txtCleanupTo.Text = config.CleanupTo.ToString("0.00");
			txtCleanupFrom.Enabled = txtCleanupTo.Enabled = config.EnableBinaryCleanup;
			chkVolCal.Checked = config.UseVolCal;
			chkApplyAfterCleanup.Checked = config.UseVolCalAfterCleanup;
			chkApplyAfterCleanup.Enabled = config.UseVolCal;
			txtNumberOfAlignFolders.Text = config.NumberOfAlignFolders.ToString();

			chkOutputOnlyR.Checked = config.EnableOutputOnlyRow;
			txtOutputOnlyR.Text = config.OutputOnlyRowNumbers.ToString();
			//subcal settings
			chkApplyPrimaryR.Checked = config.SubCalConfig.ApplyPrimaryR;
			chkApplyMultipleR.Checked = config.SubCalConfig.ApplyMultipleR;
			chkApplyAlignR.Checked = config.SubCalConfig.ApplyAlignR;

			chkSubCal.Checked = config.SubCalConfig.EnableSubCal;
			groupSubCal.Enabled = chkSubCal.Checked;
			txtSubCalLevels.Text = config.SubCalConfig.SubCalLevels.ToString();

			chkCalAvg.Checked = config.SubCalConfig.EnableCalAvg;

			txtLavg1Start.Text = config.SubCalConfig.LAvg1Start.ToString();
			txtLavg2Start.Text = config.SubCalConfig.LAvg2Start.ToString();
			txtLavg3Start.Text = config.SubCalConfig.LAvg3Start.ToString();
			txtLavg4Start.Text = config.SubCalConfig.LAvg4Start.ToString();

			txtLavg1End.Text = config.SubCalConfig.LAvg1End.ToString();
			txtLavg2End.Text = config.SubCalConfig.LAvg2End.ToString();
			txtLavg3End.Text = config.SubCalConfig.LAvg3End.ToString();
			txtLavg4End.Text = config.SubCalConfig.LAvg4End.ToString();

			chkSendCycleCompleteMsg.Checked = config.SendCycleCompleteMsg;

			panelCalAvg.Enabled = config.SubCalConfig.EnableCalAvg;

			txtOutputOnlyR.Enabled = chkOutputOnlyR.Checked;

			chkUseVolForLevels.Checked = config.SubCalConfig.UseVolumeForLevels;

			//V9 Custom Price Bar
			txtCustomBarPercentPath.Text = config.CustomPricePercentFile;
			txtCustomPricePointBarPath.Text = config.CustomPriceBarFile;
			chkCustomPercentBar.Checked = config.UseCustomPricePercent;
			chkCustomPricePoint.Checked = config.UseCustomPriceBarPoint;

			txtCustomBarPercentPath.Enabled = btnBrowseCustomBarPercent.Enabled = config.UseCustomPricePercent;
			txtCustomPricePointBarPath.Enabled = btnBrowseCustomPricePoint.Enabled = config.UseCustomPriceBarPoint;

			//latest signal gen
			chkLatestSignalOutput.Checked = config.EnableLatestSignalOutput;
			chkLatestOutPrimary.Checked = config.LatestSignalApplyPrimary;
			chkLatestOutMultiple.Checked = config.LatestSignalApplyMultiple;
			chkLatestOutAlign.Checked = config.LatestSignalApplyAlign;
			txtLastOutputFolder.Text = config.LatestSignalOutputFolder;
			chkGenLatestFile.Checked = config.GenLatestSignalFile;
			chkGenLatestMasterFile.Checked = config.GenLatestSignalMasterFile;
			chkLatestMasterNew.Checked = config.UseLatestNewSignal;

			chkLatestMasterNew.Enabled = chkGenLatestMasterFile.Checked;
			groupLatestSignal.Enabled = config.EnableLatestSignalOutput;

			chkColumnToUseForLabel.Checked = config.UseColumnForLevels;
			cmbColumnForLevel.SelectedIndex = (int)config.ColumnLevelType;
			chkBinaryLevels.Checked = config.UseBinaryLevels;
			chkMapLevels.Checked = config.UseMappedLevels;
			txtMapLevelFile.Text = config.MappedLevelFile;
			chkMasterColumnReport.Checked = config.UseMasterColumnReport;
			txtMasterReportOutput.Text = config.MasterColumnOutputFolder;
			cmbMasterColOutput.SelectedIndex = (int)config.ColumnOutput;
			txtRowsToOutput.Text = config.RowsToOutput.ToString();
			chkMasterReportColumnOnly.Checked = config.MasterReportColumnOnly;
			chkMasterReportDTC.Checked = config.MasterReportDTC;

			groupMasterColumnReport.Enabled = chkMasterColumnReport.Checked;
		}

		private void chkMultipleRFiles_CheckedChanged(object sender, EventArgs e)
		{
			groupBoxMultipleFiles.Enabled = chkMultipleRFiles.Checked;

			if (groupBoxMultipleFiles.Enabled)
			{

			}
		}

		private void chkSendZMQ_CheckedChanged(object sender, EventArgs e)
		{
			groupBoxZMQ.Enabled = chkSendZMQ.Checked;

			if (config.EnableZeroMQ)
			{
				txtIP.Text = config.IPAddressZMQ;
				txtPort.Text = config.PortZMQ.ToString();
			}
		}

		private void btnOK_Click(object sender, EventArgs e)
		{
			config.ROutputFolder = txtROutputFolder.Text;
			int tempValInt;
			double tempValDouble;

			config.Level = int.TryParse(txtLevel.Text, out tempValInt) ? tempValInt : 0;

			config.BarPercent = double.TryParse(txtBar.Text, out tempValDouble) ? tempValDouble : 0;

			config.EnableMultipleROutput = chkMultipleRFiles.Checked;

			config.NumberOfAlignFolders = int.TryParse(txtNumberOfAlignFolders.Text, out tempValInt) ? tempValInt : 0;

			config.NumberofFolderes = int.TryParse(txtNumberOfFolders.Text, out tempValInt) ? tempValInt : 0;

			TextBox[] pathTexts = { txtFolder2Path, txtFolder3Path, txtFolder4Path,
		txtFolder5Path, txtFolder6Path, txtFolder7Path, txtFolder8Path,  txtFolder9Path, txtFolder10Path};

			TextBox[] barTexts = {txtBarFolder2, txtBarFolder3, txtBarFolder4, txtBarFolder5,
		txtBarFolder6, txtBarFolder7, txtBarFolder8, txtBarFolder9, txtBarFolder10};

			config.FolderSettings.Clear();

			for (int i = 0; i < pathTexts.Length; i++)
			{
				config.FolderSettings.Add(new FolderSetting()
				{
					Path = pathTexts[i].Text,
					BarPercent = double.TryParse(barTexts[i].Text, out tempValDouble) ? tempValDouble : 0
				});
			}

			config.EnableZeroMQ = chkSendZMQ.Checked;
			if (config.EnableZeroMQ)
			{
				config.IPAddressZMQ = txtIP.Text;
				config.PortZMQ = int.TryParse(txtPort.Text, out tempValInt) ? tempValInt : 0;
			}

			config.StoreBarPercentAsChange = chkStoreBarChange.Checked;

			config.DontOutputFiles = chkDontOutputFiles.Checked;
			config.EnableGenAlignFiles = chkGenAlignOutput.Checked;
			config.AlignOutputFolder = txtAlignOutputFolder.Text;
			config.CleanupFrom = double.TryParse(txtCleanupFrom.Text, out tempValDouble) ? tempValDouble : 0;
			config.CleanupTo = double.TryParse(txtCleanupTo.Text, out tempValDouble) ? tempValDouble : 0;
			config.UseVolCal = chkVolCal.Checked;
			config.EnableBinaryCleanup = chkBinaryCleanup.Checked;

			config.EnableOutputOnlyRow = chkOutputOnlyR.Checked;
			config.OutputOnlyRowNumbers = int.TryParse(txtOutputOnlyR.Text, out tempValInt) ? tempValInt : 0;

			config.SubCalConfig.EnableSubCal = chkSubCal.Checked;
			config.SubCalConfig.ApplyPrimaryR = chkApplyPrimaryR.Checked;
			config.SubCalConfig.ApplyMultipleR = chkApplyMultipleR.Checked;
			config.SubCalConfig.ApplyAlignR = chkApplyAlignR.Checked;

			config.SubCalConfig.EnableCalAvg = chkCalAvg.Checked;
			config.SubCalConfig.SubCalLevels = int.TryParse(txtSubCalLevels.Text, out tempValInt) ? tempValInt : 0;

			config.SubCalConfig.LAvg1Start = int.TryParse(txtLavg1Start.Text, out tempValInt) ? tempValInt : 0;
			config.SubCalConfig.LAvg2Start = int.TryParse(txtLavg2Start.Text, out tempValInt) ? tempValInt : 0;
			config.SubCalConfig.LAvg3Start = int.TryParse(txtLavg3Start.Text, out tempValInt) ? tempValInt : 0;
			config.SubCalConfig.LAvg4Start = int.TryParse(txtLavg4Start.Text, out tempValInt) ? tempValInt : 0;

			config.SubCalConfig.LAvg1End = int.TryParse(txtLavg1End.Text, out tempValInt) ? tempValInt : 0;
			config.SubCalConfig.LAvg2End = int.TryParse(txtLavg2End.Text, out tempValInt) ? tempValInt : 0;
			config.SubCalConfig.LAvg3End = int.TryParse(txtLavg3End.Text, out tempValInt) ? tempValInt : 0;
			config.SubCalConfig.LAvg4End = int.TryParse(txtLavg4End.Text, out tempValInt) ? tempValInt : 0;

			config.SendCycleCompleteMsg = chkSendCycleCompleteMsg.Checked;

			config.UseVolCalAfterCleanup = chkApplyAfterCleanup.Checked;
			config.UseCustomPriceBarPoint = chkCustomPricePoint.Checked;
			config.UseCustomPricePercent = chkCustomPercentBar.Checked;
			config.CustomPriceBarFile = txtCustomPricePointBarPath.Text;
			config.CustomPricePercentFile = txtCustomBarPercentPath.Text;
			config.SubCalConfig.UseVolumeForLevels = chkUseVolForLevels.Checked;

			//last signal output 
			config.EnableLatestSignalOutput = chkLatestSignalOutput.Checked;
			config.LatestSignalApplyPrimary = chkLatestOutPrimary.Checked;
			config.LatestSignalApplyMultiple = chkLatestOutMultiple.Checked;
			config.LatestSignalApplyAlign = chkLatestOutAlign.Checked;
			config.LatestSignalOutputFolder = txtLastOutputFolder.Text;
			config.UseLatestNewSignal = chkLatestMasterNew.Checked;

			config.GenLatestSignalFile = chkGenLatestFile.Checked;
			config.GenLatestSignalMasterFile = chkGenLatestMasterFile.Checked;
			//

			config.UseColumnForLevels = chkColumnToUseForLabel.Checked;
			config.ColumnLevelType = (ColumnForLevelType)cmbColumnForLevel.SelectedIndex;
			config.UseBinaryLevels = chkBinaryLevels.Checked;
			config.UseMappedLevels = chkMapLevels.Checked;
			config.MappedLevelFile = txtMapLevelFile.Text;
			config.UseMasterColumnReport = chkMasterColumnReport.Checked;
			config.MasterColumnOutputFolder = txtMasterReportOutput.Text;
			config.ColumnOutput = (ColumnToOutputType)cmbMasterColOutput.SelectedIndex;
			config.RowsToOutput = int.Parse(txtRowsToOutput.Text);
			config.MasterReportColumnOnly = chkMasterReportColumnOnly.Checked;
			config.MasterReportDTC = chkMasterReportDTC.Checked;

			this.Close();
		}

		private void btnCancel_Click(object sender, EventArgs e)
		{
			this.Close();
		}

		private void txtNumberOfFolders_TextChanged(object sender, EventArgs e)
		{
			int nNumber = 0;

			int.TryParse(txtNumberOfFolders.Text, out nNumber);

			nNumber = Math.Min(nNumber, 10);

			if (nNumber <= 0)
				nNumber = 1;
			EnableMultiFolderControls(nNumber);
		}

		private void EnableMultiFolderControls(int nNumber)
		{
			TextBox[] pathTexts = { txtFolder2Path, txtFolder3Path, txtFolder4Path,
				txtFolder5Path, txtFolder6Path, txtFolder7Path, txtFolder8Path,  txtFolder9Path, txtFolder10Path};

			TextBox[] barTexts = {txtBarFolder2, txtBarFolder3, txtBarFolder4, txtBarFolder5,
				txtBarFolder6, txtBarFolder7, txtBarFolder8, txtBarFolder9, txtBarFolder10};

			Button[] browseButtons = {btnBrowseFolder2, btnBrowseFolder3, btnBrowseFolder4,
				btnBrowseFolder5, btnBrowseFolder6, btnBrowseFolder7, btnBrowseFolder8, btnBrowseFolder9, btnBrowseFolder10};
			for (int i = 0; i < nNumber - 1; i++)
			{
				pathTexts[i].Enabled = true;
				barTexts[i].Enabled = true;
				browseButtons[i].Enabled = true;
			}

			for (int i = nNumber - 1; i < pathTexts.Length; i++)
			{
				pathTexts[i].Enabled = false;
				barTexts[i].Enabled = false;
				browseButtons[i].Enabled = false;
			}
		}
		
		private void btnBrowsePrimaryFolder_Click(object sender, EventArgs e)
		{
		}

		private void button1_Click(object sender, EventArgs e)
		{
			txtROutputFolder.Text = Utils.GetFolderPath(txtROutputFolder.Text);
		}

		private void btnBrowseFolder2_Click(object sender, EventArgs e)
		{
			txtFolder2Path.Text = Utils.GetFolderPath(txtFolder2Path.Text);
		}

		private void btnBrowseFolder3_Click(object sender, EventArgs e)
		{
			txtFolder3Path.Text = Utils.GetFolderPath(txtFolder3Path.Text);
		}

		private void btnBrowseFolder4_Click(object sender, EventArgs e)
		{
			txtFolder4Path.Text = Utils.GetFolderPath(txtFolder4Path.Text);
		}

		private void btnBrowseFolder5_Click(object sender, EventArgs e)
		{
			txtFolder5Path.Text = Utils.GetFolderPath(txtFolder5Path.Text);
		}

		private void btnBrowseFolder6_Click(object sender, EventArgs e)
		{
			txtFolder6Path.Text = Utils.GetFolderPath(txtFolder6Path.Text);
		}

		private void btnBrowseFolder7_Click(object sender, EventArgs e)
		{
			txtFolder7Path.Text = Utils.GetFolderPath(txtFolder7Path.Text);
		}

		private void btnBrowseFolder8_Click(object sender, EventArgs e)
		{
			txtFolder8Path.Text = Utils.GetFolderPath(txtFolder8Path.Text);
		}

		private void btnBrowseFolder9_Click(object sender, EventArgs e)
		{
			txtFolder9Path.Text = Utils.GetFolderPath(txtFolder9Path.Text);
		}

		private void btnBrowseFolder10_Click(object sender, EventArgs e)
		{
			txtFolder10Path.Text = Utils.GetFolderPath(txtFolder10Path.Text);
		}

		private void btnBrowseAlignOutputFolder_Click(object sender, EventArgs e)
		{
			txtAlignOutputFolder.Text = Utils.GetFolderPath(txtAlignOutputFolder.Text);
		}

		private void chkGenAlignOutput_CheckedChanged(object sender, EventArgs e)
		{
			groupAlignOutput.Enabled = chkGenAlignOutput.Checked;
		}

		private void chkBinaryCleanup_CheckedChanged(object sender, EventArgs e)
		{
			txtCleanupFrom.Enabled = txtCleanupTo.Enabled = chkBinaryCleanup.Checked;
		}

		private void txtNumberOfAlignFolders_TextChanged(object sender, EventArgs e)
		{
			int nNumber = 0;

			int.TryParse(txtNumberOfAlignFolders.Text, out nNumber);

			nNumber = Math.Min(nNumber, 10);

			if (nNumber <= 0)
				nNumber = 1;

			EnableMultiFolderControls(nNumber);
		}

		private void chkOutputOnlyR_CheckedChanged(object sender, EventArgs e)
		{
			txtOutputOnlyR.Enabled = chkOutputOnlyR.Checked;
		}

		private void chkCalAvg_CheckedChanged(object sender, EventArgs e)
		{
			panelCalAvg.Enabled = chkCalAvg.Checked;
		}

		private void chkSubCal_CheckedChanged(object sender, EventArgs e)
		{
			groupSubCal.Enabled = chkSubCal.Checked;
		}

		private void chkVolCal_CheckedChanged(object sender, EventArgs e)
		{
			chkApplyAfterCleanup.Enabled = chkVolCal.Checked;
		}

		private void chkLatestSignalOutput_CheckedChanged(object sender, EventArgs e)
		{
			groupLatestSignal.Enabled = chkLatestSignalOutput.Checked;
		}

		private void btnBrowseCustomerPricePoint_Click(object sender, EventArgs e)
		{
			OpenFileDialog openDlg = new OpenFileDialog();
			openDlg.Filter = "CSV Files|*.csv";
			if (openDlg.ShowDialog() == DialogResult.OK)
			{
				GlobalData.Config.SymbolListFile = openDlg.FileName;
				txtCustomPricePointBarPath.Text = openDlg.FileName;
			}
		}

		private void btnBrowseCustomBarPercent_Click(object sender, EventArgs e)
		{
			OpenFileDialog openDlg = new OpenFileDialog();
			openDlg.Filter = "CSV Files|*.csv";
			if (openDlg.ShowDialog() == DialogResult.OK)
			{
				GlobalData.Config.SymbolListFile = openDlg.FileName;
				txtCustomBarPercentPath.Text = openDlg.FileName;
			}
		}

		private void chkCustomPricePoint_CheckedChanged(object sender, EventArgs e)
		{
			txtCustomPricePointBarPath.Enabled = btnBrowseCustomPricePoint.Enabled = chkCustomPricePoint.Checked;
		}

		private void chkCustomPercentBar_CheckedChanged(object sender, EventArgs e)
		{
			txtCustomBarPercentPath.Enabled = btnBrowseCustomBarPercent.Enabled = chkCustomPercentBar.Checked;
		}

		private void btnBrowselatestOutput_Click(object sender, EventArgs e)
		{
			txtLastOutputFolder.Text = Utils.GetFolderPath(txtROutputFolder.Text);
		}

		private void FrmROutputConfig_Load(object sender, EventArgs e)
		{

		}

		private void chkGenLatestMasterFile_CheckedChanged(object sender, EventArgs e)
		{
			chkLatestMasterNew.Enabled = chkGenLatestMasterFile.Checked;
		}

		private void chkLatestSignalOutput_CheckedChanged_1(object sender, EventArgs e)
		{
			groupLatestSignal.Enabled = chkLatestSignalOutput.Checked;
		}

		private void chkMasterColumnReport_CheckedChanged(object sender, EventArgs e)
		{
			groupMasterColumnReport.Enabled = chkMasterColumnReport.Checked;
		}

		private void chkMasterReportColumnOnly_CheckedChanged(object sender, EventArgs e)
		{
			chkMasterReportDTC.Checked = !chkMasterReportColumnOnly.Checked;
		}

		private void chkMasterReportDTC_CheckedChanged(object sender, EventArgs e)
		{
			chkMasterReportColumnOnly.Checked = !chkMasterReportDTC.Checked;
		}

		private void btnBrowseMasterReportOutput_Click(object sender, EventArgs e)
		{
			txtMasterReportOutput.Text = Utils.GetFolderPath(txtMasterReportOutput.Text);
		}

		private void btnBrowseMapLevelFile_Click(object sender, EventArgs e)
		{
			OpenFileDialog openDlg = new OpenFileDialog();
			openDlg.Filter = "CSV Files|*.csv";
			if (openDlg.ShowDialog() == DialogResult.OK)
			{
				config.MappedLevelFile = openDlg.FileName;
				txtMapLevelFile.Text = openDlg.FileName;
			}
		}
	}
}
