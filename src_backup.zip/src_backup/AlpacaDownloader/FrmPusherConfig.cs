﻿using SriAlpacaDLModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SriAlpacaDL
{
	public partial class FrmPusherConfig : Form
	{
		public PusherSettings config = new PusherSettings();
		public FrmPusherConfig()
		{
			InitializeComponent();
		}
		public FrmPusherConfig(PusherSettings config_) : this()
		{
			config = config_;

			txtAppID.Text = config.AppID;
			txtSecret.Text = config.Secret;
			txtKey.Text = config.Key;
			txtCluster.Text = config.Cluster;
			txtChannel.Text = config.Channel;
			chkAWSGzipFolder.Checked = config.SendAWSS3GzipFolder;
		}

		private void btnOK_Click(object sender, EventArgs e)
		{
			config.AppID = txtAppID.Text;
			config.Secret = txtSecret.Text;
			config.Key = txtKey.Text;
			config.Cluster = txtCluster.Text;
			config.Channel = txtChannel.Text;
			config.SendAWSS3GzipFolder = chkAWSGzipFolder.Checked;
			Close();
		}

		private void btnCancel_Click(object sender, EventArgs e)
		{
			Close();
		}
	}
}
