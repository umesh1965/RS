﻿
namespace SriAlpacaDL
{
	partial class FrmWebSocketSettings
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.label1 = new System.Windows.Forms.Label();
			this.cmbWebSocketSource = new System.Windows.Forms.ComboBox();
			this.chkCalendarWebSocket = new System.Windows.Forms.CheckBox();
			this.btnOK = new System.Windows.Forms.Button();
			this.btnCancel = new System.Windows.Forms.Button();
			this.btnBrowseInputDataPath = new System.Windows.Forms.Button();
			this.txtOutputDataPath = new System.Windows.Forms.TextBox();
			this.label11 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.lblParam = new System.Windows.Forms.Label();
			this.cmbEndPoint = new System.Windows.Forms.ComboBox();
			this.cmbParam = new System.Windows.Forms.ComboBox();
			this.lblInterval = new System.Windows.Forms.Label();
			this.txtInterval = new System.Windows.Forms.TextBox();
			this.txtBarsBack = new System.Windows.Forms.TextBox();
			this.lblBarsBack = new System.Windows.Forms.Label();
			this.txtIntervalTick = new System.Windows.Forms.TextBox();
			this.lblIntervalTick = new System.Windows.Forms.Label();
			this.txtMaxSymbol = new System.Windows.Forms.TextBox();
			this.lblMaxSymbol = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(26, 21);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(135, 13);
			this.label1.TabIndex = 0;
			this.label1.Text = "Active WebSocket Update";
			// 
			// cmbWebSocketSource
			// 
			this.cmbWebSocketSource.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cmbWebSocketSource.FormattingEnabled = true;
			this.cmbWebSocketSource.Items.AddRange(new object[] {
            "Alpaca V2",
            "Polygon",
            "TradeStation",
            "GlobalDataFeed",
            "TwelveData",
            "TDAmeritrade"});
			this.cmbWebSocketSource.Location = new System.Drawing.Point(178, 18);
			this.cmbWebSocketSource.Name = "cmbWebSocketSource";
			this.cmbWebSocketSource.Size = new System.Drawing.Size(121, 21);
			this.cmbWebSocketSource.TabIndex = 1;
			this.cmbWebSocketSource.SelectedIndexChanged += new System.EventHandler(this.cmbWebSocketSource_SelectedIndexChanged);
			// 
			// chkCalendarWebSocket
			// 
			this.chkCalendarWebSocket.AutoSize = true;
			this.chkCalendarWebSocket.Location = new System.Drawing.Point(33, 215);
			this.chkCalendarWebSocket.Name = "chkCalendarWebSocket";
			this.chkCalendarWebSocket.Size = new System.Drawing.Size(137, 17);
			this.chkCalendarWebSocket.TabIndex = 48;
			this.chkCalendarWebSocket.Text = "Calendar File Auto Start";
			this.chkCalendarWebSocket.UseVisualStyleBackColor = true;
			// 
			// btnOK
			// 
			this.btnOK.Location = new System.Drawing.Point(260, 228);
			this.btnOK.Name = "btnOK";
			this.btnOK.Size = new System.Drawing.Size(96, 29);
			this.btnOK.TabIndex = 49;
			this.btnOK.Text = "OK";
			this.btnOK.UseVisualStyleBackColor = true;
			this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
			// 
			// btnCancel
			// 
			this.btnCancel.Location = new System.Drawing.Point(374, 228);
			this.btnCancel.Name = "btnCancel";
			this.btnCancel.Size = new System.Drawing.Size(96, 29);
			this.btnCancel.TabIndex = 50;
			this.btnCancel.Text = "Cancel";
			this.btnCancel.UseVisualStyleBackColor = true;
			this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
			// 
			// btnBrowseInputDataPath
			// 
			this.btnBrowseInputDataPath.Location = new System.Drawing.Point(436, 50);
			this.btnBrowseInputDataPath.Name = "btnBrowseInputDataPath";
			this.btnBrowseInputDataPath.Size = new System.Drawing.Size(27, 22);
			this.btnBrowseInputDataPath.TabIndex = 53;
			this.btnBrowseInputDataPath.Text = "...";
			this.btnBrowseInputDataPath.UseVisualStyleBackColor = true;
			this.btnBrowseInputDataPath.Click += new System.EventHandler(this.btnBrowseInputDataPath_Click);
			// 
			// txtOutputDataPath
			// 
			this.txtOutputDataPath.Location = new System.Drawing.Point(178, 51);
			this.txtOutputDataPath.Name = "txtOutputDataPath";
			this.txtOutputDataPath.Size = new System.Drawing.Size(258, 20);
			this.txtOutputDataPath.TabIndex = 52;
			// 
			// label11
			// 
			this.label11.AutoSize = true;
			this.label11.Location = new System.Drawing.Point(56, 53);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(97, 13);
			this.label11.TabIndex = 51;
			this.label11.Text = "History Data Folder";
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(101, 86);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(50, 13);
			this.label2.TabIndex = 54;
			this.label2.Text = "EndPoint";
			// 
			// lblParam
			// 
			this.lblParam.AutoSize = true;
			this.lblParam.Location = new System.Drawing.Point(110, 120);
			this.lblParam.Name = "lblParam";
			this.lblParam.Size = new System.Drawing.Size(42, 13);
			this.lblParam.TabIndex = 56;
			this.lblParam.Text = "Params";
			// 
			// cmbEndPoint
			// 
			this.cmbEndPoint.FormattingEnabled = true;
			this.cmbEndPoint.Items.AddRange(new object[] {
            "wss://socket.polygon.io/stocks",
            "wss://delayed.polygon.io/stocks",
            "wss://socket.polygon.io/forex",
            "wss://socket.polygon.io/crypto",
            "ws://nimblewebstream.lisuns.com:4575",
            "wss://nimblewebstream.lisuns.com:4576",
            "wss://ws.twelvedata.com/v1/quotes/price"});
			this.cmbEndPoint.Location = new System.Drawing.Point(178, 84);
			this.cmbEndPoint.Name = "cmbEndPoint";
			this.cmbEndPoint.Size = new System.Drawing.Size(258, 21);
			this.cmbEndPoint.TabIndex = 57;
			// 
			// cmbParam
			// 
			this.cmbParam.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cmbParam.FormattingEnabled = true;
			this.cmbParam.Items.AddRange(new object[] {
            "Stocks-Second=A.*",
            "Stocks-Minute=AM.*",
            "FX-Minute=CA.*",
            "Crypto-Minute=XA.*"});
			this.cmbParam.Location = new System.Drawing.Point(178, 117);
			this.cmbParam.Name = "cmbParam";
			this.cmbParam.Size = new System.Drawing.Size(171, 21);
			this.cmbParam.TabIndex = 58;
			// 
			// lblInterval
			// 
			this.lblInterval.AutoSize = true;
			this.lblInterval.Location = new System.Drawing.Point(85, 120);
			this.lblInterval.Name = "lblInterval";
			this.lblInterval.Size = new System.Drawing.Size(67, 13);
			this.lblInterval.TabIndex = 59;
			this.lblInterval.Text = "Interval(Sec)";
			// 
			// txtInterval
			// 
			this.txtInterval.Location = new System.Drawing.Point(178, 117);
			this.txtInterval.Name = "txtInterval";
			this.txtInterval.Size = new System.Drawing.Size(100, 20);
			this.txtInterval.TabIndex = 60;
			// 
			// txtBarsBack
			// 
			this.txtBarsBack.Location = new System.Drawing.Point(178, 151);
			this.txtBarsBack.Name = "txtBarsBack";
			this.txtBarsBack.Size = new System.Drawing.Size(100, 20);
			this.txtBarsBack.TabIndex = 62;
			// 
			// lblBarsBack
			// 
			this.lblBarsBack.AutoSize = true;
			this.lblBarsBack.Location = new System.Drawing.Point(85, 154);
			this.lblBarsBack.Name = "lblBarsBack";
			this.lblBarsBack.Size = new System.Drawing.Size(53, 13);
			this.lblBarsBack.TabIndex = 61;
			this.lblBarsBack.Text = "BarsBack";
			// 
			// txtIntervalTick
			// 
			this.txtIntervalTick.Location = new System.Drawing.Point(178, 183);
			this.txtIntervalTick.Name = "txtIntervalTick";
			this.txtIntervalTick.Size = new System.Drawing.Size(100, 20);
			this.txtIntervalTick.TabIndex = 64;
			// 
			// lblIntervalTick
			// 
			this.lblIntervalTick.AutoSize = true;
			this.lblIntervalTick.Location = new System.Drawing.Point(85, 186);
			this.lblIntervalTick.Name = "lblIntervalTick";
			this.lblIntervalTick.Size = new System.Drawing.Size(69, 13);
			this.lblIntervalTick.TabIndex = 63;
			this.lblIntervalTick.Text = "Interval(Tick)";
			// 
			// txtMaxSymbol
			// 
			this.txtMaxSymbol.Location = new System.Drawing.Point(178, 151);
			this.txtMaxSymbol.Name = "txtMaxSymbol";
			this.txtMaxSymbol.Size = new System.Drawing.Size(100, 20);
			this.txtMaxSymbol.TabIndex = 66;
			// 
			// lblMaxSymbol
			// 
			this.lblMaxSymbol.AutoSize = true;
			this.lblMaxSymbol.Location = new System.Drawing.Point(23, 154);
			this.lblMaxSymbol.Name = "lblMaxSymbol";
			this.lblMaxSymbol.Size = new System.Drawing.Size(128, 13);
			this.lblMaxSymbol.TabIndex = 65;
			this.lblMaxSymbol.Text = "Max Symbols Per API Call";
			// 
			// FrmWebSocketSettings
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(482, 269);
			this.Controls.Add(this.txtMaxSymbol);
			this.Controls.Add(this.lblMaxSymbol);
			this.Controls.Add(this.txtIntervalTick);
			this.Controls.Add(this.lblIntervalTick);
			this.Controls.Add(this.txtBarsBack);
			this.Controls.Add(this.lblBarsBack);
			this.Controls.Add(this.txtInterval);
			this.Controls.Add(this.lblInterval);
			this.Controls.Add(this.cmbParam);
			this.Controls.Add(this.cmbEndPoint);
			this.Controls.Add(this.lblParam);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.btnBrowseInputDataPath);
			this.Controls.Add(this.txtOutputDataPath);
			this.Controls.Add(this.label11);
			this.Controls.Add(this.btnCancel);
			this.Controls.Add(this.btnOK);
			this.Controls.Add(this.chkCalendarWebSocket);
			this.Controls.Add(this.cmbWebSocketSource);
			this.Controls.Add(this.label1);
			this.Name = "FrmWebSocketSettings";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "WebSocket Settings";
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.ComboBox cmbWebSocketSource;
		private System.Windows.Forms.CheckBox chkCalendarWebSocket;
		private System.Windows.Forms.Button btnOK;
		private System.Windows.Forms.Button btnCancel;
		private System.Windows.Forms.Button btnBrowseInputDataPath;
		private System.Windows.Forms.TextBox txtOutputDataPath;
		private System.Windows.Forms.Label label11;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label lblParam;
		private System.Windows.Forms.ComboBox cmbEndPoint;
		private System.Windows.Forms.ComboBox cmbParam;
		private System.Windows.Forms.Label lblInterval;
		private System.Windows.Forms.TextBox txtInterval;
		private System.Windows.Forms.TextBox txtBarsBack;
		private System.Windows.Forms.Label lblBarsBack;
		private System.Windows.Forms.TextBox txtIntervalTick;
		private System.Windows.Forms.Label lblIntervalTick;
		private System.Windows.Forms.TextBox txtMaxSymbol;
		private System.Windows.Forms.Label lblMaxSymbol;
	}
}