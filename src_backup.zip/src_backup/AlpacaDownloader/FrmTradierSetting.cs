﻿using SriAlpacaDLModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SriAlpacaDL
{
	public partial class FrmTradierSetting : Form
	{
		TradierSettings config;
		public FrmTradierSetting()
		{
			InitializeComponent();
		}

		public FrmTradierSetting(TradierSettings config_) : this()
		{
			config = config_;

			cmbUrl.SelectedIndex = (int)config.EndPoint;
			txtAPIKey.Text = config.APIKey;
			txtRateLimit.Text = config.RateLimit.ToString();
			cmbAPICallType.SelectedIndex = (int)config.APICall;
			cmbSessionFilter.SelectedIndex = (int)config.SessionFilter;
			cmbSessionFilter.Visible = cmbAPICallType.SelectedIndex == 0;
			lblSessionFilter.Visible = cmbAPICallType.SelectedIndex == 0;
		}

		private void cmbAPICallType_SelectedIndexChanged(object sender, EventArgs e)
		{
			cmbSessionFilter.Visible = cmbAPICallType.SelectedIndex == 0;
			lblSessionFilter.Visible = cmbAPICallType.SelectedIndex == 0;
		}

		private void btnOK_Click(object sender, EventArgs e)
		{
			config.EndPoint = (TradierSettings.EndPointType)cmbUrl.SelectedIndex;
			config.APIKey = txtAPIKey.Text;
			int tempVal = 0;
			config.RateLimit = int.TryParse(txtRateLimit.Text, out tempVal) ? tempVal : 0;
			config.APICall = (TradierSettings.CallType)cmbAPICallType.SelectedIndex;
			config.SessionFilter = (TradierSettings.SessionFilterType)cmbSessionFilter.SelectedIndex;
			this.Close();
		}

		private void btnCancel_Click(object sender, EventArgs e)
		{
			this.Close();
		}
	}
}
