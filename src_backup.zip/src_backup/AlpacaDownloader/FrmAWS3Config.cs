﻿using SriAlpacaDLModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SriAlpacaDL
{
	public partial class FrmAWS3Config : Form
	{
		private AWSS3Settings config { get; }
		public FrmAWS3Config()
		{
			InitializeComponent();
		}
		public FrmAWS3Config(AWSS3Settings config_) : this()
		{
			config = config_;

			chkUseAWSS3.Checked = config.UseAWSUpload;
			txtAWSAccessKey.Text = config.AccessKey;
			txtAWSSecretKey.Text = config.SecretKey;
			cmbAWSRegion.Text = config.Region;
			txtAWSCannedACL.Text = config.CannedACL;
			txtBucketName.Text = config.BucketName;
			txtAWSEncrytionKey.Text = config.EncryptionKey;
			cmbCompressionFormat.Text = config.GzipFormat;
			chkGZipIndividual.Checked = config.UseGZipIndividual;
			chkGzipFolder.Checked = config.UseGZipFolder;
			txtGzipFolderName.Text = config.GZipFolderName;
			chkGzipUsePassword.Checked = config.GZipUsePasswordProtect;
			txtGzipPassword.Text = config.GZipPassword;
			chkAWSApplyPrimary.Checked = config.ApplyPrimary;
			chkAWSApplySec.Checked = config.ApplySecondary;
			chkAWSApplyAlign.Checked = config.ApplyAlign;
			chkSaveWithoutR.Checked = config.UploadWithoutR;
			chkMarketView.Checked = config.MarketView;
			txtMarketViewFolder.Text = config.MarketViewFolder;
			chkAllSignalReport.Checked = config.AllSignalReport;
			chkAllMarketHistorical.Checked = config.AllMarketHistorical;
			chkIndustryReport.Checked = config.IndustryReport;
			chkIndustryHistorical.Checked = config.IndustryHistorical;
			chkSectorReport.Checked = config.SectorReport;
			chkSectorHistorical.Checked = config.SectorHistorical;
			chkLatestSignal.Checked = config.LatestSignal;
			txtLatestSignalFolder.Text = config.LatestSignalFolder;
			chkZipLatestSignalMaster.Checked = config.LastestMasterFile;
			chkZipNewLatestSignal.Checked = config.NewLatestMasterFile;
		}

		private void btnOK_Click(object sender, EventArgs e)
		{
			config.UseAWSUpload = chkUseAWSS3.Checked;
			config.AccessKey = txtAWSAccessKey.Text;
			config.SecretKey = txtAWSSecretKey.Text;
			config.Region = cmbAWSRegion.Text;
			config.BucketName = txtBucketName.Text;
			config.CannedACL = txtAWSCannedACL.Text;
			config.EncryptionKey = txtAWSEncrytionKey.Text;

			config.GzipFormat = cmbCompressionFormat.Text;
			config.UseGZipIndividual = chkGZipIndividual.Checked;
			config.UseGZipFolder = chkGzipFolder.Checked;
			config.GZipFolderName = txtGzipFolderName.Text;
			config.GZipUsePasswordProtect = chkGzipUsePassword.Checked;
			config.GZipPassword = txtGzipPassword.Text;

			config.ApplyPrimary = chkAWSApplyPrimary.Checked;
			config.ApplyAlign = chkAWSApplyAlign.Checked;
			config.ApplySecondary = chkAWSApplySec.Checked;

			config.UploadWithoutR = chkSaveWithoutR.Checked;

			config.MarketView = chkMarketView.Checked;
			config.MarketViewFolder = txtMarketViewFolder.Text;
			config.AllSignalReport = chkAllSignalReport.Checked;
			config.AllMarketHistorical = chkAllMarketHistorical.Checked;
			config.IndustryReport = chkIndustryReport.Checked;
			config.IndustryHistorical = chkIndustryHistorical.Checked;
			config.SectorReport = chkSectorReport.Checked;
			config.SectorHistorical = chkSectorHistorical.Checked;

			config.LatestSignal = chkLatestSignal.Checked;
			config.LatestSignalFolder = txtLatestSignalFolder.Text;
			config.LastestMasterFile = chkZipLatestSignalMaster.Checked;
			config.NewLatestMasterFile = chkZipNewLatestSignal.Checked;

			Close();
		}

		private void btnCancel_Click(object sender, EventArgs e)
		{
			Close();
		}
	}
}
