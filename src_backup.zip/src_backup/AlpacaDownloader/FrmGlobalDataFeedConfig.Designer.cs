﻿
namespace SriAlpacaDL
{
	partial class FrmGlobalDataFeedConfig
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.txtEndPoint = new System.Windows.Forms.TextBox();
			this.txtAPIKey = new System.Windows.Forms.TextBox();
			this.txtExchangeCode = new System.Windows.Forms.TextBox();
			this.cmbShortIdentifier = new System.Windows.Forms.ComboBox();
			this.btnOK = new System.Windows.Forms.Button();
			this.btnCancel = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(57, 21);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(50, 13);
			this.label1.TabIndex = 0;
			this.label1.Text = "EndPoint";
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(62, 53);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(45, 13);
			this.label2.TabIndex = 1;
			this.label2.Text = "API Key";
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(24, 86);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(83, 13);
			this.label3.TabIndex = 2;
			this.label3.Text = "Exchange Code";
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(27, 121);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(80, 13);
			this.label4.TabIndex = 3;
			this.label4.Text = "IsShortIdentifier";
			// 
			// txtEndPoint
			// 
			this.txtEndPoint.Location = new System.Drawing.Point(124, 18);
			this.txtEndPoint.Name = "txtEndPoint";
			this.txtEndPoint.Size = new System.Drawing.Size(216, 20);
			this.txtEndPoint.TabIndex = 4;
			// 
			// txtAPIKey
			// 
			this.txtAPIKey.Location = new System.Drawing.Point(124, 50);
			this.txtAPIKey.Name = "txtAPIKey";
			this.txtAPIKey.Size = new System.Drawing.Size(216, 20);
			this.txtAPIKey.TabIndex = 5;
			// 
			// txtExchangeCode
			// 
			this.txtExchangeCode.Location = new System.Drawing.Point(124, 83);
			this.txtExchangeCode.Name = "txtExchangeCode";
			this.txtExchangeCode.Size = new System.Drawing.Size(104, 20);
			this.txtExchangeCode.TabIndex = 6;
			// 
			// cmbShortIdentifier
			// 
			this.cmbShortIdentifier.FormattingEnabled = true;
			this.cmbShortIdentifier.Items.AddRange(new object[] {
            "False",
            "True"});
			this.cmbShortIdentifier.Location = new System.Drawing.Point(124, 118);
			this.cmbShortIdentifier.Name = "cmbShortIdentifier";
			this.cmbShortIdentifier.Size = new System.Drawing.Size(104, 21);
			this.cmbShortIdentifier.TabIndex = 7;
			// 
			// btnOK
			// 
			this.btnOK.Location = new System.Drawing.Point(168, 153);
			this.btnOK.Name = "btnOK";
			this.btnOK.Size = new System.Drawing.Size(104, 32);
			this.btnOK.TabIndex = 8;
			this.btnOK.Text = "OK";
			this.btnOK.UseVisualStyleBackColor = true;
			this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
			// 
			// btnCancel
			// 
			this.btnCancel.Location = new System.Drawing.Point(278, 153);
			this.btnCancel.Name = "btnCancel";
			this.btnCancel.Size = new System.Drawing.Size(104, 32);
			this.btnCancel.TabIndex = 9;
			this.btnCancel.Text = "Cancel";
			this.btnCancel.UseVisualStyleBackColor = true;
			this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
			// 
			// FrmGlobalDataFeedConfig
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(394, 197);
			this.Controls.Add(this.btnCancel);
			this.Controls.Add(this.btnOK);
			this.Controls.Add(this.cmbShortIdentifier);
			this.Controls.Add(this.txtExchangeCode);
			this.Controls.Add(this.txtAPIKey);
			this.Controls.Add(this.txtEndPoint);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Name = "FrmGlobalDataFeedConfig";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Global DataFeed Settings";
			this.Load += new System.EventHandler(this.FrmGlobalDataFeedConfig_Load);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.TextBox txtEndPoint;
		private System.Windows.Forms.TextBox txtAPIKey;
		private System.Windows.Forms.TextBox txtExchangeCode;
		private System.Windows.Forms.ComboBox cmbShortIdentifier;
		private System.Windows.Forms.Button btnOK;
		private System.Windows.Forms.Button btnCancel;
	}
}