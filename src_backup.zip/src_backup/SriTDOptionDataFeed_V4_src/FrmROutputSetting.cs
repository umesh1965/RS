﻿using SriTDDataFeedSetting;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sri_TD_Options_DataFeed
{
	public partial class FrmROutputSetting : Form
	{
		private ROutputSettings config;
		public FrmROutputSetting()
		{
			InitializeComponent();
		}
		public FrmROutputSetting(ROutputSettings config_) : this()
		{
			config = config_;

			txtROutputFolder.Text = config.ROutputFolder;
			txtLevel.Text = config.Level.ToString();
			txtBar.Text = config.BarPercent.ToString("0.##");

			chkSendZMQ.Checked = config.EnableZeroMQ;
			groupBoxZMQ.Enabled = config.EnableZeroMQ;
			chkStoreBarChange.Checked = config.StoreBarPercentAsChange;

			if (config.EnableZeroMQ)
			{
				txtIP.Text = config.IPAddressZMQ;
				txtPort.Text = config.PortZMQ.ToString();
			}

			chkDontOutputFiles.Checked = config.DontOutputFiles;
			
			chkOutputOnlyR.Checked = config.EnableOutputOnlyRow;
			txtOutputOnlyR.Text = config.OutputOnlyRowNumbers.ToString();
			//subcal settings
			chkApplyPrimaryR.Checked = config.SubCalConfig.ApplyPrimaryR;

			chkSubCal.Checked = config.SubCalConfig.EnableSubCal;
			txtSubCalLevels.Text = config.SubCalConfig.SubCalLevels.ToString();
			txtBSLevels.Text = config.SubCalConfig.BSLevels.ToString();

			chkCalAvg.Checked = config.SubCalConfig.EnableCalAvg;

			txtLavg1Start.Text = config.SubCalConfig.LAvg1Start.ToString();
			txtLavg2Start.Text = config.SubCalConfig.LAvg2Start.ToString();
			txtLavg3Start.Text = config.SubCalConfig.LAvg3Start.ToString();
			txtLavg4Start.Text = config.SubCalConfig.LAvg4Start.ToString();

			txtLavg1End.Text = config.SubCalConfig.LAvg1End.ToString();
			txtLavg2End.Text = config.SubCalConfig.LAvg2End.ToString();
			txtLavg3End.Text = config.SubCalConfig.LAvg3End.ToString();
			txtLavg4End.Text = config.SubCalConfig.LAvg4End.ToString();

			chkSendCycleCompleteMsg.Checked = config.SendCycleCompleteMsg;

			panelCalAvg.Enabled = config.SubCalConfig.EnableCalAvg;

			txtOutputOnlyR.Enabled = chkOutputOnlyR.Checked;

			//V8 : BS Signal
			chkEnableBSSignal.Checked = config.SubCalConfig.EnableBSSignals;
			radioBSLevel.Checked = config.SubCalConfig.BSSignalMode == 0;
			radLavgSignal.Checked = config.SubCalConfig.BSSignalMode == 1;
			txtLavgSignal.Text = config.SubCalConfig.Lavg1SignalMin.ToString("0.00");

			panelBSLevels.Enabled = chkEnableBSSignal.Checked;

			txtBSLevels.Enabled = radioBSLevel.Checked;
			txtLavgSignal.Enabled = radLavgSignal.Checked;
			//

			//V9 Custom Price Bar
			txtCustomBarPercentPath.Text = config.CustomPricePercentFile;
			chkCustomPercentBar.Checked = config.UseCustomPricePercent;

			txtCustomBarPercentPath.Enabled = btnBrowseCustomBarPercent.Enabled = config.UseCustomPricePercent;

			//latest signal gen
			chkLatestSignalOutput.Checked = config.EnableLatestSignalOutput;
			chkLatestOutPrimary.Checked = config.LatestSignalApplyPrimary;
			txtLastOutputFolder.Text = config.LatestSignalOutputFolder;
			chkGenLatestFile.Checked = config.GenLatestSignalFile;
			chkGenLatestMasterFile.Checked = config.GenLatestSignalMasterFile;
			chkLatestMasterNew.Checked = config.UseLatestNewSignal;

			chkLatestMasterNew.Enabled = chkGenLatestMasterFile.Checked;
			groupLatestSignal.Enabled = config.EnableLatestSignalOutput;
			chkMinRowsCleanUp.Enabled = config.EnableMinRowsCleanUp;
			txtMinRowsCleanUp.Text = config.MinRowsCleanUpCount.ToString();
			chkOptionGridReport.Checked = config.GenOptionGridReport;
			chkSignalReport.Checked = config.GenOptionSignalReport;

			txtMinRowsCleanUp.Enabled = chkMinRowsCleanUp.Checked;

			txtReportOutputFolder.Text = config.ReportOutputFolder;
		}

		private void btnOK_Click(object sender, EventArgs e)
		{
			config.ROutputFolder = txtROutputFolder.Text;
			int tempValInt;
			double tempValDouble;

			config.Level = int.TryParse(txtLevel.Text, out tempValInt) ? tempValInt : 0;

			config.BarPercent = double.TryParse(txtBar.Text, out tempValDouble) ? tempValDouble : 0;

			config.EnableZeroMQ = chkSendZMQ.Checked;
			if (config.EnableZeroMQ)
			{
				config.IPAddressZMQ = txtIP.Text;
				config.PortZMQ = int.TryParse(txtPort.Text, out tempValInt) ? tempValInt : 0;
			}

			config.StoreBarPercentAsChange = chkStoreBarChange.Checked;

			config.DontOutputFiles = chkDontOutputFiles.Checked;

			config.EnableOutputOnlyRow = chkOutputOnlyR.Checked;
			config.OutputOnlyRowNumbers = int.TryParse(txtOutputOnlyR.Text, out tempValInt) ? tempValInt : 0;

			config.SubCalConfig.EnableSubCal = chkSubCal.Checked;
			config.SubCalConfig.ApplyPrimaryR = chkApplyPrimaryR.Checked;

			config.SubCalConfig.EnableCalAvg = chkCalAvg.Checked;
			config.SubCalConfig.SubCalLevels = int.TryParse(txtSubCalLevels.Text, out tempValInt) ? tempValInt : 0;
			config.SubCalConfig.BSLevels = int.TryParse(txtBSLevels.Text, out tempValInt) ? tempValInt : 0;

			config.SubCalConfig.LAvg1Start = int.TryParse(txtLavg1Start.Text, out tempValInt) ? tempValInt : 0;
			config.SubCalConfig.LAvg2Start = int.TryParse(txtLavg2Start.Text, out tempValInt) ? tempValInt : 0;
			config.SubCalConfig.LAvg3Start = int.TryParse(txtLavg3Start.Text, out tempValInt) ? tempValInt : 0;
			config.SubCalConfig.LAvg4Start = int.TryParse(txtLavg4Start.Text, out tempValInt) ? tempValInt : 0;

			config.SubCalConfig.LAvg1End = int.TryParse(txtLavg1End.Text, out tempValInt) ? tempValInt : 0;
			config.SubCalConfig.LAvg2End = int.TryParse(txtLavg2End.Text, out tempValInt) ? tempValInt : 0;
			config.SubCalConfig.LAvg3End = int.TryParse(txtLavg3End.Text, out tempValInt) ? tempValInt : 0;
			config.SubCalConfig.LAvg4End = int.TryParse(txtLavg4End.Text, out tempValInt) ? tempValInt : 0;

			config.SendCycleCompleteMsg = chkSendCycleCompleteMsg.Checked;

			config.SubCalConfig.EnableBSSignals = chkEnableBSSignal.Checked;
			config.SubCalConfig.BSSignalMode = radioBSLevel.Checked ? 0 : 1;
			config.SubCalConfig.Lavg1SignalMin = double.TryParse(txtLavgSignal.Text, out tempValDouble) ? tempValDouble : 0;

			config.UseCustomPricePercent = chkCustomPercentBar.Checked;
			config.CustomPricePercentFile = txtCustomBarPercentPath.Text;


			//last signal output 
			config.EnableLatestSignalOutput = chkLatestSignalOutput.Checked;
			config.LatestSignalApplyPrimary = chkLatestOutPrimary.Checked;
			config.LatestSignalOutputFolder = txtLastOutputFolder.Text;
			config.UseLatestNewSignal = chkLatestMasterNew.Checked;

			config.GenLatestSignalFile = chkGenLatestFile.Checked;
			config.GenLatestSignalMasterFile = chkGenLatestMasterFile.Checked;
			//
			config.EnableMinRowsCleanUp = chkMinRowsCleanUp.Checked;
			config.MinRowsCleanUpCount = int.TryParse(txtMinRowsCleanUp.Text, out tempValInt) ? tempValInt : 0;
			config.GenOptionGridReport = chkOptionGridReport.Checked;
			config.GenOptionSignalReport = chkSignalReport.Checked;

			config.ReportOutputFolder = txtReportOutputFolder.Text;
			this.Close();
		}

		private void btnCancel_Click(object sender, EventArgs e)
		{
			this.Close();
		}

		private void chkCustomPercentBar_CheckedChanged(object sender, EventArgs e)
		{
			txtCustomBarPercentPath.Enabled = btnBrowseCustomBarPercent.Enabled = chkCustomPercentBar.Checked;
		}

		private void chkLatestSignalOutput_CheckedChanged(object sender, EventArgs e)
		{
			groupLatestSignal.Enabled = chkLatestSignalOutput.Checked;
		}

		private void chkSendZMQ_CheckedChanged(object sender, EventArgs e)
		{
			groupBoxZMQ.Enabled = chkSendZMQ.Checked;

			if (config.EnableZeroMQ)
			{
				txtIP.Text = config.IPAddressZMQ;
				txtPort.Text = config.PortZMQ.ToString();
			}
		}

		private void chkSubCal_CheckedChanged(object sender, EventArgs e)
		{
			groupSubCal.Enabled = chkSubCal.Checked;
		}

		private void chkEnableBSSignal_CheckedChanged(object sender, EventArgs e)
		{
			panelBSLevels.Enabled = chkEnableBSSignal.Checked;
		}

		private void chkCalAvg_CheckedChanged(object sender, EventArgs e)
		{
			panelCalAvg.Enabled = chkCalAvg.Checked;
		}

		private void chkOutputOnlyR_CheckedChanged(object sender, EventArgs e)
		{
			txtOutputOnlyR.Enabled = chkOutputOnlyR.Checked;
		}

		private void btnBrowseROutputFolder_Click(object sender, EventArgs e)
		{
			txtROutputFolder.Text = Utils.GetFolderPath(txtROutputFolder.Text);
		}

		private void btnBrowselatestOutput_Click(object sender, EventArgs e)
		{
			txtLastOutputFolder.Text = Utils.GetFolderPath(txtLastOutputFolder.Text);
		}

		private void chkMinRowsCleanUp_CheckedChanged(object sender, EventArgs e)
		{
			txtMinRowsCleanUp.Enabled = chkMinRowsCleanUp.Checked;
		}

		private void btnBrowseCustomBarPercent_Click(object sender, EventArgs e)
		{
			OpenFileDialog openDlg = new OpenFileDialog();
			openDlg.Filter = "Custom Bar Percent File |*.csv";
			if (openDlg.ShowDialog() == DialogResult.OK)
			{
				GlobalData.Config.MergeTreeFile = openDlg.FileName;
				txtCustomBarPercentPath.Text = openDlg.FileName;
			}
		}

		private void btnReportOutputFolder_Click(object sender, EventArgs e)
		{
			txtReportOutputFolder.Text = Utils.GetFolderPath(txtLastOutputFolder.Text);
		}
	}
}
