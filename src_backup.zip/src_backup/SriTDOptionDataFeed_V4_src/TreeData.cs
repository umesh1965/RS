﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SriTDDataFeedSetting
{
	public class TreeData
	{
		public string OptionSymbol { get; set; }
		public string StockSymbol { get; set; }
		public string Company { get; set; }
		public string Sector { get; set; }
		public string Industry { get; set; }
	}
}
