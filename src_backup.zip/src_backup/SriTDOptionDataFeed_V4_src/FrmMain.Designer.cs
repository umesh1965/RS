﻿namespace Sri_TD_Options_DataFeed
{
	partial class FrmMain
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmMain));
			this.groupGeneralSetting = new System.Windows.Forms.GroupBox();
			this.chkRoundVol = new System.Windows.Forms.CheckBox();
			this.chkRoundClose = new System.Windows.Forms.CheckBox();
			this.chkRoundChange = new System.Windows.Forms.CheckBox();
			this.txtRounding = new System.Windows.Forms.TextBox();
			this.label19 = new System.Windows.Forms.Label();
			this.chkUseCalendarFile = new System.Windows.Forms.CheckBox();
			this.chkGenStockFile = new System.Windows.Forms.CheckBox();
			this.txtRefreshToken = new System.Windows.Forms.TextBox();
			this.label6 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.radioByKey = new System.Windows.Forms.RadioButton();
			this.radioByToken = new System.Windows.Forms.RadioButton();
			this.txtAPIKey = new System.Windows.Forms.TextBox();
			this.label9 = new System.Windows.Forms.Label();
			this.txtAutoStopTime = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.txtSymbolCount = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.btnBrowseInputDataPath = new System.Windows.Forms.Button();
			this.btnBrowseInputSymbolFile = new System.Windows.Forms.Button();
			this.txtInputDataPath = new System.Windows.Forms.TextBox();
			this.label11 = new System.Windows.Forms.Label();
			this.txtInputSymbolFile = new System.Windows.Forms.TextBox();
			this.label10 = new System.Windows.Forms.Label();
			this.groupProcessType = new System.Windows.Forms.GroupBox();
			this.label3 = new System.Windows.Forms.Label();
			this.txtAutoUpdateInterval = new System.Windows.Forms.TextBox();
			this.radioAutoUpdate = new System.Windows.Forms.RadioButton();
			this.radioAutoLoop = new System.Windows.Forms.RadioButton();
			this.radioManualStatic = new System.Windows.Forms.RadioButton();
			this.statusStrip1 = new System.Windows.Forms.StatusStrip();
			this.statusLabel = new System.Windows.Forms.ToolStripStatusLabel();
			this.statusProgressBar = new System.Windows.Forms.ToolStripProgressBar();
			this.groupOptionClean = new System.Windows.Forms.GroupBox();
			this.chkDeleteIfNoHIstoryFile = new System.Windows.Forms.CheckBox();
			this.txtMinimumRows = new System.Windows.Forms.TextBox();
			this.label5 = new System.Windows.Forms.Label();
			this.btnStart = new System.Windows.Forms.Button();
			this.btnStop = new System.Windows.Forms.Button();
			this.btnExit = new System.Windows.Forms.Button();
			this.btnAddTimeColumn = new System.Windows.Forms.Button();
			this.btnCleanTDOptionList = new System.Windows.Forms.Button();
			this.groupMergeFile = new System.Windows.Forms.GroupBox();
			this.btnBrowseMergePath = new System.Windows.Forms.Button();
			this.btnBrowseTreeFile = new System.Windows.Forms.Button();
			this.txtMergeOutputPath = new System.Windows.Forms.TextBox();
			this.label7 = new System.Windows.Forms.Label();
			this.txtMergeTreeFile = new System.Windows.Forms.TextBox();
			this.label8 = new System.Windows.Forms.Label();
			this.chkMergeFile = new System.Windows.Forms.CheckBox();
			this.groupAlign = new System.Windows.Forms.GroupBox();
			this.alignEndTime = new System.Windows.Forms.DateTimePicker();
			this.alignStartTime = new System.Windows.Forms.DateTimePicker();
			this.trimTime = new System.Windows.Forms.DateTimePicker();
			this.trimDate = new System.Windows.Forms.DateTimePicker();
			this.btnStartAlign = new System.Windows.Forms.Button();
			this.cmbAlignTimeFrame = new System.Windows.Forms.ComboBox();
			this.label14 = new System.Windows.Forms.Label();
			this.label13 = new System.Windows.Forms.Label();
			this.label12 = new System.Windows.Forms.Label();
			this.timerAutoUpdate = new System.Windows.Forms.Timer(this.components);
			this.btnROutputSetting = new System.Windows.Forms.Button();
			this.chkROutput = new System.Windows.Forms.CheckBox();
			this.btnGetToken = new System.Windows.Forms.Button();
			this.groupGeneralSetting.SuspendLayout();
			this.groupProcessType.SuspendLayout();
			this.statusStrip1.SuspendLayout();
			this.groupOptionClean.SuspendLayout();
			this.groupMergeFile.SuspendLayout();
			this.groupAlign.SuspendLayout();
			this.SuspendLayout();
			// 
			// groupGeneralSetting
			// 
			this.groupGeneralSetting.Controls.Add(this.chkRoundVol);
			this.groupGeneralSetting.Controls.Add(this.chkRoundClose);
			this.groupGeneralSetting.Controls.Add(this.chkRoundChange);
			this.groupGeneralSetting.Controls.Add(this.txtRounding);
			this.groupGeneralSetting.Controls.Add(this.label19);
			this.groupGeneralSetting.Controls.Add(this.chkUseCalendarFile);
			this.groupGeneralSetting.Controls.Add(this.chkGenStockFile);
			this.groupGeneralSetting.Controls.Add(this.txtRefreshToken);
			this.groupGeneralSetting.Controls.Add(this.label6);
			this.groupGeneralSetting.Controls.Add(this.label4);
			this.groupGeneralSetting.Controls.Add(this.radioByKey);
			this.groupGeneralSetting.Controls.Add(this.radioByToken);
			this.groupGeneralSetting.Controls.Add(this.txtAPIKey);
			this.groupGeneralSetting.Controls.Add(this.label9);
			this.groupGeneralSetting.Controls.Add(this.txtAutoStopTime);
			this.groupGeneralSetting.Controls.Add(this.label2);
			this.groupGeneralSetting.Controls.Add(this.txtSymbolCount);
			this.groupGeneralSetting.Controls.Add(this.label1);
			this.groupGeneralSetting.Controls.Add(this.btnBrowseInputDataPath);
			this.groupGeneralSetting.Controls.Add(this.btnBrowseInputSymbolFile);
			this.groupGeneralSetting.Controls.Add(this.txtInputDataPath);
			this.groupGeneralSetting.Controls.Add(this.label11);
			this.groupGeneralSetting.Controls.Add(this.txtInputSymbolFile);
			this.groupGeneralSetting.Controls.Add(this.label10);
			this.groupGeneralSetting.Location = new System.Drawing.Point(12, 12);
			this.groupGeneralSetting.Name = "groupGeneralSetting";
			this.groupGeneralSetting.Size = new System.Drawing.Size(511, 303);
			this.groupGeneralSetting.TabIndex = 2;
			this.groupGeneralSetting.TabStop = false;
			this.groupGeneralSetting.Text = "General";
			// 
			// chkRoundVol
			// 
			this.chkRoundVol.AutoSize = true;
			this.chkRoundVol.Location = new System.Drawing.Point(445, 271);
			this.chkRoundVol.Name = "chkRoundVol";
			this.chkRoundVol.Size = new System.Drawing.Size(41, 17);
			this.chkRoundVol.TabIndex = 69;
			this.chkRoundVol.Text = "Vol";
			this.chkRoundVol.UseVisualStyleBackColor = true;
			this.chkRoundVol.CheckedChanged += new System.EventHandler(this.chkRoundVol_CheckedChanged);
			// 
			// chkRoundClose
			// 
			this.chkRoundClose.AutoSize = true;
			this.chkRoundClose.Location = new System.Drawing.Point(373, 271);
			this.chkRoundClose.Name = "chkRoundClose";
			this.chkRoundClose.Size = new System.Drawing.Size(52, 17);
			this.chkRoundClose.TabIndex = 68;
			this.chkRoundClose.Text = "Close";
			this.chkRoundClose.UseVisualStyleBackColor = true;
			// 
			// chkRoundChange
			// 
			this.chkRoundChange.AutoSize = true;
			this.chkRoundChange.Location = new System.Drawing.Point(295, 272);
			this.chkRoundChange.Name = "chkRoundChange";
			this.chkRoundChange.Size = new System.Drawing.Size(63, 17);
			this.chkRoundChange.TabIndex = 67;
			this.chkRoundChange.Text = "Change";
			this.chkRoundChange.UseVisualStyleBackColor = true;
			// 
			// txtRounding
			// 
			this.txtRounding.Location = new System.Drawing.Point(210, 269);
			this.txtRounding.Name = "txtRounding";
			this.txtRounding.Size = new System.Drawing.Size(61, 20);
			this.txtRounding.TabIndex = 66;
			// 
			// label19
			// 
			this.label19.AutoSize = true;
			this.label19.Location = new System.Drawing.Point(119, 275);
			this.label19.Name = "label19";
			this.label19.Size = new System.Drawing.Size(75, 13);
			this.label19.TabIndex = 65;
			this.label19.Text = "Use Rounding";
			// 
			// chkUseCalendarFile
			// 
			this.chkUseCalendarFile.AutoSize = true;
			this.chkUseCalendarFile.Location = new System.Drawing.Point(362, 241);
			this.chkUseCalendarFile.Name = "chkUseCalendarFile";
			this.chkUseCalendarFile.Size = new System.Drawing.Size(109, 17);
			this.chkUseCalendarFile.TabIndex = 31;
			this.chkUseCalendarFile.Text = "Use Calendar File";
			this.chkUseCalendarFile.UseVisualStyleBackColor = true;
			// 
			// chkGenStockFile
			// 
			this.chkGenStockFile.AutoSize = true;
			this.chkGenStockFile.Location = new System.Drawing.Point(362, 203);
			this.chkGenStockFile.Name = "chkGenStockFile";
			this.chkGenStockFile.Size = new System.Drawing.Size(128, 17);
			this.chkGenStockFile.TabIndex = 30;
			this.chkGenStockFile.Text = "Gen-Stock-Quote-File";
			this.chkGenStockFile.UseVisualStyleBackColor = true;
			// 
			// txtRefreshToken
			// 
			this.txtRefreshToken.Location = new System.Drawing.Point(210, 87);
			this.txtRefreshToken.Name = "txtRefreshToken";
			this.txtRefreshToken.Size = new System.Drawing.Size(290, 20);
			this.txtRefreshToken.TabIndex = 16;
			this.txtRefreshToken.Text = resources.GetString("txtRefreshToken.Text");
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Location = new System.Drawing.Point(115, 90);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(78, 13);
			this.label6.TabIndex = 15;
			this.label6.Text = "Refresh Token";
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(146, 23);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(47, 13);
			this.label4.TabIndex = 14;
			this.label4.Text = "Call API ";
			// 
			// radioByKey
			// 
			this.radioByKey.AutoSize = true;
			this.radioByKey.Location = new System.Drawing.Point(383, 21);
			this.radioByKey.Name = "radioByKey";
			this.radioByKey.Size = new System.Drawing.Size(78, 17);
			this.radioByKey.TabIndex = 13;
			this.radioByKey.TabStop = true;
			this.radioByKey.Text = "By API Key";
			this.radioByKey.UseVisualStyleBackColor = true;
			this.radioByKey.CheckedChanged += new System.EventHandler(this.radioByKey_CheckedChanged);
			// 
			// radioByToken
			// 
			this.radioByToken.AutoSize = true;
			this.radioByToken.Checked = true;
			this.radioByToken.Location = new System.Drawing.Point(210, 21);
			this.radioByToken.Name = "radioByToken";
			this.radioByToken.Size = new System.Drawing.Size(109, 17);
			this.radioByToken.TabIndex = 12;
			this.radioByToken.TabStop = true;
			this.radioByToken.Text = "By Access Token";
			this.radioByToken.UseVisualStyleBackColor = true;
			this.radioByToken.CheckedChanged += new System.EventHandler(this.radioByToken_CheckedChanged);
			// 
			// txtAPIKey
			// 
			this.txtAPIKey.Location = new System.Drawing.Point(210, 54);
			this.txtAPIKey.Name = "txtAPIKey";
			this.txtAPIKey.Size = new System.Drawing.Size(290, 20);
			this.txtAPIKey.TabIndex = 11;
			this.txtAPIKey.Text = "KTBAEPPWUCX8KSO7ANNEKHF3A88IU2T5";
			// 
			// label9
			// 
			this.label9.AutoSize = true;
			this.label9.Location = new System.Drawing.Point(130, 57);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(63, 13);
			this.label9.TabIndex = 10;
			this.label9.Text = "TD API Key";
			// 
			// txtAutoStopTime
			// 
			this.txtAutoStopTime.Location = new System.Drawing.Point(210, 238);
			this.txtAutoStopTime.Name = "txtAutoStopTime";
			this.txtAutoStopTime.Size = new System.Drawing.Size(111, 20);
			this.txtAutoStopTime.TabIndex = 9;
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(6, 241);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(190, 13);
			this.label2.TabIndex = 8;
			this.label2.Text = "Auto Loop/Update Stop Time(HH:MM)";
			// 
			// txtSymbolCount
			// 
			this.txtSymbolCount.Location = new System.Drawing.Point(210, 200);
			this.txtSymbolCount.Name = "txtSymbolCount";
			this.txtSymbolCount.Size = new System.Drawing.Size(111, 20);
			this.txtSymbolCount.TabIndex = 7;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(66, 203);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(128, 13);
			this.label1.TabIndex = 6;
			this.label1.Text = "Max Symbols Per API Call";
			// 
			// btnBrowseInputDataPath
			// 
			this.btnBrowseInputDataPath.Location = new System.Drawing.Point(473, 121);
			this.btnBrowseInputDataPath.Name = "btnBrowseInputDataPath";
			this.btnBrowseInputDataPath.Size = new System.Drawing.Size(27, 22);
			this.btnBrowseInputDataPath.TabIndex = 2;
			this.btnBrowseInputDataPath.Text = "...";
			this.btnBrowseInputDataPath.UseVisualStyleBackColor = true;
			this.btnBrowseInputDataPath.Click += new System.EventHandler(this.btnBrowseInputDataPath_Click);
			// 
			// btnBrowseInputSymbolFile
			// 
			this.btnBrowseInputSymbolFile.Location = new System.Drawing.Point(473, 159);
			this.btnBrowseInputSymbolFile.Name = "btnBrowseInputSymbolFile";
			this.btnBrowseInputSymbolFile.Size = new System.Drawing.Size(27, 22);
			this.btnBrowseInputSymbolFile.TabIndex = 5;
			this.btnBrowseInputSymbolFile.Text = "...";
			this.btnBrowseInputSymbolFile.UseVisualStyleBackColor = true;
			this.btnBrowseInputSymbolFile.Click += new System.EventHandler(this.btnBrowseInputSymbolFile_Click);
			// 
			// txtInputDataPath
			// 
			this.txtInputDataPath.Location = new System.Drawing.Point(210, 122);
			this.txtInputDataPath.Name = "txtInputDataPath";
			this.txtInputDataPath.Size = new System.Drawing.Size(263, 20);
			this.txtInputDataPath.TabIndex = 1;
			// 
			// label11
			// 
			this.label11.AutoSize = true;
			this.label11.Location = new System.Drawing.Point(59, 125);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(135, 13);
			this.label11.TabIndex = 0;
			this.label11.Text = "Input Historical Data Folder";
			// 
			// txtInputSymbolFile
			// 
			this.txtInputSymbolFile.Location = new System.Drawing.Point(210, 160);
			this.txtInputSymbolFile.Name = "txtInputSymbolFile";
			this.txtInputSymbolFile.Size = new System.Drawing.Size(263, 20);
			this.txtInputSymbolFile.TabIndex = 4;
			// 
			// label10
			// 
			this.label10.AutoSize = true;
			this.label10.Location = new System.Drawing.Point(83, 164);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(111, 13);
			this.label10.TabIndex = 3;
			this.label10.Text = "TDOptions SymbolList";
			// 
			// groupProcessType
			// 
			this.groupProcessType.Controls.Add(this.label3);
			this.groupProcessType.Controls.Add(this.txtAutoUpdateInterval);
			this.groupProcessType.Controls.Add(this.radioAutoUpdate);
			this.groupProcessType.Controls.Add(this.radioAutoLoop);
			this.groupProcessType.Controls.Add(this.radioManualStatic);
			this.groupProcessType.Location = new System.Drawing.Point(12, 324);
			this.groupProcessType.Name = "groupProcessType";
			this.groupProcessType.Size = new System.Drawing.Size(511, 64);
			this.groupProcessType.TabIndex = 10;
			this.groupProcessType.TabStop = false;
			this.groupProcessType.Text = "Process Type";
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(442, 28);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(49, 13);
			this.label3.TabIndex = 11;
			this.label3.Text = "Seconds";
			// 
			// txtAutoUpdateInterval
			// 
			this.txtAutoUpdateInterval.Location = new System.Drawing.Point(354, 25);
			this.txtAutoUpdateInterval.Name = "txtAutoUpdateInterval";
			this.txtAutoUpdateInterval.Size = new System.Drawing.Size(82, 20);
			this.txtAutoUpdateInterval.TabIndex = 10;
			// 
			// radioAutoUpdate
			// 
			this.radioAutoUpdate.AutoSize = true;
			this.radioAutoUpdate.Location = new System.Drawing.Point(263, 26);
			this.radioAutoUpdate.Name = "radioAutoUpdate";
			this.radioAutoUpdate.Size = new System.Drawing.Size(85, 17);
			this.radioAutoUpdate.TabIndex = 2;
			this.radioAutoUpdate.TabStop = true;
			this.radioAutoUpdate.Text = "Auto Update";
			this.radioAutoUpdate.UseVisualStyleBackColor = true;
			this.radioAutoUpdate.CheckedChanged += new System.EventHandler(this.radioAutoUpdate_CheckedChanged);
			// 
			// radioAutoLoop
			// 
			this.radioAutoLoop.AutoSize = true;
			this.radioAutoLoop.Location = new System.Drawing.Point(152, 26);
			this.radioAutoLoop.Name = "radioAutoLoop";
			this.radioAutoLoop.Size = new System.Drawing.Size(74, 17);
			this.radioAutoLoop.TabIndex = 1;
			this.radioAutoLoop.TabStop = true;
			this.radioAutoLoop.Text = "Auto Loop";
			this.radioAutoLoop.UseVisualStyleBackColor = true;
			this.radioAutoLoop.CheckedChanged += new System.EventHandler(this.radioAutoLoop_CheckedChanged);
			// 
			// radioManualStatic
			// 
			this.radioManualStatic.AutoSize = true;
			this.radioManualStatic.Location = new System.Drawing.Point(30, 26);
			this.radioManualStatic.Name = "radioManualStatic";
			this.radioManualStatic.Size = new System.Drawing.Size(90, 17);
			this.radioManualStatic.TabIndex = 0;
			this.radioManualStatic.TabStop = true;
			this.radioManualStatic.Text = "Manual Static";
			this.radioManualStatic.UseVisualStyleBackColor = true;
			this.radioManualStatic.CheckedChanged += new System.EventHandler(this.radioManualStatic_CheckedChanged);
			// 
			// statusStrip1
			// 
			this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.statusLabel,
            this.statusProgressBar});
			this.statusStrip1.Location = new System.Drawing.Point(0, 498);
			this.statusStrip1.Name = "statusStrip1";
			this.statusStrip1.Size = new System.Drawing.Size(1058, 22);
			this.statusStrip1.SizingGrip = false;
			this.statusStrip1.TabIndex = 11;
			this.statusStrip1.Text = "statusStrip1";
			// 
			// statusLabel
			// 
			this.statusLabel.Name = "statusLabel";
			this.statusLabel.Size = new System.Drawing.Size(281, 17);
			this.statusLabel.Spring = true;
			// 
			// statusProgressBar
			// 
			this.statusProgressBar.Name = "statusProgressBar";
			this.statusProgressBar.Size = new System.Drawing.Size(760, 16);
			this.statusProgressBar.Step = 1;
			this.statusProgressBar.Style = System.Windows.Forms.ProgressBarStyle.Continuous;
			// 
			// groupOptionClean
			// 
			this.groupOptionClean.Controls.Add(this.chkDeleteIfNoHIstoryFile);
			this.groupOptionClean.Controls.Add(this.txtMinimumRows);
			this.groupOptionClean.Controls.Add(this.label5);
			this.groupOptionClean.Location = new System.Drawing.Point(12, 391);
			this.groupOptionClean.Name = "groupOptionClean";
			this.groupOptionClean.Size = new System.Drawing.Size(318, 93);
			this.groupOptionClean.TabIndex = 12;
			this.groupOptionClean.TabStop = false;
			this.groupOptionClean.Text = "TD Options Cleanup";
			// 
			// chkDeleteIfNoHIstoryFile
			// 
			this.chkDeleteIfNoHIstoryFile.AutoSize = true;
			this.chkDeleteIfNoHIstoryFile.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.chkDeleteIfNoHIstoryFile.Location = new System.Drawing.Point(15, 59);
			this.chkDeleteIfNoHIstoryFile.Name = "chkDeleteIfNoHIstoryFile";
			this.chkDeleteIfNoHIstoryFile.Size = new System.Drawing.Size(189, 17);
			this.chkDeleteIfNoHIstoryFile.TabIndex = 10;
			this.chkDeleteIfNoHIstoryFile.Text = "Delete Symbol if no historical file    ";
			this.chkDeleteIfNoHIstoryFile.UseVisualStyleBackColor = true;
			// 
			// txtMinimumRows
			// 
			this.txtMinimumRows.Location = new System.Drawing.Point(190, 24);
			this.txtMinimumRows.Name = "txtMinimumRows";
			this.txtMinimumRows.Size = new System.Drawing.Size(99, 20);
			this.txtMinimumRows.TabIndex = 9;
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(57, 27);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(118, 13);
			this.label5.TabIndex = 8;
			this.label5.Text = "Minimum Rows Of Data";
			// 
			// btnStart
			// 
			this.btnStart.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnStart.Location = new System.Drawing.Point(549, 443);
			this.btnStart.Name = "btnStart";
			this.btnStart.Size = new System.Drawing.Size(161, 44);
			this.btnStart.TabIndex = 13;
			this.btnStart.Text = "Start Auto Update";
			this.btnStart.UseVisualStyleBackColor = true;
			this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
			// 
			// btnStop
			// 
			this.btnStop.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnStop.Location = new System.Drawing.Point(717, 443);
			this.btnStop.Name = "btnStop";
			this.btnStop.Size = new System.Drawing.Size(161, 44);
			this.btnStop.TabIndex = 14;
			this.btnStop.Text = "Stop Auto Update";
			this.btnStop.UseVisualStyleBackColor = true;
			this.btnStop.Click += new System.EventHandler(this.btnStop_Click);
			// 
			// btnExit
			// 
			this.btnExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnExit.Location = new System.Drawing.Point(884, 443);
			this.btnExit.Name = "btnExit";
			this.btnExit.Size = new System.Drawing.Size(161, 44);
			this.btnExit.TabIndex = 15;
			this.btnExit.Text = "Exit";
			this.btnExit.UseVisualStyleBackColor = true;
			this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
			// 
			// btnAddTimeColumn
			// 
			this.btnAddTimeColumn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnAddTimeColumn.Location = new System.Drawing.Point(359, 398);
			this.btnAddTimeColumn.Name = "btnAddTimeColumn";
			this.btnAddTimeColumn.Size = new System.Drawing.Size(164, 37);
			this.btnAddTimeColumn.TabIndex = 11;
			this.btnAddTimeColumn.Text = "Add Time Column";
			this.btnAddTimeColumn.UseVisualStyleBackColor = true;
			this.btnAddTimeColumn.Click += new System.EventHandler(this.btnAddTimeColumn_Click);
			// 
			// btnCleanTDOptionList
			// 
			this.btnCleanTDOptionList.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnCleanTDOptionList.Location = new System.Drawing.Point(358, 449);
			this.btnCleanTDOptionList.Name = "btnCleanTDOptionList";
			this.btnCleanTDOptionList.Size = new System.Drawing.Size(164, 38);
			this.btnCleanTDOptionList.TabIndex = 12;
			this.btnCleanTDOptionList.Text = "Cleanup TDOptionsList";
			this.btnCleanTDOptionList.UseVisualStyleBackColor = true;
			this.btnCleanTDOptionList.Click += new System.EventHandler(this.btnCleanTDOptionList_Click);
			// 
			// groupMergeFile
			// 
			this.groupMergeFile.Controls.Add(this.btnBrowseMergePath);
			this.groupMergeFile.Controls.Add(this.btnBrowseTreeFile);
			this.groupMergeFile.Controls.Add(this.txtMergeOutputPath);
			this.groupMergeFile.Controls.Add(this.label7);
			this.groupMergeFile.Controls.Add(this.txtMergeTreeFile);
			this.groupMergeFile.Controls.Add(this.label8);
			this.groupMergeFile.Controls.Add(this.chkMergeFile);
			this.groupMergeFile.Location = new System.Drawing.Point(548, 12);
			this.groupMergeFile.Name = "groupMergeFile";
			this.groupMergeFile.Size = new System.Drawing.Size(496, 122);
			this.groupMergeFile.TabIndex = 16;
			this.groupMergeFile.TabStop = false;
			// 
			// btnBrowseMergePath
			// 
			this.btnBrowseMergePath.Location = new System.Drawing.Point(442, 31);
			this.btnBrowseMergePath.Name = "btnBrowseMergePath";
			this.btnBrowseMergePath.Size = new System.Drawing.Size(27, 22);
			this.btnBrowseMergePath.TabIndex = 20;
			this.btnBrowseMergePath.Text = "...";
			this.btnBrowseMergePath.UseVisualStyleBackColor = true;
			this.btnBrowseMergePath.Click += new System.EventHandler(this.btnBrowseMergePath_Click);
			// 
			// btnBrowseTreeFile
			// 
			this.btnBrowseTreeFile.Location = new System.Drawing.Point(442, 75);
			this.btnBrowseTreeFile.Name = "btnBrowseTreeFile";
			this.btnBrowseTreeFile.Size = new System.Drawing.Size(27, 22);
			this.btnBrowseTreeFile.TabIndex = 23;
			this.btnBrowseTreeFile.Text = "...";
			this.btnBrowseTreeFile.UseVisualStyleBackColor = true;
			this.btnBrowseTreeFile.Click += new System.EventHandler(this.btnBrowseTreeFile_Click);
			// 
			// txtMergeOutputPath
			// 
			this.txtMergeOutputPath.Location = new System.Drawing.Point(179, 32);
			this.txtMergeOutputPath.Name = "txtMergeOutputPath";
			this.txtMergeOutputPath.Size = new System.Drawing.Size(263, 20);
			this.txtMergeOutputPath.TabIndex = 19;
			// 
			// label7
			// 
			this.label7.AutoSize = true;
			this.label7.Location = new System.Drawing.Point(39, 35);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(110, 13);
			this.label7.TabIndex = 18;
			this.label7.Text = "Merged Output Folder";
			// 
			// txtMergeTreeFile
			// 
			this.txtMergeTreeFile.Location = new System.Drawing.Point(179, 76);
			this.txtMergeTreeFile.Name = "txtMergeTreeFile";
			this.txtMergeTreeFile.Size = new System.Drawing.Size(263, 20);
			this.txtMergeTreeFile.TabIndex = 22;
			// 
			// label8
			// 
			this.label8.AutoSize = true;
			this.label8.Location = new System.Drawing.Point(52, 80);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(97, 13);
			this.label8.TabIndex = 21;
			this.label8.Text = "Merge File TreeList";
			// 
			// chkMergeFile
			// 
			this.chkMergeFile.AutoSize = true;
			this.chkMergeFile.Location = new System.Drawing.Point(10, 0);
			this.chkMergeFile.Name = "chkMergeFile";
			this.chkMergeFile.Size = new System.Drawing.Size(133, 17);
			this.chkMergeFile.TabIndex = 17;
			this.chkMergeFile.Text = "Generate Merged Files";
			this.chkMergeFile.UseVisualStyleBackColor = true;
			this.chkMergeFile.CheckedChanged += new System.EventHandler(this.chkMergeFile_CheckedChanged);
			// 
			// groupAlign
			// 
			this.groupAlign.Controls.Add(this.alignEndTime);
			this.groupAlign.Controls.Add(this.alignStartTime);
			this.groupAlign.Controls.Add(this.trimTime);
			this.groupAlign.Controls.Add(this.trimDate);
			this.groupAlign.Controls.Add(this.btnStartAlign);
			this.groupAlign.Controls.Add(this.cmbAlignTimeFrame);
			this.groupAlign.Controls.Add(this.label14);
			this.groupAlign.Controls.Add(this.label13);
			this.groupAlign.Controls.Add(this.label12);
			this.groupAlign.Location = new System.Drawing.Point(548, 151);
			this.groupAlign.Name = "groupAlign";
			this.groupAlign.Size = new System.Drawing.Size(496, 229);
			this.groupAlign.TabIndex = 17;
			this.groupAlign.TabStop = false;
			this.groupAlign.Text = "Align Data";
			// 
			// alignEndTime
			// 
			this.alignEndTime.CustomFormat = "hh:mm tt";
			this.alignEndTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			this.alignEndTime.Location = new System.Drawing.Point(322, 74);
			this.alignEndTime.Name = "alignEndTime";
			this.alignEndTime.ShowUpDown = true;
			this.alignEndTime.Size = new System.Drawing.Size(120, 20);
			this.alignEndTime.TabIndex = 29;
			this.alignEndTime.Value = new System.DateTime(2020, 6, 2, 16, 0, 0, 0);
			// 
			// alignStartTime
			// 
			this.alignStartTime.CustomFormat = "hh:mm tt";
			this.alignStartTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			this.alignStartTime.Location = new System.Drawing.Point(179, 74);
			this.alignStartTime.Name = "alignStartTime";
			this.alignStartTime.ShowUpDown = true;
			this.alignStartTime.Size = new System.Drawing.Size(120, 20);
			this.alignStartTime.TabIndex = 28;
			this.alignStartTime.Value = new System.DateTime(2020, 6, 2, 16, 0, 0, 0);
			// 
			// trimTime
			// 
			this.trimTime.CustomFormat = "hh:mm tt";
			this.trimTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			this.trimTime.Location = new System.Drawing.Point(322, 31);
			this.trimTime.Name = "trimTime";
			this.trimTime.ShowUpDown = true;
			this.trimTime.Size = new System.Drawing.Size(120, 20);
			this.trimTime.TabIndex = 27;
			this.trimTime.Value = new System.DateTime(2020, 6, 2, 16, 0, 0, 0);
			// 
			// trimDate
			// 
			this.trimDate.CustomFormat = "MM/dd/yyyy";
			this.trimDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			this.trimDate.Location = new System.Drawing.Point(179, 31);
			this.trimDate.Name = "trimDate";
			this.trimDate.Size = new System.Drawing.Size(120, 20);
			this.trimDate.TabIndex = 20;
			// 
			// btnStartAlign
			// 
			this.btnStartAlign.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnStartAlign.Location = new System.Drawing.Point(177, 170);
			this.btnStartAlign.Name = "btnStartAlign";
			this.btnStartAlign.Size = new System.Drawing.Size(265, 37);
			this.btnStartAlign.TabIndex = 17;
			this.btnStartAlign.Text = "Align All Input Files";
			this.btnStartAlign.UseVisualStyleBackColor = true;
			this.btnStartAlign.Click += new System.EventHandler(this.btnStartAlign_Click);
			// 
			// cmbAlignTimeFrame
			// 
			this.cmbAlignTimeFrame.FormattingEnabled = true;
			this.cmbAlignTimeFrame.Items.AddRange(new object[] {
            "1Min",
            "5Min",
            "10Min",
            "15Min",
            "30Min",
            "60Min",
            "Daily"});
			this.cmbAlignTimeFrame.Location = new System.Drawing.Point(179, 118);
			this.cmbAlignTimeFrame.Name = "cmbAlignTimeFrame";
			this.cmbAlignTimeFrame.Size = new System.Drawing.Size(120, 21);
			this.cmbAlignTimeFrame.TabIndex = 16;
			// 
			// label14
			// 
			this.label14.AutoSize = true;
			this.label14.Location = new System.Drawing.Point(63, 78);
			this.label14.Name = "label14";
			this.label14.Size = new System.Drawing.Size(86, 13);
			this.label14.TabIndex = 12;
			this.label14.Text = "Start && End Time";
			// 
			// label13
			// 
			this.label13.AutoSize = true;
			this.label13.Location = new System.Drawing.Point(87, 123);
			this.label13.Name = "label13";
			this.label13.Size = new System.Drawing.Size(62, 13);
			this.label13.TabIndex = 10;
			this.label13.Text = "Time Frame";
			// 
			// label12
			// 
			this.label12.AutoSize = true;
			this.label12.Location = new System.Drawing.Point(36, 34);
			this.label12.Name = "label12";
			this.label12.Size = new System.Drawing.Size(113, 13);
			this.label12.TabIndex = 8;
			this.label12.Text = "Start Trim Date && Time";
			// 
			// timerAutoUpdate
			// 
			this.timerAutoUpdate.Interval = 1000;
			// 
			// btnROutputSetting
			// 
			this.btnROutputSetting.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnROutputSetting.Location = new System.Drawing.Point(717, 391);
			this.btnROutputSetting.Name = "btnROutputSetting";
			this.btnROutputSetting.Size = new System.Drawing.Size(161, 44);
			this.btnROutputSetting.TabIndex = 18;
			this.btnROutputSetting.Text = "R File Output Setting";
			this.btnROutputSetting.UseVisualStyleBackColor = true;
			this.btnROutputSetting.Click += new System.EventHandler(this.btnROutputSetting_Click);
			// 
			// chkROutput
			// 
			this.chkROutput.AutoSize = true;
			this.chkROutput.Location = new System.Drawing.Point(550, 406);
			this.chkROutput.Name = "chkROutput";
			this.chkROutput.Size = new System.Drawing.Size(88, 17);
			this.chkROutput.TabIndex = 32;
			this.chkROutput.Text = "Output R File";
			this.chkROutput.UseVisualStyleBackColor = true;
			this.chkROutput.CheckedChanged += new System.EventHandler(this.chkROutput_CheckedChanged);
			// 
			// btnGetToken
			// 
			this.btnGetToken.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnGetToken.Location = new System.Drawing.Point(884, 391);
			this.btnGetToken.Name = "btnGetToken";
			this.btnGetToken.Size = new System.Drawing.Size(161, 44);
			this.btnGetToken.TabIndex = 33;
			this.btnGetToken.Text = "Get Refresh Token";
			this.btnGetToken.UseVisualStyleBackColor = true;
			this.btnGetToken.Click += new System.EventHandler(this.btnGetToken_Click);
			// 
			// FrmMain
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(1058, 520);
			this.Controls.Add(this.btnGetToken);
			this.Controls.Add(this.chkROutput);
			this.Controls.Add(this.btnROutputSetting);
			this.Controls.Add(this.groupAlign);
			this.Controls.Add(this.groupMergeFile);
			this.Controls.Add(this.btnAddTimeColumn);
			this.Controls.Add(this.btnCleanTDOptionList);
			this.Controls.Add(this.btnExit);
			this.Controls.Add(this.btnStop);
			this.Controls.Add(this.btnStart);
			this.Controls.Add(this.groupOptionClean);
			this.Controls.Add(this.statusStrip1);
			this.Controls.Add(this.groupProcessType);
			this.Controls.Add(this.groupGeneralSetting);
			this.Name = "FrmMain";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Sri TD Options DataFeed V4";
			this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FrmMain_FormClosing);
			this.Load += new System.EventHandler(this.groupAlignData_Load);
			this.groupGeneralSetting.ResumeLayout(false);
			this.groupGeneralSetting.PerformLayout();
			this.groupProcessType.ResumeLayout(false);
			this.groupProcessType.PerformLayout();
			this.statusStrip1.ResumeLayout(false);
			this.statusStrip1.PerformLayout();
			this.groupOptionClean.ResumeLayout(false);
			this.groupOptionClean.PerformLayout();
			this.groupMergeFile.ResumeLayout(false);
			this.groupMergeFile.PerformLayout();
			this.groupAlign.ResumeLayout(false);
			this.groupAlign.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.GroupBox groupGeneralSetting;
		private System.Windows.Forms.Button btnBrowseInputDataPath;
		private System.Windows.Forms.Button btnBrowseInputSymbolFile;
		private System.Windows.Forms.TextBox txtInputDataPath;
		private System.Windows.Forms.Label label11;
		private System.Windows.Forms.TextBox txtInputSymbolFile;
		private System.Windows.Forms.Label label10;
		private System.Windows.Forms.TextBox txtSymbolCount;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox txtAutoStopTime;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.GroupBox groupProcessType;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.TextBox txtAutoUpdateInterval;
		private System.Windows.Forms.RadioButton radioAutoUpdate;
		private System.Windows.Forms.RadioButton radioAutoLoop;
		private System.Windows.Forms.RadioButton radioManualStatic;
		private System.Windows.Forms.StatusStrip statusStrip1;
		private System.Windows.Forms.ToolStripStatusLabel statusLabel;
		private System.Windows.Forms.ToolStripProgressBar statusProgressBar;
		private System.Windows.Forms.GroupBox groupOptionClean;
		private System.Windows.Forms.TextBox txtMinimumRows;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.CheckBox chkDeleteIfNoHIstoryFile;
		private System.Windows.Forms.Button btnStart;
		private System.Windows.Forms.Button btnStop;
		private System.Windows.Forms.Button btnExit;
		private System.Windows.Forms.Button btnAddTimeColumn;
		private System.Windows.Forms.Button btnCleanTDOptionList;
		private System.Windows.Forms.TextBox txtAPIKey;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.RadioButton radioByKey;
		private System.Windows.Forms.RadioButton radioByToken;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.TextBox txtRefreshToken;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.GroupBox groupMergeFile;
		private System.Windows.Forms.Button btnBrowseMergePath;
		private System.Windows.Forms.Button btnBrowseTreeFile;
		private System.Windows.Forms.TextBox txtMergeOutputPath;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.TextBox txtMergeTreeFile;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.CheckBox chkMergeFile;
		private System.Windows.Forms.GroupBox groupAlign;
		private System.Windows.Forms.Label label12;
		private System.Windows.Forms.Label label13;
		private System.Windows.Forms.Label label14;
		private System.Windows.Forms.ComboBox cmbAlignTimeFrame;
		private System.Windows.Forms.Button btnStartAlign;
		private System.Windows.Forms.DateTimePicker trimDate;
		private System.Windows.Forms.DateTimePicker trimTime;
		private System.Windows.Forms.DateTimePicker alignEndTime;
		private System.Windows.Forms.DateTimePicker alignStartTime;
		private System.Windows.Forms.CheckBox chkGenStockFile;
		private System.Windows.Forms.CheckBox chkUseCalendarFile;
		private System.Windows.Forms.Timer timerAutoUpdate;
		private System.Windows.Forms.Button btnROutputSetting;
		private System.Windows.Forms.CheckBox chkROutput;
		private System.Windows.Forms.Button btnGetToken;
		private System.Windows.Forms.CheckBox chkRoundVol;
		private System.Windows.Forms.CheckBox chkRoundClose;
		private System.Windows.Forms.CheckBox chkRoundChange;
		private System.Windows.Forms.TextBox txtRounding;
		private System.Windows.Forms.Label label19;
	}
}

