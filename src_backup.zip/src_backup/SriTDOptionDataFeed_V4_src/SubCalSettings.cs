﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SriTDDataFeedSetting
{
	public class SubCalSettings
	{
		public bool EnableSubCal { get; set; }
		public bool ApplyPrimaryR { get; set; } = true;
		public bool ApplyMultipleR { get; set; }
		public bool ApplyAlignR { get; set; }
		public int SubCalLevels { get; set; }
		public bool EnableBSSignals { get; set; }
		public int BSSignalMode { get; set; }
		public int BSLevels { get; set; }
		public double Lavg1SignalMin { get; set; }
		public bool EnableCalAvg { get; set; }
		public int LAvg1Start { get; set; }
		public int LAvg2Start { get; set; }
		public int LAvg3Start { get; set; }
		public int LAvg4Start { get; set; }
		public int LAvg1End { get; set; }
		public int LAvg2End { get; set; }
		public int LAvg3End { get; set; }
		public int LAvg4End { get; set; }
	}
}
