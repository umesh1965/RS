﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SriTDDataFeedSetting
{
	public class QuoteData
	{
		public string Symbol { get; set; }
		public double Price { get; set; }
		public static List<QuoteData> LaodFromCSV(string csvFile)
		{
			double tempValDouble = 0;
			List<QuoteData> modelList = new List<QuoteData>();

			try
			{
				string[] lines = System.IO.File.ReadAllLines(csvFile);
				for (int i = 1; i < lines.Length; i++)
				{
					string[] cols = lines[i].Split(',');
					if (cols.Length < 2)
						continue;

					QuoteData model = new QuoteData();
					model.Symbol = cols[0];
					model.Price = double.TryParse(cols[1], out tempValDouble) ? tempValDouble : 0;
					modelList.Add(model);
				}
			}
			catch
			{

			}

			return modelList;
		}

		public override string ToString()
		{
			return Symbol + "," + Price.ToString("0.##");
		}
	}
}
