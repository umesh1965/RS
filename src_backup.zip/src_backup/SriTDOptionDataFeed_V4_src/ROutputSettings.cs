﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SriTDDataFeedSetting
{
	public class ROutputSettings
	{
		public string ROutputFolder { get; set; }
		public int Level { get; set; }
		public double BarPercent { get; set; }
		public bool EnableMultipleROutput { get; set; }
		public int NumberofFolderes { get; set; }
		public bool EnableZeroMQ { get; set; }
		public string IPAddressZMQ { get; set; }
		public int PortZMQ { get; set; }
		public bool StoreBarPercentAsChange { get; set; }
		public bool DontOutputFiles { get; set; }
		public bool EnableGenAlignFiles { get; set; }
		public int NumberOfAlignFolders { get; set; }
		public string AlignOutputFolder { get; set; }
		public bool EnableBinaryCleanup { get; set; }
		public double CleanupFrom { get; set; }
		public double CleanupTo { get; set; }
		public bool EnableOutputOnlyRow { get; set; }
		public int OutputOnlyRowNumbers { get; set; }
		public bool UseVolCal { get; set; }
		public bool UseVolCalAfterCleanup { get; set; } = true;
		public bool SendCycleCompleteMsg { get; set; }
		public bool UseCustomPriceBarPoint { get; set; }
		public bool UseCustomPricePercent { get; set; }
		public string CustomPriceBarFile { get; set; }
		public string CustomPricePercentFile { get; set; }
		//Last Signal Output
		public bool EnableLatestSignalOutput { get; set; }
		public bool LatestSignalApplyPrimary { get; set; } = true;
		public bool GenLatestSignalFile { get; set; }
		public bool GenLatestSignalMasterFile { get; set; }
		public bool UseLatestNewSignal { get; set; }
		public string LatestSignalOutputFolder { get; set; }
		public bool EnableMinRowsCleanUp { get; set; }
		public int MinRowsCleanUpCount { get; set; }
		public bool GenOptionGridReport { get; set; }
		public bool GenOptionSignalReport { get; set; }
		public string ReportOutputFolder { get; set; }
		public SubCalSettings SubCalConfig { get; set; } = new SubCalSettings();
	}
}
