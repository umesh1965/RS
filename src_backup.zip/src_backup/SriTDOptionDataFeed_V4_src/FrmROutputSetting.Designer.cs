﻿
namespace Sri_TD_Options_DataFeed
{
	partial class FrmROutputSetting
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.txtLavg4End = new System.Windows.Forms.TextBox();
			this.chkEnableBSSignal = new System.Windows.Forms.CheckBox();
			this.chkCalAvg = new System.Windows.Forms.CheckBox();
			this.txtSubCalLevels = new System.Windows.Forms.TextBox();
			this.label23 = new System.Windows.Forms.Label();
			this.chkApplyPrimaryR = new System.Windows.Forms.CheckBox();
			this.label22 = new System.Windows.Forms.Label();
			this.radLavgSignal = new System.Windows.Forms.RadioButton();
			this.txtLavgSignal = new System.Windows.Forms.TextBox();
			this.radioBSLevel = new System.Windows.Forms.RadioButton();
			this.txtBSLevels = new System.Windows.Forms.TextBox();
			this.panelBSLevels = new System.Windows.Forms.Panel();
			this.chkCustomPercentBar = new System.Windows.Forms.CheckBox();
			this.txtOutputOnlyR = new System.Windows.Forms.TextBox();
			this.chkOutputOnlyR = new System.Windows.Forms.CheckBox();
			this.panelCalAvg = new System.Windows.Forms.Panel();
			this.txtLavg4Start = new System.Windows.Forms.TextBox();
			this.label30 = new System.Windows.Forms.Label();
			this.txtLavg3End = new System.Windows.Forms.TextBox();
			this.txtLavg3Start = new System.Windows.Forms.TextBox();
			this.label29 = new System.Windows.Forms.Label();
			this.txtLavg2End = new System.Windows.Forms.TextBox();
			this.txtLavg2Start = new System.Windows.Forms.TextBox();
			this.label28 = new System.Windows.Forms.Label();
			this.label27 = new System.Windows.Forms.Label();
			this.txtLavg1End = new System.Windows.Forms.TextBox();
			this.label26 = new System.Windows.Forms.Label();
			this.txtLavg1Start = new System.Windows.Forms.TextBox();
			this.label25 = new System.Windows.Forms.Label();
			this.groupSubCal = new System.Windows.Forms.GroupBox();
			this.chkLatestSignalOutput = new System.Windows.Forms.CheckBox();
			this.btnBrowseCustomBarPercent = new System.Windows.Forms.Button();
			this.txtCustomBarPercentPath = new System.Windows.Forms.TextBox();
			this.chkLatestMasterNew = new System.Windows.Forms.CheckBox();
			this.groupLatestSignal = new System.Windows.Forms.GroupBox();
			this.chkGenLatestMasterFile = new System.Windows.Forms.CheckBox();
			this.chkGenLatestFile = new System.Windows.Forms.CheckBox();
			this.btnBrowselatestOutput = new System.Windows.Forms.Button();
			this.txtLastOutputFolder = new System.Windows.Forms.TextBox();
			this.label31 = new System.Windows.Forms.Label();
			this.chkLatestOutPrimary = new System.Windows.Forms.CheckBox();
			this.label24 = new System.Windows.Forms.Label();
			this.txtLevel = new System.Windows.Forms.TextBox();
			this.txtBar = new System.Windows.Forms.TextBox();
			this.label6 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.chkDontOutputFiles = new System.Windows.Forms.CheckBox();
			this.chkStoreBarChange = new System.Windows.Forms.CheckBox();
			this.chkSendZMQ = new System.Windows.Forms.CheckBox();
			this.chkSendCycleCompleteMsg = new System.Windows.Forms.CheckBox();
			this.txtPort = new System.Windows.Forms.TextBox();
			this.label15 = new System.Windows.Forms.Label();
			this.txtIP = new System.Windows.Forms.TextBox();
			this.label14 = new System.Windows.Forms.Label();
			this.btnBrowseROutputFolder = new System.Windows.Forms.Button();
			this.txtROutputFolder = new System.Windows.Forms.TextBox();
			this.label18 = new System.Windows.Forms.Label();
			this.btnCancel = new System.Windows.Forms.Button();
			this.btnOK = new System.Windows.Forms.Button();
			this.groupBoxZMQ = new System.Windows.Forms.GroupBox();
			this.chkSubCal = new System.Windows.Forms.CheckBox();
			this.txtMinRowsCleanUp = new System.Windows.Forms.TextBox();
			this.chkMinRowsCleanUp = new System.Windows.Forms.CheckBox();
			this.chkOptionGridReport = new System.Windows.Forms.CheckBox();
			this.chkSignalReport = new System.Windows.Forms.CheckBox();
			this.label2 = new System.Windows.Forms.Label();
			this.btnReportOutputFolder = new System.Windows.Forms.Button();
			this.txtReportOutputFolder = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.panelBSLevels.SuspendLayout();
			this.panelCalAvg.SuspendLayout();
			this.groupSubCal.SuspendLayout();
			this.groupLatestSignal.SuspendLayout();
			this.groupBoxZMQ.SuspendLayout();
			this.SuspendLayout();
			// 
			// txtLavg4End
			// 
			this.txtLavg4End.Location = new System.Drawing.Point(178, 124);
			this.txtLavg4End.Name = "txtLavg4End";
			this.txtLavg4End.Size = new System.Drawing.Size(80, 20);
			this.txtLavg4End.TabIndex = 80;
			// 
			// chkEnableBSSignal
			// 
			this.chkEnableBSSignal.AutoSize = true;
			this.chkEnableBSSignal.Location = new System.Drawing.Point(24, 118);
			this.chkEnableBSSignal.Name = "chkEnableBSSignal";
			this.chkEnableBSSignal.Size = new System.Drawing.Size(83, 17);
			this.chkEnableBSSignal.TabIndex = 68;
			this.chkEnableBSSignal.Text = "B&&S Signals";
			this.chkEnableBSSignal.UseVisualStyleBackColor = true;
			this.chkEnableBSSignal.CheckedChanged += new System.EventHandler(this.chkEnableBSSignal_CheckedChanged);
			// 
			// chkCalAvg
			// 
			this.chkCalAvg.AutoSize = true;
			this.chkCalAvg.Location = new System.Drawing.Point(24, 227);
			this.chkCalAvg.Name = "chkCalAvg";
			this.chkCalAvg.Size = new System.Drawing.Size(63, 17);
			this.chkCalAvg.TabIndex = 52;
			this.chkCalAvg.Text = "Cal-Avg";
			this.chkCalAvg.UseVisualStyleBackColor = true;
			this.chkCalAvg.CheckedChanged += new System.EventHandler(this.chkCalAvg_CheckedChanged);
			// 
			// txtSubCalLevels
			// 
			this.txtSubCalLevels.Location = new System.Drawing.Point(140, 78);
			this.txtSubCalLevels.Name = "txtSubCalLevels";
			this.txtSubCalLevels.Size = new System.Drawing.Size(106, 20);
			this.txtSubCalLevels.TabIndex = 49;
			// 
			// label23
			// 
			this.label23.AutoSize = true;
			this.label23.Location = new System.Drawing.Point(21, 82);
			this.label23.Name = "label23";
			this.label23.Size = new System.Drawing.Size(78, 13);
			this.label23.TabIndex = 48;
			this.label23.Text = "Sub-Cal Levels";
			// 
			// chkApplyPrimaryR
			// 
			this.chkApplyPrimaryR.AutoSize = true;
			this.chkApplyPrimaryR.Location = new System.Drawing.Point(36, 50);
			this.chkApplyPrimaryR.Name = "chkApplyPrimaryR";
			this.chkApplyPrimaryR.Size = new System.Drawing.Size(71, 17);
			this.chkApplyPrimaryR.TabIndex = 45;
			this.chkApplyPrimaryR.Text = "Primary R";
			this.chkApplyPrimaryR.UseVisualStyleBackColor = true;
			// 
			// label22
			// 
			this.label22.AutoSize = true;
			this.label22.Location = new System.Drawing.Point(21, 26);
			this.label22.Name = "label22";
			this.label22.Size = new System.Drawing.Size(97, 13);
			this.label22.TabIndex = 44;
			this.label22.Text = "Sub-Cal Applies To";
			// 
			// radLavgSignal
			// 
			this.radLavgSignal.AutoSize = true;
			this.radLavgSignal.Location = new System.Drawing.Point(19, 43);
			this.radLavgSignal.Name = "radLavgSignal";
			this.radLavgSignal.Size = new System.Drawing.Size(87, 17);
			this.radLavgSignal.TabIndex = 75;
			this.radLavgSignal.TabStop = true;
			this.radLavgSignal.Text = "Lavg1 Signal";
			this.radLavgSignal.UseVisualStyleBackColor = true;
			// 
			// txtLavgSignal
			// 
			this.txtLavgSignal.Location = new System.Drawing.Point(118, 42);
			this.txtLavgSignal.Name = "txtLavgSignal";
			this.txtLavgSignal.Size = new System.Drawing.Size(106, 20);
			this.txtLavgSignal.TabIndex = 74;
			// 
			// radioBSLevel
			// 
			this.radioBSLevel.AutoSize = true;
			this.radioBSLevel.Location = new System.Drawing.Point(19, 12);
			this.radioBSLevel.Name = "radioBSLevel";
			this.radioBSLevel.Size = new System.Drawing.Size(89, 17);
			this.radioBSLevel.TabIndex = 73;
			this.radioBSLevel.TabStop = true;
			this.radioBSLevel.Text = "B&&S V Levels";
			this.radioBSLevel.UseVisualStyleBackColor = true;
			// 
			// txtBSLevels
			// 
			this.txtBSLevels.Location = new System.Drawing.Point(118, 11);
			this.txtBSLevels.Name = "txtBSLevels";
			this.txtBSLevels.Size = new System.Drawing.Size(106, 20);
			this.txtBSLevels.TabIndex = 72;
			// 
			// panelBSLevels
			// 
			this.panelBSLevels.Controls.Add(this.radLavgSignal);
			this.panelBSLevels.Controls.Add(this.txtLavgSignal);
			this.panelBSLevels.Controls.Add(this.radioBSLevel);
			this.panelBSLevels.Controls.Add(this.txtBSLevels);
			this.panelBSLevels.Location = new System.Drawing.Point(44, 136);
			this.panelBSLevels.Name = "panelBSLevels";
			this.panelBSLevels.Size = new System.Drawing.Size(243, 76);
			this.panelBSLevels.TabIndex = 72;
			// 
			// chkCustomPercentBar
			// 
			this.chkCustomPercentBar.AutoSize = true;
			this.chkCustomPercentBar.Location = new System.Drawing.Point(23, 169);
			this.chkCustomPercentBar.Name = "chkCustomPercentBar";
			this.chkCustomPercentBar.Size = new System.Drawing.Size(115, 17);
			this.chkCustomPercentBar.TabIndex = 84;
			this.chkCustomPercentBar.Text = "Use Custom Bars%";
			this.chkCustomPercentBar.UseVisualStyleBackColor = true;
			this.chkCustomPercentBar.CheckedChanged += new System.EventHandler(this.chkCustomPercentBar_CheckedChanged);
			// 
			// txtOutputOnlyR
			// 
			this.txtOutputOnlyR.Location = new System.Drawing.Point(717, 15);
			this.txtOutputOnlyR.Name = "txtOutputOnlyR";
			this.txtOutputOnlyR.Size = new System.Drawing.Size(80, 20);
			this.txtOutputOnlyR.TabIndex = 77;
			// 
			// chkOutputOnlyR
			// 
			this.chkOutputOnlyR.AutoSize = true;
			this.chkOutputOnlyR.Location = new System.Drawing.Point(521, 19);
			this.chkOutputOnlyR.Name = "chkOutputOnlyR";
			this.chkOutputOnlyR.Size = new System.Drawing.Size(130, 17);
			this.chkOutputOnlyR.TabIndex = 76;
			this.chkOutputOnlyR.Text = "Output Only R #Rows";
			this.chkOutputOnlyR.UseVisualStyleBackColor = true;
			this.chkOutputOnlyR.CheckedChanged += new System.EventHandler(this.chkOutputOnlyR_CheckedChanged);
			// 
			// panelCalAvg
			// 
			this.panelCalAvg.Controls.Add(this.txtLavg4End);
			this.panelCalAvg.Controls.Add(this.txtLavg4Start);
			this.panelCalAvg.Controls.Add(this.label30);
			this.panelCalAvg.Controls.Add(this.txtLavg3End);
			this.panelCalAvg.Controls.Add(this.txtLavg3Start);
			this.panelCalAvg.Controls.Add(this.label29);
			this.panelCalAvg.Controls.Add(this.txtLavg2End);
			this.panelCalAvg.Controls.Add(this.txtLavg2Start);
			this.panelCalAvg.Controls.Add(this.label28);
			this.panelCalAvg.Controls.Add(this.label27);
			this.panelCalAvg.Controls.Add(this.txtLavg1End);
			this.panelCalAvg.Controls.Add(this.label26);
			this.panelCalAvg.Controls.Add(this.txtLavg1Start);
			this.panelCalAvg.Controls.Add(this.label25);
			this.panelCalAvg.Location = new System.Drawing.Point(29, 240);
			this.panelCalAvg.Name = "panelCalAvg";
			this.panelCalAvg.Size = new System.Drawing.Size(283, 153);
			this.panelCalAvg.TabIndex = 67;
			// 
			// txtLavg4Start
			// 
			this.txtLavg4Start.Location = new System.Drawing.Point(82, 124);
			this.txtLavg4Start.Name = "txtLavg4Start";
			this.txtLavg4Start.Size = new System.Drawing.Size(80, 20);
			this.txtLavg4Start.TabIndex = 79;
			// 
			// label30
			// 
			this.label30.AutoSize = true;
			this.label30.Location = new System.Drawing.Point(24, 127);
			this.label30.Name = "label30";
			this.label30.Size = new System.Drawing.Size(37, 13);
			this.label30.TabIndex = 78;
			this.label30.Text = "Lavg4";
			// 
			// txtLavg3End
			// 
			this.txtLavg3End.Location = new System.Drawing.Point(178, 94);
			this.txtLavg3End.Name = "txtLavg3End";
			this.txtLavg3End.Size = new System.Drawing.Size(80, 20);
			this.txtLavg3End.TabIndex = 77;
			// 
			// txtLavg3Start
			// 
			this.txtLavg3Start.Location = new System.Drawing.Point(82, 94);
			this.txtLavg3Start.Name = "txtLavg3Start";
			this.txtLavg3Start.Size = new System.Drawing.Size(80, 20);
			this.txtLavg3Start.TabIndex = 76;
			// 
			// label29
			// 
			this.label29.AutoSize = true;
			this.label29.Location = new System.Drawing.Point(24, 97);
			this.label29.Name = "label29";
			this.label29.Size = new System.Drawing.Size(37, 13);
			this.label29.TabIndex = 75;
			this.label29.Text = "Lavg3";
			// 
			// txtLavg2End
			// 
			this.txtLavg2End.Location = new System.Drawing.Point(178, 61);
			this.txtLavg2End.Name = "txtLavg2End";
			this.txtLavg2End.Size = new System.Drawing.Size(80, 20);
			this.txtLavg2End.TabIndex = 74;
			// 
			// txtLavg2Start
			// 
			this.txtLavg2Start.Location = new System.Drawing.Point(82, 61);
			this.txtLavg2Start.Name = "txtLavg2Start";
			this.txtLavg2Start.Size = new System.Drawing.Size(80, 20);
			this.txtLavg2Start.TabIndex = 73;
			// 
			// label28
			// 
			this.label28.AutoSize = true;
			this.label28.Location = new System.Drawing.Point(24, 64);
			this.label28.Name = "label28";
			this.label28.Size = new System.Drawing.Size(37, 13);
			this.label28.TabIndex = 72;
			this.label28.Text = "Lavg2";
			// 
			// label27
			// 
			this.label27.AutoSize = true;
			this.label27.Location = new System.Drawing.Point(204, 8);
			this.label27.Name = "label27";
			this.label27.Size = new System.Drawing.Size(26, 13);
			this.label27.TabIndex = 71;
			this.label27.Text = "End";
			// 
			// txtLavg1End
			// 
			this.txtLavg1End.Location = new System.Drawing.Point(178, 29);
			this.txtLavg1End.Name = "txtLavg1End";
			this.txtLavg1End.Size = new System.Drawing.Size(80, 20);
			this.txtLavg1End.TabIndex = 70;
			// 
			// label26
			// 
			this.label26.AutoSize = true;
			this.label26.Location = new System.Drawing.Point(108, 8);
			this.label26.Name = "label26";
			this.label26.Size = new System.Drawing.Size(29, 13);
			this.label26.TabIndex = 69;
			this.label26.Text = "Start";
			// 
			// txtLavg1Start
			// 
			this.txtLavg1Start.Location = new System.Drawing.Point(82, 29);
			this.txtLavg1Start.Name = "txtLavg1Start";
			this.txtLavg1Start.Size = new System.Drawing.Size(80, 20);
			this.txtLavg1Start.TabIndex = 68;
			// 
			// label25
			// 
			this.label25.AutoSize = true;
			this.label25.Location = new System.Drawing.Point(24, 32);
			this.label25.Name = "label25";
			this.label25.Size = new System.Drawing.Size(37, 13);
			this.label25.TabIndex = 67;
			this.label25.Text = "Lavg1";
			// 
			// groupSubCal
			// 
			this.groupSubCal.Controls.Add(this.panelBSLevels);
			this.groupSubCal.Controls.Add(this.chkEnableBSSignal);
			this.groupSubCal.Controls.Add(this.chkCalAvg);
			this.groupSubCal.Controls.Add(this.txtSubCalLevels);
			this.groupSubCal.Controls.Add(this.label23);
			this.groupSubCal.Controls.Add(this.chkApplyPrimaryR);
			this.groupSubCal.Controls.Add(this.label22);
			this.groupSubCal.Controls.Add(this.panelCalAvg);
			this.groupSubCal.Location = new System.Drawing.Point(510, 87);
			this.groupSubCal.Name = "groupSubCal";
			this.groupSubCal.Size = new System.Drawing.Size(318, 401);
			this.groupSubCal.TabIndex = 78;
			this.groupSubCal.TabStop = false;
			// 
			// chkLatestSignalOutput
			// 
			this.chkLatestSignalOutput.AutoSize = true;
			this.chkLatestSignalOutput.Location = new System.Drawing.Point(23, 200);
			this.chkLatestSignalOutput.Name = "chkLatestSignalOutput";
			this.chkLatestSignalOutput.Size = new System.Drawing.Size(127, 17);
			this.chkLatestSignalOutput.TabIndex = 87;
			this.chkLatestSignalOutput.Text = "Latest Signals Output";
			this.chkLatestSignalOutput.UseVisualStyleBackColor = true;
			this.chkLatestSignalOutput.CheckedChanged += new System.EventHandler(this.chkLatestSignalOutput_CheckedChanged);
			// 
			// btnBrowseCustomBarPercent
			// 
			this.btnBrowseCustomBarPercent.Location = new System.Drawing.Point(457, 165);
			this.btnBrowseCustomBarPercent.Name = "btnBrowseCustomBarPercent";
			this.btnBrowseCustomBarPercent.Size = new System.Drawing.Size(34, 22);
			this.btnBrowseCustomBarPercent.TabIndex = 86;
			this.btnBrowseCustomBarPercent.Text = "...";
			this.btnBrowseCustomBarPercent.UseVisualStyleBackColor = true;
			this.btnBrowseCustomBarPercent.Click += new System.EventHandler(this.btnBrowseCustomBarPercent_Click);
			// 
			// txtCustomBarPercentPath
			// 
			this.txtCustomBarPercentPath.Location = new System.Drawing.Point(142, 166);
			this.txtCustomBarPercentPath.Name = "txtCustomBarPercentPath";
			this.txtCustomBarPercentPath.Size = new System.Drawing.Size(315, 20);
			this.txtCustomBarPercentPath.TabIndex = 85;
			// 
			// chkLatestMasterNew
			// 
			this.chkLatestMasterNew.AutoSize = true;
			this.chkLatestMasterNew.Location = new System.Drawing.Point(247, 120);
			this.chkLatestMasterNew.Name = "chkLatestMasterNew";
			this.chkLatestMasterNew.Size = new System.Drawing.Size(48, 17);
			this.chkLatestMasterNew.TabIndex = 57;
			this.chkLatestMasterNew.Text = "New";
			this.chkLatestMasterNew.UseVisualStyleBackColor = true;
			// 
			// groupLatestSignal
			// 
			this.groupLatestSignal.Controls.Add(this.chkLatestMasterNew);
			this.groupLatestSignal.Controls.Add(this.chkGenLatestMasterFile);
			this.groupLatestSignal.Controls.Add(this.chkGenLatestFile);
			this.groupLatestSignal.Controls.Add(this.btnBrowselatestOutput);
			this.groupLatestSignal.Controls.Add(this.txtLastOutputFolder);
			this.groupLatestSignal.Controls.Add(this.label31);
			this.groupLatestSignal.Controls.Add(this.chkLatestOutPrimary);
			this.groupLatestSignal.Controls.Add(this.label24);
			this.groupLatestSignal.Location = new System.Drawing.Point(16, 205);
			this.groupLatestSignal.Name = "groupLatestSignal";
			this.groupLatestSignal.Size = new System.Drawing.Size(479, 151);
			this.groupLatestSignal.TabIndex = 80;
			this.groupLatestSignal.TabStop = false;
			// 
			// chkGenLatestMasterFile
			// 
			this.chkGenLatestMasterFile.AutoSize = true;
			this.chkGenLatestMasterFile.Location = new System.Drawing.Point(41, 120);
			this.chkGenLatestMasterFile.Name = "chkGenLatestMasterFile";
			this.chkGenLatestMasterFile.Size = new System.Drawing.Size(164, 17);
			this.chkGenLatestMasterFile.TabIndex = 56;
			this.chkGenLatestMasterFile.Text = "Gen Latest Signal Master File";
			this.chkGenLatestMasterFile.UseVisualStyleBackColor = true;
			// 
			// chkGenLatestFile
			// 
			this.chkGenLatestFile.AutoSize = true;
			this.chkGenLatestFile.Location = new System.Drawing.Point(41, 94);
			this.chkGenLatestFile.Name = "chkGenLatestFile";
			this.chkGenLatestFile.Size = new System.Drawing.Size(129, 17);
			this.chkGenLatestFile.TabIndex = 55;
			this.chkGenLatestFile.Text = "Gen Latest Signal File";
			this.chkGenLatestFile.UseVisualStyleBackColor = true;
			// 
			// btnBrowselatestOutput
			// 
			this.btnBrowselatestOutput.Location = new System.Drawing.Point(436, 61);
			this.btnBrowselatestOutput.Name = "btnBrowselatestOutput";
			this.btnBrowselatestOutput.Size = new System.Drawing.Size(34, 22);
			this.btnBrowselatestOutput.TabIndex = 54;
			this.btnBrowselatestOutput.Text = "...";
			this.btnBrowselatestOutput.UseVisualStyleBackColor = true;
			this.btnBrowselatestOutput.Click += new System.EventHandler(this.btnBrowselatestOutput_Click);
			// 
			// txtLastOutputFolder
			// 
			this.txtLastOutputFolder.Location = new System.Drawing.Point(121, 62);
			this.txtLastOutputFolder.Name = "txtLastOutputFolder";
			this.txtLastOutputFolder.Size = new System.Drawing.Size(315, 20);
			this.txtLastOutputFolder.TabIndex = 53;
			// 
			// label31
			// 
			this.label31.AutoSize = true;
			this.label31.Location = new System.Drawing.Point(53, 65);
			this.label31.Name = "label31";
			this.label31.Size = new System.Drawing.Size(39, 13);
			this.label31.TabIndex = 52;
			this.label31.Text = "Output";
			// 
			// chkLatestOutPrimary
			// 
			this.chkLatestOutPrimary.AutoSize = true;
			this.chkLatestOutPrimary.Location = new System.Drawing.Point(41, 42);
			this.chkLatestOutPrimary.Name = "chkLatestOutPrimary";
			this.chkLatestOutPrimary.Size = new System.Drawing.Size(71, 17);
			this.chkLatestOutPrimary.TabIndex = 49;
			this.chkLatestOutPrimary.Text = "Primary R";
			this.chkLatestOutPrimary.UseVisualStyleBackColor = true;
			// 
			// label24
			// 
			this.label24.AutoSize = true;
			this.label24.Location = new System.Drawing.Point(26, 22);
			this.label24.Name = "label24";
			this.label24.Size = new System.Drawing.Size(57, 13);
			this.label24.TabIndex = 48;
			this.label24.Text = "Applies To";
			// 
			// txtLevel
			// 
			this.txtLevel.Location = new System.Drawing.Point(144, 49);
			this.txtLevel.Name = "txtLevel";
			this.txtLevel.Size = new System.Drawing.Size(83, 20);
			this.txtLevel.TabIndex = 62;
			// 
			// txtBar
			// 
			this.txtBar.Location = new System.Drawing.Point(314, 49);
			this.txtBar.Name = "txtBar";
			this.txtBar.Size = new System.Drawing.Size(80, 20);
			this.txtBar.TabIndex = 64;
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Location = new System.Drawing.Point(33, 52);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(33, 13);
			this.label6.TabIndex = 61;
			this.label6.Text = "Level";
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(277, 52);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(31, 13);
			this.label1.TabIndex = 63;
			this.label1.Text = "Bar%";
			// 
			// chkDontOutputFiles
			// 
			this.chkDontOutputFiles.AutoSize = true;
			this.chkDontOutputFiles.Location = new System.Drawing.Point(144, 80);
			this.chkDontOutputFiles.Name = "chkDontOutputFiles";
			this.chkDontOutputFiles.Size = new System.Drawing.Size(110, 17);
			this.chkDontOutputFiles.TabIndex = 73;
			this.chkDontOutputFiles.Text = "Don\'t Output Files";
			this.chkDontOutputFiles.UseVisualStyleBackColor = true;
			// 
			// chkStoreBarChange
			// 
			this.chkStoreBarChange.AutoSize = true;
			this.chkStoreBarChange.Checked = true;
			this.chkStoreBarChange.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chkStoreBarChange.Location = new System.Drawing.Point(314, 80);
			this.chkStoreBarChange.Name = "chkStoreBarChange";
			this.chkStoreBarChange.Size = new System.Drawing.Size(129, 17);
			this.chkStoreBarChange.TabIndex = 72;
			this.chkStoreBarChange.Text = "Store Bar% in Change";
			this.chkStoreBarChange.UseVisualStyleBackColor = true;
			// 
			// chkSendZMQ
			// 
			this.chkSendZMQ.AutoSize = true;
			this.chkSendZMQ.Location = new System.Drawing.Point(23, 366);
			this.chkSendZMQ.Name = "chkSendZMQ";
			this.chkSendZMQ.Size = new System.Drawing.Size(139, 17);
			this.chkSendZMQ.TabIndex = 60;
			this.chkSendZMQ.Text = "Send ZeroMQ Message";
			this.chkSendZMQ.UseVisualStyleBackColor = true;
			this.chkSendZMQ.CheckedChanged += new System.EventHandler(this.chkSendZMQ_CheckedChanged);
			// 
			// chkSendCycleCompleteMsg
			// 
			this.chkSendCycleCompleteMsg.AutoSize = true;
			this.chkSendCycleCompleteMsg.Location = new System.Drawing.Point(23, 58);
			this.chkSendCycleCompleteMsg.Name = "chkSendCycleCompleteMsg";
			this.chkSendCycleCompleteMsg.Size = new System.Drawing.Size(150, 17);
			this.chkSendCycleCompleteMsg.TabIndex = 30;
			this.chkSendCycleCompleteMsg.Text = "Send Cycle Complete Msg";
			this.chkSendCycleCompleteMsg.UseVisualStyleBackColor = true;
			// 
			// txtPort
			// 
			this.txtPort.Location = new System.Drawing.Point(335, 26);
			this.txtPort.Name = "txtPort";
			this.txtPort.Size = new System.Drawing.Size(59, 20);
			this.txtPort.TabIndex = 29;
			this.txtPort.Text = "12345";
			// 
			// label15
			// 
			this.label15.AutoSize = true;
			this.label15.Location = new System.Drawing.Point(301, 29);
			this.label15.Name = "label15";
			this.label15.Size = new System.Drawing.Size(26, 13);
			this.label15.TabIndex = 28;
			this.label15.Text = "Port";
			// 
			// txtIP
			// 
			this.txtIP.Location = new System.Drawing.Point(99, 26);
			this.txtIP.Name = "txtIP";
			this.txtIP.Size = new System.Drawing.Size(143, 20);
			this.txtIP.TabIndex = 27;
			this.txtIP.Text = "127.0.0.1";
			// 
			// label14
			// 
			this.label14.AutoSize = true;
			this.label14.Location = new System.Drawing.Point(20, 29);
			this.label14.Name = "label14";
			this.label14.Size = new System.Drawing.Size(58, 13);
			this.label14.TabIndex = 26;
			this.label14.Text = "IP Address";
			// 
			// btnBrowseROutputFolder
			// 
			this.btnBrowseROutputFolder.Location = new System.Drawing.Point(457, 14);
			this.btnBrowseROutputFolder.Name = "btnBrowseROutputFolder";
			this.btnBrowseROutputFolder.Size = new System.Drawing.Size(34, 22);
			this.btnBrowseROutputFolder.TabIndex = 71;
			this.btnBrowseROutputFolder.Text = "...";
			this.btnBrowseROutputFolder.UseVisualStyleBackColor = true;
			this.btnBrowseROutputFolder.Click += new System.EventHandler(this.btnBrowseROutputFolder_Click);
			// 
			// txtROutputFolder
			// 
			this.txtROutputFolder.Location = new System.Drawing.Point(144, 15);
			this.txtROutputFolder.Name = "txtROutputFolder";
			this.txtROutputFolder.Size = new System.Drawing.Size(313, 20);
			this.txtROutputFolder.TabIndex = 70;
			// 
			// label18
			// 
			this.label18.AutoSize = true;
			this.label18.Location = new System.Drawing.Point(33, 18);
			this.label18.Name = "label18";
			this.label18.Size = new System.Drawing.Size(103, 13);
			this.label18.TabIndex = 69;
			this.label18.Text = "Primary R File Folder";
			// 
			// btnCancel
			// 
			this.btnCancel.Location = new System.Drawing.Point(314, 474);
			this.btnCancel.Name = "btnCancel";
			this.btnCancel.Size = new System.Drawing.Size(112, 31);
			this.btnCancel.TabIndex = 68;
			this.btnCancel.Text = "Cancel";
			this.btnCancel.UseVisualStyleBackColor = true;
			this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
			// 
			// btnOK
			// 
			this.btnOK.Location = new System.Drawing.Point(114, 474);
			this.btnOK.Name = "btnOK";
			this.btnOK.Size = new System.Drawing.Size(112, 31);
			this.btnOK.TabIndex = 67;
			this.btnOK.Text = "OK";
			this.btnOK.UseVisualStyleBackColor = true;
			this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
			// 
			// groupBoxZMQ
			// 
			this.groupBoxZMQ.Controls.Add(this.chkSendCycleCompleteMsg);
			this.groupBoxZMQ.Controls.Add(this.txtPort);
			this.groupBoxZMQ.Controls.Add(this.label15);
			this.groupBoxZMQ.Controls.Add(this.txtIP);
			this.groupBoxZMQ.Controls.Add(this.label14);
			this.groupBoxZMQ.Location = new System.Drawing.Point(16, 370);
			this.groupBoxZMQ.Name = "groupBoxZMQ";
			this.groupBoxZMQ.Size = new System.Drawing.Size(479, 82);
			this.groupBoxZMQ.TabIndex = 66;
			this.groupBoxZMQ.TabStop = false;
			// 
			// chkSubCal
			// 
			this.chkSubCal.AutoSize = true;
			this.chkSubCal.Location = new System.Drawing.Point(521, 83);
			this.chkSubCal.Name = "chkSubCal";
			this.chkSubCal.Size = new System.Drawing.Size(63, 17);
			this.chkSubCal.TabIndex = 88;
			this.chkSubCal.Text = "Sub-Cal";
			this.chkSubCal.UseVisualStyleBackColor = true;
			this.chkSubCal.CheckedChanged += new System.EventHandler(this.chkSubCal_CheckedChanged);
			// 
			// txtMinRowsCleanUp
			// 
			this.txtMinRowsCleanUp.Location = new System.Drawing.Point(717, 46);
			this.txtMinRowsCleanUp.Name = "txtMinRowsCleanUp";
			this.txtMinRowsCleanUp.Size = new System.Drawing.Size(80, 20);
			this.txtMinRowsCleanUp.TabIndex = 90;
			// 
			// chkMinRowsCleanUp
			// 
			this.chkMinRowsCleanUp.AutoSize = true;
			this.chkMinRowsCleanUp.Location = new System.Drawing.Point(521, 50);
			this.chkMinRowsCleanUp.Name = "chkMinRowsCleanUp";
			this.chkMinRowsCleanUp.Size = new System.Drawing.Size(166, 17);
			this.chkMinRowsCleanUp.TabIndex = 89;
			this.chkMinRowsCleanUp.Text = "Output R  Min Rows CleanUp";
			this.chkMinRowsCleanUp.UseVisualStyleBackColor = true;
			this.chkMinRowsCleanUp.CheckedChanged += new System.EventHandler(this.chkMinRowsCleanUp_CheckedChanged);
			// 
			// chkOptionGridReport
			// 
			this.chkOptionGridReport.AutoSize = true;
			this.chkOptionGridReport.Location = new System.Drawing.Point(144, 109);
			this.chkOptionGridReport.Name = "chkOptionGridReport";
			this.chkOptionGridReport.Size = new System.Drawing.Size(134, 17);
			this.chkOptionGridReport.TabIndex = 92;
			this.chkOptionGridReport.Text = "Gen OptionGrid Report";
			this.chkOptionGridReport.UseVisualStyleBackColor = true;
			// 
			// chkSignalReport
			// 
			this.chkSignalReport.AutoSize = true;
			this.chkSignalReport.Location = new System.Drawing.Point(314, 109);
			this.chkSignalReport.Name = "chkSignalReport";
			this.chkSignalReport.Size = new System.Drawing.Size(134, 17);
			this.chkSignalReport.TabIndex = 91;
			this.chkSignalReport.Text = "Options Signals Report";
			this.chkSignalReport.UseVisualStyleBackColor = true;
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(33, 110);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(39, 13);
			this.label2.TabIndex = 93;
			this.label2.Text = "Report";
			// 
			// btnReportOutputFolder
			// 
			this.btnReportOutputFolder.Location = new System.Drawing.Point(457, 134);
			this.btnReportOutputFolder.Name = "btnReportOutputFolder";
			this.btnReportOutputFolder.Size = new System.Drawing.Size(34, 22);
			this.btnReportOutputFolder.TabIndex = 95;
			this.btnReportOutputFolder.Text = "...";
			this.btnReportOutputFolder.UseVisualStyleBackColor = true;
			this.btnReportOutputFolder.Click += new System.EventHandler(this.btnReportOutputFolder_Click);
			// 
			// txtReportOutputFolder
			// 
			this.txtReportOutputFolder.Location = new System.Drawing.Point(142, 135);
			this.txtReportOutputFolder.Name = "txtReportOutputFolder";
			this.txtReportOutputFolder.Size = new System.Drawing.Size(315, 20);
			this.txtReportOutputFolder.TabIndex = 94;
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(33, 138);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(106, 13);
			this.label3.TabIndex = 96;
			this.label3.Text = "Report Output Folder";
			// 
			// FrmROutputSetting
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(840, 515);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.btnReportOutputFolder);
			this.Controls.Add(this.txtReportOutputFolder);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.chkOptionGridReport);
			this.Controls.Add(this.chkSignalReport);
			this.Controls.Add(this.txtMinRowsCleanUp);
			this.Controls.Add(this.chkMinRowsCleanUp);
			this.Controls.Add(this.chkSubCal);
			this.Controls.Add(this.chkCustomPercentBar);
			this.Controls.Add(this.txtOutputOnlyR);
			this.Controls.Add(this.chkOutputOnlyR);
			this.Controls.Add(this.chkLatestSignalOutput);
			this.Controls.Add(this.groupSubCal);
			this.Controls.Add(this.btnBrowseCustomBarPercent);
			this.Controls.Add(this.txtCustomBarPercentPath);
			this.Controls.Add(this.groupLatestSignal);
			this.Controls.Add(this.txtLevel);
			this.Controls.Add(this.txtBar);
			this.Controls.Add(this.label6);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.chkDontOutputFiles);
			this.Controls.Add(this.chkStoreBarChange);
			this.Controls.Add(this.chkSendZMQ);
			this.Controls.Add(this.btnBrowseROutputFolder);
			this.Controls.Add(this.txtROutputFolder);
			this.Controls.Add(this.label18);
			this.Controls.Add(this.btnCancel);
			this.Controls.Add(this.btnOK);
			this.Controls.Add(this.groupBoxZMQ);
			this.Name = "FrmROutputSetting";
			this.Text = "FrmROutputSetting";
			this.panelBSLevels.ResumeLayout(false);
			this.panelBSLevels.PerformLayout();
			this.panelCalAvg.ResumeLayout(false);
			this.panelCalAvg.PerformLayout();
			this.groupSubCal.ResumeLayout(false);
			this.groupSubCal.PerformLayout();
			this.groupLatestSignal.ResumeLayout(false);
			this.groupLatestSignal.PerformLayout();
			this.groupBoxZMQ.ResumeLayout(false);
			this.groupBoxZMQ.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.TextBox txtLavg4End;
		private System.Windows.Forms.CheckBox chkEnableBSSignal;
		private System.Windows.Forms.CheckBox chkCalAvg;
		private System.Windows.Forms.TextBox txtSubCalLevels;
		private System.Windows.Forms.Label label23;
		private System.Windows.Forms.CheckBox chkApplyPrimaryR;
		private System.Windows.Forms.Label label22;
		private System.Windows.Forms.RadioButton radLavgSignal;
		private System.Windows.Forms.TextBox txtLavgSignal;
		private System.Windows.Forms.RadioButton radioBSLevel;
		private System.Windows.Forms.TextBox txtBSLevels;
		private System.Windows.Forms.Panel panelBSLevels;
		private System.Windows.Forms.CheckBox chkCustomPercentBar;
		private System.Windows.Forms.TextBox txtOutputOnlyR;
		private System.Windows.Forms.CheckBox chkOutputOnlyR;
		private System.Windows.Forms.Panel panelCalAvg;
		private System.Windows.Forms.TextBox txtLavg4Start;
		private System.Windows.Forms.Label label30;
		private System.Windows.Forms.TextBox txtLavg3End;
		private System.Windows.Forms.TextBox txtLavg3Start;
		private System.Windows.Forms.Label label29;
		private System.Windows.Forms.TextBox txtLavg2End;
		private System.Windows.Forms.TextBox txtLavg2Start;
		private System.Windows.Forms.Label label28;
		private System.Windows.Forms.Label label27;
		private System.Windows.Forms.TextBox txtLavg1End;
		private System.Windows.Forms.Label label26;
		private System.Windows.Forms.TextBox txtLavg1Start;
		private System.Windows.Forms.Label label25;
		private System.Windows.Forms.GroupBox groupSubCal;
		private System.Windows.Forms.CheckBox chkLatestSignalOutput;
		private System.Windows.Forms.Button btnBrowseCustomBarPercent;
		private System.Windows.Forms.TextBox txtCustomBarPercentPath;
		private System.Windows.Forms.CheckBox chkLatestMasterNew;
		private System.Windows.Forms.GroupBox groupLatestSignal;
		private System.Windows.Forms.CheckBox chkGenLatestMasterFile;
		private System.Windows.Forms.CheckBox chkGenLatestFile;
		private System.Windows.Forms.Button btnBrowselatestOutput;
		private System.Windows.Forms.TextBox txtLastOutputFolder;
		private System.Windows.Forms.Label label31;
		private System.Windows.Forms.CheckBox chkLatestOutPrimary;
		private System.Windows.Forms.Label label24;
		private System.Windows.Forms.TextBox txtLevel;
		private System.Windows.Forms.TextBox txtBar;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.CheckBox chkDontOutputFiles;
		private System.Windows.Forms.CheckBox chkStoreBarChange;
		private System.Windows.Forms.CheckBox chkSendZMQ;
		private System.Windows.Forms.CheckBox chkSendCycleCompleteMsg;
		private System.Windows.Forms.TextBox txtPort;
		private System.Windows.Forms.Label label15;
		private System.Windows.Forms.TextBox txtIP;
		private System.Windows.Forms.Label label14;
		private System.Windows.Forms.Button btnBrowseROutputFolder;
		private System.Windows.Forms.TextBox txtROutputFolder;
		private System.Windows.Forms.Label label18;
		private System.Windows.Forms.Button btnCancel;
		private System.Windows.Forms.Button btnOK;
		private System.Windows.Forms.GroupBox groupBoxZMQ;
		private System.Windows.Forms.CheckBox chkSubCal;
		private System.Windows.Forms.TextBox txtMinRowsCleanUp;
		private System.Windows.Forms.CheckBox chkMinRowsCleanUp;
		private System.Windows.Forms.CheckBox chkOptionGridReport;
		private System.Windows.Forms.CheckBox chkSignalReport;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Button btnReportOutputFolder;
		private System.Windows.Forms.TextBox txtReportOutputFolder;
		private System.Windows.Forms.Label label3;
	}
}