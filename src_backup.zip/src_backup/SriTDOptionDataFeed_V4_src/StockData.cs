﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SriTDDataFeedSetting
{
	public class StockData
	{
		public string Date { get; set; }
		public string Time { get; set; }
		public double OpenPrice { get; set; }
		public double HighPrice { get; set; }
		public double LowPrice { get; set; }
		public double ClosePrice { get; set; }
		public double Volume { get; set; }

	}

	public class StockDataComparer : IComparer<StockData>
	{
		public int Compare(StockData x, StockData y)
		{
			string str1 = x.Date + x.Time;
			string str2 = y.Date + y.Time;

			return str1.CompareTo(str2);
		}
	}

}
