﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SriTDDataFeedSetting
{
    public class DataFeedConfig
    {
		public string ApiKey { get; set; } = "KTBAEPPWUCX8KSO7ANNEKHF3A88IU2T5";
		public string RefreshToken { get; set; } = "+/SA+qBrqFo0WFZQxPTvZvMTmo53DQ9zn3YUme6aA10ItIlfSVceWyiotdy0ihBGdhKDRxH3n/R9BGCoMmZw68ArHcCmXNByhy0eWSYd3kCdGD9HivoTuewTvcC7tQrtgn+iumByZX9PoA9VOxS54jL8HVf74UPvo0LI2TcS1RUiSmFhqnduX28lWpabfgoroGlhxTN4rHYOb+k+jzvKoFVvv8NB00nQXNGr7PYyGMLCyeYvGyXXYwdU7HS+MMm9zJCD4aLpCuH1b1WhpcC0T/ril8c0RVe5oH8po5PPuKYR7I/5jE3LcEOtv7KYjTI5b9Jvxh7sIdCr+gbKzT32XHwcBfS1qa3dgoqhoZZKTZqfHt/SPoRXtrLcNCbYXXH7JX5oY3TNJ1d2YYZ6rr+h6tGyb6niQUyiNtmK04IbMAZkS63kwgGRoWxY3ik100MQuG4LYrgoVi/JHHvlP30Unsi/7XXjDdfcOqenj4JFHmViqH1qrIvTP5z6XTlKijpfMtlbJRJws8wtqQTGn+DYjPVBYMbDRh2qU8nYxrCuzKC2pcOhgGWPayLGJ/alszeI01A5n70pgK6UdcV+wcbHvFCoQ/IiFGRvv34BRzP0Tw5pvn7kgAm6aTfH2FT5xWWZsDzkk0vQeMalaxwOSpmg/na9ymlIVPywuUq5jnGjjSShqBJ5OrI8EhecSbFTshCjsp2uTaInEUFztYvM3ga+LQVcE7iUOdw+j+OtHuaQWQBMWsDTOcGyFzYJxwpG4VPdyl8YVNgRx93G0C8A5lQtXJ5uE/+/HFoag2lRAoGPtZa0ThzsCR0VrH2lgNrVniMnqLs5Rc0iizXXYaT25Ej/gl7B+m0/AFPuyvJaKrA7gUIcFq0FJtzz4K2vdqJkUG3D3S7ZqvPKZWk=212FD3x19z9sWBHDJACbC00B75E";
		public string InputHistoricalDataPath { get; set; }
		public string InputSymbolFile { get; set; }
		public int NumberOfSymbolsPerAPI { get; set; } = 100;
		public string AutoStopTime { get; set; } = "22:00";
		public int ProcessType { get; set; } = 0;
		public int AutoUpdateInterval { get; set; } = 10;
		public int MinimumRowsOfDataForClean { get; set; } = 5;
		public bool DeleteIfNoHistoricalFile { get; set; } = true;
		public int APICallType { get; set; } = 0;
		public ROutputSettings RFileOutputConfig { get; set; } = new ROutputSettings();

		#region Merge File Settings
		public bool EnableMergeFile { get; set; }
		public string MergeOutputPath { get; set; }
		public string MergeTreeFile { get; set; }
		#endregion

		#region Align Data Settings
		public DateTime TrimStartDate { get; set; } = DateTime.Now;
		public DateTime TrimStartTime { get; set; } = DateTime.Now;
		public DateTime AlignStartTime { get; set; } = DateTime.Now;
		public DateTime AlignEndTime { get; set; } = DateTime.Now;
		public int AlignInterval { get; set; } = 5;
		public bool GenStockFile { get; set; }
		public bool EnableCalendarAutoUpdate { get; set; }
		public bool EnableRFileOutput { get; set; }

		public int RoundPoints { get; set; } = 2;
		public bool RoundClose { get; set; }
		public bool RoundChange { get; set; }
		public bool RoundVolume { get; set; }

		#endregion


	}
}
