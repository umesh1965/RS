﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SriTDDataFeedSetting;
using SriTDDataFeedProcess;
using System.Threading;
using Ookii.Dialogs.Wpf;
using System.IO;
using System.Diagnostics;

namespace Sri_TD_Options_DataFeed
{
	public partial class FrmMain : Form
	{
		private DataFeedProcessor processor;
		private bool bProcessStarted = false;
		private Thread processThread = null;
		private ZeroMQSender msgSender;
		private DataFeedConfig Config { get => GlobalData.Config; }

		public FrmMain()
		{

			processor = new DataFeedProcessor();
			processor.ProcessNotifier = new DataFeedProcessor.ProcessNotifierDelegate(ProcessNotifier);
			processor.MessageSender = new DataFeedProcessor.MessageSenderDeleagate(SendMessage);

			InitializeComponent();

			GlobalData.LoadSettings();
			timerAutoUpdate.Tick += UpdateTick;

			BindSettings(false);

			msgSender = new ZeroMQSender();
		}
		private void SendMessage(string msg)
		{
			msgSender.SendMessage(msg);
		}
		private void UpdateTick(object sender, EventArgs e)
		{
			if (DateTime.Now.Second == 0)
			{
				DoAutoUpdate(sender, e);
			}
		}

		private bool BindSettings(bool bFromControl, bool bForCleanup = false, bool bDisplayError = false)
		{
			bool bRet = true;
			if (bFromControl)
			{
				//API key
				if (!string.IsNullOrEmpty(txtAPIKey.Text))
					GlobalData.Config.ApiKey = txtAPIKey.Text;
				else
				{
					if (bDisplayError)
					{
						MessageBox.Show("Please enter API Key", GlobalData.AppName, MessageBoxButtons.OK, MessageBoxIcon.Warning);
						SelectText(txtAPIKey);
						return false;
					}
					else
						bRet = false;
				}

				//refresh Token
				if (!string.IsNullOrEmpty(txtRefreshToken.Text))
					GlobalData.Config.RefreshToken = txtRefreshToken.Text;
				else
				{
					if (bDisplayError)
					{
						MessageBox.Show("Please enter Refresh Token", GlobalData.AppName, MessageBoxButtons.OK, MessageBoxIcon.Warning);
						SelectText(txtRefreshToken);
						return false;
					}
					else
						bRet = false;
				}
				//input symbol list
				if (!string.IsNullOrEmpty(txtInputSymbolFile.Text))
				{
					GlobalData.Config.InputSymbolFile = txtInputSymbolFile.Text;
				}
				else
				{
					if (bDisplayError)
					{
						MessageBox.Show("Please select a file containting TDOption SymbolList", GlobalData.AppName, MessageBoxButtons.OK, MessageBoxIcon.Warning);
						SelectText(txtInputSymbolFile);
						return false;
					}
					else
						bRet = false;
				}

				//historical data
				if (!string.IsNullOrEmpty(txtInputDataPath.Text))
				{
					GlobalData.Config.InputHistoricalDataPath = txtInputDataPath.Text;
				}
				else
				{
					if (bDisplayError)
					{
						MessageBox.Show("Please select a directory containting Input Historical Data files", GlobalData.AppName, MessageBoxButtons.OK, MessageBoxIcon.Warning);
						SelectText(txtInputDataPath);
						return false;
					}
					else
						bRet = false;
				}

				//minimum rows of data
				if (!string.IsNullOrEmpty(txtMinimumRows.Text))
				{
					try
					{
						GlobalData.Config.MinimumRowsOfDataForClean = Convert.ToInt32(txtMinimumRows.Text);
						if (GlobalData.Config.MinimumRowsOfDataForClean < 0)
						{
							if (bDisplayError)
							{
								MessageBox.Show("Minimum Rows of Data must be positive", GlobalData.AppName, MessageBoxButtons.OK, MessageBoxIcon.Warning);
								SelectText(txtMinimumRows);
								return false;
							}
							else
								bRet = false;
						}
					}
					catch
					{
						if (bDisplayError)
						{
							MessageBox.Show("Invalid Minimum Rows of Data", GlobalData.AppName, MessageBoxButtons.OK, MessageBoxIcon.Warning);
							SelectText(txtMinimumRows);
							return false;
						}
						else
							bRet = false;
					}
				}
				else if (bForCleanup)
				{
					if (bDisplayError)
					{
						MessageBox.Show("Please enter Minimum Rows of Data", GlobalData.AppName, MessageBoxButtons.OK, MessageBoxIcon.Warning);
						SelectText(txtMinimumRows);
						return false;
					}
					else
						bRet = false;
				}

				//delete if no historical file
				GlobalData.Config.DeleteIfNoHistoricalFile = chkDeleteIfNoHIstoryFile.Checked;

				if (bForCleanup)
					return bRet;

				//max symbol number per api call
				if (string.IsNullOrEmpty(txtSymbolCount.Text))
				{
					if (bDisplayError)
					{
						MessageBox.Show("Please enter Max Symbols Per API Call", GlobalData.AppName, MessageBoxButtons.OK, MessageBoxIcon.Warning);
						SelectText(txtSymbolCount);
						return false;
					}
					else
						bRet = false;
				}
				else
				{
					try
					{
						GlobalData.Config.NumberOfSymbolsPerAPI = Convert.ToInt32(txtSymbolCount.Text);
						if (GlobalData.Config.NumberOfSymbolsPerAPI <= 0)
						{
							if (bDisplayError)
							{
								MessageBox.Show("Max Symbols Per API Call must be positive.", GlobalData.AppName, MessageBoxButtons.OK, MessageBoxIcon.Warning);
								SelectText(txtSymbolCount);
								return false;
							}
							else
								bRet = false;
						}
					}
					catch
					{
						if (bDisplayError)
						{
							MessageBox.Show("Invalid Max Symbols Per API Call", GlobalData.AppName, MessageBoxButtons.OK, MessageBoxIcon.Warning);
							SelectText(txtSymbolCount);
							return false;
						}
						else
							bRet = false;
					}
				}

				//AutoStop Time
				if (!string.IsNullOrEmpty(txtAutoStopTime.Text))
				{
					try
					{
						DateTime stopTime = DateTime.Parse(txtAutoStopTime.Text);
						GlobalData.Config.AutoStopTime = stopTime.ToString("HH:mm");
					}
					catch
					{
						if (bDisplayError)
						{
							MessageBox.Show("Invalid Stop Time Format", GlobalData.AppName, MessageBoxButtons.OK, MessageBoxIcon.Warning);
							SelectText(txtAutoStopTime);
							return false;
						}
						else
							bRet = false;
					}
				}

				//Auto Update interval
				if (!string.IsNullOrEmpty(txtAutoUpdateInterval.Text))
				{
					try
					{
						GlobalData.Config.AutoUpdateInterval = Convert.ToInt32(txtAutoUpdateInterval.Text);
						if (GlobalData.Config.AutoUpdateInterval <= 0)
						{
							if (bDisplayError)
							{
								MessageBox.Show("Auto Update Interval must be positive.", GlobalData.AppName, MessageBoxButtons.OK, MessageBoxIcon.Warning);
								SelectText(txtAutoUpdateInterval);
								return false;
							}
							else
								bRet = false;
						}
					}
					catch
					{
						if (bDisplayError)
						{
							MessageBox.Show("Invalid Auto Update Interval", GlobalData.AppName, MessageBoxButtons.OK, MessageBoxIcon.Warning);
							SelectText(txtAutoUpdateInterval);
							return false;
						}
						else
							bRet = false;
					}
				}
				else
				{
					if (bDisplayError)
					{
						MessageBox.Show("Please enter Auto Update Interval", GlobalData.AppName, MessageBoxButtons.OK, MessageBoxIcon.Warning);
						SelectText(txtAutoUpdateInterval);
						return false;
					}
					else
						bRet = false;
				}

				GlobalData.Config.APICallType = radioByToken.Checked ? 0 : 1;
				GlobalData.Config.EnableMergeFile = chkMergeFile.Checked;

				//Merge File
				if (GlobalData.Config.EnableMergeFile)
				{
					GlobalData.Config.MergeOutputPath = txtMergeOutputPath.Text;
					GlobalData.Config.MergeTreeFile = txtMergeTreeFile.Text;
				}

				//Align Data
				GlobalData.Config.TrimStartDate = trimDate.Value.Date;

				GlobalData.Config.TrimStartTime = trimTime.Value;

				GlobalData.Config.AlignStartTime = alignStartTime.Value;

				GlobalData.Config.AlignEndTime = alignEndTime.Value;
			
				int[] mins = { 1, 5, 10, 15, 30, 60, 1440 };
				GlobalData.Config.AlignInterval = mins[cmbAlignTimeFrame.SelectedIndex];

				GlobalData.Config.GenStockFile = chkGenStockFile.Checked;
				Config.EnableCalendarAutoUpdate = chkUseCalendarFile.Checked;
				Config.EnableRFileOutput = chkROutput.Checked;

				int tempValInt = 0;
				Config.RoundPoints = int.TryParse(txtRounding.Text, out tempValInt) ? tempValInt : 0;

				if (Config.RoundPoints == 0)
					Config.RoundPoints = 2;

				Config.RoundChange = chkRoundChange.Checked;
				Config.RoundClose = chkRoundClose.Checked;
				Config.RoundVolume = chkRoundVol.Checked;
			}
			else
			{
				txtAPIKey.Text = GlobalData.Config.ApiKey;
				txtRefreshToken.Text = GlobalData.Config.RefreshToken;
				txtInputDataPath.Text = GlobalData.Config.InputHistoricalDataPath;
				txtInputSymbolFile.Text = GlobalData.Config.InputSymbolFile;
				txtSymbolCount.Text = GlobalData.Config.NumberOfSymbolsPerAPI.ToString();
				txtAutoStopTime.Text = GlobalData.Config.AutoStopTime;

				radioManualStatic.Checked = GlobalData.Config.ProcessType == 0;
				radioAutoLoop.Checked = GlobalData.Config.ProcessType == 1;
				radioAutoUpdate.Checked = GlobalData.Config.ProcessType == 2;

				txtAutoUpdateInterval.Text = GlobalData.Config.AutoUpdateInterval.ToString();
				txtAutoUpdateInterval.Enabled = GlobalData.Config.ProcessType == 2;

				txtMinimumRows.Text = GlobalData.Config.MinimumRowsOfDataForClean.ToString();
				chkDeleteIfNoHIstoryFile.Checked = GlobalData.Config.DeleteIfNoHistoricalFile;
				radioByToken.Checked = GlobalData.Config.APICallType == 0;
				radioByKey.Checked = GlobalData.Config.APICallType == 1;

				chkMergeFile.Checked = GlobalData.Config.EnableMergeFile;
				txtMergeOutputPath.Text = GlobalData.Config.MergeOutputPath;
				txtMergeTreeFile.Text = GlobalData.Config.MergeTreeFile;
				txtMergeOutputPath.Enabled = txtMergeTreeFile.Enabled = GlobalData.Config.EnableMergeFile;

				trimDate.Value = GlobalData.Config.TrimStartDate;
				trimTime.Value = GlobalData.Config.TrimStartTime;
				alignStartTime.Value = GlobalData.Config.AlignStartTime;
				alignEndTime.Value = GlobalData.Config.AlignEndTime;

				List<int> intervals = new List<int>();
				intervals.Add(1);
				intervals.Add(5);
				intervals.Add(10);
				intervals.Add(15);
				intervals.Add(30);
				intervals.Add(60);
				intervals.Add(1440);

				cmbAlignTimeFrame.SelectedIndex = intervals.IndexOf(GlobalData.Config.AlignInterval);

				chkGenStockFile.Checked = GlobalData.Config.GenStockFile;
				chkUseCalendarFile.Checked = Config.EnableCalendarAutoUpdate;
				chkROutput.Checked = Config.EnableRFileOutput;

				btnROutputSetting.Enabled = chkROutput.Checked;

				txtRounding.Text = Config.RoundPoints.ToString();
				chkRoundChange.Checked = Config.RoundChange;
				chkRoundClose.Checked = Config.RoundClose;
				chkRoundVol.Checked = Config.RoundVolume;
			}

			return bRet;
		}

		private void SelectText(TextBox textBox)
		{
			textBox.Focus();
			textBox.SelectAll();
		}

		private void radioManualStatic_CheckedChanged(object sender, EventArgs e)
		{
			UpdateProcessType();
		}

		private void radioAutoLoop_CheckedChanged(object sender, EventArgs e)
		{
			UpdateProcessType();
		}

		private void radioAutoUpdate_CheckedChanged(object sender, EventArgs e)
		{
			UpdateProcessType();
		}

		private void UpdateProcessType()
		{
			if (radioManualStatic.Checked)
				GlobalData.Config.ProcessType = 0;
			else if (radioAutoLoop.Checked)
				GlobalData.Config.ProcessType = 1;
			else if (radioAutoUpdate.Checked)
				GlobalData.Config.ProcessType = 2;

			txtAutoUpdateInterval.Enabled = radioAutoUpdate.Checked;
		}

		private void FrmMain_FormClosing(object sender, FormClosingEventArgs e)
		{
			if (MessageBox.Show("Are you sure you want to exit?", GlobalData.AppName, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
			{
				e.Cancel = true;
				return;
			}
			if (bProcessStarted)
				processor.StopProcess();

			if (processThread != null)
				processThread.Join();

			BindSettings(true);
			GlobalData.SaveSettings();
		}

		private void btnExit_Click(object sender, EventArgs e)
		{
			Application.Exit();
		}

		private void btnBrowseInputDataPath_Click(object sender, EventArgs e)
		{
			VistaFolderBrowserDialog folderBrowserDialog = new VistaFolderBrowserDialog();
			folderBrowserDialog.SelectedPath = txtInputDataPath.Text;
			if (folderBrowserDialog.ShowDialog() == true)
			{
				GlobalData.Config.InputHistoricalDataPath = folderBrowserDialog.SelectedPath;
				txtInputDataPath.Text = folderBrowserDialog.SelectedPath;
			}
		}

		private void btnBrowseInputSymbolFile_Click(object sender, EventArgs e)
		{
			OpenFileDialog openDlg = new OpenFileDialog();
			openDlg.Filter = "TDOption Symbol List|*.txt";
			if (openDlg.ShowDialog() == DialogResult.OK)
			{
				GlobalData.Config.InputSymbolFile = openDlg.FileName;
				txtInputSymbolFile.Text = openDlg.FileName;
			}
		}

		private bool CheckStartContidions()
		{
			string logFile = "error.log";
			DataFeedProcessor.LogFileName = logFile;
			try
			{
				File.AppendAllText(logFile, "");
			}
			catch (Exception e)
			{
				MessageBox.Show("Could not write log to error.log file." + Environment.NewLine + e.Message, GlobalData.AppName, MessageBoxButtons.OK, MessageBoxIcon.Error);
				return false;
			}

			//General
			if (string.IsNullOrEmpty(txtInputSymbolFile.Text))
			{
				MessageBox.Show("Please select a file containting TDOption Symbol List", GlobalData.AppName, MessageBoxButtons.OK, MessageBoxIcon.Warning);
				txtInputSymbolFile.Focus();
				return false;
			}
			else if (!File.Exists(txtInputSymbolFile.Text))
			{
				MessageBox.Show("The input file does not exist.", GlobalData.AppName, MessageBoxButtons.OK, MessageBoxIcon.Warning);
				SelectText(txtInputSymbolFile);
				return false;
			}

			if (string.IsNullOrEmpty(txtInputDataPath.Text))
			{
				MessageBox.Show("Please select a directory containting Input Historical Data files", GlobalData.AppName, MessageBoxButtons.OK, MessageBoxIcon.Warning);
				txtInputDataPath.Focus();
				return false;
			}
			else if (!Directory.Exists(txtInputDataPath.Text))
			{
				MessageBox.Show("The directory does not exist", GlobalData.AppName, MessageBoxButtons.OK, MessageBoxIcon.Warning);
				txtInputDataPath.Focus();
				return false;
			}

			return true;
		}

		private void btnStart_Click(object sender, EventArgs e)
		{
			if (!CheckStartContidions())
			{
				bProcessStarted = false;
				return;
			}
			if (!BindSettings(true, false, true))
			{
				bProcessStarted = false;
				return;
			}

			GlobalData.SaveSettings();

			processor.ClearOriginalData();

			if (!processor.PrepareDataList())
			{
				MessageBox.Show("Failed to load symbol list from the file.", GlobalData.AppName, MessageBoxButtons.OK, MessageBoxIcon.Error);
				bProcessStarted = false;
				return;
			}

			btnStop.Enabled = true;

			if (processThread != null)
			{
				processThread.Join();
				processThread = null;
			}

			if (Config.EnableCalendarAutoUpdate)
			{
				if (File.Exists(GlobalData.GetCalendarFilePath()))
					processor.PrepareCalendarListFromFile();
				else
				{
					MessageBox.Show("Calendar File does not exist!", GlobalData.AppName, MessageBoxButtons.OK, MessageBoxIcon.Warning);
					bProcessStarted = false;
					return;
				}
			}
			if (Config.ProcessType == 0)
			{
				processThread = new Thread(() => processor.StartProcess());
				processThread.Start();
				bProcessStarted = true;
			}
			else
			{
				DoAutoUpdate(null, null);
				timerAutoUpdate.Enabled = true;
			}
			
			btnStop.Enabled = true;
			EnableAllControls(false);
			btnStart.Enabled = false;
		}
		private bool CanAutoUpdate()
		{
			if (Config.EnableCalendarAutoUpdate)
				return processor.IsTimeInMarketHour(DateTime.UtcNow);
			else
				return true;
		}
		private void DoAutoUpdate(object sender, EventArgs e)
		{
			if (!CanAutoUpdate())
			{
				BeginInvoke(new Action(() => statusLabel.Text = "Waiting for market open..."));
				if (bProcessStarted)
					processor.StopProcess();

				bProcessStarted = false;
				return;
			}
			else
			{
				if (!bProcessStarted)
				{
					processThread = new Thread(() => processor.StartProcess());
					processThread.Start();
				}

				bProcessStarted = true;
			}
		}

		private void btnStop_Click(object sender, EventArgs e)
		{
			if (bProcessStarted)
				processor.StopProcess();

			bProcessStarted = false;
			timerAutoUpdate.Enabled = false;
			btnStop.Enabled = false;
			btnStart.Enabled = true;
			statusLabel.Text = "Stopped by user";
			statusProgressBar.Visible = false;
			statusProgressBar.Value = 0;
			EnableAllControls(true);
		}

		private void ProcessNotifier(DataFeedProcessor.ProcessState state, int param)
		{
			switch (state)
			{
				case DataFeedProcessor.ProcessState.Start:
					BeginInvoke(new Action(() => EnableAllControls(false)));
					BeginInvoke(new Action(() => statusLabel.Text = "Starting..."));
					BeginInvoke(new Action(() => statusProgressBar.Maximum = param));
					BeginInvoke(new Action(() => statusProgressBar.Visible = true));
					if (Config.RFileOutputConfig.EnableZeroMQ)
						msgSender.Start(Config.RFileOutputConfig.IPAddressZMQ, Config.RFileOutputConfig.PortZMQ);
					break;
				case DataFeedProcessor.ProcessState.Progress:
					BeginInvoke(new Action(() => statusProgressBar.Value = param));
					//BeginInvoke(new Action(() => statusLabel.Text = "Processed " + param + " of " + statusProgressBar.Maximum));
					BeginInvoke(new Action(() => statusLabel.Text = "Processing..."));
					break;
				case DataFeedProcessor.ProcessState.Pause:
					bProcessStarted = false;
					break;
				case DataFeedProcessor.ProcessState.Stop:
					BeginInvoke(new Action(() => EnableAllControls(true)));
					BeginInvoke(new Action(() => btnStart.Text = "Start Auto Update"));
					BeginInvoke(new Action(() => btnStop.Enabled = false));
					BeginInvoke(new Action(() => statusProgressBar.Visible = false));
					BeginInvoke(new Action(() => statusProgressBar.Value = 0));

					if (param == -1)
						BeginInvoke(new Action(() => statusLabel.Text = "Stopped due to connection error"));
					else if (param == 0)
						BeginInvoke(new Action(() => statusLabel.Text = "Stopped by user"));
					else if (param == 1)
						BeginInvoke(new Action(() => statusLabel.Text = "Stopped by time limit"));

					bProcessStarted = false;
					if (Config.RFileOutputConfig.EnableZeroMQ)
						msgSender.Stop();

					break;
				case DataFeedProcessor.ProcessState.Complete:
					BeginInvoke(new Action(() => EnableAllControls(true)));
					BeginInvoke(new Action(() => btnStart.Text = "Start Auto Update"));
					BeginInvoke(new Action(() => btnStop.Enabled = false));
					BeginInvoke(new Action(() => statusProgressBar.Visible = false));
					BeginInvoke(new Action(() => statusProgressBar.Value = 0));
					BeginInvoke(new Action(() => statusLabel.Text = "Completed"));
					bProcessStarted = false;
					if (Config.RFileOutputConfig.EnableZeroMQ)
						msgSender.Stop();
					break;
				case DataFeedProcessor.ProcessState.ConnectionError:
					BeginInvoke(new Action(() => statusLabel.Text = "Connection Error"));
					break;
				case DataFeedProcessor.ProcessState.Waiting:
					BeginInvoke(new Action(() => statusLabel.Text = "Waiting for " + param + " seconds"));
					break;
			}
		}

		private void EnableAllControls(bool bEnable)
		{
			groupGeneralSetting.Enabled = bEnable;
			groupProcessType.Enabled = bEnable;
			groupOptionClean.Enabled = bEnable;
			groupMergeFile.Enabled = bEnable;
			groupAlign.Enabled = bEnable;

			btnStartAlign.Enabled = bEnable;
			btnAddTimeColumn.Enabled = bEnable;
			btnCleanTDOptionList.Enabled = bEnable;
		}

		private void btnAddTimeColumn_Click(object sender, EventArgs e)
		{
			if (string.IsNullOrEmpty(txtInputDataPath.Text))
			{
				MessageBox.Show("Please select a directory containting Input Historical Data files.", GlobalData.AppName, MessageBoxButtons.OK, MessageBoxIcon.Warning);
				SelectText(txtInputDataPath);
				return;
			}
			else if (!Directory.Exists(txtInputDataPath.Text))
			{
				MessageBox.Show("The diretory you have selected does not exist.", GlobalData.AppName, MessageBoxButtons.OK, MessageBoxIcon.Warning);
				SelectText(txtInputDataPath);
				return;
			}
			if (processor.PrepareDataFileList())
			{
				processor.AddTimeColumn();
				MessageBox.Show("Time Column has been added.", GlobalData.AppName, MessageBoxButtons.OK, MessageBoxIcon.Information);

			}
		}

		private void btnCleanTDOptionList_Click(object sender, EventArgs e)
		{
			if (!BindSettings(true, true, true))
				return;

			if (processor.PrepareDataList())
			{
				processor.CleanTDOptionsList();
				MessageBox.Show("Cleanup completed.", GlobalData.AppName, MessageBoxButtons.OK, MessageBoxIcon.Information);
			}
			else
			{
				MessageBox.Show("Failure in cleaning TDOptions", GlobalData.AppName, MessageBoxButtons.OK, MessageBoxIcon.Error);
				return;
			}
		}

		private void radioByToken_CheckedChanged(object sender, EventArgs e)
		{

		}

		private void radioByKey_CheckedChanged(object sender, EventArgs e)
		{

		}

		private void groupAlignData_Load(object sender, EventArgs e)
		{

		}

		private void btnBrowseMergePath_Click(object sender, EventArgs e)
		{
			VistaFolderBrowserDialog folderBrowserDialog = new VistaFolderBrowserDialog();
			folderBrowserDialog.SelectedPath = txtMergeOutputPath.Text;
			if (folderBrowserDialog.ShowDialog() == true)
			{
				GlobalData.Config.MergeOutputPath = folderBrowserDialog.SelectedPath;
				txtMergeOutputPath.Text = folderBrowserDialog.SelectedPath;
			}
		}

		private void btnBrowseTreeFile_Click(object sender, EventArgs e)
		{
			OpenFileDialog openDlg = new OpenFileDialog();
			openDlg.Filter = "Merge TreeList File |*.csv";
			if (openDlg.ShowDialog() == DialogResult.OK)
			{
				GlobalData.Config.MergeTreeFile = openDlg.FileName;
				txtMergeTreeFile.Text = openDlg.FileName;
			}
		}

		private void chkMergeFile_CheckedChanged(object sender, EventArgs e)
		{
			txtMergeOutputPath.Enabled = chkMergeFile.Checked;
			txtMergeTreeFile.Enabled = chkMergeFile.Checked;
			btnBrowseMergePath.Enabled = chkMergeFile.Checked;
			btnBrowseTreeFile.Enabled = chkMergeFile.Checked;
		}

		private async void btnStartAlign_Click(object sender, EventArgs e)
		{
			BindSettings(true, false, false);

			DataAligner aligner = new DataAligner();

			EnableAllControls(false);

			await Task.Run(() => aligner.AlignData(GlobalData.Config.InputHistoricalDataPath, GlobalData.Config.TrimStartDate, GlobalData.Config.TrimStartTime,
				GlobalData.Config.AlignStartTime, GlobalData.Config.AlignEndTime, GlobalData.Config.AlignInterval));

			EnableAllControls(true);

			MessageBox.Show("All files aligned", GlobalData.AppName, MessageBoxButtons.OK, MessageBoxIcon.Information);
		}

		private void btnROutputSetting_Click(object sender, EventArgs e)
		{
			FrmROutputSetting frm = new FrmROutputSetting(Config.RFileOutputConfig);
			frm.ShowDialog();
		}

		private void chkROutput_CheckedChanged(object sender, EventArgs e)
		{
			btnROutputSetting.Enabled = chkROutput.Checked;
		}

		private void btnGetToken_Click(object sender, EventArgs e)
		{
			Process.Start("https://auth.tdameritrade.com/auth?response_type=code&redirect_uri=http%3A%2F%2Flocalhost&client_id=KTBAEPPWUCX8KSO7ANNEKHF3A88IU2T5%40AMER.OAUTHAP");
		}

		private void chkRoundVol_CheckedChanged(object sender, EventArgs e)
		{

		}
	}
}
