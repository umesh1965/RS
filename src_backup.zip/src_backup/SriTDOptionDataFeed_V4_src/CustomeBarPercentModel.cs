﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SriTDDataFeedSetting
{
	public class CustomBarPercentModel
	{
		public string Symbol { get; set; }
		public double BarPercent { get; set; }
		public static List<CustomBarPercentModel> LaodFromCSV(string csvFile)
		{
			double tempValDouble = 0;
			List<CustomBarPercentModel> modelList = new List<CustomBarPercentModel>();
			string[] lines = System.IO.File.ReadAllLines(csvFile);
			for (int i = 1; i < lines.Length; i++)
			{
				string[] cols = lines[i].Split(',');
				if (cols.Length < 2)
					continue;

				CustomBarPercentModel model = new CustomBarPercentModel();
				model.Symbol = cols[0];
				model.BarPercent = double.TryParse(cols[1], out tempValDouble) ? tempValDouble : 0;
				modelList.Add(model);
			}

			return modelList;
		}
	}
}
