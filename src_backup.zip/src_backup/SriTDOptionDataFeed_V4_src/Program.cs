﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sri_TD_Options_DataFeed
{
	static class Program
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main()
		{
			Application.EnableVisualStyles();
			Application.SetCompatibleTextRenderingDefault(false);
			try
			{
				Application.Run(new FrmMain());
			}
			catch (Exception e)
			{
				SriTDDataFeedProcess.DataFeedProcessor.WriteLog("An error occurred", e.Message);
			}
		}
	}
}
