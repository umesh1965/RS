﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace SriTDDataFeedSetting
{
	public class GlobalData
	{
		public static string AppName = "Sri TD Options DataFeed V1";
		
		//public static string TradeApiEndPoint = "https://localhost:44339/home/api";
		//public static string TokenApiEndPoint = "https://localhost:44339/home/gettoken";

		public static string TradeApiEndPoint = "https://api.tdameritrade.com/v1/marketdata/quotes";
		public static string TokenApiEndPoint = "https://api.tdameritrade.com/v1/oauth2/token";

		public static DataFeedConfig Config { get; set; } = new DataFeedConfig();

		public static int DefaultSymbolCountPerAPI = 100;

		public static bool LoadSettings()
		{
			string strFilePath = "config.xml";
			try
			{
				XmlSerializer serializer = new XmlSerializer(typeof(DataFeedConfig));
				FileStream fs = new FileStream(strFilePath, FileMode.Open);
				Config = (DataFeedConfig)serializer.Deserialize(fs);
				fs.Close();
			}
			catch (Exception)
			{
				return false;
			}

			return true;
		}

		public static bool SaveSettings()
		{
			string strFilePath = "config.xml";

			XmlSerializer serializer = new XmlSerializer(typeof(DataFeedConfig));
			FileStream fs = new FileStream(strFilePath, FileMode.Create);
			serializer.Serialize(fs, Config);
			fs.Close();

			return true;
		}

		public static string GetApiRequestUrlForTrade()
		{
			string requestURL = TradeApiEndPoint + "?";
			requestURL += "apikey=" + GlobalData.Config.ApiKey;

			return requestURL;
		}
		public static string CalendarFileName = "market_calendar_file.csv";

		public static string GetCalendarFilePath() => Path.Combine(Environment.CurrentDirectory, CalendarFileName);
	}
	public class DayTradeTimeInfo
	{
		public DateTime Open { get; set; }
		public DateTime Close { get; set; }
	}
}
