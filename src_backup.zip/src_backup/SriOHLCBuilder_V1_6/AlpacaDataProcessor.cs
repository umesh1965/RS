﻿using Alpaca.Markets;
using SriOHLCBuilderModel;
using SriOHLCBuilderModel.Data;
using SriOHLCBuilderModel.Enums;
using SriOHLCBuilderProcess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SriOHLCBuilderProcess
{
	public partial class SriOHLCBuilderProcessor
	{
		private IAlpacaDataClient alpacaDataClient;

		void PrepareAlpacaAPI()
		{
			if (Config.AlpacaConfig.IsLive)
			{
				alpacaDataClient = Environments.Live.GetAlpacaDataClient(new SecretKey(Config.AlpacaConfig.APIKey, Config.AlpacaConfig.SecretKey));
			}
			else
			{
				alpacaDataClient = Environments.Paper.GetAlpacaDataClient(new SecretKey(Config.AlpacaConfig.APIKey, Config.AlpacaConfig.SecretKey));
			}
		}
		async Task<bool> ProcssAlpacaV1Data(List<string> symbols, DataTimeFrame timeFrame, string strPath, bool bCleanup)
		{
			TimeFrame tf = (TimeFrame)Utils.GetTimeFrameForAPI(timeFrame, Config.General.DataFeedSource);
			var barSet = await alpacaDataClient.GetBarSetAsync(new BarSetRequest(symbols, tf) { Limit = Config.General.BarLimit });
			foreach (var symbol in symbols)
			{
				if (bStopProcess)
					break;
				var bars = barSet[symbol].Select(bar => new RawData {
					Datetime = bar.TimeUtc.ToLocalTime(),
					Open = (double)bar.Open,
					High = (double)bar.High,
					Low = (double)bar.Low,
					Close = (double)bar.Close,
					Volume = (double)bar.Volume,
				}).ToList();
				ProcessAPIData(bars, symbol, strPath);
			}

			return true;
		}

		async Task<bool> ProcessAlpacaV2Data(List<string> symbols, string strPath)
		{
			foreach (var symbol in symbols)
			{
				await ProcessAlpacaV2Data(symbol, strPath);
			}

			return true;
		}
		async Task<bool> ProcessAlpacaV2Data(string symbol, string strPath)
		{
			string token = "";
			BarTimeFrame tf = (BarTimeFrame)Utils.GetTimeFrameForAPI(Config.General.TimeFrame, Config.General.DataFeedSource);

			List<RawData> bars = new List<RawData>();
			while (true)
			{
				if (bStopProcess)
					break;
				try
				{
					var request = new HistoricalBarsRequest(symbol, Config.General.StartDate, Config.General.EndDate, tf);
					request.Pagination.Size = (uint)Config.General.BarLimit;
					request.Pagination.Token = token;
					var barSet = await alpacaDataClient.ListHistoricalBarsAsync(request);
					bars.AddRange(barSet.Items.Select(bar => new RawData
					{
						Datetime = bar.TimeUtc.ToLocalTime(),
						Open = (double)bar.Open,
						High = (double)bar.High,
						Low = (double)bar.Low,
						Close = (double)bar.Close,
						Volume = (double)bar.Volume,
					}));

					token = barSet.NextPageToken;
					if (string.IsNullOrEmpty(token))
						break;
				}
				catch (Exception e)
				{
					Utils.WriteLog("ProcessSymbol", e.Message);
				}
			}

			ProcessAPIData(bars, symbol, strPath);

			return true;
		}
	}
}
