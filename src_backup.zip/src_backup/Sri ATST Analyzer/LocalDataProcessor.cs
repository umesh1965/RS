﻿using SriATSTAnalyzerModel;
using SriATSTAnalyzerModel.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SriATSTAnalyzerProcess
{
	public partial class SriATSTAnalyzerProcessor
	{
		void ProcessLocalData(List<string> symbols, int multiplier, PolygonDataFeedSettings config, string strPath, bool isEODGen)
		{
			var barSet = LoadDataFromLocal(symbols, strPath);

			foreach (var symbol in symbols)
			{
				if (!barSet.ContainsKey(symbol))
					continue;

				var bars = barSet[symbol].ToList();

				ProcessAPIData(bars, symbol, multiplier, config, strPath, isEODGen);

				procSymbolCounter++;
				if (procSymbolCounter < procSymbolTotal)
					worker.ReportProgress(procSymbolCounter * 100 / procSymbolTotal);
			}
		}
		bool ProcessLocalData(string symbol, int multiplier, PolygonDataFeedSettings config, string strPath, bool isEODGen)
		{
			var bars = LoadDataFromLocal(symbol, strPath);

			if (bars == null)
			{
				Utils.WriteLog(string.Format("Multiplier {0} for Symbol [{1}] does not exist", multiplier, symbol));
				return false;
			}
			ProcessAPIData(bars, symbol, multiplier, config, strPath, isEODGen);
			return true;
		}
	}
}
