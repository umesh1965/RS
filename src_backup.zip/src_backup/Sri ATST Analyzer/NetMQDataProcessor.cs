﻿using SriATSTAnalyzerModel.Data;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SriATSTAnalyzerProcess
{
	public partial class SriATSTAnalyzerProcessor
	{
		NetMQReceiver netMQReceiver;
		public void ProcessNetMQData()
		{
			if (netMQReceiver == null)
				netMQReceiver = new NetMQReceiver();

			netMQReceiver.MessageProc = new NetMQReceiver.MessageProcDelegate(ProcNetMQData);
			netMQReceiver.Start(Config.NetMQDataFeedConfig.IP, Config.NetMQDataFeedConfig.Port);
		}

		public async void ProcNetMQData(string dataPath)
		{
			if (string.IsNullOrEmpty(dataPath))
				return;

			string strFileName = Path.GetFileName(dataPath).ToUpper();
			bool isSymbolFile = strFileName.IndexOf(".CSV") > 0;
			bool isCycleFinished = strFileName.IndexOf("CYCLE") >= 0;

			if (isSymbolFile && Config.NetMQDataFeedConfig.PerSymbol)
			{
				string symbol = strFileName.Replace(".CSV", "");
				string strFolderPath = Path.GetDirectoryName(dataPath);
				string rootPath = Directory.GetParent(strFolderPath).FullName;
				Config.NetMQDataFeedConfig.DataPath = rootPath;
				ProcessNotifier?.Invoke(ProcessState.ProcessingSymbol, 0, symbol);

				foreach (var multiplier in Config.PolygonConfigMain.Multipliers)
				{
					await ProcessSymbol(symbol, Config.PolygonConfigMain, GlobalData.IsEODGen);
				}
			}
			
			//process entire folder
			if (!isSymbolFile && !isCycleFinished && !Config.NetMQDataFeedConfig.PerSymbol)
			{
				Config.NetMQDataFeedConfig.DataPath = dataPath;

				if (bWorkerIsRunning)
					return;

				bWorkerIsRunning = true;
				worker.RunWorkerAsync();
			}

			if (isCycleFinished && Config.NetMQDataFeedConfig.PerSymbol)
			{
				ProcessNotifier?.Invoke(ProcessState.Complete, 0);
				netMQReceiver.Stop();
			}
		}
	}
}
