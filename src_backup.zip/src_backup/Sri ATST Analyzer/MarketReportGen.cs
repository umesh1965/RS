﻿using SriATSTAnalyzerModel;
using SriATSTAnalyzerModel.Data;
using SriATSTAnalyzerModel.Enums;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SriATSTAnalyzerProcess
{
	public class MarketReportGen
	{
		public void GenerateReport(Dictionary<string, List<RDataRecord>> dataSet, List<TreeItem> treeItemList, MarketViewSettings config, string processType)
		{
			var industryDict = treeItemList.GroupBy(x => x.Industry).ToDictionary(x => x.Key, x => x.Select(y => y.Symbol).ToList());
			var sectorDict = treeItemList.GroupBy(x => x.Sector).ToDictionary(x => x.Key, x => x.Select(y => y.Symbol).ToList());
			string dateTimeNow = DateTime.Now.ToString("yyyy/MM/dd,HH:mm:ss,");

			List<MarketViewModel> allMarketReport = new List<MarketViewModel>();
			for (int i = 0; i < treeItemList.Count; i++)
			{
				string symbol = treeItemList[i].Symbol;

				if (!dataSet.ContainsKey(symbol))
					continue;

				var latestSignal = Utils.GetLatestSignal(dataSet[symbol]);

				if (latestSignal == null)
					continue;

				allMarketReport.Add(new MarketViewModel { TreeInfo = treeItemList[i], Signal = latestSignal });
			}

			string outputFolder = Path.Combine(config.OutputFolder, processType);
			if (config.GenAllMarketView)
			{
				string allMarketReportPath = Path.Combine(outputFolder, "All_Signals_Report.csv");
				if (!Directory.Exists(outputFolder))
				{
					try
					{
						Directory.CreateDirectory(outputFolder);
					}
					catch
					{

					}
				}
				StringBuilder sb = new StringBuilder();
				sb.Append("Symbol,Company,Sector,Industry,Sig_Date,Sig_Time,Signal,Sig_Price").AppendLine();
				foreach (var record in allMarketReport)
				{
					sb.Append(record).AppendLine();
				}

				try
				{
					File.WriteAllText(allMarketReportPath, sb.ToString());
				}
				catch (Exception e)
				{
					Console.WriteLine(e);
				}
			}

			if (config.GenIndustryReport)
			{
				string industryReportPath = Path.Combine(outputFolder, "Industry_Report.csv");
				List<string> records = new List<string>();
				records.Add("Industry,Total_Stocks,Total_Buy,Total_Buy%,Total_Sell,Total_Sell%");
				foreach (var industry in industryDict.Keys)
				{
					int totalStocks = industryDict[industry].Count;
					int totalBuy = allMarketReport.Where(x => x.TreeInfo.Industry == industry && x.Signal.Signal == "BUY").Count();
					int totalSell = allMarketReport.Where(x => x.TreeInfo.Industry == industry && x.Signal.Signal == "SELL").Count();
					double totalBuyPercent = totalBuy / (double)totalStocks;
					double totalSellPercent = totalSell / (double)totalStocks;

					records.Add($"{industry},{totalStocks},{totalBuy},{totalBuyPercent.ToString("0.00")},{totalSell},{totalSellPercent.ToString("0.00")}");
				}
				try
				{
					File.WriteAllLines(industryReportPath, records);
				}
				catch (Exception e)
				{
					Console.WriteLine(e);
				}

				if (config.GenIndustryHistoricalReport)
				{
					string industryHistoricalReportPath = Path.Combine(outputFolder, "INDUSTRY_HISTORY.csv");
					if (!File.Exists(industryHistoricalReportPath))
						File.WriteAllText(industryHistoricalReportPath, "DATE,TIME,Industry,Total_Stocks,Total_Buy,Total_Buy%,Total_Sell,Total_Sell%" + Environment.NewLine);

					StringBuilder sb = new StringBuilder();

					for (int i = 1; i < records.Count; i++)
					{
						sb.AppendLine(dateTimeNow + records[i]);
					}

					File.AppendAllText(industryHistoricalReportPath, sb.ToString());
				}
			}

			if (config.GenSectorReport)
			{
				string sectorReportPath = Path.Combine(outputFolder, "Sector_Report.csv");
				List<string> records = new List<string>();
				records.Add("Industry,Total_Stocks,Total_Buy,Total_Buy%,Total_Sell,Total_Sell%");

				int nAllTotalStocks = 0;
				int nAllBuyTotal = 0;
				int nAllSellTotal = 0;
				foreach (var sector in sectorDict.Keys)
				{
					if (sector == "Transportation")
					{

					}
					int totalStocks = sectorDict[sector].Count;
					int totalBuy = allMarketReport.Where(x => x.TreeInfo.Sector == sector && x.Signal.Signal == "BUY").Count();
					int totalSell = allMarketReport.Where(x => x.TreeInfo.Sector == sector && x.Signal.Signal == "SELL").Count();

					nAllTotalStocks += totalStocks;
					nAllBuyTotal += totalBuy;
					nAllSellTotal += totalSell;

					double totalBuyPercent =  totalBuy / (double)totalStocks;
					double totalSellPercent = totalSell / (double)totalStocks;

					records.Add($"{sector},{totalStocks},{totalBuy},{totalBuyPercent.ToString("0.00")},{totalSell},{totalSellPercent.ToString("0.00")}");
				}

				double allBuyPercent = nAllBuyTotal / (double)nAllTotalStocks;
				double allSellPercent = nAllSellTotal / (double)nAllTotalStocks;

				string allMarketRow = $"ALL_MARKET,{nAllTotalStocks},{nAllBuyTotal},{allBuyPercent.ToString("0.00")},{nAllSellTotal},{allSellPercent.ToString("0.00")}";
				records.Add(allMarketRow);

				try
				{
					File.WriteAllLines(sectorReportPath, records);
				}
				catch (Exception e)
				{
					Console.WriteLine(e);
				}
				if (config.GenAllHistoricalReport)
				{
					string allHistoricalReportPath = Path.Combine(outputFolder, "ALL_MARKET_HISTORY.csv");
					if (!File.Exists(allHistoricalReportPath))
						File.WriteAllText(allHistoricalReportPath, "DATE,TIME,Sector,Total_Stocks,Total_Buy,Total_Buy%,Total_Sell,Total_Sell%" + Environment.NewLine);

					File.AppendAllText(allHistoricalReportPath, dateTimeNow + allMarketRow + Environment.NewLine);
				}

				if (config.GenSectorHistoricalReport)
				{
					string sectorHistoricalReportPath = Path.Combine(outputFolder, "SECTOR_HISTORY.csv");
					if (!File.Exists(sectorHistoricalReportPath))
						File.WriteAllText(sectorHistoricalReportPath, "DATE,TIME,Sector,Total_Stocks,Total_Buy,Total_Buy%,Total_Sell,Total_Sell%" + Environment.NewLine);

					StringBuilder sb = new StringBuilder();

					for (int i = 1; i < records.Count - 1; i++)
					{
						sb.AppendLine(dateTimeNow + records[i]);
					}

					File.AppendAllText(sectorHistoricalReportPath, sb.ToString());
				}
			}
		}
		public void GenMasterColumnReport(Dictionary<string, List<RDataRecord>> dataSet, string outputFolder, ColumnToOutputType column, int rows, bool columnOnly)
		{
			StringBuilder sb = new StringBuilder();
			
			if (!Directory.Exists(outputFolder))
			{
				try
				{
					Directory.CreateDirectory(outputFolder);
				}
				catch
				{

				}
			}
			List<string> headerItems = new List<string>();
			List<string>[] rowItems = new List<string>[rows];
			for (int i = 0; i < rows; i++)
				rowItems[i] = new List<string>();

			foreach (var symbol in dataSet.Keys)
			{
				if (!columnOnly)
				{
					headerItems.Add("DATE");
					headerItems.Add("TIME");
				}
				headerItems.Add(symbol);
				var data = dataSet[symbol];
				if (data.Count > rows)
					data = data.GetRange(data.Count - rows, rows);

				for (int i = 0; i < data.Count; i++)
				{
					if (!columnOnly)
					{
						rowItems[i].Add(data[i].Datetime.ToString("MM/dd/yyyy"));
						rowItems[i].Add(data[i].Datetime.ToString("HH:mm:ss"));
					}

					rowItems[i].Add(column == ColumnToOutputType.Change ? data[i].Change.ToString("0.##") : data[i].Volume.ToString());
				}

				if (data.Count < rows)
				{
					for (int i = data.Count; i < rows; i++)
					{
						if (!columnOnly)
						{
							rowItems[i].Add("");
							rowItems[i].Add("");
						}
						rowItems[i].Add("");
					}
				}
			}

			sb.AppendLine(string.Join(",", headerItems));
			foreach (var row in rowItems)
			{
				sb.AppendLine(string.Join(",", row));
			}

			string reportFile = Path.Combine(outputFolder, "master.csv");
			try
			{
				File.WriteAllText(reportFile, sb.ToString());
			}
			catch(Exception e)
			{
				Utils.WriteLog(e.Message);
			}
		}
	}
}
