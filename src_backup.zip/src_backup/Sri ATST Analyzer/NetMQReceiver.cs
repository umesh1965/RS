﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NetMQ;
using NetMQ.Sockets;

namespace SriATSTAnalyzerProcess
{
	public class NetMQReceiver
	{
        private const int DISCONNECTED = -1;
        public delegate void MessageProcDelegate(string message);
        public MessageProcDelegate MessageProc;
        private SubscriberSocket subscriber;
        private int port;
        public NetMQReceiver()
        {
            port = DISCONNECTED;
        }

        /// <summary>
        /// Start publisher on specified port
        /// </summary>
        /// <param name="port">Port to publish message</param>
        public void Start(string ip, int port)
        {
            try
            {
                this.port = port;

                subscriber = new SubscriberSocket();
                subscriber.Connect($"tcp://{ip}:{port}");
                subscriber.Subscribe("OHLCBuilder");
                Task.Run(() => ReceiveMessage());
            }
            catch (Exception e)
            {

            }
        }

        void ReceiveMessage()
		{
            while (port != DISCONNECTED)
            {
                string messageTopicReceived = "";
                if (subscriber.TryReceiveFrameString(out messageTopicReceived))
				{
                    string messageReceived = subscriber.ReceiveFrameString();
                    MessageProc?.Invoke(messageReceived);
                }
                System.Threading.Thread.Sleep(100);
            }
        }

        /// <summary>
        /// Send broadcast message
        /// </summary>
        /// <param name="msg">message to be sent</param>
        public void SendMessage(string msg)
        {
            lock (this)
            {
                if (port == DISCONNECTED)
                    return;
                subscriber.SendFrame(msg);
            }
        }

        /// <summary>
        /// Stop sending broadcast messsage
        /// </summary>
        public void Stop()
        {
            subscriber.Close();
            port = DISCONNECTED;
        }

        /// <summary>
        /// Dispose and release all resource
        /// </summary>
        public void Dispose()
        {
            subscriber?.Dispose();
        }
    }
}
