﻿using Alpaca.Markets;
using SriATSTAnalyzerModel;
using SriATSTAnalyzerModel.Data;
using SriATSTAnalyzerModel.Enums;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SriATSTAnalyzerProcess
{
	public static class Utils
	{
		public static string GetNameFromTimeFrame(DataTimeFrame tf)
		{
			string name = "";
			switch (tf)
			{
				case DataTimeFrame.Tick:
					name = "Tick";
					break;
				case DataTimeFrame.Second:
					name = "1S";
					break;
				case DataTimeFrame.Minute:
					name = "1Min";
					break;
				case DataTimeFrame.Minute5:
					name = "5Min";
					break;
				case DataTimeFrame.Minute15:
					name = "15Min";
					break;
				case DataTimeFrame.Minute30:
					name = "30Min";
					break;
				case DataTimeFrame.Minute45:
					name = "45Min";
					break;
				case DataTimeFrame.Hour:
					name = "1Hour";
					break;
				case DataTimeFrame.Hour2:
					name = "2Hour";
					break;
				case DataTimeFrame.Hour4:
					name = "4Hour";
					break;
				case DataTimeFrame.Day:
					name = "1D";
					break;
				case DataTimeFrame.Week:
					name = "Week";
					break;
				case DataTimeFrame.Month:
					name = "Month";
					break;
				case DataTimeFrame.Quarter:
					name = "Quarter";
					break;
				case DataTimeFrame.Year:
					name = "Year";
					break;
				default:
					name = "1Min";
					break;
			}

			return name;
		}
		public static DataTimeFrame GetTimeFrameFromName(string itemName)
		{
			DataTimeFrame dataTimeFrame = DataTimeFrame.Minute;
			switch (itemName)
			{
				case "Tick":
					dataTimeFrame = DataTimeFrame.Tick;
					break;
				case "1Min":
					dataTimeFrame = DataTimeFrame.Minute;
					break;
				case "5Min":
					dataTimeFrame = DataTimeFrame.Minute5;
					break;
				case "15Min":
					dataTimeFrame = DataTimeFrame.Minute15;
					break;
				case "30Min":
					dataTimeFrame = DataTimeFrame.Minute30;
					break;
				case "45Min":
					dataTimeFrame = DataTimeFrame.Minute45;
					break;
				case "1Hour":
					dataTimeFrame = DataTimeFrame.Hour;
					break;
				case "2Hour":
					dataTimeFrame = DataTimeFrame.Hour2;
					break;
				case "4Hour":
					dataTimeFrame = DataTimeFrame.Hour4;
					break;
				case "1D":
					dataTimeFrame = DataTimeFrame.Day;
					break;
				case "Week":
					dataTimeFrame = DataTimeFrame.Week;
					break;
				case "Month":
					dataTimeFrame = DataTimeFrame.Month;
					break;
				case "Quarter":
					dataTimeFrame = DataTimeFrame.Quarter;
					break;
				case "Year":
					dataTimeFrame = DataTimeFrame.Year;
					break;
				default:
					dataTimeFrame = DataTimeFrame.Minute;
					break;
			}

			return dataTimeFrame;
		}
		public static int GetTimeFrameForAPI(DataTimeFrame tf, DataFeedSouce dataFeed)
		{
			//else if (dataFeed == DataFeedSouce.PolygonV2)
			//{
			//	if (tf == DataTimeFrame.Minute)
			//		return (int)PolygonTimeSpan.Minute;
			//	if (tf == DataTimeFrame.Hour)
			//		return (int)PolygonTimeSpan.Hour;
			//	if (tf == DataTimeFrame.Day)
			//		return (int)PolygonTimeSpan.Day;
			//	if (tf == DataTimeFrame.Month)
			//		return (int)PolygonTimeSpan.Month;
			//	if (tf == DataTimeFrame.Quarter)
			//		return (int)PolygonTimeSpan.Quarter;
			//}

			return 0;
		}

		public static void WriteLog(string content, string message = null)
		{
			string dateTime = DateTime.Now.ToString();
			try
			{
				File.AppendAllText("error.log", dateTime + " : " + content + " - " + message + Environment.NewLine);
			}
			catch
			{

			}
		}

		public static List<int> LoadMultiplier(string file)
		{
			try
			{
				string[] multiplier = File.ReadAllLines(file);
				if (multiplier.Length == 0)
					return null;

				return multiplier.Select(x => int.Parse(x)).ToList();
			}
			catch
			{
				return null;
			}
		}

		public static List<IntervalTimeData> LoadIntervalFromFile(string filename)
		{
			List<IntervalTimeData> intervals = new List<IntervalTimeData>();
			try
			{
				string[] lines = File.ReadAllLines(filename);
				foreach (var line in lines)
				{
					DateTime tm = new DateTime();
					bool bret = DateTime.TryParseExact(line, "HH:mm", CultureInfo.InvariantCulture, DateTimeStyles.None, out tm);
					IntervalTimeData itd = new IntervalTimeData();
					itd.Hour = tm.Hour;
					itd.Minute = tm.Minute;

					if (bret)
						intervals.Add(itd);
				}
			}
			catch (Exception e)
			{
				WriteLog(e.ToString());
			}
			return intervals;
		}

		public static SignalRecord GetLatestSignal(IReadOnlyList<RDataRecord> dataList)
		{
			for (int i = dataList.Count - 1; i >= 0; i--)
			{
				var data = dataList[i];

				if (data.TrendValue > 0)
					return new SignalRecord { Date = data.Datetime, Price = data.Close, Signal = "BUY" };
				else if (data.TrendValue < 0)
					return new SignalRecord { Date = data.Datetime, Price = data.Close, Signal = "SELL" };
			}

			return null;
		}
	}
}
