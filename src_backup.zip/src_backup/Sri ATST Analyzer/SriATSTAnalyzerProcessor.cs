﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Alpaca.Markets;
using SriATSTAnalyzerModel;
using System.Net.Http;
using WebSocket4Net;
using System.Security.Authentication;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using TwelveDataSharp;
using PusherServer;
using SriATSTAnalyzerModel.Enums;
using SriATSTAnalyzerModel.Data;

namespace SriATSTAnalyzerProcess
{
	public partial class SriATSTAnalyzerProcessor
	{
		private const int RDataItemCount = 117;
		public delegate void ProcessNotifierDelegate(ProcessState state, int nParam, string strParam = "");
		public delegate void MessageSenderDeleagate(string msg);
		public ProcessNotifierDelegate ProcessNotifier { get; set; }
		public MessageSenderDeleagate MessageSender { get; set; }
		public enum ProcessState { None, Start, Stop, Progress, Pause, Complete, ConnectionError, TimeOut, Waiting, UnknownError, SocketConnected, Appended, Calendar, ROutputStart, ROutputCompleted, LimitExceeded, WaitingMessage, ProcessingSymbol }
		protected List<string> symbolListAll { get; set; } = new List<string>();
		private int nSymbolPointer = 0;
		private int nDataTypePointer = 0;
		private bool bIsProcessing;
		private bool bStopProcess;
		private int procSymbolCounter = 0;
		private int procSymbolTotal = 0;
		MarketReportGen reportGenerator = new MarketReportGen();
		public List<DataTimeFrame> TimeFrames { get; set; }
		private List<DayTradeTime> tradeTimeList = new List<DayTradeTime>();

		private Dictionary<int, Dictionary<string, List<RawData>>> originalData = new Dictionary<int, Dictionary<string, List<RawData>>>();
		private Dictionary<string, List<double>> eodDataSet = new Dictionary<string, List<double>>();
		Dictionary<DataTimeFrame, int> tfIntervals = new Dictionary<DataTimeFrame, int>();
		List<int> multipliers = new List<int>();
		BackgroundWorker worker = new BackgroundWorker();
		BackgroundWorker workerTSTick = new BackgroundWorker();
		BackgroundWorker workerCleanup = new BackgroundWorker();
		List<IntervalTimeData> intervalData = new List<IntervalTimeData>();
		public SriATSTAnalyzerSettings Config
		{
			get
			{
				return GlobalData.Config;
			}
		}
		public bool StopROutput { get; set; }

		bool bWorkerIsRunning = false;

		public SriATSTAnalyzerProcessor()
		{
			tfIntervals.Add(DataTimeFrame.Second, 1);
			tfIntervals.Add(DataTimeFrame.Minute, 1);
			tfIntervals.Add(DataTimeFrame.Minute5, 5);
			tfIntervals.Add(DataTimeFrame.Minute15, 15);
			tfIntervals.Add(DataTimeFrame.Hour, 60);
			tfIntervals.Add(DataTimeFrame.Day, 1440);
			tfIntervals.Add(DataTimeFrame.Week, 10080);
			tfIntervals.Add(DataTimeFrame.Month, 43200);
			tfIntervals.Add(DataTimeFrame.Quarter, 129600);
			tfIntervals.Add(DataTimeFrame.Year, 518400);

			worker.WorkerReportsProgress = true;
			worker.DoWork += worker_DoWork;
			worker.ProgressChanged += worker_ProgressChanged;
			worker.RunWorkerCompleted += worker_RunWorkerCompleted;
		}

		private void worker_DoWork(object sender, DoWorkEventArgs e)
		{
			//try
			{
				if (Config.Cal.OutputOnlyXIntervalRows)
					intervalData = Utils.LoadIntervalFromFile(Config.Cal.OutputXIntervalFile);

				int nThreadCount = Environment.ProcessorCount;

				int nNeedApiCallCount = symbolListAll.Count / 100;

				nThreadCount = Math.Min(nThreadCount, nNeedApiCallCount);

				if (nThreadCount == 0)
					nThreadCount = 1;

				var query = symbolListAll
					   .Select((p, index) => new { p, GroupIndex = index % nThreadCount })
					   .GroupBy(p => p.GroupIndex)
					   .ToArray();

				nThreadCount = query.Length;

				ProcessNotifier?.Invoke(ProcessState.Start, symbolListAll.Count);

				var watch = System.Diagnostics.Stopwatch.StartNew();
				Task[] tasks = new Task[nThreadCount];

				List<PolygonDataFeedSettings> polygonConfigs = new List<PolygonDataFeedSettings>();
				if (GlobalData.IsEODGen)
				{
					LoadPolygonConfigFromFile(Config.General.EODATSTPolygonSettingFile);
					polygonConfigs.AddRange(Config.PolygonConfigEODATST);
				}
				else
					polygonConfigs.Add(Config.PolygonConfigMain);

				procSymbolCounter = 0;
				procSymbolTotal = symbolListAll.Count * polygonConfigs.Count;

				for (int i = 0; i < nThreadCount; i++)
				{
					var symbols = query[i].Select(p => p.p).ToList();

					tasks[i] = Task.Run(() => Run(symbols, polygonConfigs, GlobalData.IsEODGen));
				}
				Task.WaitAll(tasks);
				watch.Stop();

				if (GlobalData.IsEODGen)
				{
					GenerateEODFiles(polygonConfigs);
				}

				if (Config.MarketViewConfig.EnableMarketView)
				{
					GenerateReports(Config.PolygonConfigMain);
				}

				if (Config.AWSS3Config.UseAWSUpload)
				{
					var taskUploader = Task.Run(() => UploadResult());
				}
			}
			//catch
			//{
			//	ProcessNotifier?.Invoke(ProcessState.UnknownError, 0);
			//}
		}
		private void GenerateReports(PolygonDataFeedSettings config)
		{
			string dataFolder = Config.General.OutputFolder;
			var treeInfo = SriATSTAnalyzerServices.LoadTreeInfoFromFile(Config.MarketViewConfig.MappingFile);

			var atDataSet = SriATSTAnalyzerServices.LoadRDataFromFolder(dataFolder, "AT");
			reportGenerator.GenerateReport(atDataSet, treeInfo, Config.MarketViewConfig, "AT");

			var stDataSet = SriATSTAnalyzerServices.LoadRDataFromFolder(dataFolder, "ST");
			reportGenerator.GenerateReport(stDataSet, treeInfo, Config.MarketViewConfig, "ST");
		}
		private void worker_ProgressChanged(object sender, ProgressChangedEventArgs e)
		{
			ProcessNotifier?.Invoke(ProcessState.Progress, e.ProgressPercentage);
		}
		private void worker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
		{
			ProcessNotifier?.Invoke(ProcessState.Complete, 0);
			bWorkerIsRunning = false;
			bStopProcess = false;

			if (Config.General.DataFeedSource == DataFeedSouce.NETMQ)
			{
				netMQReceiver.Stop();
			}
		}
		public void Start()
		{
			Config.PolygonConfigMain.Multipliers = Utils.LoadMultiplier(Config.General.MultiplierFile).ToArray();

			if (Config.General.DataFeedSource == DataFeedSouce.NETMQ)
			{
				ProcessNotifier?.Invoke(ProcessState.WaitingMessage, 0);
				ProcessNetMQData();
			}
			else
			{
				if (bWorkerIsRunning)
					return;

				bWorkerIsRunning = true;
				worker.RunWorkerAsync();
			}
		}

		public void ClearOriginalData()
		{
			originalData.Clear();
		}
		private string GetSymbolFromPath(string path)
		{
			FileInfo file = new FileInfo(path);
			string[] info = file.Name.Split('-');
			if (info.Length >= 2)
				return info[0];

			return null;
		}

		public void PrepareAPIClient()
		{

		}

		private void OutputRawDataToFile(List<RawData> dataList, string symbol, string outputPath)
		{
			StringBuilder sb = new StringBuilder();
			sb.Append("Date,Time,Open,High,Low,Close,Volume");

			foreach (var data in dataList)
				sb.Append(data).AppendLine();

			try
			{
				if (!Directory.Exists(outputPath))
					Directory.CreateDirectory(outputPath);

				string strFilePath = Path.Combine(outputPath, symbol + ".csv");
				File.WriteAllText(strFilePath, sb.ToString());
			}
			catch (Exception ex)
			{
				Console.Write(ex);
			}
		}

		public async Task Run(List<string> symbols, List<PolygonDataFeedSettings> configs, bool isEODGen = false)
		{
			bStopProcess = false;

			List<DataTimeFrame> timeFrames = new List<DataTimeFrame>();

			for (int k = 0; k < configs.Count; k++)
			{
				if (bStopProcess)
					break;

				var startTime = DateTime.Now;
				bool bRet = await ProcessSymbol(symbols, configs[k], isEODGen);

				double elapsed = (DateTime.Now - startTime).TotalMilliseconds;
				if (elapsed < 500)
				{
					int timeToWait = Math.Max(0, (int)(500 - elapsed));
					System.Threading.Thread.Sleep(timeToWait);
				}
			}

			if (Config.NetMQConfig.EnableZMQ && Config.NetMQConfig.SendPerCycle)
				MessageSender?.Invoke(Config.General.OutputFolder);

			if (bStopProcess)
				ProcessNotifier?.Invoke(ProcessState.Stop, 0);

			bIsProcessing = false;
			bStopProcess = false;

			StopROutput = true;

			//worker.ReportProgress(symbols.Count * 100 / symbolListAll.Count);
		}
		private double GetCloseBarValue(double open, double high, double low, double close)
		{
			if (Config.General.CloseBarUpdateMode == 0)     //HLC
				return (high + low + close) / 3.0;
			else if (Config.General.CloseBarUpdateMode == 1)    //OHLC
				return (open + high + low + close) / 4.0;
			else if (Config.General.CloseBarUpdateMode == 2)    //HL
				return (high + low) / 2.0;
			else
			{
				if (close > open)
					return high;
				else if (close < open)
					return low;
				else
					return close;
			}
		}

		private DateTime GetLastDataTimeFromFile(string filePath)
		{
			if (File.Exists(filePath))
			{
				try
				{
					using (var fs = new FileStream(filePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
					{
						StreamReader sr = new StreamReader(fs);

						string line, lastLine = "";
						bool bFirstLine = true;
						while ((line = sr.ReadLine()) != null)
						{
							if (bFirstLine)
							{
								bFirstLine = false;
								continue;
							}
							if (!string.IsNullOrEmpty(line))
								lastLine = line;
						}
						sr.Close();

						string[] items = lastLine.Split(',');

						if (items.Length < 2)
							return new DateTime(1970, 1, 1);

						return DateTime.Parse(items[0] + " " + items[1]);
					}
				}
				catch (Exception e)
				{
					Utils.WriteLog("Error reading File " + filePath, e.Message);
					return new DateTime(1970, 1, 1);
				}
			}
			else
				return new DateTime(1970, 1, 1);
		}

		Dictionary<string, List<RawData>> LoadDataFromLocal(List<string> symbols, string folder)
		{
			Dictionary<string, List<RawData>> localData = new Dictionary<string, List<RawData>>();

			foreach (var symbol in symbols)
			{
				localData[symbol] = LoadDataFromLocal(symbol, folder);
			}

			return localData;
		}
		List<RawData> LoadDataFromLocal(string symbol, string folder)
		{

			string symbol_ = symbol.Replace(":", ".");
			symbol_ = symbol.Replace("/", "");
			string filePath = Path.Combine(folder, symbol_ + ".csv");

			if (!File.Exists(filePath))
				return null;
			
			var localData = SriATSTAnalyzerServices.LoadRawDataFromCsv(filePath, false);

			return localData;
		}

		private void ProcessAPIData(IReadOnlyList<RawData> bars, string symbol, int multiplier, PolygonDataFeedSettings config, string strFilePath, bool isEODGen)
		{
			symbol = symbol.Replace(":", "");
			symbol = symbol.Replace("\\", "");
			symbol = symbol.Replace("/", "");

			if (!Directory.Exists(strFilePath))
				Directory.CreateDirectory(strFilePath);

			var strOutputFile = Path.Combine(strFilePath, symbol + ".csv");

			StringBuilder sb = new StringBuilder();

			//create header only in non-append mode
			if ((!Config.General.AppendUpdatedData && !config.BackfillUpate) || !File.Exists(strOutputFile))
			{
				sb.Append("Date,Time,Open,High,Low,Close,Volume");
				sb.Append(Environment.NewLine);
			}


			List<string> dataList = new List<string>();

			List<RawData> rawDataList = new List<RawData>();

			foreach (var bar in bars)
			{
				DateTime barTime = bar.Datetime;
				if (Config.General.EnableMarketTimeOnly && (int)config.TimeFrame < 5)
				{
					DateTime startTime = new DateTime(barTime.Year, barTime.Month, barTime.Day,
												Config.General.MarketStartTime.Hour, Config.General.MarketStartTime.Minute, 0);
					DateTime endTime = new DateTime(barTime.Year, barTime.Month, barTime.Day,
												Config.General.MarketEndTime.Hour, Config.General.MarketEndTime.Minute, 0);

					if (barTime < startTime || barTime > endTime)
						continue;
				}

				RawData inputData = bar;

				if (Config.General.EnableCloseBarUpdate)
				{
					inputData.Close = GetCloseBarValue(Convert.ToDouble(bar.Open), Convert.ToDouble(bar.High),
						Convert.ToDouble(bar.Low), Convert.ToDouble(bar.Close));
				}

				if (inputData.Close == 0)
					continue;

				rawDataList.Add(inputData);
				dataList.Add(inputData.ToString());
			}

			//find last row
			DateTime lastDataTime = config.BackfillUpate ? GetLastDataTimeFromFile(strOutputFile) : DateTime.Now.AddMinutes(30);

			int nLastRow = -1;

			if (rawDataList.Count == 0)
				return;

			if (rawDataList.Last().Datetime < lastDataTime)
			{
				if (config.BackfillUpate)
					nLastRow = dataList.Count;
			}
			else
			{
				for (int i = 0; i < rawDataList.Count; i++)
				{
					if (rawDataList[i].Datetime == lastDataTime)
					{
						nLastRow = i;
						break;
					}
					else if (rawDataList[i].Datetime > lastDataTime)
					{
						nLastRow = i - 1;
						break;
					}
				}
			}

			for (int i = nLastRow + 1; i < dataList.Count; i++)
			{
				sb.Append(dataList[i]).Append(Environment.NewLine);
			}

			if (nLastRow > 0 && (config.BackfillUpate || Config.General.AppendUpdatedData))
				rawDataList = rawDataList.Skip(nLastRow).ToList();


			//if backfill enabled, load original date to generate R File
			lock (originalData)
			{
				if (!originalData.ContainsKey(multiplier))
					originalData[multiplier] = new Dictionary<string, List<RawData>>();

				if (!originalData[multiplier].ContainsKey(symbol))
				{
					if (config.BackfillUpate)
					{
						List<RawData> oldData = SriATSTAnalyzerServices.LoadRawDataFromCsv(strOutputFile);
						originalData[multiplier][symbol] = oldData;
						oldData.AddRange(rawDataList);
					}
					else
					{
						originalData[multiplier][symbol] = rawDataList;
					}
				}
				else
				{
					if (config.BackfillUpate)
						originalData[multiplier][symbol].AddRange(rawDataList);
					else
						originalData[multiplier][symbol] = rawDataList;
				}
			}

			try
			{
				if (Config.General.AppendUpdatedData || config.BackfillUpate)
					File.AppendAllText(strOutputFile, sb.ToString());
				else
					File.WriteAllText(strOutputFile, sb.ToString());
			}
			catch (Exception e)
			{
				Utils.WriteLog("Error writing stock data for " + symbol, e.Message);
			}
		}
		string GetTimeFrameSuffix(DataTimeFrame tf)
		{
			if (tf == DataTimeFrame.Minute)
				return "M";
			else if (tf == DataTimeFrame.Day)
				return "D";
			else if (tf == DataTimeFrame.Week)
				return "D";
			else if (tf == DataTimeFrame.Month)
				return "MO";

			return "";
		}
		private async Task<bool> ProcessSymbol(List<string> symbols, PolygonDataFeedSettings config, bool isEODGen = false)
		{
			bool bRet = true;
			foreach (var symbol in symbols)
			{
				if (bStopProcess)
					break;

				bRet = await ProcessSymbol(symbol, config, isEODGen);

				procSymbolCounter++;
				if (procSymbolCounter < procSymbolTotal)
					worker.ReportProgress(procSymbolCounter * 100 / procSymbolTotal);

				if (!bRet)
					break;
			}
			
			return bRet;
		}

		private async Task<bool> ProcessSymbol(string symbol, PolygonDataFeedSettings config, bool isEODGen = false)
		{
			List<RDataRecord> atDataSet = new List<RDataRecord>();
			List<RDataRecord> stDataSet = new List<RDataRecord>();
			List<RDataRecord> adxDataSet = new List<RDataRecord>();
			bool bRet = true;
			foreach (var multiplier in config.Multipliers)
			{
				string strFolder = "";
				if (isEODGen)
					strFolder = Config.General.InputEODATSTFolder;
				else
					strFolder = Config.General.InputFolder;

				if (Config.General.DataFeedSource == DataFeedSouce.NETMQ)
					strFolder = Config.NetMQDataFeedConfig.DataPath;

				strFolder = Path.Combine(strFolder, multiplier.ToString() + GetTimeFrameSuffix(config.TimeFrame));

				switch (Config.General.DataFeedSource)
				{
					case DataFeedSouce.NETMQ:
					case DataFeedSouce.OnlyLocalData:
						bRet = ProcessLocalData(symbol, multiplier, config, strFolder, isEODGen);
						break;
					case DataFeedSouce.PolygonV2:
						bRet = await ProcessPolygonData(symbol, config, multiplier, strFolder, isEODGen);
						break;
				}
				if (!bRet)
					break;
				if (!isEODGen)
				{
					MergePolygonData(symbol, multiplier, atDataSet, stDataSet, adxDataSet);
				}
				else
				{
					if (originalData.ContainsKey(multiplier))
						MergeEODData(symbol, multiplier, originalData[multiplier][symbol], config);
				}
			}

			if (bRet)
			{
				if (!isEODGen)
				{

					if (Config.Cal.OutputOnlyXIntervalRows)
					{
						RemoveByXInterval(atDataSet);
						RemoveByXInterval(stDataSet);
						RemoveByXInterval(adxDataSet);
					}
					if (Config.Cal.AlignedOutputFile)
						OutputAlignedFile(symbol, atDataSet, stDataSet, adxDataSet);

					if (atDataSet != null)
					{
						//CalAvg
						if (Config.Cal.EnableCalAvg)
							CalLavg(atDataSet);
						if (Config.Cal.UseLavgForL)
							CalcLevelFromLavg(atDataSet);
						if (Config.Cal.CalSignal)
							CalcSignalFromLavg(atDataSet);
					}
					if (stDataSet != null)
					{
						if (Config.Cal.EnableCalAvg)
							CalLavg(stDataSet);
						if (Config.Cal.UseLavgForL)
							CalcLevelFromLavg(stDataSet);
						if (Config.Cal.CalSignal)
							CalcSignalFromLavg(stDataSet);
					}

					if (adxDataSet != null)
					{
						if (Config.Cal.EnableCalAvg)
							CalLavg(adxDataSet);
						if (Config.Cal.UseLavgForL)
							CalcLevelFromLavg(adxDataSet);
						if (Config.Cal.CalSignal)
							CalcSignalFromLavg(adxDataSet);
					}

					//output result
					if (!Config.Cal.DontIndividualTrend)
						OutputMergedData(symbol, atDataSet, stDataSet, adxDataSet, config);
				}
			}

			return bRet;
		}
		void RemoveByXInterval(List<RDataRecord> dataSet)
		{
			{
				int base_i = 0;

				for (int i = 0; i < dataSet.Count; i++)
				{
					if (base_i >= intervalData.Count)
						base_i = 0;

					if (intervalData[base_i].Hour > dataSet[i].Datetime.Hour)
						dataSet.RemoveAt(i--);
					else if (intervalData[base_i].Hour < dataSet[i].Datetime.Hour)
						base_i++;
					else
					{
						if (intervalData[base_i].Minute > dataSet[i].Datetime.Minute)
							dataSet.RemoveAt(i--);
						else
							base_i++;
					}
				}
			}
		}
		void OutputAlignedFile(string symbol, List<RDataRecord> atData, List<RDataRecord> stData, List<RDataRecord> adxData)
		{
			if (atData.Count == 0)
				return;

			List<RDataRecord> alignedData = atData.ToList();
			for (int i = 0; i < atData.Count; i++)
			{
				var at = atData[i];
				var st = stData[i];
				var adx = adxData[i];

				for (int j = 0; j < at.LValues.Count; j++)
				{
					if (alignedData[i].LValues.Count <= j || at.LValues.Count <= j || st.LValues.Count <= j)
					{

					}
					alignedData[i].LValues[j] = at.LValues[j] + st.LValues[j] + adx.LValues[j];
				}
			}

			if (Config.Cal.EnableCalAvg)
				CalLavg(alignedData);
			if (Config.Cal.UseLavgForL)
				CalcLevelFromLavg(alignedData);
			if (Config.Cal.CalSignal)
				CalcSignalFromLavg(alignedData);

			string header = alignedData[0].Header() + ",";

			header += string.Join(",", Config.PolygonConfigMain.Multipliers.Select(x => "L" + x));

			string outputPath = Path.Combine(Config.General.OutputFolder, "aligned");
			if (!Directory.Exists(outputPath))
				Directory.CreateDirectory(outputPath);

			if (Config.Cal.OutputOnlyXRows)
			{
				int skipCount = alignedData.Count - Config.Cal.OutputXRowsCount;
				if (skipCount > 0)
					alignedData = alignedData.Skip(skipCount).ToList();
			}

			string filename = Path.Combine(outputPath, symbol + ".csv");
			File.WriteAllText(filename, header + Environment.NewLine);
			File.AppendAllLines(filename, alignedData.Select(x => x.ToString()));
		}
		public bool PrepareStockSymbolList(string fileName, bool bAdd = false)
		{
			try
			{
				using (var fs = new FileStream(fileName, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
				{
					StreamReader sr = new StreamReader(fs);

					string line;

					if (!bAdd)
						symbolListAll.Clear();

					while ((line = sr.ReadLine()) != null)
					{
						if (string.IsNullOrEmpty(line))
							continue;

						symbolListAll.Add(line);
					}

					nSymbolPointer = 0;
					nDataTypePointer = 0;
					sr.Close();
				}
			}
			catch (Exception e)
			{
				Utils.WriteLog("Failed to load symbol list from the input file.", e.Message);
				return false;
			}

			return true;
		}

		public void Stop()
		{
			bStopProcess = true;
			if (Config.General.DataFeedSource == DataFeedSouce.NETMQ)
				netMQReceiver.Stop();
		}

		public void Pause()
		{
			bIsProcessing = false;
		}
		
		string GetOutputPathWithTimeFrame(DataTimeFrame tf)
		{
			string strTimeFrame = Utils.GetNameFromTimeFrame(tf);

			string path = Path.Combine(Config.General.OutputFolder, strTimeFrame);

			return path;
		}

		List<RawData> updatedData = new List<RawData>();
		DateTime lastFetchTime = DateTime.Now;

		public void PrepareCalendarListFromFile()
		{
			tradeTimeList.Clear();
			try
			{
				TimeZoneInfo estTimeZone = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");

				using (var fs = new FileStream(GlobalData.GetCalendarFilePath(), FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
				{
					StreamReader sr = new StreamReader(fs);
					string line = sr.ReadLine();        //header row
					while ((line = sr.ReadLine()) != null)
					{
						string[] items = line.Split(',');
						if (items.Length < 3)
							continue;

						try
						{
							var dayTradeTime = new DayTradeTime();
							dayTradeTime.Open = TimeZoneInfo.ConvertTimeToUtc(DateTime.ParseExact(items[0] + " " + items[1],
															"MM/dd/yyyy HH:mm", CultureInfo.InvariantCulture), estTimeZone);
							dayTradeTime.Close = TimeZoneInfo.ConvertTimeToUtc(DateTime.ParseExact(items[0] + " " + items[2],
															"MM/dd/yyyy HH:mm", CultureInfo.InvariantCulture), estTimeZone);

							tradeTimeList.Add(dayTradeTime);
						}
						catch
						{

						}
					}
					sr.Close();
				}
			}
			catch (Exception e)
			{
				Utils.WriteLog("Error reading calendar File", e.Message);
			}
		}

		//time to check in UTC timezone
		public bool IsTimeInMarketHour(DateTime time)
		{
			foreach (var day in tradeTimeList)
			{
				if (time.Date == day.Open.Date)
				{
					Config.General.MarketStartTime = day.Open.ToLocalTime();
					Config.General.MarketEndTime = day.Close.ToLocalTime();

					if (time >= day.Open && time < day.Close)
						return true;

					break;
				}
			}
			return false;
		}

		public bool IsLocalTimeInMarketHour(DateTime localTime)
		{
			DateTime now = DateTime.Now;

			DateTime startTime = new DateTime(now.Year, now.Month, now.Day,
													GlobalData.Config.General.MarketStartTime.Hour, GlobalData.Config.General.MarketStartTime.Minute, 0);
			DateTime endTime = new DateTime(now.Year, now.Month, now.Day,
										GlobalData.Config.General.MarketEndTime.Hour, GlobalData.Config.General.MarketEndTime.Minute, 0);

			if (startTime > now || endTime < now)
				return false;

			return true;
		}

		public void CleanupStockList()
		{
			workerCleanup.RunWorkerAsync();
		}

		public void SendPushNotification(string param, bool status)
		{
			var options = new PusherOptions
			{
				Cluster = Config.PusherConfig.Cluster,
				Encrypted = true
			};

			var pusher = new Pusher(Config.PusherConfig.AppID, Config.PusherConfig.Key, Config.PusherConfig.Secret, options);

			string message = status ? "Done" : "Error";
			var result = pusher.TriggerAsync(
			  param,
			  "Upload",
			  new { message = "Done" }).GetAwaiter().GetResult();
		}

		void UploadResult()
		{
			AWSS3Uploader awsUploader = new AWSS3Uploader();

			bool ret = true;
			if (Config.AWSS3Config.UseGZipFolder)
			{
				ret &= awsUploader.UploadFilesAsFolder(Config.General.OutputFolder, "", Config.AWSS3Config);
			}
			if (Config.AWSS3Config.UseGZipIndividual)
				awsUploader.UploadFilesInFolder(Config.General.OutputFolder, "", Config.AWSS3Config);

			if (Config.AWSS3Config.MarketView)
			{
				ret &= awsUploader.UploadMarketViewAndMasterSignal(
					Path.Combine(Config.MarketViewConfig.OutputFolder, "AT")
					, Config.AWSS3Config, "AT");

				ret &= awsUploader.UploadMarketViewAndMasterSignal(
					Path.Combine(Config.MarketViewConfig.OutputFolder, "ST")
					, Config.AWSS3Config, "ST");
			}

			if (Config.PusherConfig.SendAWSS3GzipFolder)
				SendPushNotification("SriATST", ret);
		}
	}
}
