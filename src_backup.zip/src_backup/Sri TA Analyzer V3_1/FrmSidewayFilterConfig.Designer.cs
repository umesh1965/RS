﻿
namespace SriTAAnalyzer
{
	partial class FrmSidewayFilterConfig
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btnOK = new System.Windows.Forms.Button();
			this.btnCancel = new System.Windows.Forms.Button();
			this.groupBoxSideway = new System.Windows.Forms.GroupBox();
			this.chkApplySidewayFilter = new System.Windows.Forms.CheckBox();
			this.chkUpToBottom = new System.Windows.Forms.CheckBox();
			this.chkUseSumLogic = new System.Windows.Forms.CheckBox();
			this.label6 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.txtExceptionPercent = new System.Windows.Forms.TextBox();
			this.txtLookbackRows = new System.Windows.Forms.TextBox();
			this.chkSidewayFilter = new System.Windows.Forms.CheckBox();
			this.groupBoxSideway.SuspendLayout();
			this.SuspendLayout();
			// 
			// btnOK
			// 
			this.btnOK.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnOK.Location = new System.Drawing.Point(53, 214);
			this.btnOK.Name = "btnOK";
			this.btnOK.Size = new System.Drawing.Size(131, 36);
			this.btnOK.TabIndex = 21;
			this.btnOK.Text = "OK";
			this.btnOK.UseVisualStyleBackColor = true;
			this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
			// 
			// btnCancel
			// 
			this.btnCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnCancel.Location = new System.Drawing.Point(217, 214);
			this.btnCancel.Name = "btnCancel";
			this.btnCancel.Size = new System.Drawing.Size(131, 36);
			this.btnCancel.TabIndex = 22;
			this.btnCancel.Text = "Cancel";
			this.btnCancel.UseVisualStyleBackColor = true;
			this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
			// 
			// groupBoxSideway
			// 
			this.groupBoxSideway.Controls.Add(this.chkApplySidewayFilter);
			this.groupBoxSideway.Controls.Add(this.chkUpToBottom);
			this.groupBoxSideway.Controls.Add(this.chkUseSumLogic);
			this.groupBoxSideway.Controls.Add(this.label6);
			this.groupBoxSideway.Controls.Add(this.label3);
			this.groupBoxSideway.Controls.Add(this.txtExceptionPercent);
			this.groupBoxSideway.Controls.Add(this.txtLookbackRows);
			this.groupBoxSideway.Location = new System.Drawing.Point(12, 19);
			this.groupBoxSideway.Name = "groupBoxSideway";
			this.groupBoxSideway.Size = new System.Drawing.Size(380, 189);
			this.groupBoxSideway.TabIndex = 23;
			this.groupBoxSideway.TabStop = false;
			// 
			// chkApplySidewayFilter
			// 
			this.chkApplySidewayFilter.AutoSize = true;
			this.chkApplySidewayFilter.CheckAlign = System.Drawing.ContentAlignment.BottomLeft;
			this.chkApplySidewayFilter.Checked = true;
			this.chkApplySidewayFilter.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chkApplySidewayFilter.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.chkApplySidewayFilter.Location = new System.Drawing.Point(27, 92);
			this.chkApplySidewayFilter.Name = "chkApplySidewayFilter";
			this.chkApplySidewayFilter.Size = new System.Drawing.Size(120, 17);
			this.chkApplySidewayFilter.TabIndex = 30;
			this.chkApplySidewayFilter.Text = "Apply Sideway Filter";
			this.chkApplySidewayFilter.UseVisualStyleBackColor = true;
			// 
			// chkUpToBottom
			// 
			this.chkUpToBottom.AutoSize = true;
			this.chkUpToBottom.CheckAlign = System.Drawing.ContentAlignment.BottomLeft;
			this.chkUpToBottom.Checked = true;
			this.chkUpToBottom.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chkUpToBottom.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.chkUpToBottom.Location = new System.Drawing.Point(27, 122);
			this.chkUpToBottom.Name = "chkUpToBottom";
			this.chkUpToBottom.Size = new System.Drawing.Size(157, 17);
			this.chkUpToBottom.TabIndex = 26;
			this.chkUpToBottom.Text = "Remove From Up to Bottom";
			this.chkUpToBottom.UseVisualStyleBackColor = true;
			// 
			// chkUseSumLogic
			// 
			this.chkUseSumLogic.AutoSize = true;
			this.chkUseSumLogic.CheckAlign = System.Drawing.ContentAlignment.BottomLeft;
			this.chkUseSumLogic.Checked = true;
			this.chkUseSumLogic.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chkUseSumLogic.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.chkUseSumLogic.Location = new System.Drawing.Point(27, 152);
			this.chkUseSumLogic.Name = "chkUseSumLogic";
			this.chkUseSumLogic.Size = new System.Drawing.Size(98, 17);
			this.chkUseSumLogic.TabIndex = 25;
			this.chkUseSumLogic.Text = "Use Sum Logic";
			this.chkUseSumLogic.UseVisualStyleBackColor = true;
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label6.Location = new System.Drawing.Point(24, 62);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(65, 13);
			this.label6.TabIndex = 23;
			this.label6.Text = "Exception %";
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label3.Location = new System.Drawing.Point(24, 24);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(85, 13);
			this.label3.TabIndex = 24;
			this.label3.Text = "Lookback Rows";
			// 
			// txtExceptionPercent
			// 
			this.txtExceptionPercent.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txtExceptionPercent.Location = new System.Drawing.Point(147, 59);
			this.txtExceptionPercent.Name = "txtExceptionPercent";
			this.txtExceptionPercent.Size = new System.Drawing.Size(148, 20);
			this.txtExceptionPercent.TabIndex = 21;
			this.txtExceptionPercent.Text = "0.10";
			// 
			// txtLookbackRows
			// 
			this.txtLookbackRows.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txtLookbackRows.Location = new System.Drawing.Point(147, 21);
			this.txtLookbackRows.Name = "txtLookbackRows";
			this.txtLookbackRows.Size = new System.Drawing.Size(148, 20);
			this.txtLookbackRows.TabIndex = 22;
			this.txtLookbackRows.Text = "3";
			// 
			// chkSidewayFilter
			// 
			this.chkSidewayFilter.AutoSize = true;
			this.chkSidewayFilter.CheckAlign = System.Drawing.ContentAlignment.BottomLeft;
			this.chkSidewayFilter.Checked = true;
			this.chkSidewayFilter.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chkSidewayFilter.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.chkSidewayFilter.Location = new System.Drawing.Point(23, 13);
			this.chkSidewayFilter.Name = "chkSidewayFilter";
			this.chkSidewayFilter.Size = new System.Drawing.Size(127, 17);
			this.chkSidewayFilter.TabIndex = 24;
			this.chkSidewayFilter.Text = "Enable Sideway Filter";
			this.chkSidewayFilter.UseVisualStyleBackColor = true;
			this.chkSidewayFilter.CheckedChanged += new System.EventHandler(this.chkSidewayFilter_CheckedChanged);
			// 
			// FrmSidewayFilterConfig
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(404, 265);
			this.Controls.Add(this.chkSidewayFilter);
			this.Controls.Add(this.btnCancel);
			this.Controls.Add(this.btnOK);
			this.Controls.Add(this.groupBoxSideway);
			this.Name = "FrmSidewayFilterConfig";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Sideway Filter Settings";
			this.groupBoxSideway.ResumeLayout(false);
			this.groupBoxSideway.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion
		private System.Windows.Forms.Button btnOK;
		private System.Windows.Forms.Button btnCancel;
		private System.Windows.Forms.GroupBox groupBoxSideway;
		private System.Windows.Forms.CheckBox chkUpToBottom;
		private System.Windows.Forms.CheckBox chkUseSumLogic;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.TextBox txtExceptionPercent;
		private System.Windows.Forms.TextBox txtLookbackRows;
		private System.Windows.Forms.CheckBox chkSidewayFilter;
		private System.Windows.Forms.CheckBox chkApplySidewayFilter;
	}
}