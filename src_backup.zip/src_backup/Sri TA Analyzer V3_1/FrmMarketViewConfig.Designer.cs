﻿
namespace SriTAAnalyzer
{
	partial class FrmMarketViewConfig
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.chkGenMarketViewReports = new System.Windows.Forms.CheckBox();
			this.groupMarketView = new System.Windows.Forms.GroupBox();
			this.chkSectorHistorical = new System.Windows.Forms.CheckBox();
			this.chkIndustryHistorical = new System.Windows.Forms.CheckBox();
			this.chkAllMarketHistorical = new System.Windows.Forms.CheckBox();
			this.chkSectorReport = new System.Windows.Forms.CheckBox();
			this.chkIndustryReport = new System.Windows.Forms.CheckBox();
			this.chkAllSignalReport = new System.Windows.Forms.CheckBox();
			this.label4 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.btnBrowseOutputFolder = new System.Windows.Forms.Button();
			this.txtOutputFolder = new System.Windows.Forms.TextBox();
			this.btnBrowseMappingFile = new System.Windows.Forms.Button();
			this.txtMappingFile = new System.Windows.Forms.TextBox();
			this.btnOK = new System.Windows.Forms.Button();
			this.btnCancel = new System.Windows.Forms.Button();
			this.groupMarketView.SuspendLayout();
			this.SuspendLayout();
			// 
			// chkGenMarketViewReports
			// 
			this.chkGenMarketViewReports.AutoSize = true;
			this.chkGenMarketViewReports.Location = new System.Drawing.Point(20, 9);
			this.chkGenMarketViewReports.Name = "chkGenMarketViewReports";
			this.chkGenMarketViewReports.Size = new System.Drawing.Size(145, 17);
			this.chkGenMarketViewReports.TabIndex = 1;
			this.chkGenMarketViewReports.Text = "Gen MarketView Reports";
			this.chkGenMarketViewReports.UseVisualStyleBackColor = true;
			this.chkGenMarketViewReports.CheckedChanged += new System.EventHandler(this.chkGenMarketViewReports_CheckedChanged);
			// 
			// groupMarketView
			// 
			this.groupMarketView.Controls.Add(this.chkSectorHistorical);
			this.groupMarketView.Controls.Add(this.chkIndustryHistorical);
			this.groupMarketView.Controls.Add(this.chkAllMarketHistorical);
			this.groupMarketView.Controls.Add(this.chkSectorReport);
			this.groupMarketView.Controls.Add(this.chkIndustryReport);
			this.groupMarketView.Controls.Add(this.chkAllSignalReport);
			this.groupMarketView.Controls.Add(this.label4);
			this.groupMarketView.Controls.Add(this.label2);
			this.groupMarketView.Controls.Add(this.label1);
			this.groupMarketView.Controls.Add(this.btnBrowseOutputFolder);
			this.groupMarketView.Controls.Add(this.txtOutputFolder);
			this.groupMarketView.Controls.Add(this.btnBrowseMappingFile);
			this.groupMarketView.Controls.Add(this.txtMappingFile);
			this.groupMarketView.Location = new System.Drawing.Point(12, 12);
			this.groupMarketView.Name = "groupMarketView";
			this.groupMarketView.Size = new System.Drawing.Size(408, 185);
			this.groupMarketView.TabIndex = 2;
			this.groupMarketView.TabStop = false;
			// 
			// chkSectorHistorical
			// 
			this.chkSectorHistorical.AutoSize = true;
			this.chkSectorHistorical.Location = new System.Drawing.Point(258, 152);
			this.chkSectorHistorical.Name = "chkSectorHistorical";
			this.chkSectorHistorical.Size = new System.Drawing.Size(103, 17);
			this.chkSectorHistorical.TabIndex = 72;
			this.chkSectorHistorical.Text = "Sector Historical";
			this.chkSectorHistorical.UseVisualStyleBackColor = true;
			this.chkSectorHistorical.CheckedChanged += new System.EventHandler(this.chkSectorHistorical_CheckedChanged);
			// 
			// chkIndustryHistorical
			// 
			this.chkIndustryHistorical.AutoSize = true;
			this.chkIndustryHistorical.Location = new System.Drawing.Point(258, 119);
			this.chkIndustryHistorical.Name = "chkIndustryHistorical";
			this.chkIndustryHistorical.Size = new System.Drawing.Size(109, 17);
			this.chkIndustryHistorical.TabIndex = 71;
			this.chkIndustryHistorical.Text = "Industry Historical";
			this.chkIndustryHistorical.UseVisualStyleBackColor = true;
			this.chkIndustryHistorical.CheckedChanged += new System.EventHandler(this.chkIndustryHistorical_CheckedChanged);
			// 
			// chkAllMarketHistorical
			// 
			this.chkAllMarketHistorical.AutoSize = true;
			this.chkAllMarketHistorical.Location = new System.Drawing.Point(258, 86);
			this.chkAllMarketHistorical.Name = "chkAllMarketHistorical";
			this.chkAllMarketHistorical.Size = new System.Drawing.Size(119, 17);
			this.chkAllMarketHistorical.TabIndex = 70;
			this.chkAllMarketHistorical.Text = "All Market Historical";
			this.chkAllMarketHistorical.UseVisualStyleBackColor = true;
			this.chkAllMarketHistorical.CheckedChanged += new System.EventHandler(this.chkAllMarketHistorical_CheckedChanged);
			// 
			// chkSectorReport
			// 
			this.chkSectorReport.AutoSize = true;
			this.chkSectorReport.Location = new System.Drawing.Point(120, 153);
			this.chkSectorReport.Name = "chkSectorReport";
			this.chkSectorReport.Size = new System.Drawing.Size(92, 17);
			this.chkSectorReport.TabIndex = 69;
			this.chkSectorReport.Text = "Sector Report";
			this.chkSectorReport.UseVisualStyleBackColor = true;
			// 
			// chkIndustryReport
			// 
			this.chkIndustryReport.AutoSize = true;
			this.chkIndustryReport.Location = new System.Drawing.Point(120, 120);
			this.chkIndustryReport.Name = "chkIndustryReport";
			this.chkIndustryReport.Size = new System.Drawing.Size(98, 17);
			this.chkIndustryReport.TabIndex = 68;
			this.chkIndustryReport.Text = "Industry Report";
			this.chkIndustryReport.UseVisualStyleBackColor = true;
			// 
			// chkAllSignalReport
			// 
			this.chkAllSignalReport.AutoSize = true;
			this.chkAllSignalReport.Location = new System.Drawing.Point(120, 87);
			this.chkAllSignalReport.Name = "chkAllSignalReport";
			this.chkAllSignalReport.Size = new System.Drawing.Size(109, 17);
			this.chkAllSignalReport.TabIndex = 67;
			this.chkAllSignalReport.Text = "All Signals Report";
			this.chkAllSignalReport.UseVisualStyleBackColor = true;
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(18, 87);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(44, 13);
			this.label4.TabIndex = 66;
			this.label4.Text = "Reports";
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(18, 56);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(71, 13);
			this.label2.TabIndex = 62;
			this.label2.Text = "Output Folder";
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(18, 22);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(67, 13);
			this.label1.TabIndex = 61;
			this.label1.Text = "Mapping File";
			// 
			// btnBrowseOutputFolder
			// 
			this.btnBrowseOutputFolder.Location = new System.Drawing.Point(371, 51);
			this.btnBrowseOutputFolder.Name = "btnBrowseOutputFolder";
			this.btnBrowseOutputFolder.Size = new System.Drawing.Size(30, 22);
			this.btnBrowseOutputFolder.TabIndex = 60;
			this.btnBrowseOutputFolder.Text = "...";
			this.btnBrowseOutputFolder.UseVisualStyleBackColor = true;
			this.btnBrowseOutputFolder.Click += new System.EventHandler(this.btnBrowseOutputFolder_Click);
			// 
			// txtOutputFolder
			// 
			this.txtOutputFolder.Location = new System.Drawing.Point(121, 52);
			this.txtOutputFolder.Name = "txtOutputFolder";
			this.txtOutputFolder.Size = new System.Drawing.Size(250, 20);
			this.txtOutputFolder.TabIndex = 59;
			// 
			// btnBrowseMappingFile
			// 
			this.btnBrowseMappingFile.Location = new System.Drawing.Point(371, 17);
			this.btnBrowseMappingFile.Name = "btnBrowseMappingFile";
			this.btnBrowseMappingFile.Size = new System.Drawing.Size(30, 22);
			this.btnBrowseMappingFile.TabIndex = 58;
			this.btnBrowseMappingFile.Text = "...";
			this.btnBrowseMappingFile.UseVisualStyleBackColor = true;
			this.btnBrowseMappingFile.Click += new System.EventHandler(this.btnBrowseMappingFile_Click);
			// 
			// txtMappingFile
			// 
			this.txtMappingFile.Location = new System.Drawing.Point(121, 18);
			this.txtMappingFile.Name = "txtMappingFile";
			this.txtMappingFile.Size = new System.Drawing.Size(250, 20);
			this.txtMappingFile.TabIndex = 57;
			// 
			// btnOK
			// 
			this.btnOK.Location = new System.Drawing.Point(197, 203);
			this.btnOK.Name = "btnOK";
			this.btnOK.Size = new System.Drawing.Size(103, 27);
			this.btnOK.TabIndex = 3;
			this.btnOK.Text = "OK";
			this.btnOK.UseVisualStyleBackColor = true;
			this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
			// 
			// btnCancel
			// 
			this.btnCancel.Location = new System.Drawing.Point(317, 203);
			this.btnCancel.Name = "btnCancel";
			this.btnCancel.Size = new System.Drawing.Size(103, 27);
			this.btnCancel.TabIndex = 4;
			this.btnCancel.Text = "Cancel";
			this.btnCancel.UseVisualStyleBackColor = true;
			this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
			// 
			// FrmMarketViewConfig
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(431, 240);
			this.Controls.Add(this.btnCancel);
			this.Controls.Add(this.btnOK);
			this.Controls.Add(this.chkGenMarketViewReports);
			this.Controls.Add(this.groupMarketView);
			this.Name = "FrmMarketViewConfig";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "MarketView Settings";
			this.groupMarketView.ResumeLayout(false);
			this.groupMarketView.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.CheckBox chkGenMarketViewReports;
		private System.Windows.Forms.GroupBox groupMarketView;
		private System.Windows.Forms.Button btnBrowseOutputFolder;
		private System.Windows.Forms.TextBox txtOutputFolder;
		private System.Windows.Forms.Button btnBrowseMappingFile;
		private System.Windows.Forms.TextBox txtMappingFile;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.CheckBox chkAllSignalReport;
		private System.Windows.Forms.CheckBox chkSectorReport;
		private System.Windows.Forms.CheckBox chkIndustryReport;
		private System.Windows.Forms.CheckBox chkSectorHistorical;
		private System.Windows.Forms.CheckBox chkIndustryHistorical;
		private System.Windows.Forms.CheckBox chkAllMarketHistorical;
		private System.Windows.Forms.Button btnOK;
		private System.Windows.Forms.Button btnCancel;
	}
}