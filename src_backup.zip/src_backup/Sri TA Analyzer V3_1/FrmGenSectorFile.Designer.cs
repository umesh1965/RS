﻿
namespace SriTAAnalyzer
{
	partial class FrmGenSectorFile
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.chkGenSectorFile = new System.Windows.Forms.CheckBox();
			this.btnBrowseMappingFile = new System.Windows.Forms.Button();
			this.txtMappingFile = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.btnBrowseMergedOutput = new System.Windows.Forms.Button();
			this.txtMergedOutput = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.chkGenSectorRFile = new System.Windows.Forms.CheckBox();
			this.btnBrowseSectorRFileFolder = new System.Windows.Forms.Button();
			this.txtSectorRFileFolder = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.btnOK = new System.Windows.Forms.Button();
			this.btnCancel = new System.Windows.Forms.Button();
			this.chkStoreBarChange = new System.Windows.Forms.CheckBox();
			this.txtBar = new System.Windows.Forms.TextBox();
			this.label4 = new System.Windows.Forms.Label();
			this.chkSubCal = new System.Windows.Forms.CheckBox();
			this.groupSubCal = new System.Windows.Forms.GroupBox();
			this.chkCalAvg = new System.Windows.Forms.CheckBox();
			this.txtSubCalLevels = new System.Windows.Forms.TextBox();
			this.label23 = new System.Windows.Forms.Label();
			this.chkApplyAlignR = new System.Windows.Forms.CheckBox();
			this.chkApplyMultipleR = new System.Windows.Forms.CheckBox();
			this.chkApplyPrimaryR = new System.Windows.Forms.CheckBox();
			this.label22 = new System.Windows.Forms.Label();
			this.panelCalAvg = new System.Windows.Forms.Panel();
			this.txtLavg4End = new System.Windows.Forms.TextBox();
			this.txtLavg4Start = new System.Windows.Forms.TextBox();
			this.label30 = new System.Windows.Forms.Label();
			this.txtLavg3End = new System.Windows.Forms.TextBox();
			this.txtLavg3Start = new System.Windows.Forms.TextBox();
			this.label29 = new System.Windows.Forms.Label();
			this.txtLavg2End = new System.Windows.Forms.TextBox();
			this.txtLavg2Start = new System.Windows.Forms.TextBox();
			this.label28 = new System.Windows.Forms.Label();
			this.label27 = new System.Windows.Forms.Label();
			this.txtLavg1End = new System.Windows.Forms.TextBox();
			this.label26 = new System.Windows.Forms.Label();
			this.txtLavg1Start = new System.Windows.Forms.TextBox();
			this.label25 = new System.Windows.Forms.Label();
			this.txtOutputOnlyR = new System.Windows.Forms.TextBox();
			this.chkOutputOnlyR = new System.Windows.Forms.CheckBox();
			this.groupSubCal.SuspendLayout();
			this.panelCalAvg.SuspendLayout();
			this.SuspendLayout();
			// 
			// chkGenSectorFile
			// 
			this.chkGenSectorFile.AutoSize = true;
			this.chkGenSectorFile.Location = new System.Drawing.Point(23, 21);
			this.chkGenSectorFile.Name = "chkGenSectorFile";
			this.chkGenSectorFile.Size = new System.Drawing.Size(104, 17);
			this.chkGenSectorFile.TabIndex = 0;
			this.chkGenSectorFile.Text = "Gen-Sector-Files";
			this.chkGenSectorFile.UseVisualStyleBackColor = true;
			// 
			// btnBrowseMappingFile
			// 
			this.btnBrowseMappingFile.Location = new System.Drawing.Point(401, 47);
			this.btnBrowseMappingFile.Name = "btnBrowseMappingFile";
			this.btnBrowseMappingFile.Size = new System.Drawing.Size(27, 22);
			this.btnBrowseMappingFile.TabIndex = 32;
			this.btnBrowseMappingFile.Text = "...";
			this.btnBrowseMappingFile.UseVisualStyleBackColor = true;
			this.btnBrowseMappingFile.Click += new System.EventHandler(this.btnBrowseMappingFile_Click);
			// 
			// txtMappingFile
			// 
			this.txtMappingFile.Location = new System.Drawing.Point(156, 48);
			this.txtMappingFile.Name = "txtMappingFile";
			this.txtMappingFile.Size = new System.Drawing.Size(245, 20);
			this.txtMappingFile.TabIndex = 31;
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(23, 51);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(101, 13);
			this.label3.TabIndex = 30;
			this.label3.Text = "Sector Mapping File";
			// 
			// btnBrowseMergedOutput
			// 
			this.btnBrowseMergedOutput.Location = new System.Drawing.Point(401, 85);
			this.btnBrowseMergedOutput.Name = "btnBrowseMergedOutput";
			this.btnBrowseMergedOutput.Size = new System.Drawing.Size(27, 22);
			this.btnBrowseMergedOutput.TabIndex = 35;
			this.btnBrowseMergedOutput.Text = "...";
			this.btnBrowseMergedOutput.UseVisualStyleBackColor = true;
			this.btnBrowseMergedOutput.Click += new System.EventHandler(this.btnBrowseMergedOutput_Click);
			// 
			// txtMergedOutput
			// 
			this.txtMergedOutput.Location = new System.Drawing.Point(156, 86);
			this.txtMergedOutput.Name = "txtMergedOutput";
			this.txtMergedOutput.Size = new System.Drawing.Size(245, 20);
			this.txtMergedOutput.TabIndex = 34;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(23, 89);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(112, 13);
			this.label1.TabIndex = 33;
			this.label1.Text = "Sector Merged Output";
			// 
			// chkGenSectorRFile
			// 
			this.chkGenSectorRFile.AutoSize = true;
			this.chkGenSectorRFile.Location = new System.Drawing.Point(23, 127);
			this.chkGenSectorRFile.Name = "chkGenSectorRFile";
			this.chkGenSectorRFile.Size = new System.Drawing.Size(115, 17);
			this.chkGenSectorRFile.TabIndex = 36;
			this.chkGenSectorRFile.Text = "Gen-Sector-R-Files";
			this.chkGenSectorRFile.UseVisualStyleBackColor = true;
			// 
			// btnBrowseSectorRFileFolder
			// 
			this.btnBrowseSectorRFileFolder.Location = new System.Drawing.Point(401, 165);
			this.btnBrowseSectorRFileFolder.Name = "btnBrowseSectorRFileFolder";
			this.btnBrowseSectorRFileFolder.Size = new System.Drawing.Size(27, 22);
			this.btnBrowseSectorRFileFolder.TabIndex = 39;
			this.btnBrowseSectorRFileFolder.Text = "...";
			this.btnBrowseSectorRFileFolder.UseVisualStyleBackColor = true;
			this.btnBrowseSectorRFileFolder.Click += new System.EventHandler(this.btnBrowseSectorRFileFolder_Click);
			// 
			// txtSectorRFileFolder
			// 
			this.txtSectorRFileFolder.Location = new System.Drawing.Point(156, 166);
			this.txtSectorRFileFolder.Name = "txtSectorRFileFolder";
			this.txtSectorRFileFolder.Size = new System.Drawing.Size(245, 20);
			this.txtSectorRFileFolder.TabIndex = 38;
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(23, 169);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(128, 13);
			this.label2.TabIndex = 37;
			this.label2.Text = "Gen-Sector-R-Files Folder";
			// 
			// btnOK
			// 
			this.btnOK.Location = new System.Drawing.Point(504, 357);
			this.btnOK.Name = "btnOK";
			this.btnOK.Size = new System.Drawing.Size(105, 26);
			this.btnOK.TabIndex = 40;
			this.btnOK.Text = "OK";
			this.btnOK.UseVisualStyleBackColor = true;
			this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
			// 
			// btnCancel
			// 
			this.btnCancel.Location = new System.Drawing.Point(662, 357);
			this.btnCancel.Name = "btnCancel";
			this.btnCancel.Size = new System.Drawing.Size(105, 26);
			this.btnCancel.TabIndex = 41;
			this.btnCancel.Text = "Cancel";
			this.btnCancel.UseVisualStyleBackColor = true;
			this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
			// 
			// chkStoreBarChange
			// 
			this.chkStoreBarChange.AutoSize = true;
			this.chkStoreBarChange.Checked = true;
			this.chkStoreBarChange.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chkStoreBarChange.Location = new System.Drawing.Point(156, 242);
			this.chkStoreBarChange.Name = "chkStoreBarChange";
			this.chkStoreBarChange.Size = new System.Drawing.Size(129, 17);
			this.chkStoreBarChange.TabIndex = 44;
			this.chkStoreBarChange.Text = "Store Bar% in Change";
			this.chkStoreBarChange.UseVisualStyleBackColor = true;
			// 
			// txtBar
			// 
			this.txtBar.Location = new System.Drawing.Point(156, 210);
			this.txtBar.Name = "txtBar";
			this.txtBar.Size = new System.Drawing.Size(80, 20);
			this.txtBar.TabIndex = 43;
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(119, 213);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(31, 13);
			this.label4.TabIndex = 42;
			this.label4.Text = "Bar%";
			// 
			// chkSubCal
			// 
			this.chkSubCal.AutoSize = true;
			this.chkSubCal.Location = new System.Drawing.Point(467, 19);
			this.chkSubCal.Name = "chkSubCal";
			this.chkSubCal.Size = new System.Drawing.Size(63, 17);
			this.chkSubCal.TabIndex = 53;
			this.chkSubCal.Text = "Sub-Cal";
			this.chkSubCal.UseVisualStyleBackColor = true;
			this.chkSubCal.CheckedChanged += new System.EventHandler(this.chkSubCal_CheckedChanged);
			// 
			// groupSubCal
			// 
			this.groupSubCal.Controls.Add(this.chkCalAvg);
			this.groupSubCal.Controls.Add(this.txtSubCalLevels);
			this.groupSubCal.Controls.Add(this.label23);
			this.groupSubCal.Controls.Add(this.chkApplyAlignR);
			this.groupSubCal.Controls.Add(this.chkApplyMultipleR);
			this.groupSubCal.Controls.Add(this.chkApplyPrimaryR);
			this.groupSubCal.Controls.Add(this.label22);
			this.groupSubCal.Controls.Add(this.panelCalAvg);
			this.groupSubCal.Location = new System.Drawing.Point(455, 21);
			this.groupSubCal.Name = "groupSubCal";
			this.groupSubCal.Size = new System.Drawing.Size(318, 314);
			this.groupSubCal.TabIndex = 52;
			this.groupSubCal.TabStop = false;
			// 
			// chkCalAvg
			// 
			this.chkCalAvg.AutoSize = true;
			this.chkCalAvg.Location = new System.Drawing.Point(36, 108);
			this.chkCalAvg.Name = "chkCalAvg";
			this.chkCalAvg.Size = new System.Drawing.Size(63, 17);
			this.chkCalAvg.TabIndex = 52;
			this.chkCalAvg.Text = "Cal-Avg";
			this.chkCalAvg.UseVisualStyleBackColor = true;
			// 
			// txtSubCalLevels
			// 
			this.txtSubCalLevels.Location = new System.Drawing.Point(126, 50);
			this.txtSubCalLevels.Name = "txtSubCalLevels";
			this.txtSubCalLevels.Size = new System.Drawing.Size(120, 20);
			this.txtSubCalLevels.TabIndex = 49;
			// 
			// label23
			// 
			this.label23.AutoSize = true;
			this.label23.Location = new System.Drawing.Point(21, 55);
			this.label23.Name = "label23";
			this.label23.Size = new System.Drawing.Size(78, 13);
			this.label23.TabIndex = 48;
			this.label23.Text = "Sub-Cal Levels";
			// 
			// chkApplyAlignR
			// 
			this.chkApplyAlignR.AutoSize = true;
			this.chkApplyAlignR.Location = new System.Drawing.Point(252, 0);
			this.chkApplyAlignR.Name = "chkApplyAlignR";
			this.chkApplyAlignR.Size = new System.Drawing.Size(60, 17);
			this.chkApplyAlignR.TabIndex = 47;
			this.chkApplyAlignR.Text = "Align R";
			this.chkApplyAlignR.UseVisualStyleBackColor = true;
			this.chkApplyAlignR.Visible = false;
			// 
			// chkApplyMultipleR
			// 
			this.chkApplyMultipleR.AutoSize = true;
			this.chkApplyMultipleR.Location = new System.Drawing.Point(163, 0);
			this.chkApplyMultipleR.Name = "chkApplyMultipleR";
			this.chkApplyMultipleR.Size = new System.Drawing.Size(73, 17);
			this.chkApplyMultipleR.TabIndex = 46;
			this.chkApplyMultipleR.Text = "Multiple R";
			this.chkApplyMultipleR.UseVisualStyleBackColor = true;
			this.chkApplyMultipleR.Visible = false;
			// 
			// chkApplyPrimaryR
			// 
			this.chkApplyPrimaryR.AutoSize = true;
			this.chkApplyPrimaryR.Location = new System.Drawing.Point(140, 27);
			this.chkApplyPrimaryR.Name = "chkApplyPrimaryR";
			this.chkApplyPrimaryR.Size = new System.Drawing.Size(91, 17);
			this.chkApplyPrimaryR.TabIndex = 45;
			this.chkApplyPrimaryR.Text = "Gen Sector R";
			this.chkApplyPrimaryR.UseVisualStyleBackColor = true;
			this.chkApplyPrimaryR.Visible = false;
			// 
			// label22
			// 
			this.label22.AutoSize = true;
			this.label22.Location = new System.Drawing.Point(21, 30);
			this.label22.Name = "label22";
			this.label22.Size = new System.Drawing.Size(97, 13);
			this.label22.TabIndex = 44;
			this.label22.Text = "Sub-Cal Applies To";
			this.label22.Visible = false;
			// 
			// panelCalAvg
			// 
			this.panelCalAvg.Controls.Add(this.txtLavg4End);
			this.panelCalAvg.Controls.Add(this.txtLavg4Start);
			this.panelCalAvg.Controls.Add(this.label30);
			this.panelCalAvg.Controls.Add(this.txtLavg3End);
			this.panelCalAvg.Controls.Add(this.txtLavg3Start);
			this.panelCalAvg.Controls.Add(this.label29);
			this.panelCalAvg.Controls.Add(this.txtLavg2End);
			this.panelCalAvg.Controls.Add(this.txtLavg2Start);
			this.panelCalAvg.Controls.Add(this.label28);
			this.panelCalAvg.Controls.Add(this.label27);
			this.panelCalAvg.Controls.Add(this.txtLavg1End);
			this.panelCalAvg.Controls.Add(this.label26);
			this.panelCalAvg.Controls.Add(this.txtLavg1Start);
			this.panelCalAvg.Controls.Add(this.label25);
			this.panelCalAvg.Location = new System.Drawing.Point(29, 131);
			this.panelCalAvg.Name = "panelCalAvg";
			this.panelCalAvg.Size = new System.Drawing.Size(283, 153);
			this.panelCalAvg.TabIndex = 67;
			// 
			// txtLavg4End
			// 
			this.txtLavg4End.Location = new System.Drawing.Point(178, 124);
			this.txtLavg4End.Name = "txtLavg4End";
			this.txtLavg4End.Size = new System.Drawing.Size(80, 20);
			this.txtLavg4End.TabIndex = 80;
			// 
			// txtLavg4Start
			// 
			this.txtLavg4Start.Location = new System.Drawing.Point(82, 124);
			this.txtLavg4Start.Name = "txtLavg4Start";
			this.txtLavg4Start.Size = new System.Drawing.Size(80, 20);
			this.txtLavg4Start.TabIndex = 79;
			// 
			// label30
			// 
			this.label30.AutoSize = true;
			this.label30.Location = new System.Drawing.Point(24, 127);
			this.label30.Name = "label30";
			this.label30.Size = new System.Drawing.Size(37, 13);
			this.label30.TabIndex = 78;
			this.label30.Text = "Lavg4";
			// 
			// txtLavg3End
			// 
			this.txtLavg3End.Location = new System.Drawing.Point(178, 94);
			this.txtLavg3End.Name = "txtLavg3End";
			this.txtLavg3End.Size = new System.Drawing.Size(80, 20);
			this.txtLavg3End.TabIndex = 77;
			// 
			// txtLavg3Start
			// 
			this.txtLavg3Start.Location = new System.Drawing.Point(82, 94);
			this.txtLavg3Start.Name = "txtLavg3Start";
			this.txtLavg3Start.Size = new System.Drawing.Size(80, 20);
			this.txtLavg3Start.TabIndex = 76;
			// 
			// label29
			// 
			this.label29.AutoSize = true;
			this.label29.Location = new System.Drawing.Point(24, 97);
			this.label29.Name = "label29";
			this.label29.Size = new System.Drawing.Size(37, 13);
			this.label29.TabIndex = 75;
			this.label29.Text = "Lavg3";
			// 
			// txtLavg2End
			// 
			this.txtLavg2End.Location = new System.Drawing.Point(178, 61);
			this.txtLavg2End.Name = "txtLavg2End";
			this.txtLavg2End.Size = new System.Drawing.Size(80, 20);
			this.txtLavg2End.TabIndex = 74;
			// 
			// txtLavg2Start
			// 
			this.txtLavg2Start.Location = new System.Drawing.Point(82, 61);
			this.txtLavg2Start.Name = "txtLavg2Start";
			this.txtLavg2Start.Size = new System.Drawing.Size(80, 20);
			this.txtLavg2Start.TabIndex = 73;
			// 
			// label28
			// 
			this.label28.AutoSize = true;
			this.label28.Location = new System.Drawing.Point(24, 64);
			this.label28.Name = "label28";
			this.label28.Size = new System.Drawing.Size(37, 13);
			this.label28.TabIndex = 72;
			this.label28.Text = "Lavg2";
			// 
			// label27
			// 
			this.label27.AutoSize = true;
			this.label27.Location = new System.Drawing.Point(204, 8);
			this.label27.Name = "label27";
			this.label27.Size = new System.Drawing.Size(26, 13);
			this.label27.TabIndex = 71;
			this.label27.Text = "End";
			// 
			// txtLavg1End
			// 
			this.txtLavg1End.Location = new System.Drawing.Point(178, 29);
			this.txtLavg1End.Name = "txtLavg1End";
			this.txtLavg1End.Size = new System.Drawing.Size(80, 20);
			this.txtLavg1End.TabIndex = 70;
			// 
			// label26
			// 
			this.label26.AutoSize = true;
			this.label26.Location = new System.Drawing.Point(108, 8);
			this.label26.Name = "label26";
			this.label26.Size = new System.Drawing.Size(29, 13);
			this.label26.TabIndex = 69;
			this.label26.Text = "Start";
			// 
			// txtLavg1Start
			// 
			this.txtLavg1Start.Location = new System.Drawing.Point(82, 29);
			this.txtLavg1Start.Name = "txtLavg1Start";
			this.txtLavg1Start.Size = new System.Drawing.Size(80, 20);
			this.txtLavg1Start.TabIndex = 68;
			// 
			// label25
			// 
			this.label25.AutoSize = true;
			this.label25.Location = new System.Drawing.Point(24, 32);
			this.label25.Name = "label25";
			this.label25.Size = new System.Drawing.Size(37, 13);
			this.label25.TabIndex = 67;
			this.label25.Text = "Lavg1";
			// 
			// txtOutputOnlyR
			// 
			this.txtOutputOnlyR.Location = new System.Drawing.Point(156, 275);
			this.txtOutputOnlyR.Name = "txtOutputOnlyR";
			this.txtOutputOnlyR.Size = new System.Drawing.Size(80, 20);
			this.txtOutputOnlyR.TabIndex = 51;
			// 
			// chkOutputOnlyR
			// 
			this.chkOutputOnlyR.AutoSize = true;
			this.chkOutputOnlyR.Location = new System.Drawing.Point(23, 278);
			this.chkOutputOnlyR.Name = "chkOutputOnlyR";
			this.chkOutputOnlyR.Size = new System.Drawing.Size(130, 17);
			this.chkOutputOnlyR.TabIndex = 50;
			this.chkOutputOnlyR.Text = "Output Only R #Rows";
			this.chkOutputOnlyR.UseVisualStyleBackColor = true;
			this.chkOutputOnlyR.CheckedChanged += new System.EventHandler(this.chkOutputOnlyR_CheckedChanged);
			// 
			// FrmGenSectorFile
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(786, 405);
			this.Controls.Add(this.chkSubCal);
			this.Controls.Add(this.groupSubCal);
			this.Controls.Add(this.txtOutputOnlyR);
			this.Controls.Add(this.chkOutputOnlyR);
			this.Controls.Add(this.chkStoreBarChange);
			this.Controls.Add(this.txtBar);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.btnCancel);
			this.Controls.Add(this.btnOK);
			this.Controls.Add(this.btnBrowseSectorRFileFolder);
			this.Controls.Add(this.txtSectorRFileFolder);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.chkGenSectorRFile);
			this.Controls.Add(this.btnBrowseMergedOutput);
			this.Controls.Add(this.txtMergedOutput);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.btnBrowseMappingFile);
			this.Controls.Add(this.txtMappingFile);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.chkGenSectorFile);
			this.Name = "FrmGenSectorFile";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Generate Sector Files";
			this.groupSubCal.ResumeLayout(false);
			this.groupSubCal.PerformLayout();
			this.panelCalAvg.ResumeLayout(false);
			this.panelCalAvg.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.CheckBox chkGenSectorFile;
		private System.Windows.Forms.Button btnBrowseMappingFile;
		private System.Windows.Forms.TextBox txtMappingFile;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Button btnBrowseMergedOutput;
		private System.Windows.Forms.TextBox txtMergedOutput;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.CheckBox chkGenSectorRFile;
		private System.Windows.Forms.Button btnBrowseSectorRFileFolder;
		private System.Windows.Forms.TextBox txtSectorRFileFolder;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Button btnOK;
		private System.Windows.Forms.Button btnCancel;
		private System.Windows.Forms.CheckBox chkStoreBarChange;
		private System.Windows.Forms.TextBox txtBar;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.CheckBox chkSubCal;
		private System.Windows.Forms.GroupBox groupSubCal;
		private System.Windows.Forms.CheckBox chkCalAvg;
		private System.Windows.Forms.TextBox txtSubCalLevels;
		private System.Windows.Forms.Label label23;
		private System.Windows.Forms.CheckBox chkApplyAlignR;
		private System.Windows.Forms.CheckBox chkApplyMultipleR;
		private System.Windows.Forms.CheckBox chkApplyPrimaryR;
		private System.Windows.Forms.Label label22;
		private System.Windows.Forms.Panel panelCalAvg;
		private System.Windows.Forms.TextBox txtLavg4End;
		private System.Windows.Forms.TextBox txtLavg4Start;
		private System.Windows.Forms.Label label30;
		private System.Windows.Forms.TextBox txtLavg3End;
		private System.Windows.Forms.TextBox txtLavg3Start;
		private System.Windows.Forms.Label label29;
		private System.Windows.Forms.TextBox txtLavg2End;
		private System.Windows.Forms.TextBox txtLavg2Start;
		private System.Windows.Forms.Label label28;
		private System.Windows.Forms.Label label27;
		private System.Windows.Forms.TextBox txtLavg1End;
		private System.Windows.Forms.Label label26;
		private System.Windows.Forms.TextBox txtLavg1Start;
		private System.Windows.Forms.Label label25;
		private System.Windows.Forms.TextBox txtOutputOnlyR;
		private System.Windows.Forms.CheckBox chkOutputOnlyR;
	}
}