﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using SriTAAnalyzerModel;
using SriTAAnalyzerProcess;
using Ookii.Dialogs.Wpf;

namespace SriTAAnalyzer
{
	public partial class FrmMain : Form
	{
		private bool bProcessStarted = false;
		private bool bWebSocketProcessStarted = false;
		private ZeroMQSender msgSender;

		private SriTAAnalyzerProcessor processor;
		private AlpacaDLSettings Config { get => GlobalData.Config; }
		string symbolFilter = "Symbol Files(*.txt)|*.txt";
		string csvFilter = "CSV Files(*.csv)|*.csv";
		Dictionary<string, List<DateTime>> updateSchedule = new Dictionary<string, List<DateTime>>();
		public FrmMain()
		{
			InitializeComponent();
			processor = new SriTAAnalyzerProcessor();
			processor.ProcessNotifier = new SriTAAnalyzerProcessor.ProcessNotifierDelegate(ProcessNotifier);
			processor.MessageSender = new SriTAAnalyzerProcessor.MessageSenderDeleagate(SendMessage);
			GlobalData.LoadSettings();
			timerUpdate.Tick += UpdateTick;
			BindSettings(false);

			msgSender = new ZeroMQSender();

			UpdateControlStateByDataFeed();
		}
		void LoadUpdateSchedule(string file)
		{
			updateSchedule["Day"] = new List<DateTime>();
			updateSchedule["Swing"] = new List<DateTime>();
			updateSchedule["Trend"] = new List<DateTime>();

			try
			{
				string[] line = File.ReadAllLines(file);
				for (int i = 1; i < line.Length; i++)
				{
					string[] items = line[i].Split(',');
					if (items.Length < 1)
						continue;

					DateTime dt = DateTime.Parse(items[0]);
					updateSchedule["Day"].Add(dt);

					if (items.Length > 1)
					{
						dt = DateTime.Parse(items[1]);
						updateSchedule["Swing"].Add(dt);
					}
					if (items.Length > 2)
					{
						dt = DateTime.Parse(items[2]);
						updateSchedule["Trend"].Add(dt);
					}
				}
			}
			catch (Exception e)
			{
				
			}
		}
		private void UpdateTick(object sender, EventArgs e)
		{
			if (!bProcessStarted)
				return;

			if (Config.General.UpdateType != UpdateTypeEnum.Static && DateTime.Now.Second - Config.General.AutoUpdateDelay == 0)
				DoAutoUpdate(sender, e);
		}

		private void SendMessage(string msg)
		{
			msgSender.SendMessage(msg);
		}
		private void SelectText(TextBox textBox)
		{
			textBox.Focus();
			textBox.SelectAll();
		}

		public bool BindSettings(bool bFromControl, bool bShowError = false)
		{
			bool bRet = true;
			if (bFromControl)
			{
				Config.PolygonConfigDay.Enabled = chkDay.Checked;
				Config.PolygonConfigDay.InputFolder = txtInputFolderDay.Text;
				Config.PolygonConfigDay.OutputFolder = txtOutputFolderDay.Text;
				Config.PolygonConfigDay.Multiplier = int.Parse(txtMultiplierDay.Text);
				Config.PolygonConfigDay.StartDate = dtStartDay.Value;
				Config.PolygonConfigDay.EndDate = dtEndDay.Value;
				Config.PolygonConfigDay.Sort = cmbSortDay.Text;
				Config.PolygonConfigDay.Unadjusted = cmbUnadjustedDay.SelectedIndex == 1;
				Config.PolygonConfigDay.TimeFrame = (DataTimeFrame)cmbTimeFrameDay.SelectedIndex;
				Config.PolygonConfigDay.BarLimit = int.Parse(txtBarDay.Text);

				Config.PolygonConfigSwing.Enabled = chkSwing.Checked;
				Config.PolygonConfigSwing.InputFolder = txtInputSwing.Text;
				Config.PolygonConfigSwing.OutputFolder = txtOutputSwing.Text;
				Config.PolygonConfigSwing.Multiplier = int.Parse(txtMultiplierSwing.Text);
				Config.PolygonConfigSwing.StartDate = dtStartSwing.Value;
				Config.PolygonConfigSwing.EndDate = dtEndSwing.Value;
				Config.PolygonConfigSwing.Sort = cmbSortSwing.Text;
				Config.PolygonConfigSwing.Unadjusted = cmbUnadjustedSwing.SelectedIndex == 1;
				Config.PolygonConfigSwing.TimeFrame = (DataTimeFrame)cmbTimeFrameSwing.SelectedIndex;
				Config.PolygonConfigSwing.BarLimit = int.Parse(txtBarSwing.Text);

				Config.PolygonConfigTrend.Enabled = chkTrend.Checked;
				Config.PolygonConfigTrend.InputFolder = txtInputTrend.Text;
				Config.PolygonConfigTrend.OutputFolder = txtOutputTrend.Text;
				Config.PolygonConfigTrend.Multiplier = int.Parse(txtMultiplierTrend.Text);
				Config.PolygonConfigTrend.StartDate = dtStartTrend.Value;
				Config.PolygonConfigTrend.EndDate = dtEndTrend.Value;
				Config.PolygonConfigTrend.Sort = cmbSortTrend.Text;
				Config.PolygonConfigTrend.Unadjusted = cmbUnadjustedTrend.SelectedIndex == 1;
				Config.PolygonConfigTrend.TimeFrame = (DataTimeFrame)cmbTimeFrameTrend.SelectedIndex;
				Config.PolygonConfigTrend.BarLimit = int.Parse(txtBarTrend.Text);

				int barMaxLimit = 50000;
				int barMinLimit = 1;

				if (Config.General.DataFeedSource == DataFeedSouce.PolygonV2)
					barMaxLimit = 50000;
				
				if (Config.PolygonConfigDay.BarLimit < barMinLimit || Config.PolygonConfigDay.BarLimit > barMaxLimit)
				{
					if (bShowError)
					{
						MessageBox.Show("#Bar is invalid", GlobalData.AppName, MessageBoxButtons.OK, MessageBoxIcon.Warning);
						SelectText(txtBarDay);
						return false;
					}
				}

				Config.General.EnableMarketTimeOnly = chkMarketHoursOnly.Checked;
				Config.General.MarketStartTime = dateTimeStart.Value;
				Config.General.MarketEndTime = dateTimeEnd.Value;

				if (radioUpdateStatic.Checked)
					Config.General.UpdateType = UpdateTypeEnum.Static;
				else if (radioUpdateAuto.Checked)
					Config.General.UpdateType = UpdateTypeEnum.Auto;
				else if (radioUpdateSchedule.Checked)
					Config.General.UpdateType = UpdateTypeEnum.AutoSchedule;

				Config.General.AppendUpdatedData = chkAppendData.Checked;
				Config.General.EnableCloseBarUpdate = chkCloseBarUpdate.Checked;

				if (radioHLC.Checked)
					Config.General.CloseBarUpdateMode = 0;
				else if (radioOHLC.Checked)
					Config.General.CloseBarUpdateMode = 1;
				else if (radioHL.Checked)
					Config.General.CloseBarUpdateMode = 2;
				else if (radioCO.Checked)
					Config.General.CloseBarUpdateMode = 3;

				Config.General.EnableCalendarAutoUpdate = chkCalendarAutoStart.Checked;

				Config.General.BackfillUpdate = chkBackfillUpdate.Checked;
				Config.General.ROutput = chkROutput.Checked;
				int tempValInt = 0;
				Config.General.AutoUpdateDelay = int.TryParse(txtDelay.Text, out tempValInt) ? tempValInt : 0;
				Config.General.RoundPoints = int.TryParse(txtRounding.Text, out tempValInt) ? tempValInt : 0;

				if (Config.General.RoundPoints == 0)
					Config.General.RoundPoints = 2;

				Config.General.RoundChange = chkRoundChange.Checked;
				Config.General.RoundClose = chkRoundClose.Checked;
				Config.General.RoundVolume = chkRoundVol.Checked;
				Config.General.DataFeedSource = (DataFeedSouce)cmbDataFeedType.SelectedIndex;
				Config.General.PolygonKey = txtPolygonAPIKey.Text;
				
				Config.LocalDataFeedConfig.DataFolder = txtLocalDataFolder.Text;

				Config.General.SymbolListFile = txtSymbolList.Text;
				Config.General.UpdateIntervalFile = txtUpdateSchedule.Text;
			}
			else
			{
				//Day
				chkDay.Checked = Config.PolygonConfigDay.Enabled;
				txtInputFolderDay.Text = Config.PolygonConfigDay.InputFolder;
				txtOutputFolderDay.Text = Config.PolygonConfigDay.OutputFolder;
				txtMultiplierDay.Text = Config.PolygonConfigDay.Multiplier.ToString();
				cmbTimeFrameDay.SelectedIndex = (int)Config.PolygonConfigDay.TimeFrame;
				cmbSortDay.Text = Config.PolygonConfigDay.Sort;
				cmbUnadjustedDay.SelectedIndex = Config.PolygonConfigDay.Unadjusted ? 1 : 0;
				dtStartDay.Value = Config.PolygonConfigDay.StartDate;
				dtEndDay.Value = Config.PolygonConfigDay.EndDate;
				txtBarDay.Text = Config.PolygonConfigDay.BarLimit.ToString();

				//Swing
				chkSwing.Checked = Config.PolygonConfigSwing.Enabled;
				txtInputSwing.Text = Config.PolygonConfigSwing.InputFolder;
				txtOutputSwing.Text = Config.PolygonConfigSwing.OutputFolder;
				txtMultiplierSwing.Text = Config.PolygonConfigSwing.Multiplier.ToString();
				cmbTimeFrameSwing.SelectedIndex = (int)Config.PolygonConfigSwing.TimeFrame;
				cmbSortSwing.Text = Config.PolygonConfigSwing.Sort;
				cmbUnadjustedSwing.SelectedIndex = Config.PolygonConfigSwing.Unadjusted ? 1 : 0;
				dtStartSwing.Value = Config.PolygonConfigSwing.StartDate;
				dtEndSwing.Value = Config.PolygonConfigSwing.EndDate;
				txtBarSwing.Text = Config.PolygonConfigSwing.BarLimit.ToString();

				//Swing
				chkTrend.Checked = Config.PolygonConfigTrend.Enabled;
				txtInputTrend.Text = Config.PolygonConfigTrend.InputFolder;
				txtOutputTrend.Text = Config.PolygonConfigTrend.OutputFolder;
				txtMultiplierTrend.Text = Config.PolygonConfigTrend.Multiplier.ToString();
				cmbTimeFrameTrend.SelectedIndex = (int)Config.PolygonConfigTrend.TimeFrame;
				cmbSortTrend.Text = Config.PolygonConfigTrend.Sort;
				cmbUnadjustedTrend.SelectedIndex = Config.PolygonConfigTrend.Unadjusted ? 1 : 0;
				dtStartTrend.Value = Config.PolygonConfigTrend.StartDate;
				dtEndTrend.Value = Config.PolygonConfigTrend.EndDate;
				txtBarTrend.Text = Config.PolygonConfigTrend.BarLimit.ToString();

				chkMarketHoursOnly.Checked = Config.General.EnableMarketTimeOnly;

				dateTimeStart.Enabled = dateTimeEnd.Enabled = Config.General.EnableMarketTimeOnly;

				dateTimeStart.Value = Config.General.MarketStartTime;
				dateTimeEnd.Value = Config.General.MarketEndTime;

				radioUpdateStatic.Checked = Config.General.UpdateType == UpdateTypeEnum.Static;
				radioUpdateAuto.Checked = Config.General.UpdateType == UpdateTypeEnum.Auto;
				radioUpdateSchedule.Checked = Config.General.UpdateType == UpdateTypeEnum.AutoSchedule;

				chkAppendData.Checked = Config.General.AppendUpdatedData;
				chkAppendData.Enabled = Config.General.UpdateType == UpdateTypeEnum.Auto || Config.General.UpdateType == UpdateTypeEnum.AutoSchedule;

				chkCloseBarUpdate.Checked = Config.General.EnableCloseBarUpdate;
				radioHLC.Enabled = radioOHLC.Enabled = radioHL.Enabled = radioCO.Enabled = Config.General.EnableCloseBarUpdate;
				radioHLC.Checked = Config.General.CloseBarUpdateMode == 0;
				radioOHLC.Checked = Config.General.CloseBarUpdateMode == 1;
				radioHL.Checked = Config.General.CloseBarUpdateMode == 2;
				radioCO.Checked = Config.General.CloseBarUpdateMode == 3;

				chkCalendarAutoStart.Checked = Config.General.EnableCalendarAutoUpdate;

				dateTimeStart.Enabled = dateTimeEnd.Enabled = !(Config.General.EnableCalendarAutoUpdate);

				chkBackfillUpdate.Checked = Config.General.BackfillUpdate;

				chkROutput.Checked = Config.General.ROutput;
				btnROutputSettings.Enabled = Config.General.ROutput;

				txtDelay.Text = Config.General.AutoUpdateDelay.ToString();

				txtRounding.Text = Config.General.RoundPoints.ToString();
				chkRoundChange.Checked = Config.General.RoundChange;
				chkRoundClose.Checked = Config.General.RoundClose;
				chkRoundVol.Checked = Config.General.RoundVolume;

				cmbDataFeedType.SelectedIndex = (int)Config.General.DataFeedSource;
				txtPolygonAPIKey.Text = Config.General.PolygonKey;
				txtLocalDataFolder.Text = Config.LocalDataFeedConfig.DataFolder;

				txtSymbolList.Text = Config.General.SymbolListFile;

				groupDay.Enabled = Config.PolygonConfigDay.Enabled;
				groupSwing.Enabled = Config.PolygonConfigSwing.Enabled;
				groupTrend.Enabled = Config.PolygonConfigTrend.Enabled;

				txtUpdateSchedule.Text = Config.General.UpdateIntervalFile;

				EnableAutoUpdateControl();

				ShowControlsByDataFeed();
			}

			return bRet;
		}
		private bool CheckStartConditions()
		{
			bool bRet = true;

			if (string.IsNullOrEmpty(txtBarDay.Text))
			{
				MessageBox.Show("Please enter #Bars", GlobalData.AppName, MessageBoxButtons.OK, MessageBoxIcon.Warning);
				SelectText(txtBarDay);
				return false;
			}

			return bRet;
		}
		private void FrmMain_Load(object sender, EventArgs e)
		{

		}
		private void FrmMain_FormClosing(object sender, FormClosingEventArgs e)
		{
			if (MessageBox.Show("Are you sure you want to exit?", GlobalData.AppName, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
			{
				e.Cancel = true;
				return;
			}

			BindSettings(true);
			GlobalData.SaveSettings();
		}

		private void btnStart_Click(object sender, EventArgs e)
		{
			if (!bProcessStarted)
			{
				if (!CheckStartConditions())
				{
					bProcessStarted = false;
					return;
				}
				if (!BindSettings(true, true))
				{
					bProcessStarted = false;
					return;
				}

				GlobalData.SaveSettings();

				if (Config.General.EnableCalendarAutoUpdate)
				{
					if (File.Exists(GlobalData.GetCalendarFilePath()))
						processor.PrepareCalendarListFromFile();
					else
					{
						MessageBox.Show("Calendar File does not exist!", GlobalData.AppName, MessageBoxButtons.OK, MessageBoxIcon.Warning);
						bProcessStarted = false;
						return;
					}
				}


				if (!processor.PrepareStockSymbolList(Config.General.SymbolListFile))
				{
					MessageBox.Show("Failed to load symbollist", GlobalData.AppName, MessageBoxButtons.OK, MessageBoxIcon.Information);
					bProcessStarted = false;
					return;
				}

				bProcessStarted = true;

				EnableAllControls(false);

				processor.ClearOriginalData();

				if (Config.General.ROutput)
				{
					try
					{
						if (Config.PolygonConfigDay.Enabled)
							SriTAAnalyzerServices.ClearFolder(Config.PolygonConfigDay.OutputFolder);
						if (Config.PolygonConfigSwing.Enabled) if (Config.Cal.ST.Enabled)
							SriTAAnalyzerServices.ClearFolder(Config.PolygonConfigSwing.OutputFolder);
						if (Config.PolygonConfigTrend.Enabled)
							SriTAAnalyzerServices.ClearFolder(Config.PolygonConfigTrend.OutputFolder);
					}
					catch
					{

					}
				}

				if (!Config.General.EnableCalendarAutoUpdate && Config.General.UpdateType == UpdateTypeEnum.Static)
				{
					processor.StopROutput = false;
					processor.Start();
				}
				else
				{
					if (Config.General.UpdateType == UpdateTypeEnum.AutoSchedule)
						LoadUpdateSchedule(Config.General.UpdateIntervalFile);

					processor.LoadUpdateSchedule(Config.General.UpdateIntervalFile);

					DoAutoUpdate(null, null);
				}

				btnStart.Text = "Stop";
			}
			else
			{
				processor.Stop();
				btnStart.Text = "Start";
				bProcessStarted = false;
				lblProcessStatus.Text = "Cancelled by user";
				statusProgressBar.Visible = false;
				statusProgressBar.Value = 0;
				EnableAllControls(true);
			}
		}

		private void EnableAllControls(bool bEnable)
		{
			groupDay.Enabled = bEnable;
			groupTrend.Enabled = bEnable;
			groupSwing.Enabled = bEnable;
			groupDownloadSetting.Enabled = bEnable;
		}

		private void ProcessNotifier(SriTAAnalyzerProcessor.ProcessState state, int param)
		{
			switch (state)
			{
				case SriTAAnalyzerProcessor.ProcessState.Start:
					bProcessStarted = true;

					BeginInvoke(new Action(() => EnableAllControls(false)));
					BeginInvoke(new Action(() => lblProcessStatus.Text = "Starting..."));
					BeginInvoke(new Action(() => statusProgressBar.Maximum = 100));
					BeginInvoke(new Action(() => statusProgressBar.Value = 0));
					BeginInvoke(new Action(() => statusProgressBar.Visible = true));
					break;
				case SriTAAnalyzerProcessor.ProcessState.Progress:
					BeginInvoke(new Action(() => statusProgressBar.Value = param));
					if (!bWebSocketProcessStarted)
						BeginInvoke(new Action(() => lblProcessStatus.Text = "Overall Progress"));
					break;
				case SriTAAnalyzerProcessor.ProcessState.Pause:
					BeginInvoke(new Action(() => btnStart.Text = "Resume"));
					bProcessStarted = false;
					break;
				case SriTAAnalyzerProcessor.ProcessState.Stop:
					BeginInvoke(new Action(() => EnableAllControls(true)));
					BeginInvoke(new Action(() => btnStart.Text = "Start"));
					BeginInvoke(new Action(() => statusProgressBar.Visible = false));
					BeginInvoke(new Action(() => statusProgressBar.Value = 0));
					if (param == -1)
						BeginInvoke(new Action(() => lblProcessStatus.Text = "Connection Error"));
					else
						BeginInvoke(new Action(() => lblProcessStatus.Text = "Cancelled by user"));
					bProcessStarted = false;
					msgSender.Stop();
					break;
				case SriTAAnalyzerProcessor.ProcessState.Complete:
					
					if (Config.General.UpdateType == UpdateTypeEnum.Static)
					{
						bProcessStarted = false;
						BeginInvoke(new Action(() => EnableAllControls(true)));
						BeginInvoke(new Action(() => btnStart.Text = "Start"));
						BeginInvoke(new Action(() => statusProgressBar.Visible = false));
						BeginInvoke(new Action(() => statusProgressBar.Value = 0));
						BeginInvoke(new Action(() => lblProcessStatus.Text = "Download Completed"));
					}
					else
					{
						BeginInvoke(new Action(() => statusProgressBar.Value = 0));
						BeginInvoke(new Action(() => lblProcessStatus.Text = "Waiting for Auto Update..."));
					}
					break;
				case SriTAAnalyzerProcessor.ProcessState.ConnectionError:
					BeginInvoke(new Action(() => lblProcessStatus.Text = "Connection Error. Trying again..."));
					break;
				case SriTAAnalyzerProcessor.ProcessState.SocketConnected:
					if (param == 1)
						BeginInvoke(new Action(() => lblSocketState.Text = "WebSocket Stream : Connected"));
					else
						BeginInvoke(new Action(() => lblSocketState.Text = "WebSocket Stream : Disconnected"));
					break;
				case SriTAAnalyzerProcessor.ProcessState.Appended:
					BeginInvoke(new Action(() => lblProcessStatus.Text = param.ToString() + " Symbols Appended"));
					break;
				case SriTAAnalyzerProcessor.ProcessState.Calendar:
					if (param == 1)
						BeginInvoke(new Action(() => MessageBox.Show("Calendar File generated successfully!", GlobalData.AppName, MessageBoxButtons.OK, MessageBoxIcon.Information)));
					else
						BeginInvoke(new Action(() => MessageBox.Show("An error occurred while generating Calendar File.", GlobalData.AppName, MessageBoxButtons.OK, MessageBoxIcon.Warning)));
					break;
				case SriTAAnalyzerProcessor.ProcessState.ROutputStart:
					break;
				case SriTAAnalyzerProcessor.ProcessState.ROutputCompleted:
					msgSender.Stop();
					break;
				case SriTAAnalyzerProcessor.ProcessState.LimitExceeded:
					BeginInvoke(new Action(() => lblProcessStatus.Text = "500 symbols/5 min limit excceded!"));
					break;

			}
		}

		private void btnExit_Click(object sender, EventArgs e)
		{
			processor.Stop();
			Application.Exit();
		}

		private void btnBrowseSymbolList_Click(object sender, EventArgs e)
		{
			OpenFileDialog openDlg = new OpenFileDialog();
			openDlg.Filter = "Stock Symbol List|*.txt";
			if (openDlg.ShowDialog() == DialogResult.OK)
			{
				Config.General.SymbolListFile = openDlg.FileName;
				txtSymbolList.Text = openDlg.FileName;
			}
		}

		private void btnStop_Click(object sender, EventArgs e)
		{
			
		}

		private void chkMarketHoursOnly_CheckedChanged(object sender, EventArgs e)
		{
			dateTimeStart.Enabled = dateTimeEnd.Enabled = chkMarketHoursOnly.Checked;
		}
		private bool CanAutoUpdate()
		{
			if (Config.General.EnableCalendarAutoUpdate)
			{
				return processor.IsTimeInMarketHour(DateTime.UtcNow);
			}
			else
			{
				DateTime now = DateTime.Now;

				DateTime startTime = new DateTime(now.Year, now.Month, now.Day,
														Config.General.MarketStartTime.Hour, Config.General.MarketStartTime.Minute, 0);
				DateTime endTime = new DateTime(now.Year, now.Month, now.Day,
											Config.General.MarketEndTime.Hour, Config.General.MarketEndTime.Minute, 0);

				if (startTime > now || endTime < now)
					return false;
			}

			return true;
		}
		/// <summary>
		/// Check whether auto update is available in every 1 min.
		/// Do update if time is between open and close
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void DoAutoUpdate(object sender, EventArgs e)
		{
			if (GlobalData.Config.General.UpdateType != UpdateTypeEnum.Static)
			{
				if (!CanAutoUpdate() && GlobalData.Config.General.UpdateType == UpdateTypeEnum.Auto)
				{
					BeginInvoke(new Action(() => lblProcessStatus.Text = "Waiting for market open..."));
					return;
				}
				else
				{
					processor.StopROutput = false;
					processor.Start();
				}
			}
		}
		private void chkCloseBarUpdate_CheckedChanged(object sender, EventArgs e)
		{
			radioHLC.Enabled = radioHL.Enabled = radioOHLC.Enabled = radioCO.Enabled = chkCloseBarUpdate.Checked;
		}

		private void radioHL_Click(object sender, EventArgs e)
		{
			RadioButton[] buttons = { radioHLC, radioHL, radioOHLC, radioCO };

			foreach (var btn in buttons)
			{
				btn.Checked = sender == btn;
			}
		}

		private void EnableAutoUpdateControl()
		{
			txtDelay.Enabled = radioUpdateAuto.Checked || radioUpdateSchedule.Checked;
			txtUpdateSchedule.Enabled = radioUpdateSchedule.Checked;
			btnBrowseUpdateSchedule.Enabled = radioUpdateSchedule.Checked;
		}
		private void chkCalendarAutoStart_CheckedChanged(object sender, EventArgs e)
		{
			dateTimeStart.Enabled = dateTimeEnd.Enabled = !(chkCalendarAutoStart.Checked);
		}

		private void chkCalendarWebSocket_CheckedChanged(object sender, EventArgs e)
		{
			dateTimeStart.Enabled = dateTimeEnd.Enabled = !(chkCalendarAutoStart.Checked);
		}
		private void btnRConfig_Click(object sender, EventArgs e)
		{
			FrmOutputRSettings frmRConfig = new FrmOutputRSettings(Config.RFileOutputConfig);
			frmRConfig.ShowDialog();
		}

		private void chkROutput_CheckedChanged(object sender, EventArgs e)
		{
			btnROutputSettings.Enabled = chkROutput.Checked;
		}

		private void btnTrimInputData_Click(object sender, EventArgs e)
		{
			BindSettings(true);
			Thread trimThread = new Thread(() => processor.DoTrim());
			trimThread.Start();
		}

		private string GetFolderPath(string initPath = "")
		{
			VistaFolderBrowserDialog folderBrowserDialog = new VistaFolderBrowserDialog();
			folderBrowserDialog.SelectedPath = initPath;
			if (folderBrowserDialog.ShowDialog().GetValueOrDefault())
			{
				return folderBrowserDialog.SelectedPath;
			}

			return "";
		}

		private void btnGenSectorFile_Click(object sender, EventArgs e)
		{
			FrmGenSectorFile frmGenSsectorFile = new FrmGenSectorFile(Config.SectorFileConfig);
			frmGenSsectorFile.ShowDialog();
		}

		private void btnSidewayFilters_Click(object sender, EventArgs e)
		{
			FrmSidewayFilterConfig dlg = new FrmSidewayFilterConfig(Config.SideWayConfig);
			dlg.ShowDialog();
		}

		private void btnWebSocketSettings_Click(object sender, EventArgs e)
		{

		}

		private void cmbDataFeedType_SelectedIndexChanged(object sender, EventArgs e)
		{
			Config.General.DataFeedSource = (DataFeedSouce)cmbDataFeedType.SelectedIndex;
			UpdateControlStateByDataFeed();
		}

		private void UpdateControlStateByDataFeed()
		{
			panelPolygonDataFeedSetting.Visible = Config.General.DataFeedSource == DataFeedSouce.PolygonV2;
		}

		private void btnTSDataFeedConfig_Click(object sender, EventArgs e)
		{
			
		}

		private void btnRefreshToken_Click(object sender, EventArgs e)
		{
			
		}

		void ShowControlsByDataFeed()
		{
			//panelLocalDataFeedSetting.Visible = Config.General.DataFeedSource == DataFeedSouce.OnlyLocalData;
			panelPolygonDataFeedSetting.Visible = Config.General.DataFeedSource == DataFeedSouce.PolygonV2;
		}

		private void btnBrowseLocalDataFolder_Click(object sender, EventArgs e)
		{
			txtLocalDataFolder.Text = GetFolderPath(txtLocalDataFolder.Text);
		}

		private void btnMarketView_Click(object sender, EventArgs e)
		{
			FrmMarketViewConfig frm = new FrmMarketViewConfig(Config.MarketViewReportConfig);
			frm.ShowDialog();
		}

		private void btnAWSSettings_Click(object sender, EventArgs e)
		{
			FrmAWS3Config frm = new FrmAWS3Config(Config.AWSS3Config);
			frm.ShowDialog();
		}

		private void btnCleanupStockList_Click(object sender, EventArgs e)
		{
			processor.CleanupStockList();
		}

		private void btnMiscSettings_Click(object sender, EventArgs e)
		{
			FrmMiscSettings frm = new FrmMiscSettings(Config.MiscConfig);
			frm.ShowDialog();
		}

		private void btnCleanStockListConfig_Click(object sender, EventArgs e)
		{
			FrmCleanStockListSettings frm = new FrmCleanStockListSettings(Config.CleanupStockListConfig);
			frm.ShowDialog();
		}

		private void btnTest_Click(object sender, EventArgs e)
		{
			processor.Test();
		}

		private void btnPusherSettings_Click(object sender, EventArgs e)
		{
			FrmPusherConfig frm = new FrmPusherConfig(Config.PushConfig);
			frm.ShowDialog();
		}

		private void btnSignalSettings_Click(object sender, EventArgs e)
		{
			FrmSignalSettings frm = new FrmSignalSettings(Config.SignalConfig);
			frm.ShowDialog();
		}

		private void btnBrowseSymbolList_Click_1(object sender, EventArgs e)
		{
			txtSymbolList.Text = Utils.GetFilePath(symbolFilter);
		}

		private void btnBrowseInputFolderDay_Click(object sender, EventArgs e)
		{
			txtInputFolderDay.Text = Utils.GetFolderPath(txtInputFolderDay.Text);
		}

		private void btnBrowseOutputFolderDay_Click(object sender, EventArgs e)
		{
			txtOutputFolderDay.Text = Utils.GetFolderPath(txtOutputFolderDay.Text);
		}

		private void btnBrowseInputSwing_Click(object sender, EventArgs e)
		{
			txtInputSwing.Text = Utils.GetFolderPath(txtInputSwing.Text);
		}

		private void btnBrowseOutputSwing_Click(object sender, EventArgs e)
		{
			txtOutputSwing.Text = Utils.GetFolderPath(txtOutputSwing.Text);
		}

		private void txtBrowseInputTrend_Click(object sender, EventArgs e)
		{
			txtInputTrend.Text = Utils.GetFolderPath(txtInputTrend.Text);
		}

		private void txtBrowseOutputTrend_Click(object sender, EventArgs e)
		{
			txtOutputTrend.Text = Utils.GetFolderPath(txtOutputTrend.Text);
		}

		private void btnBrowseLocalDataFolder_Click_1(object sender, EventArgs e)
		{
			txtLocalDataFolder.Text = Utils.GetFolderPath(txtLocalDataFolder.Text);
		}

		private void btnTASettings_Click(object sender, EventArgs e)
		{
			FrmTASettings frm = new FrmTASettings(Config.Cal);
			frm.ShowDialog();
		}

		private void btnBrowseUpdateSchedule_Click(object sender, EventArgs e)
		{
			txtUpdateSchedule.Text = Utils.GetFilePath(csvFilter);
		}

		private void groupDownloadSetting_Enter(object sender, EventArgs e)
		{

		}

		private void radioUpdateStatic_CheckedChanged(object sender, EventArgs e)
		{
			EnableAutoUpdateControl();
		}

		private void radioUpdateAuto_CheckedChanged(object sender, EventArgs e)
		{
			EnableAutoUpdateControl();
		}

		private void radioUpdateSchedule_CheckedChanged(object sender, EventArgs e)
		{
			EnableAutoUpdateControl();
		}

		private void chkDay_CheckedChanged(object sender, EventArgs e)
		{
			groupDay.Enabled = chkDay.Checked;
		}

		private void chkSwing_CheckedChanged(object sender, EventArgs e)
		{
			groupSwing.Enabled = chkSwing.Checked;
		}

		private void chkTrend_CheckedChanged(object sender, EventArgs e)
		{
			groupTrend.Enabled = chkTrend.Checked;
		}
	}
}
