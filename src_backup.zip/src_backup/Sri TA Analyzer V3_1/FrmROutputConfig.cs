﻿using Ookii.Dialogs.Wpf;
using SriTAAnalyzerModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SriTAAnalyzer
{
	public partial class FrmOutputRSettings : Form
	{
		private ROutputSettings config;
		public FrmOutputRSettings()
		{
			InitializeComponent();
		}
		public FrmOutputRSettings(ROutputSettings config_) : this()
		{
			config = config_;

			txtLevel.Text = config.Level.ToString();

			txtLavg1Start.Text = config.SubCalConfig.LAvg1Start.ToString();
			txtLavg2Start.Text = config.SubCalConfig.LAvg2Start.ToString();
			txtLavg3Start.Text = config.SubCalConfig.LAvg3Start.ToString();
			txtLavg4Start.Text = config.SubCalConfig.LAvg4Start.ToString();

			txtLavg1End.Text = config.SubCalConfig.LAvg1End.ToString();
			txtLavg2End.Text = config.SubCalConfig.LAvg2End.ToString();
			txtLavg3End.Text = config.SubCalConfig.LAvg3End.ToString();
			txtLavg4End.Text = config.SubCalConfig.LAvg4End.ToString();

			txtOutputRow.Enabled = chkOutputOnlyR.Checked;

			chkOutputOld.Checked = config.OutputOldFormat;
			chkOutputNew.Checked = config.OutputNewFormat;

			cmbTrendForLevels.SelectedIndex = (int)config.TrendLevel;
			chkBinaryLevels.Checked = config.UseBinaryLevels;
			txtOutputRow.Enabled = chkOutputOnlyR.Checked;
			chkOutputMaster.Checked = config.OutputMasterFile;

			//V8 : BS Signal
			chkEnableBSSignal.Checked = config.EnableBSSignals;
			radioBSLevel.Checked = config.BSSignalMode == 0;
			radLavgSignal.Checked = config.BSSignalMode == 1;
			txtLavgSignal.Text = config.Lavg1SignalMin.ToString("0.00");

			panelBSLevels.Enabled = chkEnableBSSignal.Checked;

			txtBSLevels.Enabled = radioBSLevel.Checked;
			txtLavgSignal.Enabled = radLavgSignal.Checked;
			//
		}

		private void btnOK_Click(object sender, EventArgs e)
		{
			int tempValInt;

			config.Level = int.TryParse(txtLevel.Text, out tempValInt) ? tempValInt : 0;

			config.EnableOutputOnlyRow = chkOutputOnlyR.Checked;
			config.OutputOnlyRowNumbers = int.TryParse(txtOutputRow.Text, out tempValInt) ? tempValInt : 0;

			config.SubCalConfig.LAvg1Start = int.TryParse(txtLavg1Start.Text, out tempValInt) ? tempValInt : 0;
			config.SubCalConfig.LAvg2Start = int.TryParse(txtLavg2Start.Text, out tempValInt) ? tempValInt : 0;
			config.SubCalConfig.LAvg3Start = int.TryParse(txtLavg3Start.Text, out tempValInt) ? tempValInt : 0;
			config.SubCalConfig.LAvg4Start = int.TryParse(txtLavg4Start.Text, out tempValInt) ? tempValInt : 0;

			config.SubCalConfig.LAvg1End = int.TryParse(txtLavg1End.Text, out tempValInt) ? tempValInt : 0;
			config.SubCalConfig.LAvg2End = int.TryParse(txtLavg2End.Text, out tempValInt) ? tempValInt : 0;
			config.SubCalConfig.LAvg3End = int.TryParse(txtLavg3End.Text, out tempValInt) ? tempValInt : 0;
			config.SubCalConfig.LAvg4End = int.TryParse(txtLavg4End.Text, out tempValInt) ? tempValInt : 0;

			config.OutputOldFormat = chkOutputOld.Checked;
			config.OutputNewFormat = chkOutputNew.Checked;

			config.TrendLevel = (TrendLevelType)cmbTrendForLevels.SelectedIndex;
			config.UseBinaryLevels = chkBinaryLevels.Checked;
			config.OutputMasterFile = chkOutputMaster.Checked;

			double tempValDouble = 0;

			config.EnableBSSignals = chkEnableBSSignal.Checked;
			config.BSSignalMode = radioBSLevel.Checked ? 0 : 1;
			config.Lavg1SignalMin = double.TryParse(txtLavgSignal.Text, out tempValDouble) ? tempValDouble : 0;

			this.Close();
		}

		private void btnCancel_Click(object sender, EventArgs e)
		{
			this.Close();
		}
		
		private void FrmROutputConfig_Load(object sender, EventArgs e)
		{

		}

		private void chkOutputOnlyR_CheckedChanged(object sender, EventArgs e)
		{
			txtOutputRow.Enabled = chkOutputOnlyR.Checked;
		}

		private void chkCalAvg_CheckedChanged(object sender, EventArgs e)
		{
			
		}

		private void cmbTrendForLevels_SelectedIndexChanged(object sender, EventArgs e)
		{
			
		}

		private void chkEnableBSSignal_CheckedChanged(object sender, EventArgs e)
		{
			panelBSLevels.Enabled = chkEnableBSSignal.Checked;
		}

		private void radioBSLevel_CheckedChanged(object sender, EventArgs e)
		{
			txtBSLevels.Enabled = radioBSLevel.Checked;
		}

		private void radLavgSignal_CheckedChanged(object sender, EventArgs e)
		{
			txtLavgSignal.Enabled = radLavgSignal.Checked;
		}
	}
}
