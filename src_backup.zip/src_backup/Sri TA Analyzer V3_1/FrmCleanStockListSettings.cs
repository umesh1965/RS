﻿using SriTAAnalyzerModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SriTAAnalyzer
{
	public partial class FrmCleanStockListSettings : Form
	{
		CleanStockListSettings config;
		public FrmCleanStockListSettings()
		{
			InitializeComponent();
		}

		public FrmCleanStockListSettings(CleanStockListSettings config_) : this()
		{
			config = config_;
			BindData(false);
		}

		private void btnBrowseSymbolList_Click(object sender, EventArgs e)
		{
			OpenFileDialog openDlg = new OpenFileDialog();
			openDlg.Filter = "Stock Symbol List|*.csv";
			if (openDlg.ShowDialog() == DialogResult.OK)
			{
				GlobalData.Config.General.SymbolListFile = openDlg.FileName;
				txtSymbolListFile.Text = openDlg.FileName;
			}
		}

		void BindData(bool fromControl)
		{
			if (fromControl)
			{
				config.StockListFile = txtSymbolListFile.Text;
				config.StatusInactive = chkStatus.Checked;
				config.MarginableFalse = chkMarginable.Checked;
				config.ShortableFalse = chkShortable.Checked;
				config.EasyToBorrow = chkEasyToBorrow.Checked;
				config.Fractionable = chkFractionable.Checked;
			}
			else
			{
				txtSymbolListFile.Text = config.StockListFile;
				chkStatus.Checked = config.StatusInactive;
				chkMarginable.Checked = config.MarginableFalse;
				chkShortable.Checked = config.ShortableFalse;
				chkEasyToBorrow.Checked = config.EasyToBorrow;
				chkFractionable.Checked = config.Fractionable;
			}
		}

		private void btnCleanup_Click(object sender, EventArgs e)
		{
			BindData(true);
			Close();
		}

		private void btnCancel_Click(object sender, EventArgs e)
		{
			Close();
		}
	}
}
