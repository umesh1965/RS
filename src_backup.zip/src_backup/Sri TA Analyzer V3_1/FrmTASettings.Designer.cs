﻿
namespace SriTAAnalyzer
{
	partial class FrmTASettings
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.chkSTTrend = new System.Windows.Forms.CheckBox();
			this.chkATTrend = new System.Windows.Forms.CheckBox();
			this.groupSTTrend = new System.Windows.Forms.GroupBox();
			this.txtSTPd = new System.Windows.Forms.TextBox();
			this.label17 = new System.Windows.Forms.Label();
			this.txtSTFactor = new System.Windows.Forms.TextBox();
			this.label21 = new System.Windows.Forms.Label();
			this.groupATTrend = new System.Windows.Forms.GroupBox();
			this.txtATRisk = new System.Windows.Forms.TextBox();
			this.label15 = new System.Windows.Forms.Label();
			this.chkADXTrend = new System.Windows.Forms.CheckBox();
			this.groupADXTrend = new System.Windows.Forms.GroupBox();
			this.txtADXPeriod = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.btnOK = new System.Windows.Forms.Button();
			this.btnCancel = new System.Windows.Forms.Button();
			this.groupSTTrend.SuspendLayout();
			this.groupATTrend.SuspendLayout();
			this.groupADXTrend.SuspendLayout();
			this.SuspendLayout();
			// 
			// chkSTTrend
			// 
			this.chkSTTrend.AutoSize = true;
			this.chkSTTrend.Location = new System.Drawing.Point(26, 71);
			this.chkSTTrend.Name = "chkSTTrend";
			this.chkSTTrend.Size = new System.Drawing.Size(71, 17);
			this.chkSTTrend.TabIndex = 43;
			this.chkSTTrend.Text = "ST Trend";
			this.chkSTTrend.UseVisualStyleBackColor = true;
			this.chkSTTrend.CheckedChanged += new System.EventHandler(this.chkSTTrend_CheckedChanged);
			// 
			// chkATTrend
			// 
			this.chkATTrend.AutoSize = true;
			this.chkATTrend.Location = new System.Drawing.Point(27, 8);
			this.chkATTrend.Name = "chkATTrend";
			this.chkATTrend.Size = new System.Drawing.Size(71, 17);
			this.chkATTrend.TabIndex = 42;
			this.chkATTrend.Text = "AT Trend";
			this.chkATTrend.UseVisualStyleBackColor = true;
			this.chkATTrend.CheckedChanged += new System.EventHandler(this.chkATTrend_CheckedChanged);
			// 
			// groupSTTrend
			// 
			this.groupSTTrend.Controls.Add(this.txtSTPd);
			this.groupSTTrend.Controls.Add(this.label17);
			this.groupSTTrend.Controls.Add(this.txtSTFactor);
			this.groupSTTrend.Controls.Add(this.label21);
			this.groupSTTrend.Location = new System.Drawing.Point(15, 73);
			this.groupSTTrend.Name = "groupSTTrend";
			this.groupSTTrend.Size = new System.Drawing.Size(200, 92);
			this.groupSTTrend.TabIndex = 41;
			this.groupSTTrend.TabStop = false;
			// 
			// txtSTPd
			// 
			this.txtSTPd.Location = new System.Drawing.Point(76, 54);
			this.txtSTPd.Name = "txtSTPd";
			this.txtSTPd.Size = new System.Drawing.Size(90, 20);
			this.txtSTPd.TabIndex = 41;
			// 
			// label17
			// 
			this.label17.AutoSize = true;
			this.label17.Location = new System.Drawing.Point(42, 57);
			this.label17.Name = "label17";
			this.label17.Size = new System.Drawing.Size(20, 13);
			this.label17.TabIndex = 40;
			this.label17.Text = "Pd";
			// 
			// txtSTFactor
			// 
			this.txtSTFactor.Location = new System.Drawing.Point(76, 25);
			this.txtSTFactor.Name = "txtSTFactor";
			this.txtSTFactor.Size = new System.Drawing.Size(90, 20);
			this.txtSTFactor.TabIndex = 39;
			// 
			// label21
			// 
			this.label21.AutoSize = true;
			this.label21.Location = new System.Drawing.Point(25, 28);
			this.label21.Name = "label21";
			this.label21.Size = new System.Drawing.Size(37, 13);
			this.label21.TabIndex = 38;
			this.label21.Text = "Factor";
			// 
			// groupATTrend
			// 
			this.groupATTrend.Controls.Add(this.txtATRisk);
			this.groupATTrend.Controls.Add(this.label15);
			this.groupATTrend.Location = new System.Drawing.Point(15, 10);
			this.groupATTrend.Name = "groupATTrend";
			this.groupATTrend.Size = new System.Drawing.Size(200, 57);
			this.groupATTrend.TabIndex = 40;
			this.groupATTrend.TabStop = false;
			// 
			// txtATRisk
			// 
			this.txtATRisk.Location = new System.Drawing.Point(76, 21);
			this.txtATRisk.Name = "txtATRisk";
			this.txtATRisk.Size = new System.Drawing.Size(90, 20);
			this.txtATRisk.TabIndex = 39;
			// 
			// label15
			// 
			this.label15.AutoSize = true;
			this.label15.Location = new System.Drawing.Point(27, 24);
			this.label15.Name = "label15";
			this.label15.Size = new System.Drawing.Size(28, 13);
			this.label15.TabIndex = 38;
			this.label15.Text = "Risk";
			// 
			// chkADXTrend
			// 
			this.chkADXTrend.AutoSize = true;
			this.chkADXTrend.Location = new System.Drawing.Point(26, 169);
			this.chkADXTrend.Name = "chkADXTrend";
			this.chkADXTrend.Size = new System.Drawing.Size(79, 17);
			this.chkADXTrend.TabIndex = 45;
			this.chkADXTrend.Text = "ADX Trend";
			this.chkADXTrend.UseVisualStyleBackColor = true;
			this.chkADXTrend.CheckedChanged += new System.EventHandler(this.chkADXTrend_CheckedChanged);
			// 
			// groupADXTrend
			// 
			this.groupADXTrend.Controls.Add(this.txtADXPeriod);
			this.groupADXTrend.Controls.Add(this.label1);
			this.groupADXTrend.Location = new System.Drawing.Point(15, 171);
			this.groupADXTrend.Name = "groupADXTrend";
			this.groupADXTrend.Size = new System.Drawing.Size(200, 67);
			this.groupADXTrend.TabIndex = 44;
			this.groupADXTrend.TabStop = false;
			// 
			// txtADXPeriod
			// 
			this.txtADXPeriod.Location = new System.Drawing.Point(76, 30);
			this.txtADXPeriod.Name = "txtADXPeriod";
			this.txtADXPeriod.Size = new System.Drawing.Size(90, 20);
			this.txtADXPeriod.TabIndex = 41;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(25, 33);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(37, 13);
			this.label1.TabIndex = 40;
			this.label1.Text = "Period";
			// 
			// btnOK
			// 
			this.btnOK.Location = new System.Drawing.Point(15, 249);
			this.btnOK.Name = "btnOK";
			this.btnOK.Size = new System.Drawing.Size(75, 23);
			this.btnOK.TabIndex = 46;
			this.btnOK.Text = "OK";
			this.btnOK.UseVisualStyleBackColor = true;
			this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
			// 
			// btnCancel
			// 
			this.btnCancel.Location = new System.Drawing.Point(140, 249);
			this.btnCancel.Name = "btnCancel";
			this.btnCancel.Size = new System.Drawing.Size(75, 23);
			this.btnCancel.TabIndex = 47;
			this.btnCancel.Text = "Cancel";
			this.btnCancel.UseVisualStyleBackColor = true;
			this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
			// 
			// FrmTASettings
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(230, 284);
			this.Controls.Add(this.btnCancel);
			this.Controls.Add(this.btnOK);
			this.Controls.Add(this.chkADXTrend);
			this.Controls.Add(this.groupADXTrend);
			this.Controls.Add(this.chkSTTrend);
			this.Controls.Add(this.chkATTrend);
			this.Controls.Add(this.groupSTTrend);
			this.Controls.Add(this.groupATTrend);
			this.Name = "FrmTASettings";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "TA Settings";
			this.groupSTTrend.ResumeLayout(false);
			this.groupSTTrend.PerformLayout();
			this.groupATTrend.ResumeLayout(false);
			this.groupATTrend.PerformLayout();
			this.groupADXTrend.ResumeLayout(false);
			this.groupADXTrend.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.CheckBox chkSTTrend;
		private System.Windows.Forms.CheckBox chkATTrend;
		private System.Windows.Forms.GroupBox groupSTTrend;
		private System.Windows.Forms.TextBox txtSTPd;
		private System.Windows.Forms.Label label17;
		private System.Windows.Forms.TextBox txtSTFactor;
		private System.Windows.Forms.Label label21;
		private System.Windows.Forms.GroupBox groupATTrend;
		private System.Windows.Forms.TextBox txtATRisk;
		private System.Windows.Forms.Label label15;
		private System.Windows.Forms.CheckBox chkADXTrend;
		private System.Windows.Forms.GroupBox groupADXTrend;
		private System.Windows.Forms.TextBox txtADXPeriod;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Button btnOK;
		private System.Windows.Forms.Button btnCancel;
	}
}