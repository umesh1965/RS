﻿using SriTAAnalyzerModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SriTAAnalyzer
{
	public partial class FrmAWS3Config : Form
	{
		private AWSS3Settings config { get; }
		public FrmAWS3Config()
		{
			InitializeComponent();
		}
		public FrmAWS3Config(AWSS3Settings config_) : this()
		{
			config = config_;

			chkUseAWSS3.Checked = config.UseAWSUpload;
			txtAWSAccessKey.Text = config.AccessKey;
			txtAWSSecretKey.Text = config.SecretKey;
			cmbAWSRegion.Text = config.Region;
			txtAWSCannedACL.Text = config.CannedACL;
			txtBucketName.Text = config.BucketName;
			txtAWSEncrytionKey.Text = config.EncryptionKey;
			cmbCompressionFormat.Text = config.GzipFormat;
			chkGZipIndividual.Checked = config.UseGZipIndividual;
			chkGzipFolder.Checked = config.UseGZipFolder;
			txtGzipFolderName.Text = config.GZipFolderName;
			chkGzipUsePassword.Checked = config.GZipUsePasswordProtect;
			txtGzipPassword.Text = config.GZipPassword;
			chkMarketView.Checked = config.MarketView;
			chkAllSignalReport.Checked = config.AllSignalReport;
			chkAllMarketHistorical.Checked = config.AllMarketHistorical;
			chkIndustryReport.Checked = config.IndustryReport;
			chkIndustryHistorical.Checked = config.IndustryHistorical;
			chkSectorReport.Checked = config.SectorReport;
			chkSectorHistorical.Checked = config.SectorHistorical;

			chkMasterFile.Checked = config.UploadMasterFiles;
			chkMasterZip.Checked = config.MasterZip;
			chkMasterUnzip.Checked = config.MasterUnzip;
			cmbMasterZipFormat.Text = config.MasterZipFormat;
			txtMasterFolder.Text = config.MasterFolder;
			txtMasterZipFolder.Text = config.MasterZipFormat;
			chkMasterProtect.Checked = config.MasterProtect;
			txtMasterPassword.Text = config.MasterPassword;

			chkUploadNew.Checked = config.UploadOutputNew;
			chkUploadOld.Checked = config.UploadOutputOld;

			groupMasterFiles.Enabled = chkMasterFile.Checked;
			groupMarketView.Enabled = chkMarketView.Checked;

		}

		private void btnOK_Click(object sender, EventArgs e)
		{
			config.UseAWSUpload = chkUseAWSS3.Checked;
			config.AccessKey = txtAWSAccessKey.Text;
			config.SecretKey = txtAWSSecretKey.Text;
			config.Region = cmbAWSRegion.Text;
			config.BucketName = txtBucketName.Text;
			config.CannedACL = txtAWSCannedACL.Text;
			config.EncryptionKey = txtAWSEncrytionKey.Text;

			config.GzipFormat = cmbCompressionFormat.Text;
			config.UseGZipIndividual = chkGZipIndividual.Checked;
			config.UseGZipFolder = chkGzipFolder.Checked;
			config.GZipFolderName = txtGzipFolderName.Text;
			config.GZipUsePasswordProtect = chkGzipUsePassword.Checked;
			config.GZipPassword = txtGzipPassword.Text;

			config.MarketView = chkMarketView.Checked;
			config.AllSignalReport = chkAllSignalReport.Checked;
			config.AllMarketHistorical = chkAllMarketHistorical.Checked;
			config.IndustryReport = chkIndustryReport.Checked;
			config.IndustryHistorical = chkIndustryHistorical.Checked;
			config.SectorReport = chkSectorReport.Checked;
			config.SectorHistorical = chkSectorHistorical.Checked;

			config.UploadMasterFiles = chkMasterFile.Checked;
			config.MasterZip = chkMasterZip.Checked;
			config.MasterUnzip = chkMasterUnzip.Checked;
			config.MasterFolder = txtMasterFolder.Text;
			config.MasterZipFolder = txtMasterZipFolder.Text;
			config.MasterProtect = chkMasterProtect.Checked;
			config.MasterPassword = txtMasterPassword.Text;
			config.MasterZipFormat = cmbMasterZipFormat.Text;

			config.UploadOutputNew = chkUploadNew.Checked;
			config.UploadOutputOld = chkUploadOld.Checked;

			Close();
		}

		private void btnCancel_Click(object sender, EventArgs e)
		{
			Close();
		}

		private void chkMasterFile_CheckedChanged(object sender, EventArgs e)
		{
			groupMasterFiles.Enabled = chkMasterFile.Checked;
		}

		private void chkMarketView_CheckedChanged(object sender, EventArgs e)
		{
			groupMarketView.Enabled = chkMarketView.Checked;
		}

		private void chkUseAWSS3_CheckedChanged(object sender, EventArgs e)
		{
			groupAWSInfo.Enabled = chkUseAWSS3.Checked;
			groupGZipSetting.Enabled = chkUseAWSS3.Checked;
			groupMasterFiles.Enabled = chkUseAWSS3.Checked;
			groupMarketView.Enabled = chkUseAWSS3.Checked;
		}
	}
}
