﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ZeroMQ;

namespace SriTAAnalyzer
{
	public class ZeroMQSender
	{
        private const int DISCONNECTED = -1;

        private readonly ZContext context;
        private readonly ZSocket publisher;
        private int port;
        public ZeroMQSender()
        {
            context = new ZContext();
            publisher = new ZSocket(context, ZSocketType.PUB);
            port = DISCONNECTED;
        }

        /// <summary>
        /// Start publisher on specified port
        /// </summary>
        /// <param name="port">Port to publish message</param>
        public void Start(string ip, int port)
        {
            try
			{
                this.port = port;
                publisher.Bind($"tcp://{ip}:{port}");
            }
            catch
			{

			}
        }

        /// <summary>
        /// Send broadcast message
        /// </summary>
        /// <param name="msg">message to be sent</param>
        public void SendMessage(string msg)
        {
            lock(this)
			{
                if (port == DISCONNECTED)
                    return;
                //var update = string.Format("{0},{1:MM/dd/yyyy,HH:mm:ss}", msg.FilePath, msg.ProcessedTime);
                using (var frame = new ZFrame(msg))
                {
                    publisher.Send(frame);
                }
            }
        }

        /// <summary>
        /// Stop sending broadcast messsage
        /// </summary>
        public void Stop()
        {
            ZError er;
            if (!publisher.Unbind(publisher.LastEndpoint, out er))
                Console.WriteLine(er.Text);
            port = DISCONNECTED;
        }

        /// <summary>
        /// Dispose and release all resource
        /// </summary>
        public void Dispose()
        {
            publisher?.Dispose();
            context?.Dispose();
        }
    }
}
