﻿namespace SriTAAnalyzer
{
	partial class FrmMain
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.groupDay = new System.Windows.Forms.GroupBox();
			this.txtMultiplierDay = new System.Windows.Forms.TextBox();
			this.label11 = new System.Windows.Forms.Label();
			this.label20 = new System.Windows.Forms.Label();
			this.cmbSortDay = new System.Windows.Forms.ComboBox();
			this.label5 = new System.Windows.Forms.Label();
			this.cmbUnadjustedDay = new System.Windows.Forms.ComboBox();
			this.dtEndDay = new System.Windows.Forms.DateTimePicker();
			this.dtStartDay = new System.Windows.Forms.DateTimePicker();
			this.label3 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.cmbTimeFrameDay = new System.Windows.Forms.ComboBox();
			this.txtBarDay = new System.Windows.Forms.TextBox();
			this.lblBarLimit = new System.Windows.Forms.Label();
			this.lblTimeFrame = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.btnBrowseOutputFolderDay = new System.Windows.Forms.Button();
			this.txtOutputFolderDay = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.btnBrowseInputFolderDay = new System.Windows.Forms.Button();
			this.txtInputFolderDay = new System.Windows.Forms.TextBox();
			this.btnStart = new System.Windows.Forms.Button();
			this.btnExit = new System.Windows.Forms.Button();
			this.timerUpdate = new System.Windows.Forms.Timer(this.components);
			this.groupDownloadSetting = new System.Windows.Forms.GroupBox();
			this.radioUpdateStatic = new System.Windows.Forms.RadioButton();
			this.radioUpdateSchedule = new System.Windows.Forms.RadioButton();
			this.radioUpdateAuto = new System.Windows.Forms.RadioButton();
			this.label33 = new System.Windows.Forms.Label();
			this.btnBrowseUpdateSchedule = new System.Windows.Forms.Button();
			this.txtUpdateSchedule = new System.Windows.Forms.TextBox();
			this.label32 = new System.Windows.Forms.Label();
			this.btnBrowseSymbolList = new System.Windows.Forms.Button();
			this.txtSymbolList = new System.Windows.Forms.TextBox();
			this.panelLocalDataFeedSetting = new System.Windows.Forms.Panel();
			this.lblLocalDataFolder = new System.Windows.Forms.Label();
			this.btnBrowseLocalDataFolder = new System.Windows.Forms.Button();
			this.txtLocalDataFolder = new System.Windows.Forms.TextBox();
			this.panelPolygonDataFeedSetting = new System.Windows.Forms.Panel();
			this.lblPolygonKey = new System.Windows.Forms.Label();
			this.txtPolygonAPIKey = new System.Windows.Forms.TextBox();
			this.chkRoundVol = new System.Windows.Forms.CheckBox();
			this.chkRoundClose = new System.Windows.Forms.CheckBox();
			this.chkRoundChange = new System.Windows.Forms.CheckBox();
			this.txtRounding = new System.Windows.Forms.TextBox();
			this.label19 = new System.Windows.Forms.Label();
			this.label8 = new System.Windows.Forms.Label();
			this.cmbDataFeedType = new System.Windows.Forms.ComboBox();
			this.label7 = new System.Windows.Forms.Label();
			this.txtDelay = new System.Windows.Forms.TextBox();
			this.label18 = new System.Windows.Forms.Label();
			this.btnROutputSettings = new System.Windows.Forms.Button();
			this.chkROutput = new System.Windows.Forms.CheckBox();
			this.chkBackfillUpdate = new System.Windows.Forms.CheckBox();
			this.chkCalendarAutoStart = new System.Windows.Forms.CheckBox();
			this.radioCO = new System.Windows.Forms.RadioButton();
			this.radioHL = new System.Windows.Forms.RadioButton();
			this.radioOHLC = new System.Windows.Forms.RadioButton();
			this.radioHLC = new System.Windows.Forms.RadioButton();
			this.chkCloseBarUpdate = new System.Windows.Forms.CheckBox();
			this.chkAppendData = new System.Windows.Forms.CheckBox();
			this.label10 = new System.Windows.Forms.Label();
			this.label9 = new System.Windows.Forms.Label();
			this.chkMarketHoursOnly = new System.Windows.Forms.CheckBox();
			this.dateTimeEnd = new System.Windows.Forms.DateTimePicker();
			this.dateTimeStart = new System.Windows.Forms.DateTimePicker();
			this.statusStrip1 = new System.Windows.Forms.StatusStrip();
			this.lblProcessStatus = new System.Windows.Forms.ToolStripStatusLabel();
			this.statusProgressBar = new System.Windows.Forms.ToolStripProgressBar();
			this.lblSocketState = new System.Windows.Forms.Label();
			this.btnSidewayFilters = new System.Windows.Forms.Button();
			this.btnMarketView = new System.Windows.Forms.Button();
			this.btnAWSSettings = new System.Windows.Forms.Button();
			this.button1 = new System.Windows.Forms.Button();
			this.chkDay = new System.Windows.Forms.CheckBox();
			this.chkSwing = new System.Windows.Forms.CheckBox();
			this.groupSwing = new System.Windows.Forms.GroupBox();
			this.txtMultiplierSwing = new System.Windows.Forms.TextBox();
			this.label6 = new System.Windows.Forms.Label();
			this.label12 = new System.Windows.Forms.Label();
			this.cmbSortSwing = new System.Windows.Forms.ComboBox();
			this.label13 = new System.Windows.Forms.Label();
			this.cmbUnadjustedSwing = new System.Windows.Forms.ComboBox();
			this.dtEndSwing = new System.Windows.Forms.DateTimePicker();
			this.dtStartSwing = new System.Windows.Forms.DateTimePicker();
			this.label14 = new System.Windows.Forms.Label();
			this.label15 = new System.Windows.Forms.Label();
			this.cmbTimeFrameSwing = new System.Windows.Forms.ComboBox();
			this.txtBarSwing = new System.Windows.Forms.TextBox();
			this.label16 = new System.Windows.Forms.Label();
			this.label17 = new System.Windows.Forms.Label();
			this.label21 = new System.Windows.Forms.Label();
			this.btnBrowseOutputSwing = new System.Windows.Forms.Button();
			this.txtOutputSwing = new System.Windows.Forms.TextBox();
			this.label22 = new System.Windows.Forms.Label();
			this.btnBrowseInputSwing = new System.Windows.Forms.Button();
			this.txtInputSwing = new System.Windows.Forms.TextBox();
			this.chkTrend = new System.Windows.Forms.CheckBox();
			this.groupTrend = new System.Windows.Forms.GroupBox();
			this.txtMultiplierTrend = new System.Windows.Forms.TextBox();
			this.label23 = new System.Windows.Forms.Label();
			this.label24 = new System.Windows.Forms.Label();
			this.cmbSortTrend = new System.Windows.Forms.ComboBox();
			this.label25 = new System.Windows.Forms.Label();
			this.cmbUnadjustedTrend = new System.Windows.Forms.ComboBox();
			this.dtEndTrend = new System.Windows.Forms.DateTimePicker();
			this.dtStartTrend = new System.Windows.Forms.DateTimePicker();
			this.label26 = new System.Windows.Forms.Label();
			this.label27 = new System.Windows.Forms.Label();
			this.cmbTimeFrameTrend = new System.Windows.Forms.ComboBox();
			this.txtBarTrend = new System.Windows.Forms.TextBox();
			this.label28 = new System.Windows.Forms.Label();
			this.label29 = new System.Windows.Forms.Label();
			this.label30 = new System.Windows.Forms.Label();
			this.txtBrowseOutputTrend = new System.Windows.Forms.Button();
			this.txtOutputTrend = new System.Windows.Forms.TextBox();
			this.label31 = new System.Windows.Forms.Label();
			this.txtBrowseInputTrend = new System.Windows.Forms.Button();
			this.txtInputTrend = new System.Windows.Forms.TextBox();
			this.btnTASettings = new System.Windows.Forms.Button();
			this.groupDay.SuspendLayout();
			this.groupDownloadSetting.SuspendLayout();
			this.panelLocalDataFeedSetting.SuspendLayout();
			this.panelPolygonDataFeedSetting.SuspendLayout();
			this.statusStrip1.SuspendLayout();
			this.groupSwing.SuspendLayout();
			this.groupTrend.SuspendLayout();
			this.SuspendLayout();
			// 
			// groupDay
			// 
			this.groupDay.Controls.Add(this.txtMultiplierDay);
			this.groupDay.Controls.Add(this.label11);
			this.groupDay.Controls.Add(this.label20);
			this.groupDay.Controls.Add(this.cmbSortDay);
			this.groupDay.Controls.Add(this.label5);
			this.groupDay.Controls.Add(this.cmbUnadjustedDay);
			this.groupDay.Controls.Add(this.dtEndDay);
			this.groupDay.Controls.Add(this.dtStartDay);
			this.groupDay.Controls.Add(this.label3);
			this.groupDay.Controls.Add(this.label4);
			this.groupDay.Controls.Add(this.cmbTimeFrameDay);
			this.groupDay.Controls.Add(this.txtBarDay);
			this.groupDay.Controls.Add(this.lblBarLimit);
			this.groupDay.Controls.Add(this.lblTimeFrame);
			this.groupDay.Controls.Add(this.label2);
			this.groupDay.Controls.Add(this.btnBrowseOutputFolderDay);
			this.groupDay.Controls.Add(this.txtOutputFolderDay);
			this.groupDay.Controls.Add(this.label1);
			this.groupDay.Controls.Add(this.btnBrowseInputFolderDay);
			this.groupDay.Controls.Add(this.txtInputFolderDay);
			this.groupDay.Location = new System.Drawing.Point(12, 7);
			this.groupDay.Name = "groupDay";
			this.groupDay.Size = new System.Drawing.Size(575, 131);
			this.groupDay.TabIndex = 25;
			this.groupDay.TabStop = false;
			// 
			// txtMultiplierDay
			// 
			this.txtMultiplierDay.Location = new System.Drawing.Point(470, 45);
			this.txtMultiplierDay.Name = "txtMultiplierDay";
			this.txtMultiplierDay.Size = new System.Drawing.Size(89, 20);
			this.txtMultiplierDay.TabIndex = 107;
			// 
			// label11
			// 
			this.label11.AutoSize = true;
			this.label11.Location = new System.Drawing.Point(399, 52);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(48, 13);
			this.label11.TabIndex = 106;
			this.label11.Text = "Multiplier";
			// 
			// label20
			// 
			this.label20.AutoSize = true;
			this.label20.Location = new System.Drawing.Point(421, 78);
			this.label20.Name = "label20";
			this.label20.Size = new System.Drawing.Size(26, 13);
			this.label20.TabIndex = 104;
			this.label20.Text = "Sort";
			// 
			// cmbSortDay
			// 
			this.cmbSortDay.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cmbSortDay.FormattingEnabled = true;
			this.cmbSortDay.Items.AddRange(new object[] {
            "asc",
            "desc"});
			this.cmbSortDay.Location = new System.Drawing.Point(470, 72);
			this.cmbSortDay.Name = "cmbSortDay";
			this.cmbSortDay.Size = new System.Drawing.Size(89, 21);
			this.cmbSortDay.TabIndex = 105;
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(232, 78);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(61, 13);
			this.label5.TabIndex = 102;
			this.label5.Text = "Unadjusted";
			// 
			// cmbUnadjustedDay
			// 
			this.cmbUnadjustedDay.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cmbUnadjustedDay.FormattingEnabled = true;
			this.cmbUnadjustedDay.Items.AddRange(new object[] {
            "False",
            "True"});
			this.cmbUnadjustedDay.Location = new System.Drawing.Point(303, 72);
			this.cmbUnadjustedDay.Name = "cmbUnadjustedDay";
			this.cmbUnadjustedDay.Size = new System.Drawing.Size(79, 21);
			this.cmbUnadjustedDay.TabIndex = 103;
			// 
			// dtEndDay
			// 
			this.dtEndDay.CustomFormat = "MM/dd/yyyy";
			this.dtEndDay.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			this.dtEndDay.Location = new System.Drawing.Point(251, 100);
			this.dtEndDay.Name = "dtEndDay";
			this.dtEndDay.Size = new System.Drawing.Size(90, 20);
			this.dtEndDay.TabIndex = 100;
			// 
			// dtStartDay
			// 
			this.dtStartDay.CustomFormat = "MM/dd/yyyy";
			this.dtStartDay.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			this.dtStartDay.Location = new System.Drawing.Point(118, 100);
			this.dtStartDay.Name = "dtStartDay";
			this.dtStartDay.Size = new System.Drawing.Size(90, 20);
			this.dtStartDay.TabIndex = 98;
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(223, 107);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(14, 13);
			this.label3.TabIndex = 97;
			this.label3.Text = "~";
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(72, 107);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(30, 13);
			this.label4.TabIndex = 96;
			this.label4.Text = "Date";
			// 
			// cmbTimeFrameDay
			// 
			this.cmbTimeFrameDay.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cmbTimeFrameDay.FormattingEnabled = true;
			this.cmbTimeFrameDay.Items.AddRange(new object[] {
            "1Min"});
			this.cmbTimeFrameDay.Location = new System.Drawing.Point(470, 18);
			this.cmbTimeFrameDay.Name = "cmbTimeFrameDay";
			this.cmbTimeFrameDay.Size = new System.Drawing.Size(89, 21);
			this.cmbTimeFrameDay.TabIndex = 95;
			// 
			// txtBarDay
			// 
			this.txtBarDay.Location = new System.Drawing.Point(118, 73);
			this.txtBarDay.Name = "txtBarDay";
			this.txtBarDay.Size = new System.Drawing.Size(90, 20);
			this.txtBarDay.TabIndex = 94;
			// 
			// lblBarLimit
			// 
			this.lblBarLimit.AutoSize = true;
			this.lblBarLimit.Location = new System.Drawing.Point(13, 76);
			this.lblBarLimit.Name = "lblBarLimit";
			this.lblBarLimit.Size = new System.Drawing.Size(85, 13);
			this.lblBarLimit.TabIndex = 93;
			this.lblBarLimit.Text = "#Bar(1 ~ 50000)";
			// 
			// lblTimeFrame
			// 
			this.lblTimeFrame.AutoSize = true;
			this.lblTimeFrame.Location = new System.Drawing.Point(391, 21);
			this.lblTimeFrame.Name = "lblTimeFrame";
			this.lblTimeFrame.Size = new System.Drawing.Size(59, 13);
			this.lblTimeFrame.TabIndex = 92;
			this.lblTimeFrame.Text = "TimeFrame";
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(26, 48);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(71, 13);
			this.label2.TabIndex = 91;
			this.label2.Text = "Output Folder";
			// 
			// btnBrowseOutputFolderDay
			// 
			this.btnBrowseOutputFolderDay.Location = new System.Drawing.Point(341, 44);
			this.btnBrowseOutputFolderDay.Name = "btnBrowseOutputFolderDay";
			this.btnBrowseOutputFolderDay.Size = new System.Drawing.Size(27, 22);
			this.btnBrowseOutputFolderDay.TabIndex = 90;
			this.btnBrowseOutputFolderDay.Text = "...";
			this.btnBrowseOutputFolderDay.UseVisualStyleBackColor = true;
			this.btnBrowseOutputFolderDay.Click += new System.EventHandler(this.btnBrowseOutputFolderDay_Click);
			// 
			// txtOutputFolderDay
			// 
			this.txtOutputFolderDay.Location = new System.Drawing.Point(118, 45);
			this.txtOutputFolderDay.Name = "txtOutputFolderDay";
			this.txtOutputFolderDay.Size = new System.Drawing.Size(223, 20);
			this.txtOutputFolderDay.TabIndex = 89;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(35, 22);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(63, 13);
			this.label1.TabIndex = 88;
			this.label1.Text = "Input Folder";
			// 
			// btnBrowseInputFolderDay
			// 
			this.btnBrowseInputFolderDay.Location = new System.Drawing.Point(341, 17);
			this.btnBrowseInputFolderDay.Name = "btnBrowseInputFolderDay";
			this.btnBrowseInputFolderDay.Size = new System.Drawing.Size(27, 22);
			this.btnBrowseInputFolderDay.TabIndex = 87;
			this.btnBrowseInputFolderDay.Text = "...";
			this.btnBrowseInputFolderDay.UseVisualStyleBackColor = true;
			this.btnBrowseInputFolderDay.Click += new System.EventHandler(this.btnBrowseInputFolderDay_Click);
			// 
			// txtInputFolderDay
			// 
			this.txtInputFolderDay.Location = new System.Drawing.Point(118, 18);
			this.txtInputFolderDay.Name = "txtInputFolderDay";
			this.txtInputFolderDay.Size = new System.Drawing.Size(223, 20);
			this.txtInputFolderDay.TabIndex = 86;
			// 
			// btnStart
			// 
			this.btnStart.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
			this.btnStart.Location = new System.Drawing.Point(12, 704);
			this.btnStart.Name = "btnStart";
			this.btnStart.Size = new System.Drawing.Size(188, 28);
			this.btnStart.TabIndex = 43;
			this.btnStart.Text = "Start";
			this.btnStart.UseVisualStyleBackColor = true;
			this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
			// 
			// btnExit
			// 
			this.btnExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
			this.btnExit.Location = new System.Drawing.Point(400, 772);
			this.btnExit.Name = "btnExit";
			this.btnExit.Size = new System.Drawing.Size(188, 28);
			this.btnExit.TabIndex = 48;
			this.btnExit.Text = "Exit";
			this.btnExit.UseVisualStyleBackColor = true;
			this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
			// 
			// timerUpdate
			// 
			this.timerUpdate.Enabled = true;
			this.timerUpdate.Interval = 1000;
			// 
			// groupDownloadSetting
			// 
			this.groupDownloadSetting.Controls.Add(this.radioUpdateStatic);
			this.groupDownloadSetting.Controls.Add(this.radioUpdateSchedule);
			this.groupDownloadSetting.Controls.Add(this.radioUpdateAuto);
			this.groupDownloadSetting.Controls.Add(this.label33);
			this.groupDownloadSetting.Controls.Add(this.btnBrowseUpdateSchedule);
			this.groupDownloadSetting.Controls.Add(this.txtUpdateSchedule);
			this.groupDownloadSetting.Controls.Add(this.label32);
			this.groupDownloadSetting.Controls.Add(this.btnBrowseSymbolList);
			this.groupDownloadSetting.Controls.Add(this.txtSymbolList);
			this.groupDownloadSetting.Controls.Add(this.panelLocalDataFeedSetting);
			this.groupDownloadSetting.Controls.Add(this.panelPolygonDataFeedSetting);
			this.groupDownloadSetting.Controls.Add(this.chkRoundVol);
			this.groupDownloadSetting.Controls.Add(this.chkRoundClose);
			this.groupDownloadSetting.Controls.Add(this.chkRoundChange);
			this.groupDownloadSetting.Controls.Add(this.txtRounding);
			this.groupDownloadSetting.Controls.Add(this.label19);
			this.groupDownloadSetting.Controls.Add(this.label8);
			this.groupDownloadSetting.Controls.Add(this.cmbDataFeedType);
			this.groupDownloadSetting.Controls.Add(this.label7);
			this.groupDownloadSetting.Controls.Add(this.txtDelay);
			this.groupDownloadSetting.Controls.Add(this.label18);
			this.groupDownloadSetting.Controls.Add(this.btnROutputSettings);
			this.groupDownloadSetting.Controls.Add(this.chkROutput);
			this.groupDownloadSetting.Controls.Add(this.chkBackfillUpdate);
			this.groupDownloadSetting.Controls.Add(this.chkCalendarAutoStart);
			this.groupDownloadSetting.Controls.Add(this.radioCO);
			this.groupDownloadSetting.Controls.Add(this.radioHL);
			this.groupDownloadSetting.Controls.Add(this.radioOHLC);
			this.groupDownloadSetting.Controls.Add(this.radioHLC);
			this.groupDownloadSetting.Controls.Add(this.chkCloseBarUpdate);
			this.groupDownloadSetting.Controls.Add(this.chkAppendData);
			this.groupDownloadSetting.Controls.Add(this.label10);
			this.groupDownloadSetting.Controls.Add(this.label9);
			this.groupDownloadSetting.Controls.Add(this.chkMarketHoursOnly);
			this.groupDownloadSetting.Controls.Add(this.dateTimeEnd);
			this.groupDownloadSetting.Controls.Add(this.dateTimeStart);
			this.groupDownloadSetting.Location = new System.Drawing.Point(11, 422);
			this.groupDownloadSetting.Name = "groupDownloadSetting";
			this.groupDownloadSetting.Size = new System.Drawing.Size(574, 276);
			this.groupDownloadSetting.TabIndex = 50;
			this.groupDownloadSetting.TabStop = false;
			this.groupDownloadSetting.Text = "Data Download Settings";
			this.groupDownloadSetting.Enter += new System.EventHandler(this.groupDownloadSetting_Enter);
			// 
			// radioUpdateStatic
			// 
			this.radioUpdateStatic.AutoSize = true;
			this.radioUpdateStatic.Location = new System.Drawing.Point(140, 88);
			this.radioUpdateStatic.Name = "radioUpdateStatic";
			this.radioUpdateStatic.Size = new System.Drawing.Size(52, 17);
			this.radioUpdateStatic.TabIndex = 0;
			this.radioUpdateStatic.TabStop = true;
			this.radioUpdateStatic.Text = "Static";
			this.radioUpdateStatic.UseVisualStyleBackColor = true;
			this.radioUpdateStatic.CheckedChanged += new System.EventHandler(this.radioUpdateStatic_CheckedChanged);
			// 
			// radioUpdateSchedule
			// 
			this.radioUpdateSchedule.AutoSize = true;
			this.radioUpdateSchedule.Location = new System.Drawing.Point(140, 116);
			this.radioUpdateSchedule.Name = "radioUpdateSchedule";
			this.radioUpdateSchedule.Size = new System.Drawing.Size(109, 17);
			this.radioUpdateSchedule.TabIndex = 2;
			this.radioUpdateSchedule.TabStop = true;
			this.radioUpdateSchedule.Text = "Auto by Schedule";
			this.radioUpdateSchedule.UseVisualStyleBackColor = true;
			this.radioUpdateSchedule.CheckedChanged += new System.EventHandler(this.radioUpdateSchedule_CheckedChanged);
			// 
			// radioUpdateAuto
			// 
			this.radioUpdateAuto.AutoSize = true;
			this.radioUpdateAuto.Location = new System.Drawing.Point(267, 88);
			this.radioUpdateAuto.Name = "radioUpdateAuto";
			this.radioUpdateAuto.Size = new System.Drawing.Size(47, 17);
			this.radioUpdateAuto.TabIndex = 1;
			this.radioUpdateAuto.TabStop = true;
			this.radioUpdateAuto.Text = "Auto";
			this.radioUpdateAuto.UseVisualStyleBackColor = true;
			this.radioUpdateAuto.CheckedChanged += new System.EventHandler(this.radioUpdateAuto_CheckedChanged);
			// 
			// label33
			// 
			this.label33.AutoSize = true;
			this.label33.Location = new System.Drawing.Point(260, 118);
			this.label33.Name = "label33";
			this.label33.Size = new System.Drawing.Size(61, 13);
			this.label33.TabIndex = 88;
			this.label33.Text = "Interval File";
			// 
			// btnBrowseUpdateSchedule
			// 
			this.btnBrowseUpdateSchedule.Location = new System.Drawing.Point(537, 114);
			this.btnBrowseUpdateSchedule.Name = "btnBrowseUpdateSchedule";
			this.btnBrowseUpdateSchedule.Size = new System.Drawing.Size(27, 22);
			this.btnBrowseUpdateSchedule.TabIndex = 87;
			this.btnBrowseUpdateSchedule.Text = "...";
			this.btnBrowseUpdateSchedule.UseVisualStyleBackColor = true;
			this.btnBrowseUpdateSchedule.Click += new System.EventHandler(this.btnBrowseUpdateSchedule_Click);
			// 
			// txtUpdateSchedule
			// 
			this.txtUpdateSchedule.Location = new System.Drawing.Point(327, 115);
			this.txtUpdateSchedule.Name = "txtUpdateSchedule";
			this.txtUpdateSchedule.Size = new System.Drawing.Size(210, 20);
			this.txtUpdateSchedule.TabIndex = 86;
			// 
			// label32
			// 
			this.label32.AutoSize = true;
			this.label32.Location = new System.Drawing.Point(43, 23);
			this.label32.Name = "label32";
			this.label32.Size = new System.Drawing.Size(76, 13);
			this.label32.TabIndex = 85;
			this.label32.Text = "SymbolList File";
			// 
			// btnBrowseSymbolList
			// 
			this.btnBrowseSymbolList.Location = new System.Drawing.Point(418, 18);
			this.btnBrowseSymbolList.Name = "btnBrowseSymbolList";
			this.btnBrowseSymbolList.Size = new System.Drawing.Size(27, 22);
			this.btnBrowseSymbolList.TabIndex = 84;
			this.btnBrowseSymbolList.Text = "...";
			this.btnBrowseSymbolList.UseVisualStyleBackColor = true;
			this.btnBrowseSymbolList.Click += new System.EventHandler(this.btnBrowseSymbolList_Click_1);
			// 
			// txtSymbolList
			// 
			this.txtSymbolList.Location = new System.Drawing.Point(140, 19);
			this.txtSymbolList.Name = "txtSymbolList";
			this.txtSymbolList.Size = new System.Drawing.Size(278, 20);
			this.txtSymbolList.TabIndex = 83;
			// 
			// panelLocalDataFeedSetting
			// 
			this.panelLocalDataFeedSetting.Controls.Add(this.lblLocalDataFolder);
			this.panelLocalDataFeedSetting.Controls.Add(this.btnBrowseLocalDataFolder);
			this.panelLocalDataFeedSetting.Controls.Add(this.txtLocalDataFolder);
			this.panelLocalDataFeedSetting.Location = new System.Drawing.Point(270, 47);
			this.panelLocalDataFeedSetting.Name = "panelLocalDataFeedSetting";
			this.panelLocalDataFeedSetting.Size = new System.Drawing.Size(293, 30);
			this.panelLocalDataFeedSetting.TabIndex = 82;
			this.panelLocalDataFeedSetting.Visible = false;
			// 
			// lblLocalDataFolder
			// 
			this.lblLocalDataFolder.AutoSize = true;
			this.lblLocalDataFolder.Location = new System.Drawing.Point(4, 11);
			this.lblLocalDataFolder.Name = "lblLocalDataFolder";
			this.lblLocalDataFolder.Size = new System.Drawing.Size(67, 13);
			this.lblLocalDataFolder.TabIndex = 79;
			this.lblLocalDataFolder.Text = "Data Source";
			// 
			// btnBrowseLocalDataFolder
			// 
			this.btnBrowseLocalDataFolder.Location = new System.Drawing.Point(262, 6);
			this.btnBrowseLocalDataFolder.Name = "btnBrowseLocalDataFolder";
			this.btnBrowseLocalDataFolder.Size = new System.Drawing.Size(27, 22);
			this.btnBrowseLocalDataFolder.TabIndex = 78;
			this.btnBrowseLocalDataFolder.Text = "...";
			this.btnBrowseLocalDataFolder.UseVisualStyleBackColor = true;
			this.btnBrowseLocalDataFolder.Click += new System.EventHandler(this.btnBrowseLocalDataFolder_Click_1);
			// 
			// txtLocalDataFolder
			// 
			this.txtLocalDataFolder.Location = new System.Drawing.Point(73, 7);
			this.txtLocalDataFolder.Name = "txtLocalDataFolder";
			this.txtLocalDataFolder.Size = new System.Drawing.Size(189, 20);
			this.txtLocalDataFolder.TabIndex = 77;
			// 
			// panelPolygonDataFeedSetting
			// 
			this.panelPolygonDataFeedSetting.Controls.Add(this.lblPolygonKey);
			this.panelPolygonDataFeedSetting.Controls.Add(this.txtPolygonAPIKey);
			this.panelPolygonDataFeedSetting.Location = new System.Drawing.Point(270, 48);
			this.panelPolygonDataFeedSetting.Name = "panelPolygonDataFeedSetting";
			this.panelPolygonDataFeedSetting.Size = new System.Drawing.Size(282, 29);
			this.panelPolygonDataFeedSetting.TabIndex = 81;
			// 
			// lblPolygonKey
			// 
			this.lblPolygonKey.AutoSize = true;
			this.lblPolygonKey.Location = new System.Drawing.Point(10, 10);
			this.lblPolygonKey.Name = "lblPolygonKey";
			this.lblPolygonKey.Size = new System.Drawing.Size(45, 13);
			this.lblPolygonKey.TabIndex = 67;
			this.lblPolygonKey.Text = "API Key";
			// 
			// txtPolygonAPIKey
			// 
			this.txtPolygonAPIKey.Location = new System.Drawing.Point(57, 5);
			this.txtPolygonAPIKey.Name = "txtPolygonAPIKey";
			this.txtPolygonAPIKey.Size = new System.Drawing.Size(210, 20);
			this.txtPolygonAPIKey.TabIndex = 68;
			// 
			// chkRoundVol
			// 
			this.chkRoundVol.AutoSize = true;
			this.chkRoundVol.Location = new System.Drawing.Point(435, 245);
			this.chkRoundVol.Name = "chkRoundVol";
			this.chkRoundVol.Size = new System.Drawing.Size(41, 17);
			this.chkRoundVol.TabIndex = 64;
			this.chkRoundVol.Text = "Vol";
			this.chkRoundVol.UseVisualStyleBackColor = true;
			// 
			// chkRoundClose
			// 
			this.chkRoundClose.AutoSize = true;
			this.chkRoundClose.Location = new System.Drawing.Point(335, 245);
			this.chkRoundClose.Name = "chkRoundClose";
			this.chkRoundClose.Size = new System.Drawing.Size(52, 17);
			this.chkRoundClose.TabIndex = 63;
			this.chkRoundClose.Text = "Close";
			this.chkRoundClose.UseVisualStyleBackColor = true;
			// 
			// chkRoundChange
			// 
			this.chkRoundChange.AutoSize = true;
			this.chkRoundChange.Location = new System.Drawing.Point(240, 246);
			this.chkRoundChange.Name = "chkRoundChange";
			this.chkRoundChange.Size = new System.Drawing.Size(63, 17);
			this.chkRoundChange.TabIndex = 62;
			this.chkRoundChange.Text = "Change";
			this.chkRoundChange.UseVisualStyleBackColor = true;
			// 
			// txtRounding
			// 
			this.txtRounding.Location = new System.Drawing.Point(134, 243);
			this.txtRounding.Name = "txtRounding";
			this.txtRounding.Size = new System.Drawing.Size(63, 20);
			this.txtRounding.TabIndex = 61;
			// 
			// label19
			// 
			this.label19.AutoSize = true;
			this.label19.Location = new System.Drawing.Point(33, 247);
			this.label19.Name = "label19";
			this.label19.Size = new System.Drawing.Size(75, 13);
			this.label19.TabIndex = 60;
			this.label19.Text = "Use Rounding";
			// 
			// label8
			// 
			this.label8.AutoSize = true;
			this.label8.Location = new System.Drawing.Point(28, 58);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(91, 13);
			this.label8.TabIndex = 59;
			this.label8.Text = "Primary DataFeed";
			// 
			// cmbDataFeedType
			// 
			this.cmbDataFeedType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cmbDataFeedType.FormattingEnabled = true;
			this.cmbDataFeedType.Items.AddRange(new object[] {
            "Polygon.IO V2",
            "Local Data"});
			this.cmbDataFeedType.Location = new System.Drawing.Point(140, 53);
			this.cmbDataFeedType.Name = "cmbDataFeedType";
			this.cmbDataFeedType.Size = new System.Drawing.Size(100, 21);
			this.cmbDataFeedType.TabIndex = 58;
			this.cmbDataFeedType.SelectedIndexChanged += new System.EventHandler(this.cmbDataFeedType_SelectedIndexChanged);
			// 
			// label7
			// 
			this.label7.AutoSize = true;
			this.label7.Location = new System.Drawing.Point(260, 151);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(14, 13);
			this.label7.TabIndex = 57;
			this.label7.Text = "~";
			// 
			// txtDelay
			// 
			this.txtDelay.Location = new System.Drawing.Point(402, 84);
			this.txtDelay.Name = "txtDelay";
			this.txtDelay.Size = new System.Drawing.Size(79, 20);
			this.txtDelay.TabIndex = 54;
			// 
			// label18
			// 
			this.label18.AutoSize = true;
			this.label18.Location = new System.Drawing.Point(339, 89);
			this.label18.Name = "label18";
			this.label18.Size = new System.Drawing.Size(57, 13);
			this.label18.TabIndex = 53;
			this.label18.Text = "Delay(sec)";
			// 
			// btnROutputSettings
			// 
			this.btnROutputSettings.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
			this.btnROutputSettings.Location = new System.Drawing.Point(425, 205);
			this.btnROutputSettings.Name = "btnROutputSettings";
			this.btnROutputSettings.Size = new System.Drawing.Size(147, 29);
			this.btnROutputSettings.TabIndex = 52;
			this.btnROutputSettings.Text = "R File Output Settings";
			this.btnROutputSettings.UseVisualStyleBackColor = true;
			this.btnROutputSettings.Click += new System.EventHandler(this.btnRConfig_Click);
			// 
			// chkROutput
			// 
			this.chkROutput.AutoSize = true;
			this.chkROutput.Location = new System.Drawing.Point(334, 214);
			this.chkROutput.Name = "chkROutput";
			this.chkROutput.Size = new System.Drawing.Size(93, 17);
			this.chkROutput.TabIndex = 51;
			this.chkROutput.Text = "Output R Files";
			this.chkROutput.UseVisualStyleBackColor = true;
			this.chkROutput.CheckedChanged += new System.EventHandler(this.chkROutput_CheckedChanged);
			// 
			// chkBackfillUpdate
			// 
			this.chkBackfillUpdate.AutoSize = true;
			this.chkBackfillUpdate.Location = new System.Drawing.Point(190, 216);
			this.chkBackfillUpdate.Name = "chkBackfillUpdate";
			this.chkBackfillUpdate.Size = new System.Drawing.Size(98, 17);
			this.chkBackfillUpdate.TabIndex = 49;
			this.chkBackfillUpdate.Text = "Backfill Update";
			this.chkBackfillUpdate.UseVisualStyleBackColor = true;
			// 
			// chkCalendarAutoStart
			// 
			this.chkCalendarAutoStart.AutoSize = true;
			this.chkCalendarAutoStart.Location = new System.Drawing.Point(35, 215);
			this.chkCalendarAutoStart.Name = "chkCalendarAutoStart";
			this.chkCalendarAutoStart.Size = new System.Drawing.Size(133, 17);
			this.chkCalendarAutoStart.TabIndex = 46;
			this.chkCalendarAutoStart.Text = "Auto Start By Calendar";
			this.chkCalendarAutoStart.UseVisualStyleBackColor = true;
			this.chkCalendarAutoStart.CheckedChanged += new System.EventHandler(this.chkCalendarAutoStart_CheckedChanged);
			// 
			// radioCO
			// 
			this.radioCO.AutoCheck = false;
			this.radioCO.AutoSize = true;
			this.radioCO.Location = new System.Drawing.Point(389, 180);
			this.radioCO.Name = "radioCO";
			this.radioCO.Size = new System.Drawing.Size(101, 17);
			this.radioCO.TabIndex = 44;
			this.radioCO.Text = "C > O OR C < O";
			this.radioCO.UseVisualStyleBackColor = true;
			this.radioCO.Click += new System.EventHandler(this.radioHL_Click);
			// 
			// radioHL
			// 
			this.radioHL.AutoCheck = false;
			this.radioHL.AutoSize = true;
			this.radioHL.Location = new System.Drawing.Point(334, 180);
			this.radioHL.Name = "radioHL";
			this.radioHL.Size = new System.Drawing.Size(39, 17);
			this.radioHL.TabIndex = 33;
			this.radioHL.Text = "HL";
			this.radioHL.UseVisualStyleBackColor = true;
			this.radioHL.Click += new System.EventHandler(this.radioHL_Click);
			// 
			// radioOHLC
			// 
			this.radioOHLC.AutoCheck = false;
			this.radioOHLC.AutoSize = true;
			this.radioOHLC.Location = new System.Drawing.Point(265, 181);
			this.radioOHLC.Name = "radioOHLC";
			this.radioOHLC.Size = new System.Drawing.Size(54, 17);
			this.radioOHLC.TabIndex = 32;
			this.radioOHLC.Text = "OHLC";
			this.radioOHLC.UseVisualStyleBackColor = true;
			this.radioOHLC.Click += new System.EventHandler(this.radioHL_Click);
			// 
			// radioHLC
			// 
			this.radioHLC.AutoCheck = false;
			this.radioHLC.AutoSize = true;
			this.radioHLC.Location = new System.Drawing.Point(190, 181);
			this.radioHLC.Name = "radioHLC";
			this.radioHLC.Size = new System.Drawing.Size(46, 17);
			this.radioHLC.TabIndex = 31;
			this.radioHLC.Text = "HLC";
			this.radioHLC.UseVisualStyleBackColor = true;
			this.radioHLC.Click += new System.EventHandler(this.radioHL_Click);
			// 
			// chkCloseBarUpdate
			// 
			this.chkCloseBarUpdate.AutoSize = true;
			this.chkCloseBarUpdate.Location = new System.Drawing.Point(35, 182);
			this.chkCloseBarUpdate.Name = "chkCloseBarUpdate";
			this.chkCloseBarUpdate.Size = new System.Drawing.Size(103, 17);
			this.chkCloseBarUpdate.TabIndex = 40;
			this.chkCloseBarUpdate.Text = "CloseBarUpdate";
			this.chkCloseBarUpdate.UseVisualStyleBackColor = true;
			this.chkCloseBarUpdate.CheckedChanged += new System.EventHandler(this.chkCloseBarUpdate_CheckedChanged);
			// 
			// chkAppendData
			// 
			this.chkAppendData.AutoSize = true;
			this.chkAppendData.Location = new System.Drawing.Point(487, 114);
			this.chkAppendData.Name = "chkAppendData";
			this.chkAppendData.Size = new System.Drawing.Size(89, 17);
			this.chkAppendData.TabIndex = 39;
			this.chkAppendData.Text = "Append Data";
			this.chkAppendData.UseVisualStyleBackColor = true;
			this.chkAppendData.Visible = false;
			// 
			// label10
			// 
			this.label10.AutoSize = true;
			this.label10.Location = new System.Drawing.Point(71, 152);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(68, 13);
			this.label10.TabIndex = 33;
			this.label10.Text = "MarketHours";
			// 
			// label9
			// 
			this.label9.AutoSize = true;
			this.label9.Location = new System.Drawing.Point(50, 90);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(72, 13);
			this.label9.TabIndex = 30;
			this.label9.Text = "Process Type";
			// 
			// chkMarketHoursOnly
			// 
			this.chkMarketHoursOnly.AutoSize = true;
			this.chkMarketHoursOnly.Location = new System.Drawing.Point(411, 150);
			this.chkMarketHoursOnly.Name = "chkMarketHoursOnly";
			this.chkMarketHoursOnly.Size = new System.Drawing.Size(137, 17);
			this.chkMarketHoursOnly.TabIndex = 27;
			this.chkMarketHoursOnly.Text = "MarketHours Data Only";
			this.chkMarketHoursOnly.UseVisualStyleBackColor = true;
			this.chkMarketHoursOnly.CheckedChanged += new System.EventHandler(this.chkMarketHoursOnly_CheckedChanged);
			// 
			// dateTimeEnd
			// 
			this.dateTimeEnd.CustomFormat = "hh:mm tt";
			this.dateTimeEnd.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			this.dateTimeEnd.Location = new System.Drawing.Point(288, 147);
			this.dateTimeEnd.Name = "dateTimeEnd";
			this.dateTimeEnd.ShowUpDown = true;
			this.dateTimeEnd.Size = new System.Drawing.Size(90, 20);
			this.dateTimeEnd.TabIndex = 26;
			this.dateTimeEnd.Value = new System.DateTime(2020, 6, 2, 16, 0, 0, 0);
			// 
			// dateTimeStart
			// 
			this.dateTimeStart.CustomFormat = "hh:mm tt";
			this.dateTimeStart.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			this.dateTimeStart.Location = new System.Drawing.Point(159, 148);
			this.dateTimeStart.Name = "dateTimeStart";
			this.dateTimeStart.ShowUpDown = true;
			this.dateTimeStart.Size = new System.Drawing.Size(90, 20);
			this.dateTimeStart.TabIndex = 25;
			this.dateTimeStart.Value = new System.DateTime(2020, 6, 2, 9, 30, 0, 0);
			// 
			// statusStrip1
			// 
			this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lblProcessStatus,
            this.statusProgressBar});
			this.statusStrip1.Location = new System.Drawing.Point(0, 807);
			this.statusStrip1.Name = "statusStrip1";
			this.statusStrip1.Size = new System.Drawing.Size(599, 22);
			this.statusStrip1.SizingGrip = false;
			this.statusStrip1.TabIndex = 51;
			this.statusStrip1.Text = "statusStrip1";
			// 
			// lblProcessStatus
			// 
			this.lblProcessStatus.Name = "lblProcessStatus";
			this.lblProcessStatus.Size = new System.Drawing.Size(584, 17);
			this.lblProcessStatus.Spring = true;
			// 
			// statusProgressBar
			// 
			this.statusProgressBar.Name = "statusProgressBar";
			this.statusProgressBar.Size = new System.Drawing.Size(350, 16);
			this.statusProgressBar.Visible = false;
			// 
			// lblSocketState
			// 
			this.lblSocketState.AutoSize = true;
			this.lblSocketState.Location = new System.Drawing.Point(208, 783);
			this.lblSocketState.Name = "lblSocketState";
			this.lblSocketState.Size = new System.Drawing.Size(0, 13);
			this.lblSocketState.TabIndex = 54;
			// 
			// btnSidewayFilters
			// 
			this.btnSidewayFilters.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
			this.btnSidewayFilters.Location = new System.Drawing.Point(206, 704);
			this.btnSidewayFilters.Name = "btnSidewayFilters";
			this.btnSidewayFilters.Size = new System.Drawing.Size(188, 28);
			this.btnSidewayFilters.TabIndex = 59;
			this.btnSidewayFilters.Text = "Sideway Filters";
			this.btnSidewayFilters.UseVisualStyleBackColor = true;
			this.btnSidewayFilters.Click += new System.EventHandler(this.btnSidewayFilters_Click);
			// 
			// btnMarketView
			// 
			this.btnMarketView.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
			this.btnMarketView.Location = new System.Drawing.Point(400, 704);
			this.btnMarketView.Name = "btnMarketView";
			this.btnMarketView.Size = new System.Drawing.Size(188, 28);
			this.btnMarketView.TabIndex = 66;
			this.btnMarketView.Text = "MarketView";
			this.btnMarketView.UseVisualStyleBackColor = true;
			this.btnMarketView.Click += new System.EventHandler(this.btnMarketView_Click);
			// 
			// btnAWSSettings
			// 
			this.btnAWSSettings.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
			this.btnAWSSettings.Location = new System.Drawing.Point(206, 738);
			this.btnAWSSettings.Name = "btnAWSSettings";
			this.btnAWSSettings.Size = new System.Drawing.Size(188, 28);
			this.btnAWSSettings.TabIndex = 67;
			this.btnAWSSettings.Text = "AWS S3 Upload";
			this.btnAWSSettings.UseVisualStyleBackColor = true;
			this.btnAWSSettings.Click += new System.EventHandler(this.btnAWSSettings_Click);
			// 
			// button1
			// 
			this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
			this.button1.Location = new System.Drawing.Point(400, 738);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(188, 28);
			this.button1.TabIndex = 71;
			this.button1.Text = "Pusher";
			this.button1.UseVisualStyleBackColor = true;
			this.button1.Click += new System.EventHandler(this.btnPusherSettings_Click);
			// 
			// chkDay
			// 
			this.chkDay.AutoSize = true;
			this.chkDay.Location = new System.Drawing.Point(20, 4);
			this.chkDay.Name = "chkDay";
			this.chkDay.Size = new System.Drawing.Size(45, 17);
			this.chkDay.TabIndex = 73;
			this.chkDay.Text = "Day";
			this.chkDay.UseVisualStyleBackColor = true;
			this.chkDay.CheckedChanged += new System.EventHandler(this.chkDay_CheckedChanged);
			// 
			// chkSwing
			// 
			this.chkSwing.AutoSize = true;
			this.chkSwing.Location = new System.Drawing.Point(19, 141);
			this.chkSwing.Name = "chkSwing";
			this.chkSwing.Size = new System.Drawing.Size(55, 17);
			this.chkSwing.TabIndex = 75;
			this.chkSwing.Text = "Swing";
			this.chkSwing.UseVisualStyleBackColor = true;
			this.chkSwing.CheckedChanged += new System.EventHandler(this.chkSwing_CheckedChanged);
			// 
			// groupSwing
			// 
			this.groupSwing.Controls.Add(this.txtMultiplierSwing);
			this.groupSwing.Controls.Add(this.label6);
			this.groupSwing.Controls.Add(this.label12);
			this.groupSwing.Controls.Add(this.cmbSortSwing);
			this.groupSwing.Controls.Add(this.label13);
			this.groupSwing.Controls.Add(this.cmbUnadjustedSwing);
			this.groupSwing.Controls.Add(this.dtEndSwing);
			this.groupSwing.Controls.Add(this.dtStartSwing);
			this.groupSwing.Controls.Add(this.label14);
			this.groupSwing.Controls.Add(this.label15);
			this.groupSwing.Controls.Add(this.cmbTimeFrameSwing);
			this.groupSwing.Controls.Add(this.txtBarSwing);
			this.groupSwing.Controls.Add(this.label16);
			this.groupSwing.Controls.Add(this.label17);
			this.groupSwing.Controls.Add(this.label21);
			this.groupSwing.Controls.Add(this.btnBrowseOutputSwing);
			this.groupSwing.Controls.Add(this.txtOutputSwing);
			this.groupSwing.Controls.Add(this.label22);
			this.groupSwing.Controls.Add(this.btnBrowseInputSwing);
			this.groupSwing.Controls.Add(this.txtInputSwing);
			this.groupSwing.Location = new System.Drawing.Point(11, 144);
			this.groupSwing.Name = "groupSwing";
			this.groupSwing.Size = new System.Drawing.Size(575, 131);
			this.groupSwing.TabIndex = 74;
			this.groupSwing.TabStop = false;
			// 
			// txtMultiplierSwing
			// 
			this.txtMultiplierSwing.Location = new System.Drawing.Point(470, 45);
			this.txtMultiplierSwing.Name = "txtMultiplierSwing";
			this.txtMultiplierSwing.Size = new System.Drawing.Size(89, 20);
			this.txtMultiplierSwing.TabIndex = 107;
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Location = new System.Drawing.Point(399, 52);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(48, 13);
			this.label6.TabIndex = 106;
			this.label6.Text = "Multiplier";
			// 
			// label12
			// 
			this.label12.AutoSize = true;
			this.label12.Location = new System.Drawing.Point(421, 78);
			this.label12.Name = "label12";
			this.label12.Size = new System.Drawing.Size(26, 13);
			this.label12.TabIndex = 104;
			this.label12.Text = "Sort";
			// 
			// cmbSortSwing
			// 
			this.cmbSortSwing.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cmbSortSwing.FormattingEnabled = true;
			this.cmbSortSwing.Items.AddRange(new object[] {
            "asc",
            "desc"});
			this.cmbSortSwing.Location = new System.Drawing.Point(470, 72);
			this.cmbSortSwing.Name = "cmbSortSwing";
			this.cmbSortSwing.Size = new System.Drawing.Size(89, 21);
			this.cmbSortSwing.TabIndex = 105;
			// 
			// label13
			// 
			this.label13.AutoSize = true;
			this.label13.Location = new System.Drawing.Point(232, 78);
			this.label13.Name = "label13";
			this.label13.Size = new System.Drawing.Size(61, 13);
			this.label13.TabIndex = 102;
			this.label13.Text = "Unadjusted";
			// 
			// cmbUnadjustedSwing
			// 
			this.cmbUnadjustedSwing.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cmbUnadjustedSwing.FormattingEnabled = true;
			this.cmbUnadjustedSwing.Items.AddRange(new object[] {
            "False",
            "True"});
			this.cmbUnadjustedSwing.Location = new System.Drawing.Point(303, 72);
			this.cmbUnadjustedSwing.Name = "cmbUnadjustedSwing";
			this.cmbUnadjustedSwing.Size = new System.Drawing.Size(79, 21);
			this.cmbUnadjustedSwing.TabIndex = 103;
			// 
			// dtEndSwing
			// 
			this.dtEndSwing.CustomFormat = "MM/dd/yyyy";
			this.dtEndSwing.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			this.dtEndSwing.Location = new System.Drawing.Point(251, 100);
			this.dtEndSwing.Name = "dtEndSwing";
			this.dtEndSwing.Size = new System.Drawing.Size(90, 20);
			this.dtEndSwing.TabIndex = 100;
			// 
			// dtStartSwing
			// 
			this.dtStartSwing.CustomFormat = "MM/dd/yyyy";
			this.dtStartSwing.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			this.dtStartSwing.Location = new System.Drawing.Point(118, 100);
			this.dtStartSwing.Name = "dtStartSwing";
			this.dtStartSwing.Size = new System.Drawing.Size(90, 20);
			this.dtStartSwing.TabIndex = 98;
			// 
			// label14
			// 
			this.label14.AutoSize = true;
			this.label14.Location = new System.Drawing.Point(223, 107);
			this.label14.Name = "label14";
			this.label14.Size = new System.Drawing.Size(14, 13);
			this.label14.TabIndex = 97;
			this.label14.Text = "~";
			// 
			// label15
			// 
			this.label15.AutoSize = true;
			this.label15.Location = new System.Drawing.Point(72, 107);
			this.label15.Name = "label15";
			this.label15.Size = new System.Drawing.Size(30, 13);
			this.label15.TabIndex = 96;
			this.label15.Text = "Date";
			// 
			// cmbTimeFrameSwing
			// 
			this.cmbTimeFrameSwing.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cmbTimeFrameSwing.FormattingEnabled = true;
			this.cmbTimeFrameSwing.Items.AddRange(new object[] {
            "1Min"});
			this.cmbTimeFrameSwing.Location = new System.Drawing.Point(470, 18);
			this.cmbTimeFrameSwing.Name = "cmbTimeFrameSwing";
			this.cmbTimeFrameSwing.Size = new System.Drawing.Size(89, 21);
			this.cmbTimeFrameSwing.TabIndex = 95;
			// 
			// txtBarSwing
			// 
			this.txtBarSwing.Location = new System.Drawing.Point(118, 73);
			this.txtBarSwing.Name = "txtBarSwing";
			this.txtBarSwing.Size = new System.Drawing.Size(90, 20);
			this.txtBarSwing.TabIndex = 94;
			// 
			// label16
			// 
			this.label16.AutoSize = true;
			this.label16.Location = new System.Drawing.Point(13, 76);
			this.label16.Name = "label16";
			this.label16.Size = new System.Drawing.Size(85, 13);
			this.label16.TabIndex = 93;
			this.label16.Text = "#Bar(1 ~ 50000)";
			// 
			// label17
			// 
			this.label17.AutoSize = true;
			this.label17.Location = new System.Drawing.Point(391, 21);
			this.label17.Name = "label17";
			this.label17.Size = new System.Drawing.Size(59, 13);
			this.label17.TabIndex = 92;
			this.label17.Text = "TimeFrame";
			// 
			// label21
			// 
			this.label21.AutoSize = true;
			this.label21.Location = new System.Drawing.Point(26, 48);
			this.label21.Name = "label21";
			this.label21.Size = new System.Drawing.Size(71, 13);
			this.label21.TabIndex = 91;
			this.label21.Text = "Output Folder";
			// 
			// btnBrowseOutputSwing
			// 
			this.btnBrowseOutputSwing.Location = new System.Drawing.Point(341, 44);
			this.btnBrowseOutputSwing.Name = "btnBrowseOutputSwing";
			this.btnBrowseOutputSwing.Size = new System.Drawing.Size(27, 22);
			this.btnBrowseOutputSwing.TabIndex = 90;
			this.btnBrowseOutputSwing.Text = "...";
			this.btnBrowseOutputSwing.UseVisualStyleBackColor = true;
			this.btnBrowseOutputSwing.Click += new System.EventHandler(this.btnBrowseOutputSwing_Click);
			// 
			// txtOutputSwing
			// 
			this.txtOutputSwing.Location = new System.Drawing.Point(118, 45);
			this.txtOutputSwing.Name = "txtOutputSwing";
			this.txtOutputSwing.Size = new System.Drawing.Size(223, 20);
			this.txtOutputSwing.TabIndex = 89;
			// 
			// label22
			// 
			this.label22.AutoSize = true;
			this.label22.Location = new System.Drawing.Point(35, 22);
			this.label22.Name = "label22";
			this.label22.Size = new System.Drawing.Size(63, 13);
			this.label22.TabIndex = 88;
			this.label22.Text = "Input Folder";
			// 
			// btnBrowseInputSwing
			// 
			this.btnBrowseInputSwing.Location = new System.Drawing.Point(341, 17);
			this.btnBrowseInputSwing.Name = "btnBrowseInputSwing";
			this.btnBrowseInputSwing.Size = new System.Drawing.Size(27, 22);
			this.btnBrowseInputSwing.TabIndex = 87;
			this.btnBrowseInputSwing.Text = "...";
			this.btnBrowseInputSwing.UseVisualStyleBackColor = true;
			this.btnBrowseInputSwing.Click += new System.EventHandler(this.btnBrowseInputSwing_Click);
			// 
			// txtInputSwing
			// 
			this.txtInputSwing.Location = new System.Drawing.Point(118, 18);
			this.txtInputSwing.Name = "txtInputSwing";
			this.txtInputSwing.Size = new System.Drawing.Size(223, 20);
			this.txtInputSwing.TabIndex = 86;
			// 
			// chkTrend
			// 
			this.chkTrend.AutoSize = true;
			this.chkTrend.Location = new System.Drawing.Point(19, 278);
			this.chkTrend.Name = "chkTrend";
			this.chkTrend.Size = new System.Drawing.Size(54, 17);
			this.chkTrend.TabIndex = 77;
			this.chkTrend.Text = "Trend";
			this.chkTrend.UseVisualStyleBackColor = true;
			this.chkTrend.CheckedChanged += new System.EventHandler(this.chkTrend_CheckedChanged);
			// 
			// groupTrend
			// 
			this.groupTrend.Controls.Add(this.txtMultiplierTrend);
			this.groupTrend.Controls.Add(this.label23);
			this.groupTrend.Controls.Add(this.label24);
			this.groupTrend.Controls.Add(this.cmbSortTrend);
			this.groupTrend.Controls.Add(this.label25);
			this.groupTrend.Controls.Add(this.cmbUnadjustedTrend);
			this.groupTrend.Controls.Add(this.dtEndTrend);
			this.groupTrend.Controls.Add(this.dtStartTrend);
			this.groupTrend.Controls.Add(this.label26);
			this.groupTrend.Controls.Add(this.label27);
			this.groupTrend.Controls.Add(this.cmbTimeFrameTrend);
			this.groupTrend.Controls.Add(this.txtBarTrend);
			this.groupTrend.Controls.Add(this.label28);
			this.groupTrend.Controls.Add(this.label29);
			this.groupTrend.Controls.Add(this.label30);
			this.groupTrend.Controls.Add(this.txtBrowseOutputTrend);
			this.groupTrend.Controls.Add(this.txtOutputTrend);
			this.groupTrend.Controls.Add(this.label31);
			this.groupTrend.Controls.Add(this.txtBrowseInputTrend);
			this.groupTrend.Controls.Add(this.txtInputTrend);
			this.groupTrend.Location = new System.Drawing.Point(11, 281);
			this.groupTrend.Name = "groupTrend";
			this.groupTrend.Size = new System.Drawing.Size(575, 131);
			this.groupTrend.TabIndex = 76;
			this.groupTrend.TabStop = false;
			// 
			// txtMultiplierTrend
			// 
			this.txtMultiplierTrend.Location = new System.Drawing.Point(470, 45);
			this.txtMultiplierTrend.Name = "txtMultiplierTrend";
			this.txtMultiplierTrend.Size = new System.Drawing.Size(89, 20);
			this.txtMultiplierTrend.TabIndex = 107;
			// 
			// label23
			// 
			this.label23.AutoSize = true;
			this.label23.Location = new System.Drawing.Point(399, 52);
			this.label23.Name = "label23";
			this.label23.Size = new System.Drawing.Size(48, 13);
			this.label23.TabIndex = 106;
			this.label23.Text = "Multiplier";
			// 
			// label24
			// 
			this.label24.AutoSize = true;
			this.label24.Location = new System.Drawing.Point(421, 78);
			this.label24.Name = "label24";
			this.label24.Size = new System.Drawing.Size(26, 13);
			this.label24.TabIndex = 104;
			this.label24.Text = "Sort";
			// 
			// cmbSortTrend
			// 
			this.cmbSortTrend.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cmbSortTrend.FormattingEnabled = true;
			this.cmbSortTrend.Items.AddRange(new object[] {
            "asc",
            "desc"});
			this.cmbSortTrend.Location = new System.Drawing.Point(470, 72);
			this.cmbSortTrend.Name = "cmbSortTrend";
			this.cmbSortTrend.Size = new System.Drawing.Size(89, 21);
			this.cmbSortTrend.TabIndex = 105;
			// 
			// label25
			// 
			this.label25.AutoSize = true;
			this.label25.Location = new System.Drawing.Point(232, 78);
			this.label25.Name = "label25";
			this.label25.Size = new System.Drawing.Size(61, 13);
			this.label25.TabIndex = 102;
			this.label25.Text = "Unadjusted";
			// 
			// cmbUnadjustedTrend
			// 
			this.cmbUnadjustedTrend.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cmbUnadjustedTrend.FormattingEnabled = true;
			this.cmbUnadjustedTrend.Items.AddRange(new object[] {
            "False",
            "True"});
			this.cmbUnadjustedTrend.Location = new System.Drawing.Point(303, 72);
			this.cmbUnadjustedTrend.Name = "cmbUnadjustedTrend";
			this.cmbUnadjustedTrend.Size = new System.Drawing.Size(79, 21);
			this.cmbUnadjustedTrend.TabIndex = 103;
			// 
			// dtEndTrend
			// 
			this.dtEndTrend.CustomFormat = "MM/dd/yyyy";
			this.dtEndTrend.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			this.dtEndTrend.Location = new System.Drawing.Point(251, 100);
			this.dtEndTrend.Name = "dtEndTrend";
			this.dtEndTrend.Size = new System.Drawing.Size(90, 20);
			this.dtEndTrend.TabIndex = 100;
			// 
			// dtStartTrend
			// 
			this.dtStartTrend.CustomFormat = "MM/dd/yyyy";
			this.dtStartTrend.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			this.dtStartTrend.Location = new System.Drawing.Point(118, 100);
			this.dtStartTrend.Name = "dtStartTrend";
			this.dtStartTrend.Size = new System.Drawing.Size(90, 20);
			this.dtStartTrend.TabIndex = 98;
			// 
			// label26
			// 
			this.label26.AutoSize = true;
			this.label26.Location = new System.Drawing.Point(223, 107);
			this.label26.Name = "label26";
			this.label26.Size = new System.Drawing.Size(14, 13);
			this.label26.TabIndex = 97;
			this.label26.Text = "~";
			// 
			// label27
			// 
			this.label27.AutoSize = true;
			this.label27.Location = new System.Drawing.Point(72, 107);
			this.label27.Name = "label27";
			this.label27.Size = new System.Drawing.Size(30, 13);
			this.label27.TabIndex = 96;
			this.label27.Text = "Date";
			// 
			// cmbTimeFrameTrend
			// 
			this.cmbTimeFrameTrend.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cmbTimeFrameTrend.FormattingEnabled = true;
			this.cmbTimeFrameTrend.Items.AddRange(new object[] {
            "1Min",
            "1Hour",
            "1D"});
			this.cmbTimeFrameTrend.Location = new System.Drawing.Point(470, 18);
			this.cmbTimeFrameTrend.Name = "cmbTimeFrameTrend";
			this.cmbTimeFrameTrend.Size = new System.Drawing.Size(89, 21);
			this.cmbTimeFrameTrend.TabIndex = 95;
			// 
			// txtBarTrend
			// 
			this.txtBarTrend.Location = new System.Drawing.Point(118, 73);
			this.txtBarTrend.Name = "txtBarTrend";
			this.txtBarTrend.Size = new System.Drawing.Size(90, 20);
			this.txtBarTrend.TabIndex = 94;
			// 
			// label28
			// 
			this.label28.AutoSize = true;
			this.label28.Location = new System.Drawing.Point(13, 76);
			this.label28.Name = "label28";
			this.label28.Size = new System.Drawing.Size(85, 13);
			this.label28.TabIndex = 93;
			this.label28.Text = "#Bar(1 ~ 50000)";
			// 
			// label29
			// 
			this.label29.AutoSize = true;
			this.label29.Location = new System.Drawing.Point(391, 21);
			this.label29.Name = "label29";
			this.label29.Size = new System.Drawing.Size(59, 13);
			this.label29.TabIndex = 92;
			this.label29.Text = "TimeFrame";
			// 
			// label30
			// 
			this.label30.AutoSize = true;
			this.label30.Location = new System.Drawing.Point(26, 48);
			this.label30.Name = "label30";
			this.label30.Size = new System.Drawing.Size(71, 13);
			this.label30.TabIndex = 91;
			this.label30.Text = "Output Folder";
			// 
			// txtBrowseOutputTrend
			// 
			this.txtBrowseOutputTrend.Location = new System.Drawing.Point(341, 44);
			this.txtBrowseOutputTrend.Name = "txtBrowseOutputTrend";
			this.txtBrowseOutputTrend.Size = new System.Drawing.Size(27, 22);
			this.txtBrowseOutputTrend.TabIndex = 90;
			this.txtBrowseOutputTrend.Text = "...";
			this.txtBrowseOutputTrend.UseVisualStyleBackColor = true;
			this.txtBrowseOutputTrend.Click += new System.EventHandler(this.txtBrowseOutputTrend_Click);
			// 
			// txtOutputTrend
			// 
			this.txtOutputTrend.Location = new System.Drawing.Point(118, 45);
			this.txtOutputTrend.Name = "txtOutputTrend";
			this.txtOutputTrend.Size = new System.Drawing.Size(223, 20);
			this.txtOutputTrend.TabIndex = 89;
			// 
			// label31
			// 
			this.label31.AutoSize = true;
			this.label31.Location = new System.Drawing.Point(35, 22);
			this.label31.Name = "label31";
			this.label31.Size = new System.Drawing.Size(63, 13);
			this.label31.TabIndex = 88;
			this.label31.Text = "Input Folder";
			// 
			// txtBrowseInputTrend
			// 
			this.txtBrowseInputTrend.Location = new System.Drawing.Point(341, 17);
			this.txtBrowseInputTrend.Name = "txtBrowseInputTrend";
			this.txtBrowseInputTrend.Size = new System.Drawing.Size(27, 22);
			this.txtBrowseInputTrend.TabIndex = 87;
			this.txtBrowseInputTrend.Text = "...";
			this.txtBrowseInputTrend.UseVisualStyleBackColor = true;
			this.txtBrowseInputTrend.Click += new System.EventHandler(this.txtBrowseInputTrend_Click);
			// 
			// txtInputTrend
			// 
			this.txtInputTrend.Location = new System.Drawing.Point(118, 18);
			this.txtInputTrend.Name = "txtInputTrend";
			this.txtInputTrend.Size = new System.Drawing.Size(223, 20);
			this.txtInputTrend.TabIndex = 86;
			// 
			// btnTASettings
			// 
			this.btnTASettings.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
			this.btnTASettings.Location = new System.Drawing.Point(12, 738);
			this.btnTASettings.Name = "btnTASettings";
			this.btnTASettings.Size = new System.Drawing.Size(188, 28);
			this.btnTASettings.TabIndex = 78;
			this.btnTASettings.Text = "TA Settings";
			this.btnTASettings.UseVisualStyleBackColor = true;
			this.btnTASettings.Click += new System.EventHandler(this.btnTASettings_Click);
			// 
			// FrmMain
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(599, 829);
			this.Controls.Add(this.btnTASettings);
			this.Controls.Add(this.chkTrend);
			this.Controls.Add(this.groupTrend);
			this.Controls.Add(this.chkSwing);
			this.Controls.Add(this.groupSwing);
			this.Controls.Add(this.chkDay);
			this.Controls.Add(this.button1);
			this.Controls.Add(this.btnAWSSettings);
			this.Controls.Add(this.btnMarketView);
			this.Controls.Add(this.btnSidewayFilters);
			this.Controls.Add(this.lblSocketState);
			this.Controls.Add(this.statusStrip1);
			this.Controls.Add(this.groupDownloadSetting);
			this.Controls.Add(this.btnExit);
			this.Controls.Add(this.btnStart);
			this.Controls.Add(this.groupDay);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.Name = "FrmMain";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "SriTAAnalyzer V2";
			this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FrmMain_FormClosing);
			this.Load += new System.EventHandler(this.FrmMain_Load);
			this.groupDay.ResumeLayout(false);
			this.groupDay.PerformLayout();
			this.groupDownloadSetting.ResumeLayout(false);
			this.groupDownloadSetting.PerformLayout();
			this.panelLocalDataFeedSetting.ResumeLayout(false);
			this.panelLocalDataFeedSetting.PerformLayout();
			this.panelPolygonDataFeedSetting.ResumeLayout(false);
			this.panelPolygonDataFeedSetting.PerformLayout();
			this.statusStrip1.ResumeLayout(false);
			this.statusStrip1.PerformLayout();
			this.groupSwing.ResumeLayout(false);
			this.groupSwing.PerformLayout();
			this.groupTrend.ResumeLayout(false);
			this.groupTrend.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion
		private System.Windows.Forms.GroupBox groupDay;
		private System.Windows.Forms.Button btnStart;
		private System.Windows.Forms.Button btnExit;
		private System.Windows.Forms.Timer timerUpdate;
		private System.Windows.Forms.GroupBox groupDownloadSetting;
		private System.Windows.Forms.StatusStrip statusStrip1;
		private System.Windows.Forms.ToolStripStatusLabel lblProcessStatus;
		private System.Windows.Forms.ToolStripProgressBar statusProgressBar;
		private System.Windows.Forms.CheckBox chkMarketHoursOnly;
		private System.Windows.Forms.DateTimePicker dateTimeEnd;
		private System.Windows.Forms.DateTimePicker dateTimeStart;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.Label label10;
		private System.Windows.Forms.CheckBox chkAppendData;
		private System.Windows.Forms.RadioButton radioCO;
		private System.Windows.Forms.RadioButton radioHL;
		private System.Windows.Forms.RadioButton radioOHLC;
		private System.Windows.Forms.RadioButton radioHLC;
		private System.Windows.Forms.CheckBox chkCloseBarUpdate;
		private System.Windows.Forms.Label lblSocketState;
		private System.Windows.Forms.CheckBox chkBackfillUpdate;
		private System.Windows.Forms.Button btnROutputSettings;
		private System.Windows.Forms.CheckBox chkROutput;
		private System.Windows.Forms.TextBox txtDelay;
		private System.Windows.Forms.Label label18;
		private System.Windows.Forms.Button btnSidewayFilters;
		private System.Windows.Forms.Label label19;
		private System.Windows.Forms.TextBox txtRounding;
		private System.Windows.Forms.CheckBox chkRoundChange;
		private System.Windows.Forms.CheckBox chkRoundClose;
		private System.Windows.Forms.CheckBox chkRoundVol;
		private System.Windows.Forms.CheckBox chkCalendarAutoStart;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.ComboBox cmbDataFeedType;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Button btnMarketView;
		private System.Windows.Forms.Button btnAWSSettings;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Panel panelLocalDataFeedSetting;
		private System.Windows.Forms.Label lblLocalDataFolder;
		private System.Windows.Forms.Button btnBrowseLocalDataFolder;
		private System.Windows.Forms.TextBox txtLocalDataFolder;
		private System.Windows.Forms.Panel panelPolygonDataFeedSetting;
		private System.Windows.Forms.Label lblPolygonKey;
		private System.Windows.Forms.TextBox txtPolygonAPIKey;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Button btnBrowseOutputFolderDay;
		private System.Windows.Forms.TextBox txtOutputFolderDay;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Button btnBrowseInputFolderDay;
		private System.Windows.Forms.TextBox txtInputFolderDay;
		private System.Windows.Forms.TextBox txtMultiplierDay;
		private System.Windows.Forms.Label label11;
		private System.Windows.Forms.Label label20;
		private System.Windows.Forms.ComboBox cmbSortDay;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.ComboBox cmbUnadjustedDay;
		private System.Windows.Forms.DateTimePicker dtEndDay;
		private System.Windows.Forms.DateTimePicker dtStartDay;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.ComboBox cmbTimeFrameDay;
		private System.Windows.Forms.TextBox txtBarDay;
		private System.Windows.Forms.Label lblBarLimit;
		private System.Windows.Forms.Label lblTimeFrame;
		private System.Windows.Forms.CheckBox chkDay;
		private System.Windows.Forms.CheckBox chkSwing;
		private System.Windows.Forms.GroupBox groupSwing;
		private System.Windows.Forms.TextBox txtMultiplierSwing;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label12;
		private System.Windows.Forms.ComboBox cmbSortSwing;
		private System.Windows.Forms.Label label13;
		private System.Windows.Forms.ComboBox cmbUnadjustedSwing;
		private System.Windows.Forms.DateTimePicker dtEndSwing;
		private System.Windows.Forms.DateTimePicker dtStartSwing;
		private System.Windows.Forms.Label label14;
		private System.Windows.Forms.Label label15;
		private System.Windows.Forms.ComboBox cmbTimeFrameSwing;
		private System.Windows.Forms.TextBox txtBarSwing;
		private System.Windows.Forms.Label label16;
		private System.Windows.Forms.Label label17;
		private System.Windows.Forms.Label label21;
		private System.Windows.Forms.Button btnBrowseOutputSwing;
		private System.Windows.Forms.TextBox txtOutputSwing;
		private System.Windows.Forms.Label label22;
		private System.Windows.Forms.Button btnBrowseInputSwing;
		private System.Windows.Forms.TextBox txtInputSwing;
		private System.Windows.Forms.CheckBox chkTrend;
		private System.Windows.Forms.GroupBox groupTrend;
		private System.Windows.Forms.TextBox txtMultiplierTrend;
		private System.Windows.Forms.Label label23;
		private System.Windows.Forms.Label label24;
		private System.Windows.Forms.ComboBox cmbSortTrend;
		private System.Windows.Forms.Label label25;
		private System.Windows.Forms.ComboBox cmbUnadjustedTrend;
		private System.Windows.Forms.DateTimePicker dtEndTrend;
		private System.Windows.Forms.DateTimePicker dtStartTrend;
		private System.Windows.Forms.Label label26;
		private System.Windows.Forms.Label label27;
		private System.Windows.Forms.ComboBox cmbTimeFrameTrend;
		private System.Windows.Forms.TextBox txtBarTrend;
		private System.Windows.Forms.Label label28;
		private System.Windows.Forms.Label label29;
		private System.Windows.Forms.Label label30;
		private System.Windows.Forms.Button txtBrowseOutputTrend;
		private System.Windows.Forms.TextBox txtOutputTrend;
		private System.Windows.Forms.Label label31;
		private System.Windows.Forms.Button txtBrowseInputTrend;
		private System.Windows.Forms.TextBox txtInputTrend;
		private System.Windows.Forms.Label label32;
		private System.Windows.Forms.Button btnBrowseSymbolList;
		private System.Windows.Forms.TextBox txtSymbolList;
		private System.Windows.Forms.Button btnTASettings;
		private System.Windows.Forms.Label label33;
		private System.Windows.Forms.Button btnBrowseUpdateSchedule;
		private System.Windows.Forms.TextBox txtUpdateSchedule;
		private System.Windows.Forms.RadioButton radioUpdateSchedule;
		private System.Windows.Forms.RadioButton radioUpdateAuto;
		private System.Windows.Forms.RadioButton radioUpdateStatic;
	}
}

