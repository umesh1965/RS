﻿
namespace SriTAAnalyzer
{
	partial class FrmPusherConfig
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.label1 = new System.Windows.Forms.Label();
			this.txtAppID = new System.Windows.Forms.TextBox();
			this.txtKey = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.txtSecret = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.txtCluster = new System.Windows.Forms.TextBox();
			this.label4 = new System.Windows.Forms.Label();
			this.txtChannel = new System.Windows.Forms.TextBox();
			this.label5 = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.chkAWSGzipFolder = new System.Windows.Forms.CheckBox();
			this.btnOK = new System.Windows.Forms.Button();
			this.btnCancel = new System.Windows.Forms.Button();
			this.txtMessage = new System.Windows.Forms.TextBox();
			this.label7 = new System.Windows.Forms.Label();
			this.txtEvent = new System.Windows.Forms.TextBox();
			this.label8 = new System.Windows.Forms.Label();
			this.chkSendFilePath = new System.Windows.Forms.CheckBox();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(30, 30);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(40, 13);
			this.label1.TabIndex = 0;
			this.label1.Text = "App ID";
			// 
			// txtAppID
			// 
			this.txtAppID.Location = new System.Drawing.Point(149, 27);
			this.txtAppID.Name = "txtAppID";
			this.txtAppID.Size = new System.Drawing.Size(172, 20);
			this.txtAppID.TabIndex = 1;
			// 
			// txtKey
			// 
			this.txtKey.Location = new System.Drawing.Point(149, 63);
			this.txtKey.Name = "txtKey";
			this.txtKey.Size = new System.Drawing.Size(172, 20);
			this.txtKey.TabIndex = 3;
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(30, 66);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(25, 13);
			this.label2.TabIndex = 2;
			this.label2.Text = "Key";
			// 
			// txtSecret
			// 
			this.txtSecret.Location = new System.Drawing.Point(149, 100);
			this.txtSecret.Name = "txtSecret";
			this.txtSecret.Size = new System.Drawing.Size(172, 20);
			this.txtSecret.TabIndex = 5;
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(30, 103);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(38, 13);
			this.label3.TabIndex = 4;
			this.label3.Text = "Secret";
			// 
			// txtCluster
			// 
			this.txtCluster.Location = new System.Drawing.Point(149, 137);
			this.txtCluster.Name = "txtCluster";
			this.txtCluster.Size = new System.Drawing.Size(172, 20);
			this.txtCluster.TabIndex = 7;
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(30, 140);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(39, 13);
			this.label4.TabIndex = 6;
			this.label4.Text = "Cluster";
			// 
			// txtChannel
			// 
			this.txtChannel.Location = new System.Drawing.Point(149, 174);
			this.txtChannel.Name = "txtChannel";
			this.txtChannel.Size = new System.Drawing.Size(172, 20);
			this.txtChannel.TabIndex = 9;
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(30, 177);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(46, 13);
			this.label5.TabIndex = 8;
			this.label5.Text = "Channel";
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Location = new System.Drawing.Point(30, 288);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(111, 13);
			this.label6.TabIndex = 10;
			this.label6.Text = "Send Notifications For";
			// 
			// chkAWSGzipFolder
			// 
			this.chkAWSGzipFolder.AutoSize = true;
			this.chkAWSGzipFolder.Location = new System.Drawing.Point(149, 316);
			this.chkAWSGzipFolder.Name = "chkAWSGzipFolder";
			this.chkAWSGzipFolder.Size = new System.Drawing.Size(123, 17);
			this.chkAWSGzipFolder.TabIndex = 11;
			this.chkAWSGzipFolder.Text = "AWS S3 Gzip Folder";
			this.chkAWSGzipFolder.UseVisualStyleBackColor = true;
			this.chkAWSGzipFolder.Visible = false;
			// 
			// btnOK
			// 
			this.btnOK.Location = new System.Drawing.Point(63, 346);
			this.btnOK.Name = "btnOK";
			this.btnOK.Size = new System.Drawing.Size(100, 31);
			this.btnOK.TabIndex = 12;
			this.btnOK.Text = "OK";
			this.btnOK.UseVisualStyleBackColor = true;
			this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
			// 
			// btnCancel
			// 
			this.btnCancel.Location = new System.Drawing.Point(192, 346);
			this.btnCancel.Name = "btnCancel";
			this.btnCancel.Size = new System.Drawing.Size(100, 31);
			this.btnCancel.TabIndex = 13;
			this.btnCancel.Text = "Cancel";
			this.btnCancel.UseVisualStyleBackColor = true;
			this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
			// 
			// txtMessage
			// 
			this.txtMessage.Location = new System.Drawing.Point(149, 211);
			this.txtMessage.Name = "txtMessage";
			this.txtMessage.Size = new System.Drawing.Size(172, 20);
			this.txtMessage.TabIndex = 15;
			// 
			// label7
			// 
			this.label7.AutoSize = true;
			this.label7.Location = new System.Drawing.Point(30, 214);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(106, 13);
			this.label7.TabIndex = 14;
			this.label7.Text = "Notification Message";
			// 
			// txtEvent
			// 
			this.txtEvent.Location = new System.Drawing.Point(149, 247);
			this.txtEvent.Name = "txtEvent";
			this.txtEvent.Size = new System.Drawing.Size(172, 20);
			this.txtEvent.TabIndex = 17;
			// 
			// label8
			// 
			this.label8.AutoSize = true;
			this.label8.Location = new System.Drawing.Point(30, 250);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(35, 13);
			this.label8.TabIndex = 16;
			this.label8.Text = "Event";
			// 
			// chkSendFilePath
			// 
			this.chkSendFilePath.AutoSize = true;
			this.chkSendFilePath.Location = new System.Drawing.Point(149, 285);
			this.chkSendFilePath.Name = "chkSendFilePath";
			this.chkSendFilePath.Size = new System.Drawing.Size(95, 17);
			this.chkSendFilePath.TabIndex = 18;
			this.chkSendFilePath.Text = "Send File Path";
			this.chkSendFilePath.UseVisualStyleBackColor = true;
			// 
			// FrmPusherConfig
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(345, 392);
			this.Controls.Add(this.chkSendFilePath);
			this.Controls.Add(this.txtEvent);
			this.Controls.Add(this.label8);
			this.Controls.Add(this.txtMessage);
			this.Controls.Add(this.label7);
			this.Controls.Add(this.btnCancel);
			this.Controls.Add(this.btnOK);
			this.Controls.Add(this.chkAWSGzipFolder);
			this.Controls.Add(this.label6);
			this.Controls.Add(this.txtChannel);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.txtCluster);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.txtSecret);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.txtKey);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.txtAppID);
			this.Controls.Add(this.label1);
			this.Name = "FrmPusherConfig";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Cancel";
			this.Load += new System.EventHandler(this.FrmPusherConfig_Load);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox txtAppID;
		private System.Windows.Forms.TextBox txtKey;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.TextBox txtSecret;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.TextBox txtCluster;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.TextBox txtChannel;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.CheckBox chkAWSGzipFolder;
		private System.Windows.Forms.Button btnOK;
		private System.Windows.Forms.Button btnCancel;
		private System.Windows.Forms.TextBox txtMessage;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.TextBox txtEvent;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.CheckBox chkSendFilePath;
	}
}