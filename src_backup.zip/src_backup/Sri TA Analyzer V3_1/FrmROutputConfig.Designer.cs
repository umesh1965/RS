﻿
namespace SriTAAnalyzer
{
	partial class FrmOutputRSettings
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btnOK = new System.Windows.Forms.Button();
			this.btnCancel = new System.Windows.Forms.Button();
			this.groupOutputROld = new System.Windows.Forms.GroupBox();
			this.cmbTrendForLevels = new System.Windows.Forms.ComboBox();
			this.panelCalAvg = new System.Windows.Forms.Panel();
			this.txtLavg4End = new System.Windows.Forms.TextBox();
			this.txtLavg4Start = new System.Windows.Forms.TextBox();
			this.label30 = new System.Windows.Forms.Label();
			this.txtLavg3End = new System.Windows.Forms.TextBox();
			this.txtLavg3Start = new System.Windows.Forms.TextBox();
			this.label29 = new System.Windows.Forms.Label();
			this.txtLavg2End = new System.Windows.Forms.TextBox();
			this.txtLavg2Start = new System.Windows.Forms.TextBox();
			this.label28 = new System.Windows.Forms.Label();
			this.label27 = new System.Windows.Forms.Label();
			this.txtLavg1End = new System.Windows.Forms.TextBox();
			this.label26 = new System.Windows.Forms.Label();
			this.txtLavg1Start = new System.Windows.Forms.TextBox();
			this.label25 = new System.Windows.Forms.Label();
			this.chkBinaryLevels = new System.Windows.Forms.CheckBox();
			this.txtOutputRow = new System.Windows.Forms.TextBox();
			this.chkOutputOnlyR = new System.Windows.Forms.CheckBox();
			this.txtLevel = new System.Windows.Forms.TextBox();
			this.label6 = new System.Windows.Forms.Label();
			this.chkOutputMaster = new System.Windows.Forms.CheckBox();
			this.panelBSLevels = new System.Windows.Forms.Panel();
			this.radLavgSignal = new System.Windows.Forms.RadioButton();
			this.txtLavgSignal = new System.Windows.Forms.TextBox();
			this.radioBSLevel = new System.Windows.Forms.RadioButton();
			this.txtBSLevels = new System.Windows.Forms.TextBox();
			this.chkEnableBSSignal = new System.Windows.Forms.CheckBox();
			this.chkOutputOld = new System.Windows.Forms.CheckBox();
			this.chkOutputNew = new System.Windows.Forms.CheckBox();
			this.groupOutputROld.SuspendLayout();
			this.panelCalAvg.SuspendLayout();
			this.panelBSLevels.SuspendLayout();
			this.SuspendLayout();
			// 
			// btnOK
			// 
			this.btnOK.Location = new System.Drawing.Point(46, 500);
			this.btnOK.Name = "btnOK";
			this.btnOK.Size = new System.Drawing.Size(112, 31);
			this.btnOK.TabIndex = 30;
			this.btnOK.Text = "OK";
			this.btnOK.UseVisualStyleBackColor = true;
			this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
			// 
			// btnCancel
			// 
			this.btnCancel.Location = new System.Drawing.Point(191, 500);
			this.btnCancel.Name = "btnCancel";
			this.btnCancel.Size = new System.Drawing.Size(112, 31);
			this.btnCancel.TabIndex = 31;
			this.btnCancel.Text = "Cancel";
			this.btnCancel.UseVisualStyleBackColor = true;
			this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
			// 
			// groupOutputROld
			// 
			this.groupOutputROld.Controls.Add(this.cmbTrendForLevels);
			this.groupOutputROld.Controls.Add(this.panelCalAvg);
			this.groupOutputROld.Controls.Add(this.chkBinaryLevels);
			this.groupOutputROld.Controls.Add(this.txtOutputRow);
			this.groupOutputROld.Controls.Add(this.chkOutputOnlyR);
			this.groupOutputROld.Controls.Add(this.txtLevel);
			this.groupOutputROld.Controls.Add(this.label6);
			this.groupOutputROld.Location = new System.Drawing.Point(12, 46);
			this.groupOutputROld.Name = "groupOutputROld";
			this.groupOutputROld.Size = new System.Drawing.Size(324, 301);
			this.groupOutputROld.TabIndex = 80;
			this.groupOutputROld.TabStop = false;
			this.groupOutputROld.Text = "Output Format";
			// 
			// cmbTrendForLevels
			// 
			this.cmbTrendForLevels.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cmbTrendForLevels.FormattingEnabled = true;
			this.cmbTrendForLevels.Items.AddRange(new object[] {
            "AT Trend",
            "ST Trend",
            "ADX Trend",
            "Merged"});
			this.cmbTrendForLevels.Location = new System.Drawing.Point(23, 264);
			this.cmbTrendForLevels.Name = "cmbTrendForLevels";
			this.cmbTrendForLevels.Size = new System.Drawing.Size(121, 21);
			this.cmbTrendForLevels.TabIndex = 87;
			this.cmbTrendForLevels.SelectedIndexChanged += new System.EventHandler(this.cmbTrendForLevels_SelectedIndexChanged);
			// 
			// panelCalAvg
			// 
			this.panelCalAvg.Controls.Add(this.txtLavg4End);
			this.panelCalAvg.Controls.Add(this.txtLavg4Start);
			this.panelCalAvg.Controls.Add(this.label30);
			this.panelCalAvg.Controls.Add(this.txtLavg3End);
			this.panelCalAvg.Controls.Add(this.txtLavg3Start);
			this.panelCalAvg.Controls.Add(this.label29);
			this.panelCalAvg.Controls.Add(this.txtLavg2End);
			this.panelCalAvg.Controls.Add(this.txtLavg2Start);
			this.panelCalAvg.Controls.Add(this.label28);
			this.panelCalAvg.Controls.Add(this.label27);
			this.panelCalAvg.Controls.Add(this.txtLavg1End);
			this.panelCalAvg.Controls.Add(this.label26);
			this.panelCalAvg.Controls.Add(this.txtLavg1Start);
			this.panelCalAvg.Controls.Add(this.label25);
			this.panelCalAvg.Location = new System.Drawing.Point(23, 99);
			this.panelCalAvg.Name = "panelCalAvg";
			this.panelCalAvg.Size = new System.Drawing.Size(283, 153);
			this.panelCalAvg.TabIndex = 86;
			// 
			// txtLavg4End
			// 
			this.txtLavg4End.Location = new System.Drawing.Point(178, 124);
			this.txtLavg4End.Name = "txtLavg4End";
			this.txtLavg4End.Size = new System.Drawing.Size(80, 20);
			this.txtLavg4End.TabIndex = 80;
			// 
			// txtLavg4Start
			// 
			this.txtLavg4Start.Location = new System.Drawing.Point(82, 124);
			this.txtLavg4Start.Name = "txtLavg4Start";
			this.txtLavg4Start.Size = new System.Drawing.Size(80, 20);
			this.txtLavg4Start.TabIndex = 79;
			// 
			// label30
			// 
			this.label30.AutoSize = true;
			this.label30.Location = new System.Drawing.Point(24, 127);
			this.label30.Name = "label30";
			this.label30.Size = new System.Drawing.Size(37, 13);
			this.label30.TabIndex = 78;
			this.label30.Text = "Lavg4";
			// 
			// txtLavg3End
			// 
			this.txtLavg3End.Location = new System.Drawing.Point(178, 94);
			this.txtLavg3End.Name = "txtLavg3End";
			this.txtLavg3End.Size = new System.Drawing.Size(80, 20);
			this.txtLavg3End.TabIndex = 77;
			// 
			// txtLavg3Start
			// 
			this.txtLavg3Start.Location = new System.Drawing.Point(82, 94);
			this.txtLavg3Start.Name = "txtLavg3Start";
			this.txtLavg3Start.Size = new System.Drawing.Size(80, 20);
			this.txtLavg3Start.TabIndex = 76;
			// 
			// label29
			// 
			this.label29.AutoSize = true;
			this.label29.Location = new System.Drawing.Point(24, 97);
			this.label29.Name = "label29";
			this.label29.Size = new System.Drawing.Size(37, 13);
			this.label29.TabIndex = 75;
			this.label29.Text = "Lavg3";
			// 
			// txtLavg2End
			// 
			this.txtLavg2End.Location = new System.Drawing.Point(178, 61);
			this.txtLavg2End.Name = "txtLavg2End";
			this.txtLavg2End.Size = new System.Drawing.Size(80, 20);
			this.txtLavg2End.TabIndex = 74;
			// 
			// txtLavg2Start
			// 
			this.txtLavg2Start.Location = new System.Drawing.Point(82, 61);
			this.txtLavg2Start.Name = "txtLavg2Start";
			this.txtLavg2Start.Size = new System.Drawing.Size(80, 20);
			this.txtLavg2Start.TabIndex = 73;
			// 
			// label28
			// 
			this.label28.AutoSize = true;
			this.label28.Location = new System.Drawing.Point(24, 64);
			this.label28.Name = "label28";
			this.label28.Size = new System.Drawing.Size(37, 13);
			this.label28.TabIndex = 72;
			this.label28.Text = "Lavg2";
			// 
			// label27
			// 
			this.label27.AutoSize = true;
			this.label27.Location = new System.Drawing.Point(204, 8);
			this.label27.Name = "label27";
			this.label27.Size = new System.Drawing.Size(26, 13);
			this.label27.TabIndex = 71;
			this.label27.Text = "End";
			// 
			// txtLavg1End
			// 
			this.txtLavg1End.Location = new System.Drawing.Point(178, 29);
			this.txtLavg1End.Name = "txtLavg1End";
			this.txtLavg1End.Size = new System.Drawing.Size(80, 20);
			this.txtLavg1End.TabIndex = 70;
			// 
			// label26
			// 
			this.label26.AutoSize = true;
			this.label26.Location = new System.Drawing.Point(108, 8);
			this.label26.Name = "label26";
			this.label26.Size = new System.Drawing.Size(29, 13);
			this.label26.TabIndex = 69;
			this.label26.Text = "Start";
			// 
			// txtLavg1Start
			// 
			this.txtLavg1Start.Location = new System.Drawing.Point(82, 29);
			this.txtLavg1Start.Name = "txtLavg1Start";
			this.txtLavg1Start.Size = new System.Drawing.Size(80, 20);
			this.txtLavg1Start.TabIndex = 68;
			// 
			// label25
			// 
			this.label25.AutoSize = true;
			this.label25.Location = new System.Drawing.Point(24, 32);
			this.label25.Name = "label25";
			this.label25.Size = new System.Drawing.Size(37, 13);
			this.label25.TabIndex = 67;
			this.label25.Text = "Lavg1";
			// 
			// chkBinaryLevels
			// 
			this.chkBinaryLevels.AutoSize = true;
			this.chkBinaryLevels.Location = new System.Drawing.Point(201, 266);
			this.chkBinaryLevels.Name = "chkBinaryLevels";
			this.chkBinaryLevels.Size = new System.Drawing.Size(90, 17);
			this.chkBinaryLevels.TabIndex = 84;
			this.chkBinaryLevels.Text = "Binary Output";
			this.chkBinaryLevels.UseVisualStyleBackColor = true;
			// 
			// txtOutputRow
			// 
			this.txtOutputRow.Location = new System.Drawing.Point(164, 61);
			this.txtOutputRow.Name = "txtOutputRow";
			this.txtOutputRow.Size = new System.Drawing.Size(83, 20);
			this.txtOutputRow.TabIndex = 83;
			// 
			// chkOutputOnlyR
			// 
			this.chkOutputOnlyR.AutoSize = true;
			this.chkOutputOnlyR.Location = new System.Drawing.Point(18, 64);
			this.chkOutputOnlyR.Name = "chkOutputOnlyR";
			this.chkOutputOnlyR.Size = new System.Drawing.Size(122, 17);
			this.chkOutputOnlyR.TabIndex = 82;
			this.chkOutputOnlyR.Text = "R #Rows To Output";
			this.chkOutputOnlyR.UseVisualStyleBackColor = true;
			this.chkOutputOnlyR.CheckedChanged += new System.EventHandler(this.chkOutputOnlyR_CheckedChanged);
			// 
			// txtLevel
			// 
			this.txtLevel.Location = new System.Drawing.Point(164, 30);
			this.txtLevel.Name = "txtLevel";
			this.txtLevel.Size = new System.Drawing.Size(83, 20);
			this.txtLevel.TabIndex = 81;
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Location = new System.Drawing.Point(15, 30);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(33, 13);
			this.label6.TabIndex = 80;
			this.label6.Text = "Level";
			// 
			// chkOutputMaster
			// 
			this.chkOutputMaster.AutoSize = true;
			this.chkOutputMaster.Location = new System.Drawing.Point(30, 357);
			this.chkOutputMaster.Name = "chkOutputMaster";
			this.chkOutputMaster.Size = new System.Drawing.Size(112, 17);
			this.chkOutputMaster.TabIndex = 83;
			this.chkOutputMaster.Text = "Output Master File";
			this.chkOutputMaster.UseVisualStyleBackColor = true;
			// 
			// panelBSLevels
			// 
			this.panelBSLevels.Controls.Add(this.radLavgSignal);
			this.panelBSLevels.Controls.Add(this.txtLavgSignal);
			this.panelBSLevels.Controls.Add(this.radioBSLevel);
			this.panelBSLevels.Controls.Add(this.txtBSLevels);
			this.panelBSLevels.Location = new System.Drawing.Point(50, 407);
			this.panelBSLevels.Name = "panelBSLevels";
			this.panelBSLevels.Size = new System.Drawing.Size(243, 76);
			this.panelBSLevels.TabIndex = 85;
			// 
			// radLavgSignal
			// 
			this.radLavgSignal.AutoSize = true;
			this.radLavgSignal.Location = new System.Drawing.Point(19, 43);
			this.radLavgSignal.Name = "radLavgSignal";
			this.radLavgSignal.Size = new System.Drawing.Size(87, 17);
			this.radLavgSignal.TabIndex = 75;
			this.radLavgSignal.TabStop = true;
			this.radLavgSignal.Text = "Lavg1 Signal";
			this.radLavgSignal.UseVisualStyleBackColor = true;
			this.radLavgSignal.CheckedChanged += new System.EventHandler(this.radLavgSignal_CheckedChanged);
			// 
			// txtLavgSignal
			// 
			this.txtLavgSignal.Location = new System.Drawing.Point(118, 42);
			this.txtLavgSignal.Name = "txtLavgSignal";
			this.txtLavgSignal.Size = new System.Drawing.Size(106, 20);
			this.txtLavgSignal.TabIndex = 74;
			// 
			// radioBSLevel
			// 
			this.radioBSLevel.AutoSize = true;
			this.radioBSLevel.Location = new System.Drawing.Point(19, 12);
			this.radioBSLevel.Name = "radioBSLevel";
			this.radioBSLevel.Size = new System.Drawing.Size(89, 17);
			this.radioBSLevel.TabIndex = 73;
			this.radioBSLevel.TabStop = true;
			this.radioBSLevel.Text = "B&&S V Levels";
			this.radioBSLevel.UseVisualStyleBackColor = true;
			this.radioBSLevel.CheckedChanged += new System.EventHandler(this.radioBSLevel_CheckedChanged);
			// 
			// txtBSLevels
			// 
			this.txtBSLevels.Location = new System.Drawing.Point(118, 11);
			this.txtBSLevels.Name = "txtBSLevels";
			this.txtBSLevels.Size = new System.Drawing.Size(106, 20);
			this.txtBSLevels.TabIndex = 72;
			// 
			// chkEnableBSSignal
			// 
			this.chkEnableBSSignal.AutoSize = true;
			this.chkEnableBSSignal.Location = new System.Drawing.Point(30, 389);
			this.chkEnableBSSignal.Name = "chkEnableBSSignal";
			this.chkEnableBSSignal.Size = new System.Drawing.Size(83, 17);
			this.chkEnableBSSignal.TabIndex = 84;
			this.chkEnableBSSignal.Text = "B&&S Signals";
			this.chkEnableBSSignal.UseVisualStyleBackColor = true;
			this.chkEnableBSSignal.CheckedChanged += new System.EventHandler(this.chkEnableBSSignal_CheckedChanged);
			// 
			// chkOutputOld
			// 
			this.chkOutputOld.AutoSize = true;
			this.chkOutputOld.Location = new System.Drawing.Point(35, 16);
			this.chkOutputOld.Name = "chkOutputOld";
			this.chkOutputOld.Size = new System.Drawing.Size(112, 17);
			this.chkOutputOld.TabIndex = 86;
			this.chkOutputOld.Text = "Output Old Format";
			this.chkOutputOld.UseVisualStyleBackColor = true;
			// 
			// chkOutputNew
			// 
			this.chkOutputNew.AutoSize = true;
			this.chkOutputNew.Location = new System.Drawing.Point(179, 16);
			this.chkOutputNew.Name = "chkOutputNew";
			this.chkOutputNew.Size = new System.Drawing.Size(118, 17);
			this.chkOutputNew.TabIndex = 87;
			this.chkOutputNew.Text = "Output New Format";
			this.chkOutputNew.UseVisualStyleBackColor = true;
			// 
			// FrmOutputRSettings
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(347, 543);
			this.Controls.Add(this.chkOutputNew);
			this.Controls.Add(this.chkOutputOld);
			this.Controls.Add(this.panelBSLevels);
			this.Controls.Add(this.chkEnableBSSignal);
			this.Controls.Add(this.chkOutputMaster);
			this.Controls.Add(this.groupOutputROld);
			this.Controls.Add(this.btnCancel);
			this.Controls.Add(this.btnOK);
			this.Name = "FrmOutputRSettings";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "R File Output Settings";
			this.Load += new System.EventHandler(this.FrmROutputConfig_Load);
			this.groupOutputROld.ResumeLayout(false);
			this.groupOutputROld.PerformLayout();
			this.panelCalAvg.ResumeLayout(false);
			this.panelCalAvg.PerformLayout();
			this.panelBSLevels.ResumeLayout(false);
			this.panelBSLevels.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion
		private System.Windows.Forms.Button btnOK;
		private System.Windows.Forms.Button btnCancel;
		private System.Windows.Forms.GroupBox groupOutputROld;
		private System.Windows.Forms.Panel panelCalAvg;
		private System.Windows.Forms.TextBox txtLavg4End;
		private System.Windows.Forms.TextBox txtLavg4Start;
		private System.Windows.Forms.Label label30;
		private System.Windows.Forms.TextBox txtLavg3End;
		private System.Windows.Forms.TextBox txtLavg3Start;
		private System.Windows.Forms.Label label29;
		private System.Windows.Forms.TextBox txtLavg2End;
		private System.Windows.Forms.TextBox txtLavg2Start;
		private System.Windows.Forms.Label label28;
		private System.Windows.Forms.Label label27;
		private System.Windows.Forms.TextBox txtLavg1End;
		private System.Windows.Forms.Label label26;
		private System.Windows.Forms.TextBox txtLavg1Start;
		private System.Windows.Forms.Label label25;
		private System.Windows.Forms.CheckBox chkBinaryLevels;
		private System.Windows.Forms.TextBox txtOutputRow;
		private System.Windows.Forms.CheckBox chkOutputOnlyR;
		private System.Windows.Forms.TextBox txtLevel;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.ComboBox cmbTrendForLevels;
		private System.Windows.Forms.CheckBox chkOutputMaster;
		private System.Windows.Forms.Panel panelBSLevels;
		private System.Windows.Forms.RadioButton radLavgSignal;
		private System.Windows.Forms.TextBox txtLavgSignal;
		private System.Windows.Forms.RadioButton radioBSLevel;
		private System.Windows.Forms.TextBox txtBSLevels;
		private System.Windows.Forms.CheckBox chkEnableBSSignal;
		private System.Windows.Forms.CheckBox chkOutputOld;
		private System.Windows.Forms.CheckBox chkOutputNew;
	}
}