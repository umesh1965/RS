﻿using SriTAAnalyzerModel.Config;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SriTAAnalyzer
{
	public partial class FrmTASettings : Form
	{
		CalSettings config;
		public FrmTASettings()
		{
			InitializeComponent();
		}

		public FrmTASettings(CalSettings cal) : this()
		{
			config = cal;
			BindSetting(false);
		}

		void BindSetting(bool bFromControl)
		{
			int val = 0;
			if (bFromControl)
			{
				config.AT.Risk = int.TryParse(txtATRisk.Text, out val) ? val : 0;
				config.ST.Factor = int.TryParse(txtSTFactor.Text, out val) ? val : 0;
				config.ST.Pd = int.TryParse(txtSTPd.Text, out val) ? val : 0;
				config.ADX.Period = int.TryParse(txtADXPeriod.Text, out val) ? val : 0;
				config.AT.Enabled = chkATTrend.Checked;
				config.ST.Enabled = chkSTTrend.Checked;
				config.ADX.Enabled = chkADXTrend.Checked;
			}
			else
			{
				txtATRisk.Text = config.AT.Risk.ToString();
				txtSTFactor.Text = config.ST.Factor.ToString();
				txtSTPd.Text = config.ST.Pd.ToString();
				txtADXPeriod.Text = config.ADX.Period.ToString();

				chkATTrend.Checked = config.AT.Enabled;
				chkSTTrend.Checked = config.ST.Enabled;
				chkADXTrend.Checked = config.ADX.Enabled;
				groupATTrend.Enabled = chkATTrend.Checked;
				groupSTTrend.Enabled = chkSTTrend.Checked;
				groupADXTrend.Enabled = chkADXTrend.Checked;

			}
		}

		private void btnOK_Click(object sender, EventArgs e)
		{
			BindSetting(true);
			Close();
		}

		private void btnCancel_Click(object sender, EventArgs e)
		{
			Close();
		}

		private void chkATTrend_CheckedChanged(object sender, EventArgs e)
		{
			groupATTrend.Enabled = chkATTrend.Checked;
		}

		private void chkSTTrend_CheckedChanged(object sender, EventArgs e)
		{
			groupSTTrend.Enabled = chkSTTrend.Checked;
		}

		private void chkADXTrend_CheckedChanged(object sender, EventArgs e)
		{
			groupADXTrend.Enabled = chkADXTrend.Checked;
		}
	}
}
