﻿
namespace SriTAAnalyzer
{
	partial class FrmSignalSettings
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.chkEnableBSSignal = new System.Windows.Forms.CheckBox();
			this.groupBSSignal = new System.Windows.Forms.GroupBox();
			this.radLavgSignal = new System.Windows.Forms.RadioButton();
			this.txtLavgSignal = new System.Windows.Forms.TextBox();
			this.radioBSLevel = new System.Windows.Forms.RadioButton();
			this.txtBSLevels = new System.Windows.Forms.TextBox();
			this.groupTrendSignal = new System.Windows.Forms.GroupBox();
			this.chkL14 = new System.Windows.Forms.CheckBox();
			this.chkL13 = new System.Windows.Forms.CheckBox();
			this.chkL23 = new System.Windows.Forms.CheckBox();
			this.chkL34 = new System.Windows.Forms.CheckBox();
			this.chkL24 = new System.Windows.Forms.CheckBox();
			this.chkL4 = new System.Windows.Forms.CheckBox();
			this.chkL3 = new System.Windows.Forms.CheckBox();
			this.chkL2 = new System.Windows.Forms.CheckBox();
			this.chkL1 = new System.Windows.Forms.CheckBox();
			this.chkTrendSignals = new System.Windows.Forms.CheckBox();
			this.groupGenSignal = new System.Windows.Forms.GroupBox();
			this.label4 = new System.Windows.Forms.Label();
			this.cmbQtyCalculation = new System.Windows.Forms.ComboBox();
			this.txtMaxTimeGap = new System.Windows.Forms.TextBox();
			this.btnBrowseFolder = new System.Windows.Forms.Button();
			this.txtFolderPath = new System.Windows.Forms.TextBox();
			this.radioGenTrendSignal = new System.Windows.Forms.RadioButton();
			this.radGenBSSignal = new System.Windows.Forms.RadioButton();
			this.label3 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.chkGenSignal = new System.Windows.Forms.CheckBox();
			this.btnOK = new System.Windows.Forms.Button();
			this.btnCancel = new System.Windows.Forms.Button();
			this.txtAmount = new System.Windows.Forms.TextBox();
			this.lblAmount = new System.Windows.Forms.Label();
			this.groupBSSignal.SuspendLayout();
			this.groupTrendSignal.SuspendLayout();
			this.groupGenSignal.SuspendLayout();
			this.SuspendLayout();
			// 
			// chkEnableBSSignal
			// 
			this.chkEnableBSSignal.AutoSize = true;
			this.chkEnableBSSignal.Location = new System.Drawing.Point(34, 9);
			this.chkEnableBSSignal.Name = "chkEnableBSSignal";
			this.chkEnableBSSignal.Size = new System.Drawing.Size(83, 17);
			this.chkEnableBSSignal.TabIndex = 73;
			this.chkEnableBSSignal.Text = "B&&S Signals";
			this.chkEnableBSSignal.UseVisualStyleBackColor = true;
			this.chkEnableBSSignal.CheckedChanged += new System.EventHandler(this.chkEnableBSSignal_CheckedChanged);
			// 
			// groupBSSignal
			// 
			this.groupBSSignal.Controls.Add(this.radLavgSignal);
			this.groupBSSignal.Controls.Add(this.txtLavgSignal);
			this.groupBSSignal.Controls.Add(this.radioBSLevel);
			this.groupBSSignal.Controls.Add(this.txtBSLevels);
			this.groupBSSignal.Location = new System.Drawing.Point(26, 12);
			this.groupBSSignal.Name = "groupBSSignal";
			this.groupBSSignal.Size = new System.Drawing.Size(236, 90);
			this.groupBSSignal.TabIndex = 75;
			this.groupBSSignal.TabStop = false;
			// 
			// radLavgSignal
			// 
			this.radLavgSignal.AutoSize = true;
			this.radLavgSignal.Location = new System.Drawing.Point(17, 54);
			this.radLavgSignal.Name = "radLavgSignal";
			this.radLavgSignal.Size = new System.Drawing.Size(87, 17);
			this.radLavgSignal.TabIndex = 79;
			this.radLavgSignal.TabStop = true;
			this.radLavgSignal.Text = "Lavg1 Signal";
			this.radLavgSignal.UseVisualStyleBackColor = true;
			// 
			// txtLavgSignal
			// 
			this.txtLavgSignal.Location = new System.Drawing.Point(116, 53);
			this.txtLavgSignal.Name = "txtLavgSignal";
			this.txtLavgSignal.Size = new System.Drawing.Size(106, 20);
			this.txtLavgSignal.TabIndex = 78;
			// 
			// radioBSLevel
			// 
			this.radioBSLevel.AutoSize = true;
			this.radioBSLevel.Location = new System.Drawing.Point(17, 23);
			this.radioBSLevel.Name = "radioBSLevel";
			this.radioBSLevel.Size = new System.Drawing.Size(89, 17);
			this.radioBSLevel.TabIndex = 77;
			this.radioBSLevel.TabStop = true;
			this.radioBSLevel.Text = "B&&S V Levels";
			this.radioBSLevel.UseVisualStyleBackColor = true;
			// 
			// txtBSLevels
			// 
			this.txtBSLevels.Location = new System.Drawing.Point(116, 22);
			this.txtBSLevels.Name = "txtBSLevels";
			this.txtBSLevels.Size = new System.Drawing.Size(106, 20);
			this.txtBSLevels.TabIndex = 76;
			// 
			// groupTrendSignal
			// 
			this.groupTrendSignal.Controls.Add(this.chkL14);
			this.groupTrendSignal.Controls.Add(this.chkL13);
			this.groupTrendSignal.Controls.Add(this.chkL23);
			this.groupTrendSignal.Controls.Add(this.chkL34);
			this.groupTrendSignal.Controls.Add(this.chkL24);
			this.groupTrendSignal.Controls.Add(this.chkL4);
			this.groupTrendSignal.Controls.Add(this.chkL3);
			this.groupTrendSignal.Controls.Add(this.chkL2);
			this.groupTrendSignal.Controls.Add(this.chkL1);
			this.groupTrendSignal.Location = new System.Drawing.Point(26, 108);
			this.groupTrendSignal.Name = "groupTrendSignal";
			this.groupTrendSignal.Size = new System.Drawing.Size(236, 174);
			this.groupTrendSignal.TabIndex = 77;
			this.groupTrendSignal.TabStop = false;
			// 
			// chkL14
			// 
			this.chkL14.AutoSize = true;
			this.chkL14.Location = new System.Drawing.Point(17, 137);
			this.chkL14.Name = "chkL14";
			this.chkL14.Size = new System.Drawing.Size(62, 17);
			this.chkL14.TabIndex = 87;
			this.chkL14.Text = "L1 && L4";
			this.chkL14.UseVisualStyleBackColor = true;
			// 
			// chkL13
			// 
			this.chkL13.AutoSize = true;
			this.chkL13.Location = new System.Drawing.Point(127, 102);
			this.chkL13.Name = "chkL13";
			this.chkL13.Size = new System.Drawing.Size(62, 17);
			this.chkL13.TabIndex = 86;
			this.chkL13.Text = "L1 && L3";
			this.chkL13.UseVisualStyleBackColor = true;
			// 
			// chkL23
			// 
			this.chkL23.AutoSize = true;
			this.chkL23.Location = new System.Drawing.Point(17, 102);
			this.chkL23.Name = "chkL23";
			this.chkL23.Size = new System.Drawing.Size(62, 17);
			this.chkL23.TabIndex = 85;
			this.chkL23.Text = "L2 && L3";
			this.chkL23.UseVisualStyleBackColor = true;
			// 
			// chkL34
			// 
			this.chkL34.AutoSize = true;
			this.chkL34.Location = new System.Drawing.Point(127, 64);
			this.chkL34.Name = "chkL34";
			this.chkL34.Size = new System.Drawing.Size(62, 17);
			this.chkL34.TabIndex = 84;
			this.chkL34.Text = "L3 && L4";
			this.chkL34.UseVisualStyleBackColor = true;
			// 
			// chkL24
			// 
			this.chkL24.AutoSize = true;
			this.chkL24.Location = new System.Drawing.Point(17, 64);
			this.chkL24.Name = "chkL24";
			this.chkL24.Size = new System.Drawing.Size(62, 17);
			this.chkL24.TabIndex = 83;
			this.chkL24.Text = "L2 && L4";
			this.chkL24.UseVisualStyleBackColor = true;
			// 
			// chkL4
			// 
			this.chkL4.AutoSize = true;
			this.chkL4.Location = new System.Drawing.Point(184, 25);
			this.chkL4.Name = "chkL4";
			this.chkL4.Size = new System.Drawing.Size(38, 17);
			this.chkL4.TabIndex = 82;
			this.chkL4.Text = "L4";
			this.chkL4.UseVisualStyleBackColor = true;
			// 
			// chkL3
			// 
			this.chkL3.AutoSize = true;
			this.chkL3.Location = new System.Drawing.Point(127, 25);
			this.chkL3.Name = "chkL3";
			this.chkL3.Size = new System.Drawing.Size(38, 17);
			this.chkL3.TabIndex = 81;
			this.chkL3.Text = "L3";
			this.chkL3.UseVisualStyleBackColor = true;
			// 
			// chkL2
			// 
			this.chkL2.AutoSize = true;
			this.chkL2.Location = new System.Drawing.Point(71, 25);
			this.chkL2.Name = "chkL2";
			this.chkL2.Size = new System.Drawing.Size(38, 17);
			this.chkL2.TabIndex = 80;
			this.chkL2.Text = "L2";
			this.chkL2.UseVisualStyleBackColor = true;
			// 
			// chkL1
			// 
			this.chkL1.AutoSize = true;
			this.chkL1.Location = new System.Drawing.Point(17, 25);
			this.chkL1.Name = "chkL1";
			this.chkL1.Size = new System.Drawing.Size(38, 17);
			this.chkL1.TabIndex = 79;
			this.chkL1.Text = "L1";
			this.chkL1.UseVisualStyleBackColor = true;
			// 
			// chkTrendSignals
			// 
			this.chkTrendSignals.AutoSize = true;
			this.chkTrendSignals.Location = new System.Drawing.Point(35, 105);
			this.chkTrendSignals.Name = "chkTrendSignals";
			this.chkTrendSignals.Size = new System.Drawing.Size(91, 17);
			this.chkTrendSignals.TabIndex = 78;
			this.chkTrendSignals.Text = "Trend Signals";
			this.chkTrendSignals.UseVisualStyleBackColor = true;
			this.chkTrendSignals.CheckedChanged += new System.EventHandler(this.chkTrendSignals_CheckedChanged);
			// 
			// groupGenSignal
			// 
			this.groupGenSignal.Controls.Add(this.txtAmount);
			this.groupGenSignal.Controls.Add(this.lblAmount);
			this.groupGenSignal.Controls.Add(this.label4);
			this.groupGenSignal.Controls.Add(this.cmbQtyCalculation);
			this.groupGenSignal.Controls.Add(this.txtMaxTimeGap);
			this.groupGenSignal.Controls.Add(this.btnBrowseFolder);
			this.groupGenSignal.Controls.Add(this.txtFolderPath);
			this.groupGenSignal.Controls.Add(this.radioGenTrendSignal);
			this.groupGenSignal.Controls.Add(this.radGenBSSignal);
			this.groupGenSignal.Controls.Add(this.label3);
			this.groupGenSignal.Controls.Add(this.label2);
			this.groupGenSignal.Controls.Add(this.label1);
			this.groupGenSignal.Location = new System.Drawing.Point(288, 12);
			this.groupGenSignal.Name = "groupGenSignal";
			this.groupGenSignal.Size = new System.Drawing.Size(369, 270);
			this.groupGenSignal.TabIndex = 79;
			this.groupGenSignal.TabStop = false;
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(27, 177);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(149, 13);
			this.label4.TabIndex = 86;
			this.label4.Text = "Gen Latest Signal Text File for";
			// 
			// cmbQtyCalculation
			// 
			this.cmbQtyCalculation.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cmbQtyCalculation.FormattingEnabled = true;
			this.cmbQtyCalculation.Items.AddRange(new object[] {
            "Calculate Qty",
            "Fixed Qty"});
			this.cmbQtyCalculation.Location = new System.Drawing.Point(137, 99);
			this.cmbQtyCalculation.Name = "cmbQtyCalculation";
			this.cmbQtyCalculation.Size = new System.Drawing.Size(109, 21);
			this.cmbQtyCalculation.TabIndex = 85;
			this.cmbQtyCalculation.SelectedIndexChanged += new System.EventHandler(this.cmbQtyCalculation_SelectedIndexChanged);
			// 
			// txtMaxTimeGap
			// 
			this.txtMaxTimeGap.Location = new System.Drawing.Point(137, 62);
			this.txtMaxTimeGap.Name = "txtMaxTimeGap";
			this.txtMaxTimeGap.Size = new System.Drawing.Size(109, 20);
			this.txtMaxTimeGap.TabIndex = 84;
			// 
			// btnBrowseFolder
			// 
			this.btnBrowseFolder.Location = new System.Drawing.Point(336, 24);
			this.btnBrowseFolder.Name = "btnBrowseFolder";
			this.btnBrowseFolder.Size = new System.Drawing.Size(27, 22);
			this.btnBrowseFolder.TabIndex = 83;
			this.btnBrowseFolder.Text = "...";
			this.btnBrowseFolder.UseVisualStyleBackColor = true;
			this.btnBrowseFolder.Click += new System.EventHandler(this.btnBrowseFolder_Click);
			// 
			// txtFolderPath
			// 
			this.txtFolderPath.Location = new System.Drawing.Point(137, 25);
			this.txtFolderPath.Name = "txtFolderPath";
			this.txtFolderPath.Size = new System.Drawing.Size(199, 20);
			this.txtFolderPath.TabIndex = 82;
			// 
			// radioGenTrendSignal
			// 
			this.radioGenTrendSignal.AutoSize = true;
			this.radioGenTrendSignal.Location = new System.Drawing.Point(210, 208);
			this.radioGenTrendSignal.Name = "radioGenTrendSignal";
			this.radioGenTrendSignal.Size = new System.Drawing.Size(90, 17);
			this.radioGenTrendSignal.TabIndex = 5;
			this.radioGenTrendSignal.TabStop = true;
			this.radioGenTrendSignal.Text = "Trend Signals";
			this.radioGenTrendSignal.UseVisualStyleBackColor = true;
			// 
			// radGenBSSignal
			// 
			this.radGenBSSignal.AutoSize = true;
			this.radGenBSSignal.Location = new System.Drawing.Point(80, 209);
			this.radGenBSSignal.Name = "radGenBSSignal";
			this.radGenBSSignal.Size = new System.Drawing.Size(82, 17);
			this.radGenBSSignal.TabIndex = 4;
			this.radGenBSSignal.TabStop = true;
			this.radGenBSSignal.Text = "B&&S Signals";
			this.radGenBSSignal.UseVisualStyleBackColor = true;
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(27, 105);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(78, 13);
			this.label3.TabIndex = 2;
			this.label3.Text = "Qty Calculation";
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(27, 65);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(101, 13);
			this.label2.TabIndex = 1;
			this.label2.Text = "Max Time Gap(Sec)";
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(27, 28);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(36, 13);
			this.label1.TabIndex = 0;
			this.label1.Text = "Folder";
			// 
			// chkGenSignal
			// 
			this.chkGenSignal.AutoSize = true;
			this.chkGenSignal.Location = new System.Drawing.Point(299, 10);
			this.chkGenSignal.Name = "chkGenSignal";
			this.chkGenSignal.Size = new System.Drawing.Size(102, 17);
			this.chkGenSignal.TabIndex = 80;
			this.chkGenSignal.Text = "Gen Signal Text";
			this.chkGenSignal.UseVisualStyleBackColor = true;
			this.chkGenSignal.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
			// 
			// btnOK
			// 
			this.btnOK.Location = new System.Drawing.Point(452, 294);
			this.btnOK.Name = "btnOK";
			this.btnOK.Size = new System.Drawing.Size(94, 27);
			this.btnOK.TabIndex = 81;
			this.btnOK.Text = "OK";
			this.btnOK.UseVisualStyleBackColor = true;
			this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
			// 
			// btnCancel
			// 
			this.btnCancel.Location = new System.Drawing.Point(563, 294);
			this.btnCancel.Name = "btnCancel";
			this.btnCancel.Size = new System.Drawing.Size(94, 27);
			this.btnCancel.TabIndex = 82;
			this.btnCancel.Text = "Cancel";
			this.btnCancel.UseVisualStyleBackColor = true;
			this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
			// 
			// txtAmount
			// 
			this.txtAmount.Location = new System.Drawing.Point(210, 136);
			this.txtAmount.Name = "txtAmount";
			this.txtAmount.Size = new System.Drawing.Size(90, 20);
			this.txtAmount.TabIndex = 88;
			// 
			// lblAmount
			// 
			this.lblAmount.AutoSize = true;
			this.lblAmount.Location = new System.Drawing.Point(137, 139);
			this.lblAmount.Name = "lblAmount";
			this.lblAmount.Size = new System.Drawing.Size(43, 13);
			this.lblAmount.TabIndex = 87;
			this.lblAmount.Text = "Amount";
			// 
			// FrmSignalSettings
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(681, 335);
			this.Controls.Add(this.btnCancel);
			this.Controls.Add(this.btnOK);
			this.Controls.Add(this.chkGenSignal);
			this.Controls.Add(this.groupGenSignal);
			this.Controls.Add(this.chkTrendSignals);
			this.Controls.Add(this.groupTrendSignal);
			this.Controls.Add(this.chkEnableBSSignal);
			this.Controls.Add(this.groupBSSignal);
			this.Name = "FrmSignalSettings";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Signal Setting";
			this.groupBSSignal.ResumeLayout(false);
			this.groupBSSignal.PerformLayout();
			this.groupTrendSignal.ResumeLayout(false);
			this.groupTrendSignal.PerformLayout();
			this.groupGenSignal.ResumeLayout(false);
			this.groupGenSignal.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion
		private System.Windows.Forms.CheckBox chkEnableBSSignal;
		private System.Windows.Forms.GroupBox groupBSSignal;
		private System.Windows.Forms.RadioButton radLavgSignal;
		private System.Windows.Forms.TextBox txtLavgSignal;
		private System.Windows.Forms.RadioButton radioBSLevel;
		private System.Windows.Forms.TextBox txtBSLevels;
		private System.Windows.Forms.GroupBox groupTrendSignal;
		private System.Windows.Forms.CheckBox chkTrendSignals;
		private System.Windows.Forms.CheckBox chkL4;
		private System.Windows.Forms.CheckBox chkL3;
		private System.Windows.Forms.CheckBox chkL2;
		private System.Windows.Forms.CheckBox chkL1;
		private System.Windows.Forms.CheckBox chkL24;
		private System.Windows.Forms.CheckBox chkL13;
		private System.Windows.Forms.CheckBox chkL23;
		private System.Windows.Forms.CheckBox chkL34;
		private System.Windows.Forms.CheckBox chkL14;
		private System.Windows.Forms.GroupBox groupGenSignal;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.RadioButton radioGenTrendSignal;
		private System.Windows.Forms.RadioButton radGenBSSignal;
		private System.Windows.Forms.Button btnBrowseFolder;
		private System.Windows.Forms.TextBox txtFolderPath;
		private System.Windows.Forms.TextBox txtMaxTimeGap;
		private System.Windows.Forms.ComboBox cmbQtyCalculation;
		private System.Windows.Forms.CheckBox chkGenSignal;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Button btnOK;
		private System.Windows.Forms.Button btnCancel;
		private System.Windows.Forms.TextBox txtAmount;
		private System.Windows.Forms.Label lblAmount;
	}
}